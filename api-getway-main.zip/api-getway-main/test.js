const crypto = require('crypto');
const axios = require('axios');

const generateSignature = (data, key) => {
  const hmac = crypto.createHmac('sha256', key);
  hmac.update(data);
  return hmac.digest('hex');
};
const publicKey = '9298f2919535317390f78f30078cd16a09a8619eed8996b0e2c48525d50cfe19';
const privateKey = 'c715e2cd-395a-431e-b6b9-fc9d5f9288b2';
const timestamp = new Date().getTime().toString();
const signature = generateSignature(timestamp, privateKey);

const headers = {
  'Content-Type': 'application/json',
  'timestamp':timestamp,
  'signature':signature,
  'dpc-api-key': publicKey,
};
const body = {};
const apiUrl = 'https://api.wh.dev.dp-cargo.com/partner/awbs';


axios
  .get(apiUrl, { headers })
  .then(async response => {
    console.log(response);
    return true;
  })
  .catch(async error => {
    console.log(error);
    return false;
  });
