import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class GeneralConfigs extends Model {
  id: number;
  config_key: string;
  config_value: string;
  isDelete: boolean;

  static tableName = 'general_configs'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
}

export type generalConfigShape = ModelObject<GeneralConfigs>;
