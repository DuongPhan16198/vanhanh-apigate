import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
export class CustomerTrackingType extends Model {
  id: number;
  customerId: number;
  trackingTypeId: number;
  price: number;

  static tableName = 'customer_tracking_type_prices';
  static idColumn = 'id';

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
}

export type CustomerTrackingTypeShape = ModelObject<CustomerTrackingType>;
