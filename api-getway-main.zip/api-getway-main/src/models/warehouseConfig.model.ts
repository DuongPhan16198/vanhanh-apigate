import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class WarehouseConfig extends Model {
  id: number;
  name: string;
  is_deleted: boolean;
  password: string;
  createdAt: Date;
  updatedAt: Date;

  static tableName = 'warehouse_configs'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
}

export type warehouseConfigShape = ModelObject<WarehouseConfig>;
