import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { Tracking } from './tracking.model';
import { Box } from './box.model';
import { Customer } from './customer.model.';
import { Users } from './users.model';
export class CustomerTransactionLogs extends Model {
  id: number;
  customerTransactionType: string;
  customerTransactionNote: number;
  customerTransactionMoney: number;
  customerTransactionDate: Date;
  customerTransactionBalance: number;
  createdAt: Date;
  updatedAt: Date;
  createdById: Date;
  updatedById: Date;
  status: string;
  bank_account: string;
  image: string;

  static tableName = 'customer_transaction_logs'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static getTableName() {
    return this.tableName;
  }

  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
    customer: {
      relation: Model.ManyToManyRelation,
      modelClass: Customer,
      join: {
        from: 'customer_transaction_logs.id',
        through: {
          from: 'customer_transaction_logs_customer_id_links.customer_transaction_log_id',
          to: 'customer_transaction_logs_customer_id_links.customer_id',
        },
        to: 'customers.id',
      },
    },
    employee: {
      relation: Model.HasOneRelation,
      modelClass: Users,
      join: {
        from: 'customer_transaction_logs.created_by_id',
        to: 'up_users.id',
      },
      modify: builder => {
        builder.select('id', 'phone', 'email', 'fullname');
      },
    },
  });
}

export type CustomerTransactionLogsShape = ModelObject<CustomerTransactionLogs>;
