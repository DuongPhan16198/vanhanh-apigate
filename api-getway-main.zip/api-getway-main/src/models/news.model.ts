import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { NewsCategory } from './categories.model';
export enum NewsStatus {
  ACTIVE,
  DELETED,
}

export class News extends Model {
  id: number;
  category?: number;
  title?: string;
  thumbnail?: string;
  content?: string;
  status: number;
  createdAt: Date;
  updatedAt: Date;
  slug: string;
  description: string;

  static tableName = 'news'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
    categories: {
      relation: Model.ManyToManyRelation,
      modelClass: NewsCategory,
      join: {
        from: 'news.id',
        through: {
          from: 'news_category_links.news_id',
          to: 'news_category_links.category_id',
        },
        to: 'news_categories.id',
      },
    },
  });
}

export type NewsShape = ModelObject<News>;
