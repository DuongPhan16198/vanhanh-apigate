import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
export class TrackingCustomerLinks extends Model {
  id: number;
  tracking_id: number;
  customer_id: number;

  static tableName = 'trackings_customer_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

}

export type TrackingCustomerLinksShape = ModelObject<TrackingCustomerLinks>;
