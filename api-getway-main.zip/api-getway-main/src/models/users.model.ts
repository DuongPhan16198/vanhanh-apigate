import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { User } from '@interfaces/users.interface';
import { Customer } from './customer.model.';
import { BusinessPartner } from './businessPartner.model';
import { WarehouseConfig } from './warehouseConfig.model';
import { UpRole } from './upRole.model';
export class Users extends Model {
  id: number;
  username: string;
  department: string;
  role: any;
  customerName: string;
  email: string;
  password: string;
  manager: string;
  isRemove: boolean;
  customerId?: number;
  customer: Customer;
  warehouseVN?: WarehouseConfig;
  type: string;
  saleOfCustomer?: Customer[];
  confirmed: boolean;
  blocked: boolean;
  phone: string;
  fullname: string;
  businessPartner: any;
  createdById: number;
  resetPasswordToken: string;
  avatarUrl: string;

  static tableName = 'up_users'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
    customer: {
      relation: Model.ManyToManyRelation,
      modelClass: Customer,
      join: {
        from: 'up_users.id',
        through: {
          from: 'up_users_customer_links.user_id',
          to: 'up_users_customer_links.customer_id',
        },
        to: 'customers.id',
      },
      modify: builder => {
        builder
          .select(
            'customers.id',
            'customers.name',
            'customers.nick_name',
            'customers.shipping_cost',
            'customers.email',
            'customers.id_customer as code',
            'customers.gender',
            'customers.birthday',
            'customers.balance',
            'customers.creditAmount',
            'customers.address'
          )
          .leftJoinRelated('boxStag');
      },
    },
    businessPartner: {
      relation: Model.ManyToManyRelation,
      modelClass: BusinessPartner,
      join: {
        from: 'up_users.id',
        through: {
          from: 'up_users_business_partner_links.user_id',
          to: 'up_users_business_partner_links.business_partner_id',
        },
        to: 'business_partners.id',
      },
    },
    warehouseVN: {
      relation: Model.ManyToManyRelation,
      modelClass: WarehouseConfig,
      join: {
        from: 'up_users.id',
        through: {
          from: 'up_users_warehouse_vn_links.user_id',
          to: 'up_users_warehouse_vn_links.warehouse_config_id',
        },
        to: 'warehouse_configs.id',
      },
      modify: builder => {
        builder.select('warehouse_configs.id', 'warehouse_configs.name');
      },
    },
    saleOfCustomer: {
      relation: Model.ManyToManyRelation,
      modelClass: Customer,
      join: {
        from: 'up_users.id',
        through: {
          from: 'customers_sale_links.user_id',
          to: 'customers_sale_links.customer_id',
        },
        to: 'customers.id',
      },
    },
    role: {
      relation: Model.ManyToManyRelation,
      modelClass: UpRole,
      join: {
        from: 'up_users.id',
        through: {
          from: 'up_users_role_links.user_id',
          to: 'up_users_role_links.role_id',
        },
        to: 'up_roles.id',
      },
      modify: builder => {
        builder.select('up_roles.id', 'up_roles.name', 'up_roles.type', 'up_roles.is_delete').withGraphFetched('actions');
      },
    },
  });

  //TODO: set relationship cho user vs customer
  // login đẩy thểm cútomerId trong token
  // trong trackingSerive thêm customerId vào
}

export type UsersShape = ModelObject<Users>;
