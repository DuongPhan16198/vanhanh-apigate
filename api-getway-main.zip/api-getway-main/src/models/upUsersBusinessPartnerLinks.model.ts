import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class UpUsersBusinessPartnerLinks extends Model {
  id: number;
  user_id: number;
  business_partner_id: number;

  static tableName = 'up_users_business_partner_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
}

export type UpUsersBusinessPartnerLinksShape = ModelObject<UpUsersBusinessPartnerLinks>;
