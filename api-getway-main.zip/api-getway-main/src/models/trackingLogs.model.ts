import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { Users } from './users.model';
export class TrackingLogs extends Model {
  id: number;
  actionTime: Date;
  actionType: string;
  extraData: string;
  trackingCode: string;
  changedField: string;
  createdAt: Date;
  updatedAt: Date;
  createdById: number;
  updatedById: number;
  trackingId: number;

  static tableName = 'tracking_logs'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
    createdBy: {
      relation: Model.HasOneRelation,
      modelClass: Users,
      join: {
        from: 'tracking_logs.created_by_id',
        to: 'up_users.id',
      },
      modify: builder => {
        builder.select('id', 'phone', 'email', 'fullname');
      },
    },
  });
}

export type TrackingLogsShape = ModelObject<TrackingLogs>;
