import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class UserCustomerLinks extends Model {
  id: number;
  customer_id: number;
  user_id: number;

  static tableName = 'up_users_customer_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

}

export type UserCustomerShape = ModelObject<UserCustomerLinks>;
