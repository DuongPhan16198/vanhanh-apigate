import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
export class Warehouse extends Model {
  id: number;
  name: string;
  address: string;
  tel: string;
  country: string;
  uid: string;
  createdAt: Date;
  updatedAt: Date;

  static tableName = 'warehouses'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

}

export type warehouseShape = ModelObject<Warehouse>;
