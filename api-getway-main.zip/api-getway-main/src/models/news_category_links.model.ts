import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class NewsCategoryLinks extends Model {
  id: number;
  news_id: number;
  category_id: number;

  static tableName = 'news_category_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

}

export type NewsCategoryLinksShape = ModelObject<NewsCategoryLinks>;
