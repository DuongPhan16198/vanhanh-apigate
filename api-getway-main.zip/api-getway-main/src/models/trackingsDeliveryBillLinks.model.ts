import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class TrackingsDeliveryBillLinks extends Model {
  id: number;
  tracking_id: number;
  delivery_bill_id: number;

  static tableName = 'trackings_delivery_bill_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
}

export type TrackingsDeliveryBillLinksShape = ModelObject<TrackingsDeliveryBillLinks>;
