import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { Box } from './box.model';
import { Awb } from './awb.model';
import { TrackingType } from './trackingType.model';
import { TrackingsTrackingTypeLinks } from './trackingsTrackingTypeLinks.model';
import { Customer } from './customer.model.';
import { BusinessPartner } from './businessPartner.model';
import { Warehouse } from './warehouse.model';
import { WarehouseConfig } from './warehouseConfig.model';
import { Users } from './users.model';
import { DeliveryBill } from './deliveryBill.model';
import { TrackingStatusLogs } from './trackingStatusLog.model';
import { UpUsers } from './upUsers.model';

export class Tracking extends Model {
  id!: number;
  code: string;
  trackingType!: string;
  description!: string;
  businessPartner!: string;
  status!: string;
  importDate!: Date;
  repackDate!: Date;
  packedDate!: Date;
  exportDate!: Date;
  arrivalDate!: Date;
  completedAt!: Date;
  exploitedDate!: Date;
  invoicedDate!: Date;
  checkingDate!: Date;
  isRepack!: boolean;
  box!: Box;
  awb!: Awb;
  warehouse!: string;
  customer!: any;
  isSplit!: boolean;
  parentTracking!: Tracking;
  isDeleted!: boolean;
  imageUrl!: string;
  note!: string;
  exploitStatus!: string;
  shippingFee!: number;
  trackingMiningWeight!: number;
  trackingCalculationWeight!: number;
  trackingBarrelCoefficient!: number;
  trackingShippingCost!: number;
  trackingShippingFee!: number;
  trackingSurcharge!: number;
  trackingDeliveryFee!: number;
  trackingOtherFee!: number;
  trackingDiscountAmount: number;
  trackingTotalMoney!: number;
  weight!: number;
  tracking!: number;
  deliveryBill!: string;
  trackingAmount!: number;
  orderId!: string;
  warehouseVn!: number;
  optionalImage!: string;
  exploitedBy!: string;
  price!: number;
  sale!: number;
  uid: number;
  createdAt: Date;
  updatedAt: Date;
  isRenamed: boolean;
  ticketResponse: string;
  whTrackingId: number;
  vnPackedDate: Date;
  vnImportDate: Date;
  vnExportDate: Date;
  vnPackedById: number;

  static tableName = 'trackings'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
    box: {
      relation: Model.ManyToManyRelation,
      modelClass: Box,
      join: {
        from: 'trackings.id',
        through: {
          from: 'trackings_box_links.tracking_id',
          to: 'trackings_box_links.box_id',
        },
        to: 'boxes.id',
      },
      modify: builder => {
        builder.select('boxes.code', 'boxes.id');
      },
    },
    trackingType: {
      relation: Model.ManyToManyRelation,
      modelClass: TrackingType,
      join: {
        from: 'trackings.id',
        through: {
          modelClass: TrackingsTrackingTypeLinks,
          from: 'trackings_tracking_type_links.tracking_id',
          to: 'trackings_tracking_type_links.tracking_type_id',
        },
        to: 'tracking_types.id',
      },
      modify: builder => {
        builder.select('tracking_types.id', 'tracking_types.name', 'tracking_types.color');
      },
    },
    boxTrackingType: {
      relation: Model.ManyToManyRelation,
      modelClass: TrackingType,
      join: {
        from: 'trackings.id',
        through: {
          modelClass: TrackingsTrackingTypeLinks,
          from: 'trackings_tracking_type_links.tracking_id',
          to: 'trackings_tracking_type_links.tracking_type_id',
        },
        to: 'tracking_types.id',
      },
      modify: builder => {
        builder.select('tracking_types.id', 'tracking_types.name');
      },
    },
    boxCustomer: {
      relation: Model.ManyToManyRelation,
      modelClass: Customer,
      join: {
        from: 'trackings.id',
        through: {
          from: 'trackings_customer_links.tracking_id',
          to: 'trackings_customer_links.customer_id',
        },
        to: 'customers.id',
      },
      modify: builder => {
        builder.select('customers.id', 'customers.name', 'customers.nick_name', 'customers.shipping_cost').leftJoinRelated('boxStag');
      },
    },
    customer: {
      relation: Model.ManyToManyRelation,
      modelClass: Customer,
      join: {
        from: 'trackings.id',
        through: {
          from: 'trackings_customer_links.tracking_id',
          to: 'trackings_customer_links.customer_id',
        },
        to: 'customers.id',
      },
      modify: builder => {
        builder
          .select(
            'customers.id',
            'customers.name',
            'customers.nick_name',
            'customers.shipping_cost',
            'customers.email',
            'customers.id_customer',
            'customers.address',
            'customers.phone',
            'customers.is_subcribe_to_fcm_notification',
            'customers.is_subcribe_to_email_notification',
          )
          .leftJoinRelated('boxStag');
      },
    },
    awb: {
      relation: Model.ManyToManyRelation,
      modelClass: Awb,
      join: {
        from: 'trackings.id',
        through: {
          from: 'trackings_awb_links.tracking_id',
          to: 'trackings_awb_links.awb_id',
        },
        to: 'awbs.id',
      },
      modify: builder => {
        builder.select('awbs.code', 'awbs.id');
      },
    },
    businessPartner: {
      relation: Model.ManyToManyRelation,
      modelClass: BusinessPartner,
      join: {
        from: 'trackings.id',
        through: {
          from: 'trackings_business_partner_links.tracking_id',
          to: 'trackings_business_partner_links.business_partner_id',
        },
        to: 'business_partners.id',
      },
      modify: builder => {
        builder.select('business_partners.id', 'business_partners.name');
      },
    },
    boxBusinessPartner: {
      relation: Model.ManyToManyRelation,
      modelClass: BusinessPartner,
      join: {
        from: 'trackings.id',
        through: {
          from: 'trackings_business_partner_links.tracking_id',
          to: 'trackings_business_partner_links.business_partner_id',
        },
        to: 'business_partners.id',
      },
      modify: builder => {
        builder.select('business_partners.id', 'business_partners.name', 'business_partners.email');
      },
    },
    warehouse: {
      relation: Model.ManyToManyRelation,
      modelClass: Warehouse,
      join: {
        from: 'trackings.id',
        through: {
          from: 'trackings_warehouse_links.tracking_id',
          to: 'trackings_warehouse_links.warehouse_id',
        },
        to: 'warehouses.id',
      },
      modify: builder => {
        builder.select('warehouses.id', 'warehouses.name');
      },
    },
    warehouseVn: {
      relation: Model.ManyToManyRelation,
      modelClass: WarehouseConfig,
      join: {
        from: 'trackings.id',
        through: {
          from: 'trackings_warehouse_vn_links.tracking_id',
          to: 'trackings_warehouse_vn_links.warehouse_config_id',
        },
        to: 'warehouse_configs.id',
      },
      modify: builder => {
        builder.select('warehouse_configs.id', 'warehouse_configs.name');
      },
    },
    exploitedBy: {
      relation: Model.ManyToManyRelation,
      modelClass: Users,
      join: {
        from: 'trackings.id',
        through: {
          from: 'trackings_exploited_by_links.tracking_id',
          to: 'trackings_exploited_by_links.user_id',
        },
        to: 'up_users.id',
      },
      modify: builder => {
        builder.select('up_users.id', 'up_users.fullname', 'up_users.username', 'up_users.email', 'up_users.phone');
      },
    },
    deliveryBill: {
      relation: Model.ManyToManyRelation,
      modelClass: DeliveryBill,
      join: {
        from: 'trackings.id',
        through: {
          from: 'trackings_delivery_bill_links.tracking_id',
          to: 'trackings_delivery_bill_links.delivery_bill_id',
        },
        to: 'delivery_bills.id',
      },
      modify: builder => {
        builder.select('delivery_bills.id', 'delivery_bills.code', 'delivery_bills.created_at');
      },
    },
    sale: {
      relation: Model.ManyToManyRelation,
      modelClass: Users,
      join: {
        from: 'trackings.id',
        through: {
          from: 'trackings_sale_links.tracking_id',
          to: 'trackings_sale_links.user_id',
        },
        to: 'up_users.id',
      },
      modify: builder => {
        builder.select('up_users.id', 'up_users.username', 'up_users.email', 'up_users.phone', 'up_users.fullname', 'up_users.avatar_url');
      },
    },
    statusLogs: {
      relation: Model.HasManyRelation,
      modelClass: TrackingStatusLogs,
      join: {
        from: 'trackings.id',
        to: 'tracking_status_logs.tracking_id',
      },
    },
    vnPackedBy: {
      relation: Model.HasOneRelation,
      modelClass: UpUsers,
      join: {
        from: 'trackings.vn_packed_by_id',
        to: 'up_users.id',
      },
      modify: builder => {
        builder.select('up_users.id', 'up_users.username', 'up_users.email', 'up_users.phone', 'up_users.fullname', 'up_users.avatar_url');
      },
    },
  });
}

export type TrackingShape = ModelObject<Tracking>;
