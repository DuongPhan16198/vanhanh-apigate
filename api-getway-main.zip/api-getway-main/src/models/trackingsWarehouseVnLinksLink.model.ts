import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class TrackingsWarehouseVnLinksLink extends Model {
  id: number;
  tracking_id: number;
  warehouse_config_id: number;

  static tableName = 'trackings_warehouse_vn_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

}

export type TrackingsWarehouseVnLinksLinkShape = ModelObject<TrackingsWarehouseVnLinksLink>;
