import { Model, ModelObject, snakeCaseMappers } from 'objection';
export enum VnDeliveryUnitStatus {
  ACTIVE,
  DELETED,
}

export class VnDeliveryUnits extends Model {
  id: number;
  name: string;
  code: string;
  logoUrl: string;
  status: number;

  static tableName = 'vn_delivery_units'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
}

export type DeliverUnitShape = ModelObject<VnDeliveryUnits>;
