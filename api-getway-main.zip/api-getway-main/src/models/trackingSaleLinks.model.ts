import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
export class TrackingSaleLinks extends Model {
  id: number;
  tracking_id: number;
  user_id: number;

  static tableName = 'trackings_sale_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

}

export type TrackingSaleLinksShape = ModelObject<TrackingSaleLinks>;
