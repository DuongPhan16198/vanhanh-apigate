import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { Box } from './box.model';
import { CustomerBusinessPartnerLinks } from './customerBusinessPartnerLinks.model';
import { Customer } from './customer.model.';
export class BusinessPartner extends Model {
  id: number;
  name: string;
  address: string;
  phone: string;
  email: string;
  boxes: Box[];
  customers: string;
  deliveryBills: string;
  uid: string;
  isSyncing: boolean;
  syncStatus: string;
  message: string;
  lastSync: Date;

  static tableName = 'business_partners'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
    customerIn: {
      relation: Model.ManyToManyRelation,
      modelClass: Customer,
      join: {
        from: 'business_partners.id',
        through: {
          from: 'customers_business_partner_links.business_partner_id',
          to: 'customers_business_partner_links.customer_id',
        },
        to: 'customers.id',
      },
    },
  });
}

export type BusinessPartnerShape = ModelObject<BusinessPartner>;
