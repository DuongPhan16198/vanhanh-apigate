import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';

export class BoxWarehouseVnLinks extends Model {
  id: number;
  box_id: number;
  warehouse_config_id: number;

  static tableName = 'boxes_warehouse_vn_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({});
}

export type BoxShape = ModelObject<BoxWarehouseVnLinks>;
