import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { Permission } from './permission.model';

export class Role extends Model {
  id: number;
  name: string;
  description: string;
  type: string;
  

  static tableName = 'up_roles'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
    actions: {
      relation: Model.ManyToManyRelation,
      modelClass: Permission,
      join: {
        from: 'up_roles.id',
        through: {
          from: 'up_permissions_role_links.role_id',
          to: 'up_permissions_role_links.permission_id',
        },
        to: 'up_permissions.id',
      },
    },
  });
}

export type RoleShape = ModelObject<Role>;
