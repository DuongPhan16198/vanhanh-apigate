import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { Tracking } from './tracking.model';
import { Box } from './box.model';

export class Awb extends Model {
  id: number;
  code: string;
  weight: number;
  status: string;
  trackingQuantity: number;
  boxQuantity: number;
  completedAt: Date;
  flightDate: Date;
  arrivalDate: Date;
  boxes: Box[];
  trackings: Tracking[];
  warehouse: String;
  receiverInfo: string;
  flightInfo: string;
  exploitStatus: string;
  deliveryPartner: string;
  flyingWeight: number;
  clearanceWeight: number;
  flyingFee: number;
  clearanceFee: number;
  exchangeRate: number;
  otherFee: string;
  amount: number;
  totalFlyingFee: number;
  totalClearanceFee: number;
  totalFee: number;
  totalCalculationWeight: number;
  uid: string;
  cost: number;
  sync_status: string;

  static tableName = 'awbs'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
    tracking: {
      relation: Model.ManyToManyRelation,
      modelClass: Tracking,
      join: {
        from: 'awbs.id',
        through: {
          from: 'trackings_awb_links.awb_id',
          to: 'trackings_awb_links.tracking_id',
        },
        to: 'trackings.id',
      },
      modify: builder => {
        builder
          .select(
            'trackings.id',
            'trackings.code',
            'trackings.tracking_total_money',
            'trackings.tracking_calculation_weight',
            'trackings.tracking_mining_weight',
            'trackings.exploit_status',
          )
          .where('trackings.is_deleted', false);
      },
    },
    box: {
      relation: Model.ManyToManyRelation,
      modelClass: Box,
      join: {
        from: 'awbs.id',
        through: {
          from: 'boxes_awb_links.awb_id',
          to: 'boxes_awb_links.box_id',
        },
        to: 'boxes.id',
      },
      modify: builder => {
        builder.select().leftJoinRelated('businessPartner');
      },
    },
  });
}

export type AwbShape = ModelObject<Awb>;
