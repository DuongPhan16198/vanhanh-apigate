import { Model, ModelObject, snakeCaseMappers } from 'objection';

export class FcmTokens extends Model {
  id: number;
  userId: number;
  fcmToken: string;
  lastUpdatedAt: Date;

  static tableName = 'fcm_tokens'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
}

export type FcmTokenShape = ModelObject<FcmTokens>;
