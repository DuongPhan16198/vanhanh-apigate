import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class CustomerTransactionLinks extends Model {
  id: number;
  customerId: number;
  customerTransactionLogId: number;

  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static get tableName() {
    return 'customer_transaction_logs_customer_id_links';
  }
}

export type CustomerTransactionLinksShape = ModelObject<CustomerTransactionLinks>;
