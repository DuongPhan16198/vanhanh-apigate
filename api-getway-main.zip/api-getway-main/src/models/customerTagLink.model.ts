import { Model, ModelObject, snakeCaseMappers } from 'objection';

export class CustomerTagLink extends Model {
  id: number;
  customer_id: number;
  customer_tag_id: number;

  static tableName = 'customers_tags_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
}

export type CustomerTagLinkShape = ModelObject<CustomerTagLink>;
