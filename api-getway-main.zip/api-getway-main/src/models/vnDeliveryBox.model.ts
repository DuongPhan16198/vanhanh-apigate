import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { VnDeliveryOrders } from './vnDeliveryOrder.model';
import { DeliveryBill } from './deliveryBill.model';
import { UpUsers } from './upUsers.model';
export enum VnDeliveryBoxStatus {
  NEWLYCREATED,
  ONDELIVERING,
  COMPLETED,
  FAILED,
  DELETED,
}

export class VnDeliveryBoxes extends Model {
  id: number;
  code: string;
  vnDeliveryOrderId: number;
  deliveredById: number;
  receivedDate: Date;
  deliveredDate: Date;
  note: string;
  status: number;

  static tableName = 'vn_delivery_boxes'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
    vnDeliveryOrder: {
      relation: Model.HasOneRelation,
      modelClass: VnDeliveryOrders,
      join: {
        from: 'vn_delivery_boxes.vn_delivery_order_id',
        to: 'vn_delivery_orders.id',
      },
    },
    deliveryBill: {
      relation: Model.HasOneThroughRelation,
      modelClass: DeliveryBill,
      join: {
        from: 'vn_delivery_boxes.vn_delivery_order_id',
        through: {
          from: 'vn_delivery_orders.id',
          to: 'vn_delivery_orders.delivery_bill_id',
        },
        to: 'delivery_bills.id',
      },
    },
    deliveredBy: {
      relation: Model.HasOneRelation,
      modelClass: UpUsers,
      join: {
        from: 'vn_delivery_boxes.delivered_by_id',
        to: 'up_users.id',
      },
    },
  });
}

export type DeliverUnitShape = ModelObject<VnDeliveryBoxes>;
