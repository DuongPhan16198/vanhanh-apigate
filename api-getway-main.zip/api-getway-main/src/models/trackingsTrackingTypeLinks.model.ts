import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class TrackingsTrackingTypeLinks extends Model {
  id: number;
  tracking_id: number;
  tracking_type_id: number;

  static tableName = 'trackings_tracking_type_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

}

export type TrackingsTrackingTypeLinksShape = ModelObject<TrackingsTrackingTypeLinks>;
