import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { Customer } from './customer.model.';

export class CustomerTags extends Model {
  id: number;
  name: string;
  color: number;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
  createdById: number;
  updatedById: number;

  static tableName = 'customer_tags'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
    boxStag: {
      relation: Model.ManyToManyRelation,
      modelClass: Customer,
      join: {
        from: 'customers.id',
        through: {
          from: 'customers_tags_links.customer_tag_id',
          to: 'customers_tags_links.customer_id',
        },
        to: 'customer_tags.id',
      },
      modify: builder => {
        builder.select('customer_tags.id', 'customer_tags.name', 'customer_tags.color');
      },
    },
  });
}

export type CustomerTagsShape = ModelObject<CustomerTags>;
