import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { CustomerTags } from './customerTags.mode';
import { Tracking } from './tracking.model';
import { BusinessPartner } from './businessPartner.model';
import { User } from '@/interfaces/users.interface';
import { Users } from './users.model';
import { GeneralConfigs } from './generalConfig.model';
export class Customer extends Model {
  id: number;
  name: string;
  phone: string;
  address: string;
  email: string;
  trackings: Tracking[];
  businessPartner: BusinessPartner;
  deliveryBills: string;
  customerTransactionLogs: string;
  balance: number;
  customerCode: string;
  accountCode: string;
  birthday: Date;
  displayName: string;
  note: string;
  chargeMoney: number;
  depositMoney: number;
  addressList: string;
  phoneList: string;
  nickName: string;
  user: User;
  isAllowDebt: boolean;
  shippingCost: any;
  sale: User;
  customerMoneyLogs: string;
  tags: string;
  taxId: string;
  createdById: number;
  idCustomer: string;
  creditAmount: number;
  isSubcribeToEmailNotification: boolean;
  isSubcribeToFcmNotification: boolean;

  // static tableName = 'customers'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static get tableName() {
    return 'customers';
  }

  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
    sale: {
      relation: Model.ManyToManyRelation,
      modelClass: Users,
      join: {
        from: 'customers.id',
        through: {
          from: 'customers_sale_links.customer_id',
          to: 'customers_sale_links.user_id',
        },
        to: 'up_users.id',
      },
      modify: builder => {
        builder.select('up_users.id', 'up_users.username', 'up_users.email', 'up_users.phone', 'up_users.fullname', 'up_users.avatar_url');
      },
    },
    customersServiceStaff: {
      relation: Model.ManyToManyRelation,
      modelClass: Users,
      join: {
        from: 'customers.id',
        through: {
          from: 'customers_service_staff_links.customer_id',
          to: 'customers_service_staff_links.user_id',
        },
        to: 'up_users.id',
      },
      modify: builder => {
        builder.select('up_users.id', 'up_users.username', 'up_users.email', 'up_users.phone', 'up_users.fullname', 'up_users.avatar_url');
      },
    },
    user: {
      relation: Model.ManyToManyRelation,
      modelClass: Users,
      join: {
        from: 'customers.id',
        through: {
          from: 'up_users_customer_links.customer_id',
          to: 'up_users_customer_links.user_id',
        },
        to: 'up_users.id',
      },
    },
    boxStagxxx: {
      relation: Model.ManyToManyRelation,
      modelClass: CustomerTags,
      join: {
        from: 'customers.id',
        through: {
          from: 'customers_tags_links.customer_tag_id',
          to: 'customers_tags_links.customer_id',
        },
        to: 'customer_tags.id',
      },
      modify: builder => {
        builder.select('customer_tags.id', 'customer_tags.name', 'customer_tags.color');
      },
    },
    boxStag: {
      relation: Model.ManyToManyRelation,
      modelClass: CustomerTags,
      join: {
        from: 'customers.id',
        through: {
          from: 'customers_tags_links.customer_id',
          to: 'customers_tags_links.customer_tag_id',
        },
        to: 'customer_tags.id',
      },
      modify: builder => {
        builder.select('customer_tags.id', 'customer_tags.name', 'customer_tags.color');
      },
    },
    trackings: {
      relation: Model.ManyToManyRelation,
      modelClass: Tracking,
      join: {
        from: 'customers.id',
        through: {
          from: 'trackings_customer_links.customer_id',
          to: 'trackings_customer_links.tracking_id',
        },
        to: 'trackings.id',
      },
    },
    generalConfigs: {
      relation: Model.HasOneRelation,
      modelClass: GeneralConfigs,
      join: {
        from: 'customers.shipping_cost',
        to: 'general_configs.id',
      },
      modify: builder => {
        builder.select('id', 'config_key', 'config_value');
      },
    },
  });
}

export type CustomerShape = ModelObject<Customer>;
