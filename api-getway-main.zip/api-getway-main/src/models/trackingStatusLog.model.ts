import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class TrackingStatusLogs extends Model {
  id: number;
  name:string;
  updatedTime: Date;
  trackingId:number;

  static tableName = 'tracking_status_logs'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
}

export type TrackingStatusLogsShape = ModelObject<TrackingStatusLogs>;
