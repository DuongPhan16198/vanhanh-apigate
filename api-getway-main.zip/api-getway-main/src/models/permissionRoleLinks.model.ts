import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class PermissionsRoleLinks extends Model {
  id: number;
  permission_id: number;
  role_id: number;
  permission_business_logic_id : number;

  static tableName = 'up_permissions_role_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
}

export type PermissionsRoleLinksShape = ModelObject<PermissionsRoleLinks>;
