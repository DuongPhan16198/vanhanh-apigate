import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { VnDeliveryUnits } from './vnDeliveryUnit.model';
import { VnDeliveryBoxes } from './vnDeliveryBox.model';
import { DeliveryBill } from './deliveryBill.model';
export enum VnDeliveryOrderStatus {
  NEWLYCREATED,
  ONDELIVERING,
  COMPLETED,
  FAILED,
  DELETED,
}

export class VnDeliveryOrders extends Model {
  id: number;
  code: string;
  quantity: number;
  deliveryBillId: number;
  deliveryUnitId: number;
  status: VnDeliveryOrderStatus;

  static tableName = 'vn_delivery_orders'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
    vnDeliveryUnit: {
      relation: Model.HasOneRelation,
      modelClass: VnDeliveryUnits,
      join: {
        from: 'vn_delivery_orders.vn_delivery_unit_id',
        to: 'vn_delivery_units.id',
      },
    },
    vnDeliveryBill: {
      relation: Model.HasOneRelation,
      modelClass: DeliveryBill,
      join: {
        from: 'vn_delivery_orders.delivery_bill_id',
        to: 'delivery_bills.id',
      },
    },
    vnDeliveryBoxes: {
      relation: Model.HasManyRelation,
      modelClass: VnDeliveryBoxes,
      join: {
        from: 'vn_delivery_orders.id',
        to: 'vn_delivery_boxes.vn_delivery_order_id',
      },
    },
  });
}

export type DeliverUnitShape = ModelObject<VnDeliveryOrders>;
