import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';

export class Permission extends Model {
  id: number;
  action: string;

  static tableName = 'up_permissions'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
}

export type PermissionShape = ModelObject<Permission>;
