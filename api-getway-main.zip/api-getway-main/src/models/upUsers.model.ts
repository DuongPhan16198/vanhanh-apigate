import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { UpRole } from './upRole.model';
export class UpUsers extends Model {
  id: number;
  username: string;
  email: string;
  provider: string;
  password: string;
  resetPasswordToken: string;
  confirmationToken: string;
  confirmed: boolean;
  blocked: boolean;
  phone: string;
  type: string;
  fullname: string;
  confirmPassword: string;
  tmpPassword: string;
  createdAt: Date;
  updatedAt: Date;
  createdById: number;
  updatedById: number;

  static tableName = 'up_users'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
    role: {
      relation: Model.ManyToManyRelation,
      modelClass: UpRole,
      join: {
        from: 'up_users.id',
        through: {
          from: 'up_users_role_links.user_id',
          to: 'up_users_role_links.role_id',
        },
        to: 'up_roles.id',
      },
      modify: builder => {
        builder.select('up_roles.id', 'up_roles.name', 'up_roles.description', 'up_roles.type');
      },
    },
  });
}

export type UpUsersShape = ModelObject<UpUsers>;
