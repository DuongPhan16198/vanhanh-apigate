import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class TrackingsBoxLinks extends Model {
  id: number;
  tracking_id: number;
  box_id: number;

  static tableName = 'trackings_box_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

}

export type TrackingsBoxLinksShape = ModelObject<TrackingsBoxLinks>;
