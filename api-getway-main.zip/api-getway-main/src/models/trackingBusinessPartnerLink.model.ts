import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class TrackingBusinessPartnerLink extends Model {
  id: number;
  tracking_id: number;
  business_partner_id: number;

  static tableName = 'trackings_business_partner_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

}

export type TrackingBusinessPartnerLinkShape = ModelObject<TrackingBusinessPartnerLink>;
