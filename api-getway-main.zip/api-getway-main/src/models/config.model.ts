import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { Tracking } from './tracking.model';
import { Box } from './box.model';

export class Config extends Model {
  id: number;
  apiToken: string;
  apiUrl: string;
  trackingBarrelCoefficient: number;

  static tableName = 'configs'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
}

export type ConfigShape = ModelObject<Config>;
