import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class CustomerSaleLinks extends Model {
  id: number;
  customerId: number;
  userId: number;

  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static get tableName() {
    return 'customers_sale_links';
  }
}

export type CustomerSaleLinkShape = ModelObject<CustomerSaleLinks>;
