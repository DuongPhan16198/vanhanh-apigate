import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { Tracking } from './tracking.model';
import { Awb } from './awb.model';
import { WarehouseConfig } from './warehouseConfig.model';
import { BusinessPartner } from './businessPartner.model';

export class Box extends Model {
  id: number;
  code: string;
  description: string;
  trackingQuantity: number;
  status: string;
  weight: number;
  trackings: Tracking[];
  awb: Awb;
  warehouse: string;
  completedAt: Date;
  businessPartner: string;
  exploitStatus: string;
  exploitStartDate: Date;
  exploitEndDate: Date;
  boxRate: number;
  warehouseVn: string;
  uid: string;

  static tableName = 'boxes'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
    awb: {
      relation: Model.ManyToManyRelation,
      modelClass: Awb,
      join: {
        from: 'boxes.id',
        through: {
          from: 'boxes_awb_links.box_id',
          to: 'boxes_awb_links.awb_id',
        },
        to: 'awbs.id',
      },
    },
    trackingBoxes: {
      relation: Model.ManyToManyRelation,
      modelClass: Tracking,
      join: {
        from: 'boxes.id',
        through: {
          from: 'trackings_box_links.box_id',
          to: 'trackings_box_links.tracking_id',
        },
        to: 'trackings.id',
      },
      modify: builder => {
        builder.where('trackings.is_deleted', false);
      },
    },
    warehouseVN: {
      relation: Model.ManyToManyRelation,
      modelClass: WarehouseConfig,
      join: {
        from: 'boxes.id',
        through: {
          from: 'boxes_warehouse_vn_links.box_id',
          to: 'boxes_warehouse_vn_links.warehouse_config_id',
        },
        to: 'warehouse_configs.id',
      },
      modify: builder => {
        builder.select('warehouse_configs.id', 'warehouse_configs.name');
      },
    },
    businessPartner: {
      relation: Model.ManyToManyRelation,
      modelClass: BusinessPartner,
      join: {
        from: 'boxes.id',
        through: {
          from: 'boxes_business_partners_links.box_id',
          to: 'boxes_business_partners_links.business_partner_id',
        },
        to: 'business_partners.id',
      },
    },
    boxBusinessPartner: {
      relation: Model.ManyToManyRelation,
      modelClass: BusinessPartner,
      join: {
        from: 'boxes.id',
        through: {
          from: 'boxes_business_partners_links.box_id',
          to: 'boxes_business_partners_links.business_partner_id',
        },
        to: 'business_partners.id',
      },
    },
  });
  // static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
  //   stores: {
  //     relation: Model.ManyToManyRelation,
  //     modelClass: Store,
  //     join: {
  //       from: 'users.staff_code',
  //       through: {
  //         from: 'accessible.staff_code',
  //         to: 'accessible.id_store',
  //       },
  //       to: 'store.id_store',
  //     },
  //   },
  // });
}

export type BoxShape = ModelObject<Box>;
