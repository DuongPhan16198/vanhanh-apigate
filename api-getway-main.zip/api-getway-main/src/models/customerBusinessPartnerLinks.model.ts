import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class CustomerBusinessPartnerLinks extends Model {
  id: number;
  customer_id: number;
  business_partner_id: number;

  // static tableName = 'customers'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static get tableName() {
    return 'customers_business_partner_links';
  }
}

export type CustomerBusinessPartnerLinksShape = ModelObject<CustomerBusinessPartnerLinks>;
