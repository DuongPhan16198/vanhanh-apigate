import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class TrackingsWarehouseLinksLink extends Model {
  id: number;
  tracking_id: number;
  warehouse_id: number;

  static tableName = 'trackings_warehouse_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

}

export type TrackingsWarehouseLinksLinkShape = ModelObject<TrackingsWarehouseLinksLink>;
