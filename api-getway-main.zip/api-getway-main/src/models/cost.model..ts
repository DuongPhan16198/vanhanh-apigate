import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { Awb } from './awb.model';
export class Cost extends Model {
  id: number;
  awb: Awb;
  money: number;
  warehouseVn: string;
  content: string;

  static tableName = 'costs'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

}

export type CostShape = ModelObject<Cost>;
