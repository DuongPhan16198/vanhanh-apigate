import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
export class TrackingType extends Model {
  id: number;
  name: string;
  status: string;
  color: string;
  uid: string;

  static tableName = 'tracking_types'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

}

export type TrackingTypeShape = ModelObject<TrackingType>;
