import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class Pages extends Model {
  id: number;
  pageInterfaceFileName: string;
  pageMetadata: string;
  isDelete: boolean;
  isSystem: boolean;
  title: string;
  slug: string;
  description: string;
  imageUrl: string;

  static tableName = 'pages'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
}

export type pageShape = ModelObject<Pages>;
