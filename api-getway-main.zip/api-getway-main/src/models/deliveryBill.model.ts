import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { Customer } from './customer.model.';
import { Tracking } from './tracking.model';
import { BusinessPartner } from './businessPartner.model';
import { Users } from './users.model';
import { VnDeliveryOrderStatus, VnDeliveryOrders } from './vnDeliveryOrder.model';
import { VnDeliveryBoxStatus, VnDeliveryBoxes } from './vnDeliveryBox.model';
export class DeliveryBill extends Model {
  id: number;
  code: string;
  customerName: string;
  deliveryBillStatus: string;
  customerAddress: string;
  customerPhone: string;
  description: string;
  note: string;
  isConfirmedByCustomer: boolean;
  isPackaged: boolean;
  isCharged: boolean;
  createdById: number;
  trackings: Tracking[];
  customer: Customer;
  createdAt: string;
  updatedAt: string;
  name: string;
  email: string;
  shipper_note: string;

  $beforeInsert() {
    this.createdAt = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updatedAt = new Date().toISOString();
  }

  static tableName = 'delivery_bills'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
    customer: {
      relation: Model.ManyToManyRelation,
      modelClass: Customer,
      join: {
        from: 'delivery_bills.id',
        through: {
          from: 'delivery_bills_customer_links.delivery_bill_id',
          to: 'delivery_bills_customer_links.customer_id',
        },
        to: 'customers.id',
      },
    },
    customerInfo: {
      relation: Model.ManyToManyRelation,
      modelClass: Customer,
      join: {
        from: 'delivery_bills.id',
        through: {
          from: 'delivery_bills_customer_links.delivery_bill_id',
          to: 'delivery_bills_customer_links.customer_id',
        },
        to: 'customers.id',
      },
      modify: builder => {
        builder.select('customers.id', 'customers.name', 'customers.nick_name');
      },
    },
    tracking: {
      relation: Model.ManyToManyRelation,
      modelClass: Tracking,
      join: {
        from: 'delivery_bills.id',
        through: {
          from: 'trackings_delivery_bill_links.delivery_bill_id',
          to: 'trackings_delivery_bill_links.tracking_id',
        },
        to: 'trackings.id',
      },
    },
    businessPartner: {
      relation: Model.ManyToManyRelation,
      modelClass: BusinessPartner,
      join: {
        from: 'delivery_bills.id',
        through: {
          from: 'delivery_bills_business_partner_links.delivery_bill_id',
          to: 'delivery_bills_business_partner_links.business_partner_id',
        },
        to: 'business_partners.id',
      },
    },
    employee: {
      relation: Model.HasOneRelation,
      modelClass: Users,
      join: {
        from: 'delivery_bills.created_by_id',
        to: 'up_users.id',
      },
      modify: builder => {
        builder.select('id', 'phone', 'email', 'fullname', 'avatar_url');
      },
    },
    vnDeliveryOrder: {
      relation: Model.HasManyRelation,
      modelClass: VnDeliveryOrders,
      join: {
        from: 'delivery_bills.id',
        to: 'vn_delivery_orders.delivery_bill_id',
      },
      modify: builder => {
        builder.whereNot('vn_delivery_orders.status', VnDeliveryOrderStatus.DELETED);
      },
    },
    vnDeliveryBoxes: {
      relation: Model.ManyToManyRelation,
      modelClass: VnDeliveryBoxes,
      join: {
        from: 'delivery_bills.id',
        through: {
          from: 'vn_delivery_orders.delivery_bill_id',
          to: 'vn_delivery_orders.id',
        },
        to: 'vn_delivery_boxes.vn_delivery_order_id',
      },
    },
  });
}

export type DeliveryBillShape = ModelObject<DeliveryBill>;
