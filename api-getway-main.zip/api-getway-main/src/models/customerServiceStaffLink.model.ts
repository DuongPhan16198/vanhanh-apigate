import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class CustomerServiceStaffLinks extends Model {
  id: number;
  customerId: number;
  userId: number;

  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static get tableName() {
    return 'customers_service_staff_links';
  }
}

export type CustomerServiceStaffLinkShape = ModelObject<CustomerServiceStaffLinks>;
