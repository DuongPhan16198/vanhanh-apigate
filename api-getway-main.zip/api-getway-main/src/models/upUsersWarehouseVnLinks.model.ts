import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class UpUsersWarehouseVnLinks extends Model {
  id: number;
  user_id: number;
  warehouse_config_id: number;

  static tableName = 'up_users_warehouse_vn_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
}

export type UpUsersWarehouseVnLinksShape = ModelObject<UpUsersWarehouseVnLinks>;
