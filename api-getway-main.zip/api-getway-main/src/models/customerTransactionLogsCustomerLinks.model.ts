import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class CustomerTransactionLogsCustomerLinks extends Model {
  id: number;
  customerTransactionLogId: number;
  customerId: number;

  // static tableName = 'customers'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static get tableName() {
    return 'customer_transaction_logs_customer_id_links';
  }
}

export type CustomerTransactionLogsCustomerLink = ModelObject<CustomerTransactionLogsCustomerLinks>;
