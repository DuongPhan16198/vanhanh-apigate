import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class DeliveryBillCustomerLinks extends Model {
  id: number;
  delivery_bill_id: number;
  customer_id: number;

  static tableName = 'delivery_bills_customer_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }
}

export type DeliveryBillCustomerLinksShape = ModelObject<DeliveryBillCustomerLinks>;
