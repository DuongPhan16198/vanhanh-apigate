import { Model, ModelObject, snakeCaseMappers } from 'objection';

export class NewsCategory extends Model {
  id: number;
  name: string;
  slug: string;


  static tableName = 'news_categories'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

}

export type CategoryShape = ModelObject<NewsCategory>;
