import { Model, ModelObject, snakeCaseMappers } from 'objection';
export class BoxesAwbLinks extends Model {
  id: number;
  box_id: number;
  awb_id: number;

  static tableName = 'boxes_awb_links'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

}

export type TrackingsBoxLinksShape = ModelObject<BoxesAwbLinks>;
