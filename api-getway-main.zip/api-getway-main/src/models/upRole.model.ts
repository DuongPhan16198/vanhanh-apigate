import { Model, ModelObject, RelationMappings, RelationMappingsThunk, snakeCaseMappers } from 'objection';
import { UpUsers } from './upUsers.model';
import { Permission } from './permission.model';
export class UpRole extends Model {
  id: number;
  name: string;
  description: string;
  type: string;
  createdAt: Date;
  updatedAt: Date;
  createdById: number;
  updatedById: number;
  isDelete: boolean;

  static tableName = 'up_roles'; // database table name
  static idColumn = 'id'; // id column name

  static get columnNameMappers() {
    return snakeCaseMappers();
  }

  static relationMappings: RelationMappings | RelationMappingsThunk = () => ({
    account: {
      relation: Model.ManyToManyRelation,
      modelClass: UpUsers,
      join: {
        from: 'up_roles.id',
        through: {
          from: 'up_users_role_links.role_id',
          to: 'up_users_role_links.user_id',
        },
        to: 'up_users.id',
      },
      modify: builder => {
        builder.select('up_users.id', 'up_users.username', 'up_users.email', 'up_users.phone', 'up_users.fullname');
      },
    },
    actions: {
      relation: Model.ManyToManyRelation,
      modelClass: Permission,
      join: {
        from: 'up_roles.id',
        through: {
          from: 'up_permissions_role_links.role_id',
          to: 'up_permissions_role_links.permission_id',
        },
        to: 'up_permissions.id',
      },
      modify: builder => {
        builder.select(
          'up_permissions.id',
          'up_permissions.action',
          'up_permissions.description',
          'up_permissions.business_logic',
          'up_permissions_role_links.permission_business_logic_id',
        );
      },
    },
  });
}

export type UpRoleShape = ModelObject<UpRole>;
