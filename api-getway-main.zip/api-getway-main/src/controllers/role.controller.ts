import { NextFunction, Request, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import RoleService from '@/services/role.service';
class RoleController {
  private service = RoleService.getInstant();

  public list = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const data = await this.service.findRoles(user, req.query);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public roleDetail = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.service.roleDetail(id);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public create = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.service.create(req.body);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public update = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.service.update(id, req.body);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public delete = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.service.delete(id);
      return res.status(200).json({ data, message: 'deleted' });
    } catch (error) {
      next(error);
    }
  };
}

export default RoleController;
