import { NextFunction, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import VnDeliveryUnitService from '@/services/vnDeliveryUnit.service';
class VnDeliveryUnitController {
  private vnDeliveryUnitService = VnDeliveryUnitService.getInstant();


  public getListVnDeliveryUnits = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user, query } = req;
      const data = await this.vnDeliveryUnitService.getVnDeliveryUnits(query)
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public create = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.vnDeliveryUnitService.create(req.body);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };



  public update = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const { id } = req.params;
      const data = await this.vnDeliveryUnitService.update(id, req.body);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public delete = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const { id } = req.params;
      const data = await this.vnDeliveryUnitService.delete(id);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getDetailVnDeliveryUnit = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.vnDeliveryUnitService.vnDeliveryUnitsDetail(id);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };
}

export default VnDeliveryUnitController;
