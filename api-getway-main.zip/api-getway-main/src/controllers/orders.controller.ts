import { NextFunction, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import OrdersService from '@/services/orders.service';

class OrderController {
  private OrdersService = OrdersService.getInstant();

  public list = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const data: any = await this.OrdersService.findAll(req, user, req.query);
      data.message = 'success';
      return res.status(200).json(data);
    } catch (error) {
      next(error);
    }
  };

  public getOrderById = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const { user } = req;
      const { isGettingStatusLog }: any = req.query;
      const data = await this.OrdersService.findById(req, user, id, true, isGettingStatusLog);

      return res.status(200).json({ data, message: 'find one' });
    } catch (error) {
      next(error);
    }
  };

  // public codeSuggestion = async (req: RequestWithUser, res: Response, next: NextFunction) => {
  //   try {
  //     const { user } = req;
  //     const { code } = req.params;
  //     const data = await this.OrdersService.codeSuggestion(user, code, req.query);
  //     return res.status(200).json({ data, message: 'suggestion' });
  //   } catch (error) {
  //     next(error);
  //   }
  // };

  // public waitingCreateDeliveryBills = async (req: RequestWithUser, res: Response, next: NextFunction) => {
  //   try {
  //     const { user } = req;
  //     const data = await this.OrdersService.waitingCreateDeliveryBills(user, req.query);
  //     return res.status(200).json({ ...data, message: 'suggestion' });
  //   } catch (error) {
  //     next(error);
  //   }
  // };
  public updateOrderById = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const { user } = req;
      const data = await this.OrdersService.updateOrderById(req, parseInt(id), user, req.body);
      return res.status(200).json({ ...data, message: 'update order' });
    } catch (error) {
      next(error);
    }
  };

  public createOrder = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const data = await this.OrdersService.createOrder(req, user, req.body);
      return res.status(200).json({ ...data, message: 'create order' });
    } catch (error) {
      next(error);
    }
  };

  public cancelOrder = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const { id } = req.params;
      const data = await this.OrdersService.cancelOrderById(req, parseInt(id), user);
      return res.status(200).json({ ...data, message: 'cancel order successfully' });
    } catch (error) {
      next(error);
    }
  };
}

export default OrderController;
