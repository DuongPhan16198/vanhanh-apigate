import { NextFunction, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import VnDeliveryOrderService from '@/services/vnDeliveryOrder.service';
import VnDeliveryOrdersCommonService from '@/services/vnDeliveryOrderCommon.service';
import { VnDeliveryOrderStatus } from '@/models/vnDeliveryOrder.model';
import VnDeliveryBoxesService from '@/services/vnDeliveryBox.service';
class VnDeliveryOrderController {
  private vnDeliveryOrderService = VnDeliveryOrderService.getInstant();
  private vnDeliveryBoxService = VnDeliveryBoxesService.getInstant();
  public getListVnDeliveryOrders = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user, query } = req;
      const data = await this.vnDeliveryOrderService.getVnDeliveryOrders(req, query);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public create = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.vnDeliveryOrderService.create(req, req.body);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public update = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const { id } = req.params;
      const data = await this.vnDeliveryOrderService.update(id, req.body);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public delete = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const { id } = req.params;
      const data = await this.vnDeliveryOrderService.delete(id);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getDetailVnDeliveryOrder = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.vnDeliveryOrderService.getVnDeliveryOrdersDetail(id);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getVnDeliveryOrderStatus = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.vnDeliveryOrderService.getVnDeliveryOrdersStatus();
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };
  public switchStatusOfAVnDeliveryOrder = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const orderBoxesIds: any = ((await this.vnDeliveryOrderService.getVnDeliveryOrdersDetail(id)) as any)?.vnDeliveryBoxes?.map(x => x.id);
      if (orderBoxesIds?.length)
        switch (req.body.newStatus) {
          case VnDeliveryOrderStatus.ONDELIVERING:
            await this.vnDeliveryBoxService.receiveBoxes(req, req.user, { ids: orderBoxesIds });
            break;
          case VnDeliveryOrderStatus.COMPLETED:
            await this.vnDeliveryBoxService.deliverySuccessfulBox(req, { ids: orderBoxesIds }, req.user);
            break;
          case VnDeliveryOrderStatus.FAILED:
            await this.vnDeliveryBoxService.deliveryFailedBox(req, orderBoxesIds, req.user);
            break;
          default:
            break;
        }
      return res.status(200).json({ message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public assignShipperAVnDeliveryOrder = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.vnDeliveryOrderService.assignShipperToADeliveryOrder(id, req.body);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };
}

export default VnDeliveryOrderController;
