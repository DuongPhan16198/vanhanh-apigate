import { NextFunction, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import PageService from '@/services/page.service';
class PageController {
  private service = PageService.getInstant();

  public getPageInterfaces = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const data = await this.service.getPageMetadataInterface();
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getListPages = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user, query } = req;
      const data = await this.service.getPages(query);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public create = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.service.createPage(req.body);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public update = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const { id } = req.params;
      const data = await this.service.updatePage(id, req.body);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public delete = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const { id } = req.params;
      const data = await this.service.deletePage(id);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getDetailPageById = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.service.getDetailPage(id);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };
}

export default PageController;
