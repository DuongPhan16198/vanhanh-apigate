import { NextFunction, Request, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import DeliveryBillsService from '@/services/deliveryBills.service';
import VnDeliveryBoxesService from '@/services/vnDeliveryBox.service';
import BadRequestException from '@/exceptions/BadRequestException';
class DeliveryBillsController {
  private DeliveryBillsService = DeliveryBillsService.getInstant();
  private deliveryBoxesService = VnDeliveryBoxesService.getInstant();
  public list = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const data: any = await this.DeliveryBillsService.findAll(req, user, req.query);
      data.message = 'success';
      return res.status(200).json(data);
    } catch (error) {
      next(error);
    }
  };

  public getDeliveryBillById = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.DeliveryBillsService.findDeliveryBillById(req, req.user, id);

      return res.status(200).json({ data, message: 'suggestion' });
    } catch (error) {
      next(error);
    }
  };

  public codeSuggestion = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const { code } = req.params;
      const data = await this.DeliveryBillsService.codeSuggestion(user, code, req.query);
      return res.status(200).json({ data, message: 'suggestion' });
    } catch (error) {
      next(error);
    }
  };

  public waitingCreateDeliveryBills = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const data = await this.DeliveryBillsService.waitingCreateDeliveryBills(req, user, req.query);
      return res.status(200).json({ ...data, message: 'suggestion' });
    } catch (error) {
      next(error);
    }
  };

  public updateDeliveryBills = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const billId = req.params.id;
      const data = await this.DeliveryBillsService.updateNewlyCreatedDeliveryBills(req, billId, req.body);
      return res.status(200).json({ ...data, message: 'suggestion' });
    } catch (error) {
      next(error);
    }
  };

  public getTrackingCustomer = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const { user } = req;
      const data = await this.DeliveryBillsService.getTrackingCustomer(Number(id), user, req.query);
      return res.status(200).json({ ...data, message: 'get tracking of customer waiting create delivery bill' });
    } catch (error) {
      next(error);
    }
  };

  public getTrackingOfCurrentCustomer = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const data = await this.DeliveryBillsService.getTrackingCustomer(user.customer.id, user, req.query);
      return res.status(200).json({ ...data, message: 'get tracking of customer waiting create delivery bill' });
    } catch (error) {
      next(error);
    }
  };

  public createDeliveryBill = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const deliveryBillData = req.body;
      const { user } = req;
      const data = await this.DeliveryBillsService.createDeliveryBill(req, deliveryBillData, user);
      return res.status(200).json({ data, message: 'create delivery bill success' });
    } catch (error) {
      next(error);
    }
  };

  public getDetailDeliveryBill = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.DeliveryBillsService.findDeliveryBillById(req, req.user, Number(id), false);
      return res.status(200).json({ ...data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getStatusUpdateBill = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.DeliveryBillsService.statusUpdateBill();
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public printDeliveryBill = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.DeliveryBillsService.printBill(req, id, false);
      return res.status(200).json({ data, message: 'Print delivery bill success' });
    } catch (error) {
      next(error);
    }
  };

  public skipApprovalToPrintDeliveryBill = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.DeliveryBillsService.printBill(req, id, true);
      return res.status(200).json({ data, message: 'Print delivery bill success' });
    } catch (error) {
      next(error);
    }
  };

  public saleApproveDeliveryBill = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.DeliveryBillsService.saleApproveBill(req, id);
      return res.status(200).json({ data, message: 'Approve delivery bill success' });
    } catch (error) {
      next(error);
    }
  };

  public accountantApproveDeliveryBill = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.DeliveryBillsService.accountantApproveBill(id);
      return res.status(200).json({ data, message: 'Approve delivery bill success' });
    } catch (error) {
      next(error);
    }
  };

  public exportDeliveryBill = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.DeliveryBillsService.exportBill(req, id, req.body);
      return res.status(200).json({ data, message: 'Export delivery bill success' });
    } catch (error) {
      next(error);
    }
  };

  public packDeliveryBill = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.DeliveryBillsService.packBill(id);
      return res.status(200).json({ data, message: 'Pack delivery bill success' });
    } catch (error) {
      next(error);
    }
  };

  public finishDeliveryBill = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.DeliveryBillsService.finishBill(id);
      return res.status(200).json({ data, message: 'Finish delivery bill success' });
    } catch (error) {
      next(error);
    }
  };

  public failedDeliveryBill = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      let data;
      const bill: any = await this.DeliveryBillsService.findDeliveryBillById(req, req.user, id, false);
      if (req.permission_business_logic === 6) {
        if (bill.deliveryBillStatus === 'Đang giao hàng')
          await this.deliveryBoxesService.deliveryFailedBox(
            req,
            bill.vnDeliveryBoxes.map(x => x.id),
            req.user,
          );
        else throw new BadRequestException('Bill is not in delivering status!');
      } else {
        data = await this.DeliveryBillsService.failedBill(req, id);
      }
      return res.status(200).json({ data, message: 'Finish delivery bill success' });
    } catch (error) {
      next(error);
    }
  };

  public cancelDeliveryBill = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.DeliveryBillsService.cancelBill(req, id);
      return res.status(200).json({ data, message: 'Cancel delivery bill success' });
    } catch (error) {
      next(error);
    }
  };

  public getBillCustomer = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.DeliveryBillsService.getBillCustomer(Number(id), req.query);
      return res.status(200).json({ ...data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public search = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.DeliveryBillsService.search(req, req.query.keyword.toString());
      return res.status(200).json({ data: data, message: 'search delivery bill' });
    } catch (error) {
      next(error);
    }
  };

  public searchTracking = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const { user } = req;
      const data = await this.DeliveryBillsService.searchTrackingCustomer(Number(id), user, req.query);
      return res.status(200).json({ ...data, message: 'search tracking of customer waiting create delivery bill' });
    } catch (error) {
      next(error);
    }
  };

  public createManyTrackingInBill = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const { trackingIds } = req.body;
      const { user } = req;
      const data = await this.DeliveryBillsService.createManyTrackingInBill(user, Number(id), trackingIds);
      return res.status(200).json({ ...data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public deleteTrackingInBill = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const { trackingId } = req.body;
      const data = await this.DeliveryBillsService.deleteTrackingInBill(Number(id), trackingId);
      res.status(200).json({ ...data, message: 'success' });
      await this.DeliveryBillsService.logStatusTracking(trackingId, `Đơn hàng đã bị xóa khỏi PXK ${data.code}`);
    } catch (error) {
      next(error);
    }
  };

  public packTrackingInBill = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const { trackingId } = req.body;
      const data = await this.DeliveryBillsService.packTrackingInBill(Number(id), trackingId, req.user);
      res.status(200).json({ ...data, message: 'success' });
      await this.DeliveryBillsService.logStatusTracking(trackingId, `Đơn hàng đã được đóng hàng tại phiếu ${data.code}`);
    } catch (error) {
      next(error);
    }
  };

  public getDeliveryBillStatus = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.DeliveryBillsService.getDeliveryBillStatus(req, req.query);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public exportExcel = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.DeliveryBillsService.exportExcel(req, id, res);
    } catch (error) {
      next(error);
    }
  };

  public updateDeliveredImageUrl = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.DeliveryBillsService.updateDeliveredImageUrl(req, id, req.body);
      return res.status(200).json({ data, message: 'Cancel delivery bill success' });
    } catch (error) {
      next(error);
    }
  };

  public assignShipperToADeliveryBill = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const { deliveredById } = req.body;
      const data = await this.DeliveryBillsService.assignShipperToADeliveryBill(req, id, deliveredById);
      return res.status(200).json({ data, message: 'assign shipper successfully' });
    } catch (error) {
      next(error);
    }
  };
}

export default DeliveryBillsController;
