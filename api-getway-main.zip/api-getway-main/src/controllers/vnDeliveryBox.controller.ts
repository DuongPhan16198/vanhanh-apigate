import { NextFunction, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import VnDeliveryBoxService from '@/services/vnDeliveryBox.service';
class VnDeliveryBoxController {
  private vnDeliveryBoxService = VnDeliveryBoxService.getInstant();

  public getListVnDeliveryBoxesStatus = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.vnDeliveryBoxService.getVnDeliveryBoxesStatus();
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getListVnDeliveryBoxes = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user, query } = req;
      const data = await this.vnDeliveryBoxService.getVnDeliveryBoxes(req, query);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public update = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const { id } = req.params;
      const data = await this.vnDeliveryBoxService.update(req, id, req.body);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getDetailVnDeliveryBox = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.vnDeliveryBoxService.getVnDeliveryBoxesDetail(req, id);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public receiveBoxes = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.vnDeliveryBoxService.receiveBoxes(req,req.user, req.body);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public deliverySuccessfulBoxes = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.vnDeliveryBoxService.deliverySuccessfulBox(req, req.body, req.user);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public deliveryFailedBoxes = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.vnDeliveryBoxService.deliveryFailedBox(req, req.body?.ids, req.user);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };
}

export default VnDeliveryBoxController;
