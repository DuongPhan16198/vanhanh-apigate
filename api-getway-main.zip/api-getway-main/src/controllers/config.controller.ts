import { NextFunction, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import GeneralConfigService from '@/services/config.service';
class GeneralConfigController {
  private service = GeneralConfigService.getInstant();

  public getConfigInterfaces = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const data = await this.service.getAllConfigsInterface();
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getListConfigs = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user, query } = req;
      const data = await this.service.getGeneralConfigs(req, query);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public create = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.service.createConfig(req.body);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getBoxCoefficientConfig = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.service.getBoxCoefficientConfig();
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public updateBoxCoefficient = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.service.updateBoxCoefficient(Number(id), req.body);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public update = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const { id } = req.params;
      const data = await this.service.updateConfig(id, req.body);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public delete = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const { id } = req.params;
      const data = await this.service.deleteConfig(id);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getDetailConfig = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.service.getDetailConfig(id);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getPublicGeneralConfig = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.service.getPublicGeneralConfigs(req.query);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };
}

export default GeneralConfigController;
