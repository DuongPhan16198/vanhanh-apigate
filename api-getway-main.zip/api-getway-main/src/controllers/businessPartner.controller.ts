import { NextFunction, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import BusinessPartnerService from '@/services/businessPartner.service';
class BusinessPartnerController {
  private service = BusinessPartnerService.getInstant();

  public getAllPartner = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data: any = await this.service.getAllPartner();

      res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };
}

export default BusinessPartnerController;
