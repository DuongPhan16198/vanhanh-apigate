import { NextFunction, Request, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import CustomerTransactionLogsService from '@/services/customerTransactionLogs.service';
import { getImageUrl } from '@/utils/getImageUrl';
import { HttpException } from '@/exceptions/HttpException';
import fs from 'fs';
import { promisify } from 'util';
import getReqPerrmissionBusinessLogic from '@/utils/getReqPerrmissionBusinessLogic';
const unlinkAsync = promisify(fs.unlink);
class CustomerTransactionLogs {
  private customerTransactionLogsService = CustomerTransactionLogsService.getInstant();

  public list = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const data: any = await this.customerTransactionLogsService.find(req, user, req.query);
      data.message = 'success';
      return res.status(200).json(data);
    } catch (error) {
      next(error);
    }
  };

  public getTransactionById = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.customerTransactionLogsService.getTransactionById(req, id);

      return res.status(200).json({ data, message: 'suggestion' });
    } catch (error) {
      next(error);
    }
  };

  public getTransactionByCustomerId = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.customerTransactionLogsService.getTransactionByCustomerId(id, req.query);

      return res.status(200).json({ ...data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public createTransaction = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      let imageFileUrl: string = null;
      await getReqPerrmissionBusinessLogic(req, 'api:: GET /api/transactions');
      if (
        (req.permission_business_logic && req.permission_business_logic === 5) ||
        req.user.role.type === 'khach_hang' ||
        req.user.type === 'customer'
      ) {
        delete req.body.customer_id;
        req.body.customer_id = req.user.customer.id;
      }
      if (req.file) {
        if (!req.body.customer_id) {
          throw new HttpException(400, 'Customer_id is required');
        }
        imageFileUrl = await getImageUrl(req.accessToken, req.file.path, 'customer_transaction_images', `customer_${req.body.customer_id}`);
        await unlinkAsync(req.file.path);
      }
      const data = await this.customerTransactionLogsService.createTransaction(req, req.body, imageFileUrl, false);

      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public approveTransaction = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.customerTransactionLogsService.approveTransaction(req, Number(id), req.body);

      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getTransactionStatus = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.customerTransactionLogsService.getTransactionStatus(req);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };
}

export default CustomerTransactionLogs;
