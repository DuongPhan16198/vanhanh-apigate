import { NextFunction, Request, Response } from 'express';

class IndexController {
  public index = async (req: Request, res: Response, next: NextFunction): Promise<any> => {
    try {
      res.status(200).end('OK');
    } catch (error) {
      console.error(error);
      next(error);
    }
  };
}

export default IndexController;
