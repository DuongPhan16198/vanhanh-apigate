import { NextFunction, Request, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import TrackingService from '@/services/trackings.service';
import { HttpException } from '@/exceptions/HttpException';
import BadRequestException from '@/exceptions/BadRequestException';
import UserService from '@/services/users.service';
class TrackingController {
  private trackingService = TrackingService.getInstant();
  private userService = new UserService();

  public list = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      let data = {};
      if (user.role.type === 'nhan_vien_kinh_doanh' || user.role.type === 'nhan_vien_khai_thac') {
        data = await this.trackingService.findAllByPartner(user, req.query);
      } else {
        data = await this.trackingService.findAll(user, req.query);
      }
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public createMany = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      if (user.type === 'customer') {
        req.body = req.body.map(data => {
          return {
            ...data,
            customer: user.customerId,
          };
        });
      } else {
        req.body.forEach(data => {
          if (!data.customer) {
            throw new BadRequestException('tracking has no customer');
          }
        });
      }
      const data = await this.trackingService.createMany(req.body, user);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public createManyWithBox = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { box_id } = req.params;
      const { user } = req;
      if (user.type === 'customer') {
        req.body = req.body.map(data => {
          return {
            ...data,
            customer: user.customerId,
          };
        });
      }
      const data = await this.trackingService.createManyWithBox(req.body.data, box_id);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public createTracking = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const data = await this.trackingService.createManyTracking(req.body, user);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public delete = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const { id } = req.params;
      const data = await this.trackingService.delete(id, user);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public codeSuggestion = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const { code } = req.params;
      const data = await this.trackingService.codeSuggestion(user, code, req.query);
      return res.status(200).json({ data, message: 'suggestion' });
    } catch (error) {
      next(error);
    }
  };

  public updateTracking = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const { id } = req.params;
      const data = await this.trackingService.updateTracking(id, req.body, false, user);
      if (data) {
        return res.status(200).json({ data, message: 'update success' });
      }
    } catch (error) {
      next(error);
    }
  };

  public exploitTracking = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const { id } = req.params;
      const data = await this.trackingService.exploitTracking(user, id, req.body);
      if (data) {
        return res.status(200).json({ data, message: 'success' });
      }
    } catch (error) {
      next(error);
    }
  };

  public findPublic = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { code, isGettingStatusLog }: any = req.query;
      if (!code) {
        throw new BadRequestException('tracking code and customer phone number is required');
      }
      const data = await this.trackingService.findPublic(code.toString(), isGettingStatusLog);
      if (data) {
        return res.status(200).json({ data, message: 'find' });
      } else {
        return res.status(200).json({ data: null, message: 'find' });
      }
    } catch (error) {
      next(error);
    }
  };

  public getOne = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const { user } = req;

      if (!id) {
        throw new BadRequestException('tracking id is required');
      }
      const data = await this.trackingService.findOne(user, id);
      if (data) {
        return res.status(200).json({ data, message: 'findOne' });
      }
    } catch (error) {
      next(error);
    }
  };

  public findFromDatabaseAndWarehouse = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { code } = req.query;
      const { user } = req;
      const data = await this.trackingService.findFromDatabaseAndWarehouse(code);
      if (data) {
        return res.status(200).json({ data, message: 'success' });
      }
    } catch (error) {
      next(error);
    }
  };

  public findAndUpdateFromWarehouse = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.trackingService.findAndUpdateFromWarehouse(req.body.map(x => x.code));
      if (data) {
        return res.status(200).json({ data, message: 'success' });
      }
    } catch (error) {
      next(error);
    }
  };

  public getListTrackings = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const data = await this.trackingService.getListTracking(req, user, req.query);
      if (data) {
        return res.status(200).json({ ...data, message: 'list tracking' });
      }
    } catch (error) {
      next(error);
    }
  };

  public getDetailTracking = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const { isGettingStatusLog } = req.query;
      if (!id) {
        throw new BadRequestException("tracking's id is required");
      }
      const data = await this.trackingService.getDetailTracking(req, id, isGettingStatusLog, true);
      if (data) {
        return res.status(200).json({ ...data, message: 'detail tracking' });
      }
    } catch (error) {
      next(error);
    }
  };

  public getStatusTracking = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.trackingService.getStatusTracking(req, req.query);
      if (data) {
        return res.status(200).json({ data, message: 'list status' });
      }
    } catch (error) {
      next(error);
    }
  };

  public addOrderId = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const trackingId = req.params.id;
      const { user } = req;
      const data = await this.trackingService.addOrderId(trackingId, user);
      if (data) {
        return res.status(200).json({ data, message: 'set order id' });
      }
    } catch (error) {
      next(error);
    }
  };

  public requestCheck = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const trackingId = req.params.id;
      const { message } = req.body;
      const data = await this.trackingService.sendCheckRequest(trackingId, message);
      if (data) {
        return res.status(200).json({ data, message: 'request check tracking' });
      }
    } catch (error) {
      next(error);
    }
  };

  public getTrackingWarehouse = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const businessPartners: any[] = await this.userService.getBusinessPartner(user.id);
      let data = {};
      if (businessPartners?.length) {
        const partnerUID: string = businessPartners[0].uid;
        data = await this.trackingService.findWarehouseTracking(partnerUID, req.query);
      }
      return res.status(200).json({ ...data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getTrackingByCustomer = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const data = await this.trackingService.getTrackingByCustomer(Number(id), req.query);
      if (data) {
        return res.status(200).json({ data, message: 'list tracking by customer' });
      }
    } catch (error) {
      next(error);
    }
  };

  public getTrackingType = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.trackingService.getTrackingType();
      if (data) {
        return res.status(200).json({ ...data, message: 'success' });
      }
    } catch (error) {
      next(error);
    }
  };

  public syncTracking = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const businessPartners: any[] = await this.userService.getBusinessPartner(user.id);
      const data = {};
      if (businessPartners?.length) {
        const partnerUID: string = businessPartners[0].uid;
        await this.trackingService.syncTracking(partnerUID);
      }
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public updateTicketResponse = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { trackingId, content } = req.body;
      const data = await this.trackingService.hookUpdateTrackingTicketResponse(trackingId, content);
      return res.status(200).json({ message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public updateWhStatusOfTracking = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { whTrackingId, whTrackingStatus } = req.body;
      const data = await this.trackingService.hookUpdateWhTrackingStatus(whTrackingId, whTrackingStatus);
      return res.status(200).json({ message: 'success' });
    } catch (error) {
      next(error);
    }
  };
}

export default TrackingController;
