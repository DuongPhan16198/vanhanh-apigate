import { NextFunction, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import FcmPushNotificationService from '@/services/fcmPushNotification.service';
class FcmTokenController {
  private service = FcmPushNotificationService.getInstant();

  public create = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.service.createFcmTokenUserLink(req.user, req.body);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public broadcastTestNotification = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.service.sendTestNotificationToAllDevice();
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public testDeviceNotification = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { fcm_token } = req.params;
      const data = await this.service.sendTestNotificationToDevice(fcm_token);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };
}

export default FcmTokenController;
