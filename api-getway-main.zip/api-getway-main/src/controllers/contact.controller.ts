import { NextFunction, Request, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import ContactService from '@/services/contact.service';
class ContactController {
  private contactService = ContactService.getInstant();

  public submitContact = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.contactService.submitContact(req.body);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };
}

export default ContactController;
