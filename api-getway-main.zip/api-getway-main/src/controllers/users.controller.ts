import { NextFunction, Request, Response } from 'express';
import { User } from '@interfaces/users.interface';
import userService from '@services/users.service';
// import { CreateUserDto } from '@/dtos/create-user.dto';
import { Users } from '@/models/users.model';
// import { EditUserDto } from '@/dtos/edit-user.dto';
import { RequestWithUser } from '@/interfaces/auth.interface';

class UsersController {
  public userService = new userService();

  public getUsers = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data = await this.userService.findAllUser(req.query);

      res.status(200).json({ ...data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getUserById = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { id } = req.params;
      const findOneUserData: User = await this.userService.findUserById(id);

      res.status(200).json({ data: findOneUserData, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public createEmployee = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const employeeData = req.body;
      const { user } = req;

      const createEmployeeData: User = await this.userService.createEmployee(employeeData, user);
      res.status(200).json({ data: createEmployeeData, message: 'created' });
    } catch (error) {
      next(error);
    }
  };

  public updateEmployee = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { id } = req.params;
      const employeeData = req.body;
      const updateEmployeeData: any = await this.userService.updateEmployee(Number(id), employeeData);
      res.status(200).json({ data: updateEmployeeData, message: 'updated' });
    } catch (error) {
      next(error);
    }
  };

  public deleteUser = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { id } = req.params;
      const data = await this.userService.deleteUser(id);
      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public find = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    const { user } = req;

    try {
      res.status(200).json(await Users.query());
    } catch (e) {
      next(e);
    }
  };

  public findOne = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { id } = req.user;
      const data: any = await this.userService.detail(id);

      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public searchUser = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { keyword, role_id } = req.query;
      const data: any = await this.userService.suggestion(keyword.toString(), Number(role_id));

      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public employeeRole = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data: any = await this.userService.getRole();
      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public employeePermission = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data: any = await this.userService.getPermission();
      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getCustomerBelongToEmployee = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { id } = req.params;
      const data: any = await this.userService.getCustomerBelongToEmployee(id, req.query);
      res.status(200).json({ ...data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getAllEmployee = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data = await this.userService.getAllEmployee(req.query);

      res.status(200).json({ ...data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getAllSale = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data = await this.userService.getAllSale(req.query);
      res.status(200).json({ ...data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getUserLogged = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const user = req.user;
      const data = await this.userService.getUserLogged(user);

      res.status(200).json({ ...data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getAllExploit = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data = await this.userService.getAllExploit(req.query);
      res.status(200).json({ ...data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };
}

export default UsersController;
