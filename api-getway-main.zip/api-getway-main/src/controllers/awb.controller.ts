import { NextFunction, Request, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import { SyncAwbInput } from '@/schema/awb.schema';
import AwbService from '@/services/awb.service';
import UserService from '@/services/users.service';
import { promisify } from 'util';
import fs from 'fs';
const unlinkAsync = promisify(fs.unlink);
class AwbController {
  private awbService = AwbService.getInstant();
  private userService = new UserService();

  public list = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const data = await this.awbService.findAll(req, user, req.query);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public update = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { user } = req;
      const formData = req.body;
      const { id } = req.params;
      const data = await this.awbService.updateAwb(user, id, formData);

      res.status(200).json({ data, message: 'updated' });
    } catch (error) {
      next(error);
    }
  };

  public checkReady = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { user } = req;
      const businessPartners: any[] = await this.userService.getBusinessPartner(user.id);
      let data;
      if (businessPartners?.length) {
        const partnerUID: string = businessPartners[0].uid;
        data = await this.awbService.checkAwb(partnerUID);
      }
      res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public sync = async (req: Request<{}, {}, SyncAwbInput, {}, RequestWithUser>, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { user } = req;
      const businessPartners: any[] = await this.userService.getBusinessPartner(user.id);
      if (businessPartners?.length) {
        const partner = businessPartners[0];
        const body: SyncAwbInput = req.body;
        await this.awbService.sync(partner, body.awbs, res);
      }
    } catch (error) {
      next(error);
    }
  };

  public importExcel = async (req: Request<{}, {}, SyncAwbInput, {}, RequestWithUser>, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { user } = req;
      const businessPartners: any[] = await this.userService.getBusinessPartner(user.id);
      if (businessPartners?.length) {
        const partner = businessPartners[0];
        const body: any = req.body;
        await this.awbService.importExcel(partner, req.file.path);
        await unlinkAsync(req.file.path);
      }

      res.status(200).json({ data: [], message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public search = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const data = await this.awbService.searchAwb(req.query.keyword);
      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public listStatus = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.awbService.getStatusAwb(req, req.query);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getDetailAwb = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;

      const data = await this.awbService.getDetail(req, Number(id), req.query);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };
}

export default AwbController;
