import { NextFunction, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import BoxService from '@/services/box.service';
import UserService from '@/services/users.service';
class BoxController {
  private boxService = BoxService.getInstant();
  private userService = new UserService();
  public list = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const data = await this.boxService.findBox(user, req.query);
      return res.status(200).json({ ...data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public update = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { user } = req;
      const formData = req.body;
      const { id } = req.params;
      const data = await this.boxService.updateBox(user, id, formData);

      res.status(200).json({ data, message: 'updated' });
    } catch (error) {
      next(error);
    }
  };

  public find = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const businessPartners: any[] = await this.userService.getBusinessPartner(user.id);
      let data = {};
      if (businessPartners?.length) {
        const partnerUID: string = businessPartners[0].uid;
        data = await this.boxService.findNewBox(partnerUID, req.query);
      }
      return res.status(200).json({ ...data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getTracking = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const { id } = req.params;
      const data = await this.boxService.findTrackings(user, id, req.query);
      return res.status(200).json({ ...data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public importTracking = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const { idWarehouse, passWords } = req.body;

      const data = await this.boxService.importTrackings(id, idWarehouse, passWords);
      return res.status(200).json({ ...data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };
}

export default BoxController;
