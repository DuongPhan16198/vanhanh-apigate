import { NextFunction, Request, Response } from 'express';
import { DataStoredInToken, RequestWithUser } from '@interfaces/auth.interface';
import { User } from '@interfaces/users.interface';
import AuthService from '@services/auth.service';
import { CreateUserDto } from '@/dtos/users.dto';
import { plainToInstance } from 'class-transformer';
import RefreshNewTokenRequestDto from '@/dtos/refresh-new-token-request.dto';
import { Users } from '@/models/users.model';
import { ChangePasswordDto } from '@/dtos/change-password.dto';
import CustomerService from '@/services/customer.service';

class AuthController {
  public authService = new AuthService();
  private readonly customerService = new CustomerService();
  public signUp = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const userData: CreateUserDto = req.body;
      const signUpUserData: User = await this.customerService.addCustomer({ fullname: userData.username, ...userData }, null);
      res.status(201).json({ data: signUpUserData, message: 'signup' });
    } catch (error) {
      next(error);
    }
  };

  public signUpCustomer = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const userData: CreateUserDto = req.body;
      const signUpUserData: User = await this.customerService.addCustomer({ fullname: userData.username, ...userData }, null);
      res.status(201).json({ data: signUpUserData, message: 'signup' });
    } catch (error) {
      next(error);
    }
  };

  public logIn = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const userData: CreateUserDto = req.body;
      const { cookie, loginData } = await this.authService.login(userData);
      res.setHeader('Set-Cookie', [cookie]);
      res.status(200).json({
        token: loginData.token,
        refreshToken: loginData.refreshToken,
        expiresIn: loginData.expiresIn,
        data: {
          id: loginData.id,
          customerName: loginData.customerName,
          fullname: loginData.fullname,
          email: loginData.email.toLowerCase(),
          businessPartnerId: loginData.businessPartnerId,
          warehouseVN: loginData.warehouseVN,
          type: loginData.type,
        },
        role: loginData.role,
      });
    } catch (error) {
      next(error);
    }
  };

  public createAccountPartner = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const userData = req.body;
      const data = await this.authService.createAccountPartner(userData);
      res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public logOut = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const userData: User = req.user;
      const logOutUserData: User = await this.authService.logout(userData, req.accessToken);

      res.setHeader('Set-Cookie', ['Authorization=; Max-age=0']);
      res.status(200).json({ data: logOutUserData, message: 'logout' });
    } catch (error) {
      next(error);
    }
  };

  public resetPassword = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const changePassword: ChangePasswordDto = req.body;
      const userData: User = req.user;
      const { cookie, loginData } = await this.authService.resetPassword(userData, changePassword);

      res.setHeader('Set-Cookie', [cookie]);
      res.status(200).json({
        token: loginData.token,
        refreshToken: loginData.refreshToken,
        expiresIn: loginData.expiresIn,
        data: {
          id: loginData.id,
          customerName: loginData.customerName,
          username: loginData.username,
          email: loginData.email.toLowerCase(),
          businessPartnerId: loginData.businessPartnerId,
          warehouseVN: loginData.warehouseVN,
          type: loginData.type,
        },
        role: loginData.role,
      });
    } catch (error) {
      next(error);
    }
  };

  public sendResetPasswordRequest = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { email } = req.body;
      await this.authService.resetPasswordRequest(email);
      res.status(200).json({
        message: 'Verify Reset Password Token Successfully',
      });
    } catch (error) {
      next(error);
    }
  };

  public verifyResetPasswordToken = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { resetPasswordToken } = req.body;
      await this.authService.verifyResetPasswordToken(resetPasswordToken);
      res.status(200).json({
        message: 'Verify Reset Password Token Successfully',
      });
    } catch (error) {
      next(error);
    }
  };

  public setNewPassword = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const setNewPasswordDto = req.body;
      await this.authService.setNewPassword(setNewPasswordDto);
      res.status(200).json({
        message: 'Reset Password Successfully',
      });
    } catch (error) {
      next(error);
    }
  };

  public refreshToken = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { refreshToken } = plainToInstance(RefreshNewTokenRequestDto, req.body);
      const userId = await this.authService.verifyRefreshToken(refreshToken);
      const user = await Users.query().withGraphFetched('warehouseVN').findById(userId);
      const tokenData = this.authService.createToken(user);
      const cookie = this.authService.createCookie(tokenData);

      res.setHeader('Set-Cookie', [cookie]);
      res.status(200).json({ ...tokenData, message: 'refreshToken' });
    } catch (error) {
      next(error);
    }
  };

  public changePassword = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const changePassword: ChangePasswordDto = req.body;
      const { id } = req.user;
      const { cookie, loginData } = await this.authService.changePassword(id, changePassword);
      res.setHeader('Set-Cookie', [cookie]);
      res.status(200).json({
        token: loginData.token,
        refreshToken: loginData.refreshToken,
        expiresIn: loginData.expiresIn,
        data: {
          id: loginData.id,
          customerName: loginData.customerName,
          username: loginData.username,
          email: loginData.email.toLowerCase(),
          businessPartnerId: loginData.businessPartnerId,
          warehouseVN: loginData.warehouseVN,
          type: loginData.type,
        },
        role: loginData.role,
      });
    } catch (error) {
      next(error);
    }
  };

  public changeRole = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { userId, roleId } = req.params;
      const data = await this.authService.changeRole(userId, roleId);
      res.status(200).json({ data, message: 'update success' });
    } catch (error) {
      next(error);
    }
  };
}

export default AuthController;
