import { NextFunction, Request, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import CustomerService from '@/services/customer.service';
import { Customer } from '@/models/customer.model.';
import { ChangePasswordDto } from '@/dtos/change-password.dto';
class CustomerController {
  private service = CustomerService.getInstant();

  public findUserByCustomerByEmail = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { id } = req.user;
      const data: any = await this.service.findCustomerById(id);

      res.status(200).json({ data, message: 'customer info' });
    } catch (error) {
      next(error);
    }
  };

  // public updateCustomer = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
  //   try {
  //     const { user } = req;
  //     const userData = req.body;
  //     const updateUserData: Customer = await this.service.updateCustomer(user.email, userData);

  //     res.status(200).json({ data: updateUserData, message: 'updated' });
  //   } catch (error) {
  //     next(error);
  //   }
  // };

  public listCustomer = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data = await this.service.findAllCustomer(req, req.query);
      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public listCustomerTag = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data = await this.service.findAllCustomerTag();
      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public searchCustomer = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data = await this.service.searchAllCustomer(req, req.query.keyword);
      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public deleteCustomer = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { id } = req.params;
      const data = await this.service.deleteCustomer(id);
      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public changePasswordCustomer = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const changePassword: ChangePasswordDto = req.body;
      const { id } = req.params;
      const data = await this.service.changePasswordCustomer(id, changePassword);
      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getCustomerById = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { id } = req.params;
      const data = await this.service.findCustomerById(id);
      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getTrackingsByCustomerId = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { id } = req.params;
      const data = await this.service.findTrackingsByCustomerId(id, req.query);
      data.error_message = '';
      data.message = 'success';
      res.status(200).json(data);
    } catch (error) {
      next(error);
    }
  };

  public getOrdersByCustomerId = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { id } = req.params;
      const data = await this.service.findOrdersByCustomerId(id, req.query);
      data.error_message = '';
      data.message = 'success';
      res.status(200).json(data);
    } catch (error) {
      next(error);
    }
  };

  public getTransactionsByCustomerId = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { id } = req.params;
      const data = await this.service.findTransactionsByCustomerId(id, req.query);
      data.error_message = '';
      data.message = 'success';
      res.status(200).json(data);
    } catch (error) {
      next(error);
    }
  };

  public updateCurrentCustomerAccountInfo = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { id } = req.user.customer;
      const { name, nickName, email, phone, birthday, gender, avatar_url, address, isSubcribeToEmailNotification, isSubcribeToFcmNotification } =
        req.body;
      const userData = {
        name,
        nickName,
        email,
        phone,
        birthday,
        gender,
        avatar_url,
        address,
        isSubcribeToEmailNotification,
        isSubcribeToFcmNotification,
      };
      const data = await this.service.updateCustomerInfo(id, userData);
      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public deleteCurrentCustomerAccount = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data = await this.service.deleteCustomer(req?.user?.customer?.id);
      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public updateCustomerInfo = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const userData = req.body;
      const { id } = req.params;
      const data = await this.service.updateCustomerInfo(id, userData);
      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public addCustomer = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const userData = req.body;
      const { user } = req;
      const data = await this.service.addCustomer(userData, user);
      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public findAllTrackingType = async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const data = await this.service.getAllTrackingType();
      res.status(200).json({ data, error_message: '', message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public exportCustomer = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.service.findAllCustomer(req, { pageSize: 9999 });
      await this.service.exportExcel(data, res);
    } catch (error) {
      next(error);
    }
  };
}

export default CustomerController;
