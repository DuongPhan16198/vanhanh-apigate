import { NextFunction, Request, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import NewsCategoryService from '@/services/category.service';
class NewsCategoryController {
  private service = NewsCategoryService.getInstant();

  public getAllNewsCategories = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.service.getAllNewsCategories();
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };
}

export default NewsCategoryController;
