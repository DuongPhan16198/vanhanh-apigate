import { NextFunction, Request, Response } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import OverviewReportService from '@/services/overviewReport.service';

class OverviewReportController {
  private service = OverviewReportService.getInstant();

  public getOverviewReport = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const data = await this.service.getOverviewReport(user);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getRevenueByWarehouseReport = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const queries = req.query;
      const data = await this.service.getOverviewRevenueByWarehouse(user, queries);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getRevenueByWarehouseDetailByTypeReport = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const queries = req.query;
      const { id } = req.params;
      const data = await this.service.getOverviewRevenueByWarehouseDetail(user, queries, id);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getRevenueByDeliveryBillBySaleReport = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const queries = req.query;
      const data = await this.service.getOverviewRevenueByDeliveryBillSale(user, queries);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getRevenueByDeliveryBillByCustomerReport = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const queries = req.query;
      const data = await this.service.getOverviewRevenueByDeliveryBillCustomer(user, queries, true);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getRevenueByAwbReport = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const queries = req.query;
      const data = await this.service.getOverviewRevenueByAwb(user, queries);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getRevenueByTrackingReport = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const queries = req.query;
      const data = await this.service.getTrackingStatistic(user, queries);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getExploitationReport = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const queries = req.query;
      const data = await this.service.getExploitationStatistic(user, queries, true);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public getDetailDeliveryBillReport = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const queries = req.query;
      const { id } = req.params;
      const data = await this.service.getDetailRevenueByDeliveryBillSale(user, id, queries);
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };

  public exportDeliveryBillReport = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const queries = req.query;
      const data = await this.service.getRevenueByDeliveryReport(user, queries);
      await this.service.exportExcelDeliveryBillReport(data, res);
    } catch (error) {
      next(error);
    }
  };

  public exportExploitationReport = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const queries = req.query;
      const data = await this.service.getExploitationStatistic(user, queries, false);
      await this.service.exportExcel(data, res);
    } catch (error) {
      next(error);
    }
  };

  public exportRevenueReportByCustomer = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const { user } = req;
      const queries = req.query;
      const { data } = await this.service.getOverviewRevenueByDeliveryBillCustomer(user, queries, false);
      await this.service.exportExcelRevenueReportByCustomer(data, res);
    } catch (error) {
      next(error);
    }
  };
}

export default OverviewReportController;
