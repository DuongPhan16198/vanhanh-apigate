import { NextFunction, Request, Response, query } from 'express';
import { RequestWithUser } from '@interfaces/auth.interface';
import WarehouseService from '@/services/warehouse.service';

class WarehouseController {
  private service = WarehouseService.getInstant();

  public getAllWarhouseConfig = async (req: RequestWithUser, res: Response, next: NextFunction) => {
    try {
      const data = await this.service.getAllWarehouseVn();
      return res.status(200).json({ data, message: 'success' });
    } catch (error) {
      next(error);
    }
  };
}

export default WarehouseController;
