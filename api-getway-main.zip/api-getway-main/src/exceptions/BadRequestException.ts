import { HttpException } from './HttpException';
export default class BadRequestException extends HttpException {
  constructor(msg: string) {
    super(400, msg);
  }
}
