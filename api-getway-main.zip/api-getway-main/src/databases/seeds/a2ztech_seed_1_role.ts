import { Knex } from 'knex';

export async function seed(knex: Knex): Promise<void> {
  // Deletes ALL existing entries
  await knex('up_roles').update('is_delete', true);

  await knex('up_roles').insert([
    {
      id: 9,
      name: 'Quản lý',
      description: 'Quản lý',
      type: 'quan_ly',
      created_at: '2023-01-27 15:17:25.989',
      updated_at: '2023-01-27 15:17:25.989',
      is_delete: false,
    },
    {
      id: 7,
      name: 'Kế toán',
      description: 'Kế toán',
      type: 'ke_toan',
      created_at: '2023-01-27 15:17:25.989',
      updated_at: '2023-01-27 15:17:25.989',
      is_delete: false,
    },
    {
      id: 11,
      name: 'Nhân viên kinh doanh',
      description: 'Nhân viên kinh doanh',
      type: 'nhan_vien_kinh_doanh',
      created_at: '2023-01-27 15:17:25.989',
      updated_at: '2023-01-27 15:17:25.989',
      is_delete: false,
    },
    {
      id: 8,
      name: 'Nhân viên khai thác',
      description: 'Nhân viên khai thác',
      type: 'nhan_vien_khai_thac',
      created_at: '2023-01-27 15:17:25.989',
      updated_at: '2023-01-27 15:17:25.989',
      is_delete: false,
    },
    {
      id: 10,
      name: 'Nhân viên CSKH',
      description: 'Nhân viên chăm sóc khách hàng',
      type: 'nhan_vien_cskh',
      created_at: '2023-01-27 15:17:25.989',
      updated_at: '2023-01-27 15:17:25.989',
      is_delete: false,
    },
  ]);
  await knex('up_roles')
    .update({
      id: 1,
      name: 'Super Admin',
      description: 'Tài khoản quản trị',
      type: 'admin',
      created_at: '2023-01-27 12:37:34.506',
      updated_at: '2023-03-30 09:46:42.357',
      is_delete: false,
    })
    .where('id', 1);
  await knex('up_roles')
    .update({
      id: 3,
      name: 'Khách hàng',
      description: 'Khách hàng của hệ thống',
      type: 'khach_hang',
      created_at: '2023-01-27 15:17:25.989',
      updated_at: '2023-04-10 04:02:45.41',
      is_delete: false,
    })
    .where('id', 3);
  // await knex('up_roles').del();

  await knex('up_users_role_links').whereIn('role_id', [4, 5]).update('role_id', 8);

  await knex('up_roles').where('is_delete', true).del();

  await knex('up_roles')
  .max('id as maxId')
  .then(result => {
    const maxId = result[0].maxId || 0;

    // Set the next value of the sequence to be greater than the maximum 'id'
    const rawQuery = `SELECT pg_catalog.setval(pg_get_serial_sequence('up_roles', 'id'), ${maxId})`;

    return knex.raw(rawQuery);
  })
}
