import { Knex } from 'knex';

export async function seed(knex: Knex): Promise<void> {
  // Deletes ALL existing entries
  await knex('up_permissions').del();

  // Inserts seed entries
  await knex('up_permissions').insert([
    {
      id: 595,
      action: 'api:: GET /api/customers/customer-tag',
      description: 'Lấy danh sách tag customer',
    },
    {
      id: 40,
      action: 'api:: GET /api/trackings',
      description: 'Lấy ra danh sách tracking',
      business_logic: JSON.stringify([
        { id: 1, label: 'Được quyền xem toàn bộ tracking' },
        { id: 2, label: '(Sale) Được quyền xem các tracking của khách hàng được giao phụ trách' },
        { id: 3, label: 'Được quyền xem các tracking do kho mình phụ trách' },
        { id: 4, label: '(Nhân viên CSKH) Được quyền xem các tracking của khách hàng được giao hỗ trợ' },
        { id: 5, label: '(Khách hàng) Được quyền xem các tracking chưa có khách hàng' },
      ]),
    },

    {
      id: 98,
      action: 'api:: GET /api/employees/role',
      description: 'Lấy danh sách các vai trò của nhân viên',
    },
    {
      id: 84,
      action: 'api:: GET /api/customers/tracking-type',
      description: 'Lấy ra danh sách các mặt hàng',
    },

    {
      id: 14,
      action: 'api:: GET /api/awbs/status',
      description: 'Lấy ra danh sách trạng thái của AWB',
    },
    {
      id: 95,
      action: 'api:: GET /api/employees/get-sale',
      description: 'Tìm kiếm danh sách nhân viên sale',
    },
    {
      id: 46,
      action: 'api:: GET /api/trackings/:id',
      description: 'Lấy ra chi tiết tracking',
    },
    {
      id: 5,
      action: 'api:: POST /api/auth/logout',
      description: 'Đăng xuất',
    },
    {
      id: 10,
      action: 'api:: POST /api/auth/reset_password',
      description: 'Reset mật khẩu',
    },
    {
      id: 11,
      action: 'api:: POST /api/auth/change_password',
      description: 'Đổi mật khẩu',
    },
    {
      id: 13,
      action: 'api:: GET /api/awbs/list',
      description: 'Lấy ra danh sách các AWB',
      business_logic: JSON.stringify([
        { id: 1, label: 'Được quyền xem danh sách tất cả các awb' },
        { id: 2, label: 'Được quyền xem danh sách các awb chứa box thuộc kho mà mình phụ trách' },
      ]),
    },
    {
      id: 50,
      action: 'api:: GET /api/delivery_bills/status_update_bill',
      description: 'Lấy ra danh sách các trạng thái PXK',
    },
    {
      id: 51,
      action: 'api:: GET /api/delivery_bills',
      description: 'Lấy ra danh sách các PXK',
      business_logic: JSON.stringify([
        { id: 1, label: 'Được quyền xem danh sách tất cả các PXK' },
        { id: 2, label: '(Sale) Được quyền xem danh sách PXK chứa đơn hàng của khách hàng do mình phụ trách' },
        { id: 3, label: 'Được quyền xem  danh sách PXK của kho mình phụ trách' },
        { id: 4, label: '(Nhân viên CSKH) Được quyền xem danh sách PXK chứa đơn hàng của khách hàng do mình hỗ trợ' },
        { id: 5, label: '(Khách hàng) Được quyền xem danh sách PXK chứa đơn hàng của mình' },
      ]),
    },
    {
      id: 52,
      action: 'api:: GET /api/delivery_bills/:id/search_tracking',
      description: 'Tìm PXK/Tracking',
    },
    {
      id: 53,
      action: 'api:: GET /api/delivery_bills/waiting_create_delivery_bills',
      description: 'Danh sách khách hàng chờ đợi tạo PXK',
      business_logic: JSON.stringify([
        { id: 1, label: 'Được quyền lấy ra tất cả các khách hàng' },
        { id: 2, label: '(Sale) Được quyền lấy ra khách hàng do mình phụ trách' },
        { id: 3, label: '(Nhân viên CSKH) Được quyền lấy ra khách hàng do mình hỗ trợ' },
      ]),
    },
    {
      id: 54,
      action: 'api:: GET /api/delivery_bills/:id/tracking_customer_detail',
      description: 'Danh sách tracking của khách hàng chưa được xuất kho',
    },
    {
      id: 56,
      action: 'api:: GET /api/delivery_bills/:id',
      description: 'Lấy ra chi tiết PXK',
    },
    {
      id: 58,
      action: 'api:: PUT /api/delivery_bills/:id',
      description: 'Cập nhật PXK',
    },
    {
      id: 60,
      action: 'api:: POST /api/delivery_bills/:id/create_many_tracking_in_bill',
      description: 'Tạo nhiều tracking cùng lúc cho PXK',
    },
    {
      id: 61,
      action: 'api:: DELETE /api/delivery_bills/:id/delete_tracking_in_bill',
      description: 'Xóa tracking trong PXK',
    },
    {
      id: 66,
      action: 'api:: GET /api/transactions',
      description: 'Lấy ra danh sách các giao dịch',
      business_logic: JSON.stringify([
        { id: 1, label: 'Được quyền xem danh sách tất cả các giao dịch' },
        { id: 2, label: '(Sale) Được quyền xem danh sách các giao dịch của khách hàng do mình phụ trách' },
        { id: 3, label: 'Được quyền xem danh sách các giao dịch do mình tạo' },
        { id: 4, label: '(Nhân viên CSKH) Được quyền xem danh sách các giao dịch của khách hàng do mình hỗ trợ' },
        { id: 5, label: '(Khách hàng) Được quyền xem danh sách các giao dịch của mình' },
      ]),
    },
    {
      id: 67,
      action: 'api:: GET /api/transactions/:id/customer-detail',
      description: 'Lấy ra danh sách các giao dịch theo id khách hàng',
    },
    {
      id: 68,
      action: 'api:: GET /api/transactions/:id',
      description: 'Lấy ra chi tiết giao dịch',
    },
    {
      id: 69,
      action: 'api:: POST /api/transactions',
      description: 'Tạo giao dịch',
    },
    {
      id: 70,
      action: 'api:: PUT /api/transactions/:id',
      description: 'Sửa giao dịch',
    },
    {
      id: 71,
      action: 'api:: GET /api/users/is_logged',
      description: 'Lấy ra thông tin của tài khoản đang đăng nhập',
    },
    {
      id: 79,
      action: 'api:: GET /api/permissions/list',
      description: 'Lấy ra danh sách các quyền',
    },
    {
      id: 80,
      action: 'api:: POST /api/permissions/create',
      description: 'Tạo quyền mới',
    },
    {
      id: 81,
      action: 'api:: GET /api/customers',
      description: 'Lấy ra danh sách các khách hàng',
      business_logic: JSON.stringify([
        { id: 1, label: 'Được quyền xem danh sách tất cả các khách hàng' },
        { id: 2, label: '(Sale) Được quyền xem danh sách khách hàng do mình phụ trách' },
        { id: 3, label: '(Nhân viên CSKH) Được quyền xem danh sách khách hàng do mình hỗ trợ' },
      ]),
    },
    {
      id: 82,
      action: 'api:: POST /api/customers',
      description: 'Thêm khách hàng mới',
    },
    {
      id: 83,
      action: 'api:: GET /api/customers/search',
      description: 'Tìm kiếm khách hàng',
      business_logic: JSON.stringify([
        { id: 1, label: 'Được quyền tìm tất cả các khách hàng' },
        { id: 2, label: '(Sale) Được quyền tìm khách hàng do mình phụ trách' },
        { id: 3, label: '(Nhân viên CSKH) Được quyền tìm khách hàng do mình hỗ trợ' },
      ]),
    },
    {
      id: 86,
      action: 'api:: GET /api/customers/:id',
      description: 'Lấy ra thông tin khách hàng theo id',
    },
    {
      id: 87,
      action: 'api:: PUT /api/customers/:id',
      description: 'Sửa thông tin khách hàng',
    },
    {
      id: 88,
      action: 'api:: GET /api/customers/:id/trackings',
      description: 'Lấy ra danh sách các tracking của khách hàng',
    },
    {
      id: 89,
      action: 'api:: GET /api/customers/:id/orders',
      description: 'Lấy ra danh sách các đơn hàng của khách hàng',
    },
    {
      id: 90,
      action: 'api:: GET /api/customers/:id/transactions',
      description: 'Lấy ra danh sách các giao dịch của khách hàng',
    },
    {
      id: 92,
      action: 'api:: DELETE /api/customers/:id',
      description: 'Xóa khách hàng',
    },
    {
      id: 93,
      action: 'api:: GET /api/employees',
      description: 'Lấy ra danh sách tất cả nhân viên',
    },
    {
      id: 96,
      action: 'api:: GET /api/employees/get-employee-exploit',
      description: 'Lấy ra danh sách nhân viên khai thác',
    },
    {
      id: 97,
      action: 'api:: GET /api/employees/search',
      description: 'Tìm kiếm nhân viên',
    },
    {
      id: 99,
      action: 'api:: GET /api/employees/permissions',
      description: 'Lấy ra danh sách các quyền của nhân viên',
    },
    {
      id: 100,
      action: 'api:: GET /api/employees/:id/customers',
      description: 'Lấy ra danh sách các nhân viên ứng với khách hàng',
    },
    {
      id: 101,
      action: 'api:: GET /api/employees/:id',
      description: 'Lấy ra chi tiết nhân viên',
    },
    {
      id: 102,
      action: 'api:: PUT /api/employees/:id',
      description: 'Sửa thông tin nhân viên',
    },
    {
      id: 55,
      action: 'api:: GET /api/delivery_bills/:id/bill_customer_detail',
      description: 'Lấy ra danh sách các PXK của khách hàng',
    },
    {
      id: 9,
      action: 'api:: POST /api/auth/refresh-token',
      description: 'Refresh token',
    },
    {
      id: 124,
      action: 'api:: GET /api/roles/:id',
      description: 'Lấy thông tin chi tiết của role ',
    },
    {
      id: 49,
      action: 'api:: DELETE /api/trackings/:id',
      description: 'Xóa tracking',
    },
    {
      id: 47,
      action: 'api:: PUT /api/trackings/:id',
      description: 'Cập nhật tracking',
    },
    {
      id: 43,
      action: 'api:: GET /api/trackings/:id/detail-customer',
      description: 'Lấy danh sách tracking chi tiết của khách hàng',
    },
    {
      id: 44,
      action: 'api:: POST /api/trackings/:id/create-order',
      description: 'Tạo đơn hàng cho tracking',
    },
    {
      id: 45,
      action: 'api:: POST /api/trackings/:id/check-request',
      description: 'Gửi yêu cầu kiểm tra tracking cho kho',
    },
    {
      id: 42,
      action: 'api:: GET /api/trackings/status',
      description: 'Lấy ra danh sách trạng thái tracking',
    },
    {
      id: 41,
      action: 'api:: GET /api/trackings/type',
      description: 'Lấy ra danh sách các mặt hàng',
    },
    {
      id: 589,
      action: 'api:: GET /api/general_configs/:id',
      description: 'Lấy thông tin cấu hình chi tiết',
    },
    {
      id: 15,
      action: 'api:: GET /api/awbs/check-ready',
      description: 'Lấy ra danh sách các AWB chưa đồng bộ',
    },
    {
      id: 16,
      action: 'api:: GET /api/awbs/search',
      description: 'Tìm kiếm AWB',
    },
    {
      id: 17,
      action: 'api:: GET /api/awbs/:id',
      description: 'Lấy chi tiết AWB',
      business_logic: JSON.stringify([
        { id: 1, label: 'Được quyền xem tiết awb bao gồm list tất cả các box' },
        { id: 2, label: 'Được quyền xem tiết awb bao gồm list các box chứa thuộc kho mình phụ trách' },
      ]),
    },
    {
      id: 19,
      action: 'api:: POST /api/awbs/sync',
      description: 'Đồng bộ AWB từ kho',
    },
    {
      id: 22,
      action: 'api:: GET /api/boxes/:id/trackings',
      description: 'Lấy ra các trackings của thùng hàng',
    },
    {
      id: 24,
      action: 'api:: PUT /api/boxes/:id/import',
      description: 'Nhập thùng hàng vào kho',
    },
    {
      id: 34,
      action: 'api:: POST /api/trackings/create_many',
      description: 'Tạ̣o nhiều tracking',
    },
    {
      id: 35,
      action: 'api:: POST /api/trackings/create_many/:box_id',
      description: 'Tạ̣o nhiều tracking cho thùng hàng',
    },
    {
      id: 37,
      action: 'api:: GET /api/trackings/suggestion/:code',
      description: 'Gợi ý mã tracking',
    },
    {
      id: 103,
      action: 'api:: POST /api/employees',
      description: 'Tạo nhân viên mới',
    },
    {
      id: 104,
      action: 'api:: DELETE /api/employees/:id',
      description: 'Xóa nhân viên',
    },
    {
      id: 105,
      action: 'api:: GET /api/orders',
      description: 'Lấy ra danh sách các đơn hàng',
      business_logic: JSON.stringify([
        { id: 1, label: 'Được quyền xem danh sách tất cả các đơn hàng' },
        { id: 2, label: '(Sale) Được quyền xem danh sách đơn hàng của khách hàng do mình phụ trách' },
        { id: 3, label: 'Được quyền xem danh sách đơn hàng của kho do mình phụ trách' },
        { id: 4, label: '(Nhân viên CSKH) Được quyền xem danh sách đơn hàng của khách hàng do mình hỗ trợ' },
        { id: 5, label: '(Khách hàng) Được quyền xem danh sách đơn hàng của mình' },
      ]),
    },
    {
      id: 106,
      action: 'api:: GET /api/orders/:id',
      description: 'Lấy ra chi tiết đơn hàng',
    },
    {
      id: 107,
      action: 'api:: PUT /api/orders/:id',
      description: 'Sửa đơn hàng',
    },
    {
      id: 108,
      action: 'api:: POST /api/orders',
      description: 'Tạo đơn hàng',
    },
    {
      id: 109,
      action: 'api:: GET /api/warehouses/warehouse-config',
      description: 'Lấy ra danh sách cấu hình kho VN',
    },
    {
      id: 110,
      action: 'api:: GET /api/report/overview',
      description: 'Lấy ra báo cáo tổng quan',
    },
    {
      id: 111,
      action: 'api:: GET /api/report/revenue/warehouse',
      description: 'Lấy ra báo cáo doanh thu theo kho',
    },
    {
      id: 112,
      action: 'api:: GET /api/report/revenue/delivery_bill/sale',
      description: 'Lấy ra báo cáo doanh thu theo PXK, thống kê theo sale',
    },
    {
      id: 125,
      action: 'api:: GET /api/business_partners',
      description: 'Danh sách thông tin đối tác',
    },
    {
      id: 18,
      action: 'api:: PUT /api/awbs/update/:id',
      description: 'Cập nhật AWB',
    },
    {
      id: 25,
      action: 'api:: GET /api/roles/list',
      description: 'Lấy danh sách role',
    },
    {
      id: 27,
      action: 'api:: POST /api/roles/create',
      description: 'Tạo role mới',
    },
    {
      id: 28,
      action: 'api:: PUT /api/roles/update/:id',
      description: 'Cập nhật role',
    },
    {
      id: 29,
      action: 'api:: DELETE /api/roles/delete/:id',
      description: 'Xóa role',
    },
    {
      id: 588,
      action: 'api:: POST /api/awbs/import_excel',
      description: 'Đồng bộ Awb bằng excel',
    },

    {
      id: 113,
      action: 'api:: GET /api/report/revenue/delivery_bill/customer',
      description: 'Lấy ra báo cáo doanh thu theo PXK, thống kê theo khách hàng',
    },
    {
      id: 114,
      action: 'api:: GET /api/report/revenue/awb',
      description: 'Lấy ra báo cáo doanh thu theo AWB',
    },
    {
      id: 115,
      action: 'api:: GET /api/report/revenue/tracking',
      description: 'Lấy ra báo cáo doanh thu theo tracking ',
    },
    {
      id: 116,
      action: 'api:: GET /api/report/exploitation',
      description: 'Lấy ra báo cáo khai thác',
    },
    {
      id: 117,
      action: 'api:: GET /api/general_configs/box-coefficient-config',
      description: 'Lấy ra cấu hình hệ số thùng',
    },
    {
      id: 118,
      action: 'api:: PUT /api/general_configs/box-coefficient-update/:id',
      description: 'Sửa cấu hình hệ số thùng',
    },
    {
      id: 119,
      action: 'api:: GET /api/general_configs/interfaces',
      description: 'Lấy ra giao diện cấu hình chung',
    },
    {
      id: 121,
      action: 'api:: POST /api/general_configs',
      description: 'Tạo cấu hình mới',
    },
    {
      id: 123,
      action: 'api:: DELETE /api/general_configs/:id',
      description: 'Xóa cấu hình',
    },
    {
      id: 122,
      action: 'api:: PUT /api/general_configs/:id',
      description: 'Sửa cấu hình',
    },
    {
      id: 120,
      action: 'api:: GET /api/general_configs/list',
      description: 'Lấy ra danh sách các cấu hình',
      business_logic: JSON.stringify([
        { id: 1, label: 'Lấy ra các cấu hình có mức độ giới hạn: Quản lí vận hành' },
        { id: 2, label: 'Lấy ra cấu hình có mức độ giới hạn: Khách hàng' },
      ]),
    },
    {
      id: 593,
      action: 'api:: PUT /api/trackings/:id/exploit',
      description: 'Khai thác tracking',
    },
    {
      id: 594,
      action: 'api:: POST /api/trackings/sync-tracking',
      description: 'Đồng bộ tracking',
    },
    {
      id: 30,
      action: 'api:: GET /api/trackings/find-from-warehouse',
      description: 'Tìm kiếm thông tin tracking từ tất cả các kho',
    },
    {
      id: 597,
      action: 'api:: POST /api/delivery_bills',
      description: 'Tạo PXK',
    },
    {
      id: 598,
      action: 'api:: PUT /api/delivery_bills/:id/sale_approve_delivery_bills',
      description: 'Sale duyệt PXK',
    },
    {
      id: 599,
      action: 'api:: PUT /api/delivery_bills/:id/accountant_approve_delivery_bills',
      description: 'Kế toán duyệt PXK',
    },
    {
      id: 600,
      action: 'api:: PUT /api/delivery_bills/:id/print_delivery_bills',
      description: 'Khách hàng xác nhận - Tạo yêu cầu xuất kho',
    },
    {
      id: 601,
      action: 'api:: PUT /api/delivery_bills/:id/export_delivery_bills',
      description: 'Đóng hàng trong PXK',
    },
    {
      id: 602,
      action: 'api:: PUT /api/delivery_bills/:id/pack_delivery_bills',
      description: 'Xác nhận giao hàng',
    },
    {
      id: 603,
      action: 'api:: PUT /api/delivery_bills/:id/finish_delivery_bills',
      description: 'Hoàn thành PXK',
    },
    {
      id: 604,
      action: 'api:: PUT /api/delivery_bills/:id/failed_delivery_bills',
      description: 'Xác nhận PXK giao hàng không thành công',
    },
    {
      id: 605,
      action: 'api:: PUT /api/delivery_bills/:id/cancel_delivery_bills',
      description: 'Hủy PXK',
      business_logic: JSON.stringify([
        { id: 1, label: 'Cấp độ quản lí: Được quyền hủy cả khi đã đóng hàng' },
        { id: 2, label: 'Cấp độ nhân viên vận hành: Được quyền hủy trước khi đóng hàng' },
      ]),
    },
    {
      id: 606,
      action: 'api:: POST /api/news',
      description: 'Tạo ra bài viết tin tức',
    },
    {
      id: 607,
      action: 'api:: PUT /api/news/:id',
      description: 'Cập nhập bài viết tin tức',
    },
    {
      id: 608,
      action: 'api:: DELETE /api/news/:id',
      description: 'Xóa bài viết tin tức',
    },
    {
      id: 609,
      action: 'api:: POST /api/pages',
      description: 'Tạo cấu hình trang',
    },
    {
      id: 610,
      action: 'api:: PUT /api/pages/:id',
      description: 'Cập nhập cấu hình trang',
    },
    {
      id: 611,
      action: 'api:: DELETE /api/pages/:id',
      description: 'Xóa cấu hình trang',
    },
    {
      id: 612,
      action: 'api:: POST /api/report/exploitation/export',
      description: 'Xuất file Excel cho báo cáo thống kê khai thác',
    },
    {
      id: 613,
      action: 'api:: POST /api/delivery_units',
      description: 'Thêm đơn vị vận chuyển',
    },
    {
      id: 614,
      action: 'api:: PUT /api/delivery_units/:id',
      description: 'Cập nhập đơn vị vận chuyển',
    },
    {
      id: 615,
      action: 'api:: DELETE /api/delivery_units/:id',
      description: 'Xóa đơn vị vận chuyển',
    },
    {
      id: 616,
      action: 'api:: GET /api/delivery_units',
      description: 'Lấy danh sách đơn vị vận chuyển',
    },
    {
      id: 617,
      action: 'api:: GET /api/delivery_units/:id',
      description: 'Lấy ra chi tiết đơn vị vận chuyển',
    },
    {
      id: 618,
      action: 'api:: GET /api/delivery_bills/trackings',
      description: 'Lấy ra các tracking của tài khoản khách hàng hiện tại',
    },
    {
      id: 619,
      action: 'api:: GET /api/vn_delivery_orders',
      description: 'Lấy ra danh sách các vận đơn Việt Nam',
      business_logic: JSON.stringify([
        { id: 1, label: 'Được quyền xem danh sách tất cả các vận đơn' },
        { id: 2, label: '(Sale) Được quyền xem danh sách vận đơn chứa đơn hàng của khách hàng do mình phụ trách' },
        { id: 3, label: 'Được quyền xem  danh sách vận đơn của kho mình phụ trách' },
        { id: 4, label: '(Nhân viên CSKH) Được quyền xem danh sách vận đơn chứa đơn hàng của khách hàng do mình hỗ trợ' },
        { id: 5, label: '(Khách hàng) Được quyền xem danh sách vận đơn chứa đơn hàng của mình' },
      ]),
    },
    {
      id: 620,
      action: 'api:: GET /api/vn_delivery_orders/:id',
      description: 'Lấy ra chi tiết vận đơn Việt Nam',
    },
    {
      id: 621,
      action: 'api:: POST /api/vn_delivery_orders',
      description: 'Tạo vận đơn Việt Nam',
    },
    {
      id: 622,
      action: 'api:: PUT /api/vn_delivery_orders/:id',
      description: 'Cập nhật thông tin vận đơn Việt nam',
    },
    {
      id: 623,
      action: 'api:: DELETE /api/vn_delivery_orders/:id',
      description: 'Xóa vận đơn Việt Nam',
    },
    {
      id: 624,
      action: 'api:: POST /api/fcm_tokens',
      description: 'Gửi token lên server',
    },
    {
      id: 625,
      action: 'api:: DELETE /api/orders/:id',
      description: 'Hủy đơn hàng',
    },
    {
      id: 626,
      action: 'api:: PUT /api/customer_accounts',
      description: 'Thay đổi thông tin tài khoản customer đang đăng nhập',
    },
    {
      id: 627,
      action: 'api:: PUT /api/fcm_tokens/dev_time_only',
      description: 'Broadcast notification to all device',
    },
    {
      id: 628,
      action: 'api:: DELETE /api/customer_accounts',
      description: 'Xóa tài khoản customer đang đăng nhập',
    },
    {
      id: 629,
      action: 'api:: GET /api/delivery_bills/:id/export_excel',
      description: 'Xuất excel cho PXK',
    },
    {
      id: 630,
      action: 'api:: PUT /api/delivery_bills/:id/pack_tracking_in_bill',
      description: 'Đóng hàng tracking ở trong bill',
    },
    {
      id:631,
      action: 'api:: GET /api/report/revenue/delivery_bill/sale/export_excel',
      description: 'Xuất excel cho thống kê doanh thu theo PXK của Sale',
    }
  ]);

  await knex('up_permissions')
    .max('id as maxId')
    .then(result => {
      const maxId = result[0].maxId || 0;

      // Set the next value of the sequence to be greater than the maximum 'id'
      const rawQuery = `SELECT pg_catalog.setval(pg_get_serial_sequence('up_permissions', 'id'), ${maxId})`;

      return knex.raw(rawQuery);
    });
}
