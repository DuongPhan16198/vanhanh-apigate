import { Knex } from 'knex';

export async function seed(knex: Knex): Promise<void> {
  // Deletes ALL existing entries
  await knex('up_permissions_role_links').del();

  // Inserts seed entries
  await knex('up_permissions_role_links').insert([
    {
      id: 934,
      permission_id: 5,
      role_id: 3,
    },
    {
      id: 935,
      permission_id: 9,
      role_id: 3,
    },
    {
      id: 936,
      permission_id: 10,
      role_id: 3,
    },
    {
      id: 937,
      permission_id: 11,
      role_id: 3,
    },
    {
      id: 4358,
      permission_id: 9,
      role_id: 7,
    },
    {
      id: 4361,
      permission_id: 11,
      role_id: 7,
    },
    {
      id: 4362,
      permission_id: 13,
      role_id: 7,
      permission_business_logic_id: 1,
    },
    {
      id: 4363,
      permission_id: 14,
      role_id: 7,
    },
    {
      id: 4366,
      permission_id: 30,
      role_id: 7,
    },
    {
      id: 4367,
      permission_id: 40,
      role_id: 7,
      permission_business_logic_id: 1,
    },
    {
      id: 4370,
      permission_id: 43,
      role_id: 7,
    },
    {
      id: 4372,
      permission_id: 50,
      role_id: 7,
    },
    {
      id: 4374,
      permission_id: 52,
      role_id: 7,
    },
    {
      id: 4376,
      permission_id: 56,
      role_id: 7,
    },
    {
      id: 4377,
      permission_id: 605,
      role_id: 7,
    },
    {
      id: 4380,
      permission_id: 68,
      role_id: 7,
    },
    {
      id: 4381,
      permission_id: 69,
      role_id: 7,
    },
    {
      id: 4382,
      permission_id: 70,
      role_id: 7,
    },
    {
      id: 4385,
      permission_id: 81,
      role_id: 7,
      permission_business_logic_id: 1,
    },
    {
      id: 4386,
      permission_id: 84,
      role_id: 7,
    },
    {
      id: 4387,
      permission_id: 83,
      role_id: 7,
      permission_business_logic_id: 1,
    },
    {
      id: 4390,
      permission_id: 88,
      role_id: 7,
    },
    {
      id: 4391,
      permission_id: 89,
      role_id: 7,
    },
    {
      id: 4394,
      permission_id: 96,
      role_id: 7,
    },
    {
      id: 4395,
      permission_id: 97,
      role_id: 7,
    },
    {
      id: 4518,
      permission_id: 5,
      role_id: 10,
    },
    {
      id: 4521,
      permission_id: 11,
      role_id: 10,
    },
    {
      id: 4522,
      permission_id: 13,
      role_id: 10,
      permission_business_logic_id: 1,
    },
    {
      id: 4523,
      permission_id: 14,
      role_id: 10,
    },
    {
      id: 4526,
      permission_id: 22,
      role_id: 10,
    },
    {
      id: 4528,
      permission_id: 34,
      role_id: 10,
    },
    {
      id: 4530,
      permission_id: 41,
      role_id: 10,
    },
    {
      id: 4532,
      permission_id: 43,
      role_id: 10,
    },
    {
      id: 4534,
      permission_id: 45,
      role_id: 10,
    },
    {
      id: 4537,
      permission_id: 52,
      role_id: 10,
    },
    {
      id: 4539,
      permission_id: 54,
      role_id: 10,
    },
    {
      id: 4542,
      permission_id: 597,
      role_id: 10,
    },
    {
      id: 4397,
      permission_id: 109,
      role_id: 7,
    },
    {
      id: 4399,
      permission_id: 110,
      role_id: 7,
    },
    {
      id: 4401,
      permission_id: 112,
      role_id: 7,
    },
    {
      id: 4403,
      permission_id: 115,
      role_id: 7,
    },
    {
      id: 4406,
      permission_id: 119,
      role_id: 7,
    },
    {
      id: 4408,
      permission_id: 124,
      role_id: 7,
    },
    {
      id: 4411,
      permission_id: 599,
      role_id: 7,
    },
    {
      id: 4413,
      permission_id: 9,
      role_id: 8,
    },
    {
      id: 4416,
      permission_id: 13,
      role_id: 8,
      permission_business_logic_id: 2,
    },
    {
      id: 4418,
      permission_id: 15,
      role_id: 8,
    },
    {
      id: 4423,
      permission_id: 22,
      role_id: 8,
    },
    {
      id: 4426,
      permission_id: 34,
      role_id: 8,
    },
    {
      id: 4429,
      permission_id: 40,
      role_id: 8,
      permission_business_logic_id: 3,
    },
    {
      id: 4430,
      permission_id: 41,
      role_id: 8,
    },
    {
      id: 4433,
      permission_id: 44,
      role_id: 8,
    },
    {
      id: 4434,
      permission_id: 45,
      role_id: 8,
    },
    {
      id: 4438,
      permission_id: 50,
      role_id: 8,
    },
    {
      id: 4439,
      permission_id: 51,
      role_id: 8,
      permission_business_logic_id: 3,
    },
    {
      id: 4442,
      permission_id: 61,
      role_id: 8,
    },
    {
      id: 4443,
      permission_id: 601,
      role_id: 8,
    },
    {
      id: 4446,
      permission_id: 69,
      role_id: 8,
    },
    {
      id: 4447,
      permission_id: 71,
      role_id: 8,
    },
    {
      id: 4450,
      permission_id: 106,
      role_id: 8,
    },
    {
      id: 4451,
      permission_id: 108,
      role_id: 8,
    },
    {
      id: 4454,
      permission_id: 125,
      role_id: 8,
    },
    {
      id: 4455,
      permission_id: 588,
      role_id: 8,
    },
    {
      id: 4458,
      permission_id: 593,
      role_id: 8,
    },
    {
      id: 4459,
      permission_id: 594,
      role_id: 8,
    },
    {
      id: 4462,
      permission_id: 10,
      role_id: 11,
    },
    {
      id: 4463,
      permission_id: 11,
      role_id: 11,
    },
    {
      id: 4466,
      permission_id: 17,
      role_id: 11,
      permission_business_logic_id: 1,
    },
    {
      id: 4468,
      permission_id: 30,
      role_id: 11,
    },
    {
      id: 4469,
      permission_id: 34,
      role_id: 11,
    },
    {
      id: 4472,
      permission_id: 42,
      role_id: 11,
    },
    {
      id: 4474,
      permission_id: 44,
      role_id: 11,
    },
    {
      id: 4475,
      permission_id: 45,
      role_id: 11,
    },
    {
      id: 4477,
      permission_id: 47,
      role_id: 11,
    },
    {
      id: 4479,
      permission_id: 51,
      role_id: 11,
      permission_business_logic_id: 2,
    },
    {
      id: 4482,
      permission_id: 54,
      role_id: 11,
    },
    {
      id: 4483,
      permission_id: 55,
      role_id: 11,
    },
    {
      id: 4486,
      permission_id: 597,
      role_id: 11,
    },
    {
      id: 4488,
      permission_id: 61,
      role_id: 11,
    },
    {
      id: 4491,
      permission_id: 601,
      role_id: 11,
    },
    {
      id: 4493,
      permission_id: 66,
      role_id: 11,
      permission_business_logic_id: 2,
    },
    {
      id: 4495,
      permission_id: 68,
      role_id: 11,
    },
    {
      id: 4496,
      permission_id: 69,
      role_id: 11,
    },
    {
      id: 4498,
      permission_id: 81,
      role_id: 11,
      permission_business_logic_id: 2,
    },
    {
      id: 4501,
      permission_id: 84,
      role_id: 11,
    },
    {
      id: 4502,
      permission_id: 86,
      role_id: 11,
    },
    {
      id: 4505,
      permission_id: 89,
      role_id: 11,
    },
    {
      id: 4519,
      permission_id: 9,
      role_id: 10,
    },
    {
      id: 4525,
      permission_id: 16,
      role_id: 10,
    },
    {
      id: 4529,
      permission_id: 40,
      role_id: 10,
      permission_business_logic_id: 4,
    },
    {
      id: 4531,
      permission_id: 42,
      role_id: 10,
    },
    {
      id: 4535,
      permission_id: 46,
      role_id: 10,
    },
    {
      id: 4536,
      permission_id: 51,
      role_id: 10,
      permission_business_logic_id: 4,
    },
    {
      id: 4540,
      permission_id: 55,
      role_id: 10,
    },
    {
      id: 4543,
      permission_id: 60,
      role_id: 10,
    },
    {
      id: 4359,
      permission_id: 10,
      role_id: 7,
    },
    {
      id: 4545,
      permission_id: 50,
      role_id: 10,
    },
    {
      id: 4547,
      permission_id: 81,
      role_id: 10,
      permission_business_logic_id: 3,
    },
    {
      id: 4548,
      permission_id: 67,
      role_id: 10,
    },
    {
      id: 4550,
      permission_id: 83,
      role_id: 10,
      permission_business_logic_id: 3,
    },
    {
      id: 4552,
      permission_id: 86,
      role_id: 10,
    },
    {
      id: 4554,
      permission_id: 88,
      role_id: 10,
    },
    {
      id: 4556,
      permission_id: 90,
      role_id: 10,
    },
    {
      id: 4558,
      permission_id: 105,
      role_id: 10,
      permission_business_logic_id: 4,
    },
    {
      id: 4560,
      permission_id: 108,
      role_id: 10,
    },
    {
      id: 4561,
      permission_id: 109,
      role_id: 10,
    },
    {
      id: 4563,
      permission_id: 119,
      role_id: 10,
    },
    {
      id: 4566,
      permission_id: 125,
      role_id: 10,
    },
    {
      id: 4567,
      permission_id: 589,
      role_id: 10,
    },
    {
      id: 4568,
      permission_id: 595,
      role_id: 10,
    },
    {
      id: 4569,
      permission_id: 9,
      role_id: 9,
    },
    {
      id: 4570,
      permission_id: 10,
      role_id: 9,
    },
    {
      id: 4571,
      permission_id: 11,
      role_id: 9,
    },
    {
      id: 4572,
      permission_id: 5,
      role_id: 9,
    },
    {
      id: 4573,
      permission_id: 13,
      role_id: 9,
      permission_business_logic_id: 1,
    },
    {
      id: 4574,
      permission_id: 14,
      role_id: 9,
    },
    {
      id: 4575,
      permission_id: 15,
      role_id: 9,
    },
    {
      id: 4576,
      permission_id: 16,
      role_id: 9,
    },
    {
      id: 4364,
      permission_id: 17,
      role_id: 7,
      permission_business_logic_id: 1,
    },
    {
      id: 4368,
      permission_id: 41,
      role_id: 7,
    },
    {
      id: 4371,
      permission_id: 46,
      role_id: 7,
    },
    {
      id: 4375,
      permission_id: 55,
      role_id: 7,
    },
    {
      id: 4379,
      permission_id: 67,
      role_id: 7,
    },
    {
      id: 4384,
      permission_id: 79,
      role_id: 7,
    },
    {
      id: 4388,
      permission_id: 86,
      role_id: 7,
    },
    {
      id: 4392,
      permission_id: 90,
      role_id: 7,
    },
    {
      id: 4396,
      permission_id: 105,
      role_id: 7,
      permission_business_logic_id: 1,
    },
    {
      id: 4400,
      permission_id: 111,
      role_id: 7,
    },
    {
      id: 4405,
      permission_id: 114,
      role_id: 7,
    },
    {
      id: 4407,
      permission_id: 120,
      role_id: 7,
      permission_business_logic_id: 1,
    },
    {
      id: 4410,
      permission_id: 595,
      role_id: 7,
    },
    {
      id: 4414,
      permission_id: 10,
      role_id: 8,
    },
    {
      id: 4419,
      permission_id: 16,
      role_id: 8,
    },
    {
      id: 4424,
      permission_id: 24,
      role_id: 8,
    },
    {
      id: 4431,
      permission_id: 42,
      role_id: 8,
    },
    {
      id: 4435,
      permission_id: 46,
      role_id: 8,
    },
    {
      id: 4440,
      permission_id: 52,
      role_id: 8,
    },
    {
      id: 4448,
      permission_id: 83,
      role_id: 8,
      permission_business_logic_id: 1,
    },
    {
      id: 4577,
      permission_id: 17,
      role_id: 9,
      permission_business_logic_id: 1,
    },
    {
      id: 4578,
      permission_id: 18,
      role_id: 9,
    },
    {
      id: 4579,
      permission_id: 19,
      role_id: 9,
    },
    {
      id: 4580,
      permission_id: 22,
      role_id: 9,
    },
    {
      id: 4581,
      permission_id: 24,
      role_id: 9,
    },
    {
      id: 4582,
      permission_id: 25,
      role_id: 9,
    },
    {
      id: 4583,
      permission_id: 30,
      role_id: 9,
    },
    {
      id: 4584,
      permission_id: 34,
      role_id: 9,
    },
    {
      id: 4585,
      permission_id: 35,
      role_id: 9,
    },
    {
      id: 4586,
      permission_id: 37,
      role_id: 9,
    },
    {
      id: 4587,
      permission_id: 40,
      role_id: 9,
      permission_business_logic_id: 1,
    },
    {
      id: 4456,
      permission_id: 603,
      role_id: 8,
    },
    {
      id: 4588,
      permission_id: 41,
      role_id: 9,
    },
    {
      id: 4589,
      permission_id: 42,
      role_id: 9,
    },
    {
      id: 4590,
      permission_id: 43,
      role_id: 9,
    },
    {
      id: 4591,
      permission_id: 44,
      role_id: 9,
    },
    {
      id: 4592,
      permission_id: 45,
      role_id: 9,
    },
    {
      id: 4593,
      permission_id: 49,
      role_id: 9,
    },
    {
      id: 4594,
      permission_id: 46,
      role_id: 9,
    },
    {
      id: 4595,
      permission_id: 47,
      role_id: 9,
    },
    {
      id: 4596,
      permission_id: 50,
      role_id: 9,
    },
    {
      id: 4597,
      permission_id: 51,
      role_id: 9,
      permission_business_logic_id: 1,
    },
    {
      id: 4598,
      permission_id: 52,
      role_id: 9,
    },
    {
      id: 4599,
      permission_id: 53,
      role_id: 9,
      permission_business_logic_id: 1,
    },
    {
      id: 4600,
      permission_id: 54,
      role_id: 9,
    },
    {
      id: 4601,
      permission_id: 55,
      role_id: 9,
    },
    {
      id: 4602,
      permission_id: 56,
      role_id: 9,
    },
    {
      id: 4603,
      permission_id: 58,
      role_id: 9,
    },
    {
      id: 4604,
      permission_id: 597,
      role_id: 9,
    },
    {
      id: 4605,
      permission_id: 60,
      role_id: 9,
    },
    {
      id: 4606,
      permission_id: 61,
      role_id: 9,
    },
    {
      id: 4607,
      permission_id: 600,
      role_id: 9,
    },
    {
      id: 4608,
      permission_id: 598,
      role_id: 9,
    },
    {
      id: 4460,
      permission_id: 5,
      role_id: 11,
    },
    {
      id: 4464,
      permission_id: 13,
      role_id: 11,
      permission_business_logic_id: 1,
    },
    {
      id: 4467,
      permission_id: 22,
      role_id: 11,
    },
    {
      id: 4470,
      permission_id: 40,
      role_id: 11,
      permission_business_logic_id: 2,
    },
    {
      id: 4473,
      permission_id: 43,
      role_id: 11,
    },
    {
      id: 4478,
      permission_id: 50,
      role_id: 11,
    },
    {
      id: 4480,
      permission_id: 52,
      role_id: 11,
    },
    {
      id: 4484,
      permission_id: 56,
      role_id: 11,
    },
    {
      id: 4485,
      permission_id: 58,
      role_id: 11,
    },
    {
      id: 4489,
      permission_id: 600,
      role_id: 11,
    },
    {
      id: 4490,
      permission_id: 598,
      role_id: 11,
    },
    {
      id: 4494,
      permission_id: 67,
      role_id: 11,
    },
    {
      id: 4497,
      permission_id: 71,
      role_id: 11,
    },
    {
      id: 4499,
      permission_id: 82,
      role_id: 11,
    },
    {
      id: 4503,
      permission_id: 87,
      role_id: 11,
    },
    {
      id: 4504,
      permission_id: 88,
      role_id: 11,
    },
    {
      id: 4508,
      permission_id: 105,
      role_id: 11,
      permission_business_logic_id: 2,
    },
    {
      id: 4509,
      permission_id: 106,
      role_id: 11,
    },
    {
      id: 4512,
      permission_id: 110,
      role_id: 11,
    },
    {
      id: 4514,
      permission_id: 120,
      role_id: 11,
      permission_business_logic_id: 1,
    },
    {
      id: 4609,
      permission_id: 601,
      role_id: 9,
    },
    {
      id: 4610,
      permission_id: 605,
      role_id: 9,
    },
    {
      id: 4611,
      permission_id: 66,
      role_id: 9,
      permission_business_logic_id: 1,
    },
    {
      id: 4612,
      permission_id: 67,
      role_id: 9,
    },
    {
      id: 4613,
      permission_id: 68,
      role_id: 9,
    },
    {
      id: 4614,
      permission_id: 69,
      role_id: 9,
    },
    {
      id: 4615,
      permission_id: 70,
      role_id: 9,
    },
    {
      id: 4616,
      permission_id: 71,
      role_id: 9,
    },
    {
      id: 4617,
      permission_id: 81,
      role_id: 9,
      permission_business_logic_id: 1,
    },
    {
      id: 4618,
      permission_id: 84,
      role_id: 9,
    },
    {
      id: 4619,
      permission_id: 82,
      role_id: 9,
    },
    {
      id: 4620,
      permission_id: 83,
      role_id: 9,
      permission_business_logic_id: 1,
    },
    {
      id: 4621,
      permission_id: 86,
      role_id: 9,
    },
    {
      id: 4622,
      permission_id: 87,
      role_id: 9,
    },
    {
      id: 4623,
      permission_id: 88,
      role_id: 9,
    },
    {
      id: 4624,
      permission_id: 89,
      role_id: 9,
    },
    {
      id: 4625,
      permission_id: 90,
      role_id: 9,
    },
    {
      id: 4626,
      permission_id: 92,
      role_id: 9,
    },
    {
      id: 4627,
      permission_id: 93,
      role_id: 9,
    },
    {
      id: 4628,
      permission_id: 95,
      role_id: 9,
    },
    {
      id: 4629,
      permission_id: 96,
      role_id: 9,
    },
    {
      id: 4630,
      permission_id: 97,
      role_id: 9,
    },
    {
      id: 4631,
      permission_id: 98,
      role_id: 9,
    },
    {
      id: 4632,
      permission_id: 99,
      role_id: 9,
    },
    {
      id: 4633,
      permission_id: 100,
      role_id: 9,
    },
    {
      id: 4634,
      permission_id: 101,
      role_id: 9,
    },
    {
      id: 4635,
      permission_id: 102,
      role_id: 9,
    },
    {
      id: 4636,
      permission_id: 103,
      role_id: 9,
    },
    {
      id: 4637,
      permission_id: 104,
      role_id: 9,
    },
    {
      id: 4638,
      permission_id: 105,
      role_id: 9,
      permission_business_logic_id: 1,
    },
    {
      id: 4639,
      permission_id: 106,
      role_id: 9,
    },
    {
      id: 4640,
      permission_id: 107,
      role_id: 9,
    },
    {
      id: 4516,
      permission_id: 589,
      role_id: 11,
    },
    {
      id: 4641,
      permission_id: 108,
      role_id: 9,
    },
    {
      id: 4642,
      permission_id: 109,
      role_id: 9,
    },
    {
      id: 4643,
      permission_id: 110,
      role_id: 9,
    },
    {
      id: 4644,
      permission_id: 111,
      role_id: 9,
    },
    {
      id: 4645,
      permission_id: 112,
      role_id: 9,
    },
    {
      id: 4646,
      permission_id: 113,
      role_id: 9,
    },
    {
      id: 4647,
      permission_id: 114,
      role_id: 9,
    },
    {
      id: 4648,
      permission_id: 115,
      role_id: 9,
    },
    {
      id: 4649,
      permission_id: 116,
      role_id: 9,
    },
    {
      id: 4650,
      permission_id: 119,
      role_id: 9,
    },
    {
      id: 4651,
      permission_id: 120,
      role_id: 9,
      permission_business_logic_id: 1,
    },
    {
      id: 4652,
      permission_id: 124,
      role_id: 9,
    },
    {
      id: 4653,
      permission_id: 125,
      role_id: 9,
    },
    {
      id: 4654,
      permission_id: 588,
      role_id: 9,
    },
    {
      id: 4655,
      permission_id: 589,
      role_id: 9,
    },
    {
      id: 4656,
      permission_id: 599,
      role_id: 9,
    },
    {
      id: 4657,
      permission_id: 603,
      role_id: 9,
    },
    {
      id: 4658,
      permission_id: 604,
      role_id: 9,
    },
    {
      id: 4360,
      permission_id: 5,
      role_id: 7,
    },
    {
      id: 4520,
      permission_id: 10,
      role_id: 10,
    },
    {
      id: 4524,
      permission_id: 17,
      role_id: 10,
      permission_business_logic_id: 1,
    },
    {
      id: 4527,
      permission_id: 30,
      role_id: 10,
    },
    {
      id: 4533,
      permission_id: 44,
      role_id: 10,
    },
    {
      id: 4538,
      permission_id: 53,
      role_id: 10,
      permission_business_logic_id: 3,
    },
    {
      id: 4541,
      permission_id: 56,
      role_id: 10,
    },
    {
      id: 4544,
      permission_id: 605,
      role_id: 10,
    },
    {
      id: 4546,
      permission_id: 71,
      role_id: 10,
    },
    {
      id: 4549,
      permission_id: 82,
      role_id: 10,
    },
    {
      id: 4551,
      permission_id: 84,
      role_id: 10,
    },
    {
      id: 4553,
      permission_id: 87,
      role_id: 10,
    },
    {
      id: 4555,
      permission_id: 89,
      role_id: 10,
    },
    {
      id: 4557,
      permission_id: 95,
      role_id: 10,
    },
    {
      id: 4559,
      permission_id: 106,
      role_id: 10,
    },
    {
      id: 4562,
      permission_id: 110,
      role_id: 10,
    },
    {
      id: 4564,
      permission_id: 120,
      role_id: 10,
      permission_business_logic_id: 1,
    },
    {
      id: 4565,
      permission_id: 124,
      role_id: 10,
    },
    {
      id: 4255,
      permission_id: 5,
      role_id: 1,
    },
    {
      id: 4256,
      permission_id: 9,
      role_id: 1,
    },
    {
      id: 4257,
      permission_id: 10,
      role_id: 1,
    },
    {
      id: 4258,
      permission_id: 11,
      role_id: 1,
    },
    {
      id: 4259,
      permission_id: 13,
      role_id: 1,
      permission_business_logic_id: 1,
    },
    {
      id: 4260,
      permission_id: 14,
      role_id: 1,
    },
    {
      id: 4261,
      permission_id: 15,
      role_id: 1,
    },
    {
      id: 4262,
      permission_id: 16,
      role_id: 1,
    },
    {
      id: 4263,
      permission_id: 17,
      role_id: 1,
      permission_business_logic_id: 1,
    },
    {
      id: 4264,
      permission_id: 18,
      role_id: 1,
    },
    {
      id: 4265,
      permission_id: 19,
      role_id: 1,
    },
    {
      id: 4266,
      permission_id: 22,
      role_id: 1,
    },
    {
      id: 4267,
      permission_id: 24,
      role_id: 1,
    },
    {
      id: 4268,
      permission_id: 25,
      role_id: 1,
    },
    {
      id: 4269,
      permission_id: 27,
      role_id: 1,
    },
    {
      id: 4270,
      permission_id: 28,
      role_id: 1,
    },
    {
      id: 4271,
      permission_id: 29,
      role_id: 1,
    },
    {
      id: 4272,
      permission_id: 30,
      role_id: 1,
    },
    {
      id: 4273,
      permission_id: 34,
      role_id: 1,
    },
    {
      id: 4274,
      permission_id: 35,
      role_id: 1,
    },
    {
      id: 4275,
      permission_id: 37,
      role_id: 1,
    },
    {
      id: 4276,
      permission_id: 40,
      role_id: 1,
      permission_business_logic_id: 1,
    },
    {
      id: 4277,
      permission_id: 41,
      role_id: 1,
    },
    {
      id: 4278,
      permission_id: 42,
      role_id: 1,
    },
    {
      id: 4279,
      permission_id: 43,
      role_id: 1,
    },
    {
      id: 4280,
      permission_id: 44,
      role_id: 1,
    },
    {
      id: 4281,
      permission_id: 45,
      role_id: 1,
    },
    {
      id: 4282,
      permission_id: 46,
      role_id: 1,
      permission_business_logic_id: 1,
    },
    {
      id: 4283,
      permission_id: 47,
      role_id: 1,
    },
    {
      id: 4284,
      permission_id: 49,
      role_id: 1,
    },
    {
      id: 4285,
      permission_id: 50,
      role_id: 1,
    },
    {
      id: 4286,
      permission_id: 51,
      role_id: 1,
      permission_business_logic_id: 1,
    },
    {
      id: 4287,
      permission_id: 52,
      role_id: 1,
    },
    {
      id: 4288,
      permission_id: 53,
      role_id: 1,
      permission_business_logic_id: 1,
    },
    {
      id: 4289,
      permission_id: 54,
      role_id: 1,
    },
    {
      id: 4290,
      permission_id: 55,
      role_id: 1,
    },
    {
      id: 4291,
      permission_id: 56,
      role_id: 1,
    },
    {
      id: 4292,
      permission_id: 58,
      role_id: 1,
    },
    {
      id: 4293,
      permission_id: 597,
      role_id: 1,
    },
    {
      id: 4294,
      permission_id: 60,
      role_id: 1,
    },
    {
      id: 4295,
      permission_id: 61,
      role_id: 1,
    },
    {
      id: 4296,
      permission_id: 600,
      role_id: 1,
    },
    {
      id: 4297,
      permission_id: 598,
      role_id: 1,
    },
    {
      id: 4298,
      permission_id: 601,
      role_id: 1,
    },
    {
      id: 4299,
      permission_id: 605,
      role_id: 1,
    },
    {
      id: 4300,
      permission_id: 66,
      role_id: 1,
      permission_business_logic_id: 1,
    },
    {
      id: 4301,
      permission_id: 67,
      role_id: 1,
    },
    {
      id: 4302,
      permission_id: 68,
      role_id: 1,
    },
    {
      id: 4303,
      permission_id: 69,
      role_id: 1,
    },
    {
      id: 4304,
      permission_id: 70,
      role_id: 1,
    },
    {
      id: 4305,
      permission_id: 71,
      role_id: 1,
    },
    {
      id: 4306,
      permission_id: 79,
      role_id: 1,
    },
    {
      id: 4307,
      permission_id: 80,
      role_id: 1,
    },
    {
      id: 4308,
      permission_id: 81,
      role_id: 1,
      permission_business_logic_id: 1,
    },
    {
      id: 4309,
      permission_id: 82,
      role_id: 1,
    },
    {
      id: 4310,
      permission_id: 83,
      role_id: 1,
      permission_business_logic_id: 1,
    },
    {
      id: 4311,
      permission_id: 84,
      role_id: 1,
    },
    {
      id: 4312,
      permission_id: 86,
      role_id: 1,
    },
    {
      id: 4313,
      permission_id: 87,
      role_id: 1,
    },
    {
      id: 4314,
      permission_id: 88,
      role_id: 1,
    },
    {
      id: 4315,
      permission_id: 89,
      role_id: 1,
    },
    {
      id: 4316,
      permission_id: 90,
      role_id: 1,
    },
    {
      id: 4317,
      permission_id: 92,
      role_id: 1,
    },
    {
      id: 4318,
      permission_id: 93,
      role_id: 1,
    },
    {
      id: 4319,
      permission_id: 95,
      role_id: 1,
    },
    {
      id: 4320,
      permission_id: 96,
      role_id: 1,
    },
    {
      id: 4321,
      permission_id: 97,
      role_id: 1,
    },
    {
      id: 4322,
      permission_id: 98,
      role_id: 1,
    },
    {
      id: 4323,
      permission_id: 99,
      role_id: 1,
    },
    {
      id: 4324,
      permission_id: 100,
      role_id: 1,
    },
    {
      id: 4325,
      permission_id: 101,
      role_id: 1,
    },
    {
      id: 4326,
      permission_id: 102,
      role_id: 1,
    },
    {
      id: 4327,
      permission_id: 103,
      role_id: 1,
    },
    {
      id: 4328,
      permission_id: 104,
      role_id: 1,
    },
    {
      id: 4329,
      permission_id: 105,
      role_id: 1,
      permission_business_logic_id: 1,
    },
    {
      id: 4330,
      permission_id: 106,
      role_id: 1,
    },
    {
      id: 4331,
      permission_id: 107,
      role_id: 1,
    },
    {
      id: 4332,
      permission_id: 108,
      role_id: 1,
    },
    {
      id: 4333,
      permission_id: 109,
      role_id: 1,
    },
    {
      id: 4334,
      permission_id: 110,
      role_id: 1,
    },
    {
      id: 4335,
      permission_id: 111,
      role_id: 1,
    },
    {
      id: 4336,
      permission_id: 112,
      role_id: 1,
    },
    {
      id: 4337,
      permission_id: 113,
      role_id: 1,
    },
    {
      id: 4338,
      permission_id: 114,
      role_id: 1,
    },
    {
      id: 4339,
      permission_id: 115,
      role_id: 1,
    },
    {
      id: 4340,
      permission_id: 116,
      role_id: 1,
    },
    {
      id: 4341,
      permission_id: 117,
      role_id: 1,
    },
    {
      id: 4342,
      permission_id: 118,
      role_id: 1,
    },
    {
      id: 4343,
      permission_id: 119,
      role_id: 1,
    },
    {
      id: 4344,
      permission_id: 120,
      role_id: 1,
      permission_business_logic_id: 1,
    },
    {
      id: 4345,
      permission_id: 121,
      role_id: 1,
    },
    {
      id: 4346,
      permission_id: 122,
      role_id: 1,
    },
    {
      id: 4347,
      permission_id: 123,
      role_id: 1,
    },
    {
      id: 4348,
      permission_id: 124,
      role_id: 1,
    },
    {
      id: 4349,
      permission_id: 125,
      role_id: 1,
    },
    {
      id: 4350,
      permission_id: 588,
      role_id: 1,
    },
    {
      id: 4351,
      permission_id: 589,
      role_id: 1,
    },
    {
      id: 4352,
      permission_id: 599,
      role_id: 1,
    },
    {
      id: 4353,
      permission_id: 603,
      role_id: 1,
    },
    {
      id: 4354,
      permission_id: 604,
      role_id: 1,
    },
    {
      id: 4355,
      permission_id: 593,
      role_id: 1,
    },
    {
      id: 4356,
      permission_id: 594,
      role_id: 1,
    },
    {
      id: 4357,
      permission_id: 595,
      role_id: 1,
    },
    {
      id: 4365,
      permission_id: 22,
      role_id: 7,
    },
    {
      id: 4369,
      permission_id: 42,
      role_id: 7,
    },
    {
      id: 4373,
      permission_id: 51,
      role_id: 7,
      permission_business_logic_id: 1,
    },
    {
      id: 4378,
      permission_id: 66,
      role_id: 7,
      permission_business_logic_id: 1,
    },
    {
      id: 4383,
      permission_id: 71,
      role_id: 7,
    },
    {
      id: 4389,
      permission_id: 87,
      role_id: 7,
    },
    {
      id: 4393,
      permission_id: 95,
      role_id: 7,
    },
    {
      id: 4398,
      permission_id: 106,
      role_id: 7,
    },
    {
      id: 4402,
      permission_id: 113,
      role_id: 7,
    },
    {
      id: 4404,
      permission_id: 116,
      role_id: 7,
    },
    {
      id: 4409,
      permission_id: 589,
      role_id: 7,
    },
    {
      id: 4412,
      permission_id: 5,
      role_id: 8,
    },
    {
      id: 4415,
      permission_id: 11,
      role_id: 8,
    },
    {
      id: 4417,
      permission_id: 14,
      role_id: 8,
    },
    {
      id: 4420,
      permission_id: 17,
      role_id: 8,
      permission_business_logic_id: 2,
    },
    {
      id: 4421,
      permission_id: 18,
      role_id: 8,
    },
    {
      id: 4422,
      permission_id: 19,
      role_id: 8,
    },
    {
      id: 4425,
      permission_id: 30,
      role_id: 8,
    },
    {
      id: 4427,
      permission_id: 35,
      role_id: 8,
    },
    {
      id: 4428,
      permission_id: 37,
      role_id: 8,
    },
    {
      id: 4432,
      permission_id: 43,
      role_id: 8,
    },
    {
      id: 4436,
      permission_id: 47,
      role_id: 8,
    },
    {
      id: 4437,
      permission_id: 49,
      role_id: 8,
    },
    {
      id: 4441,
      permission_id: 56,
      role_id: 8,
    },
    {
      id: 4444,
      permission_id: 605,
      role_id: 8,
    },
    {
      id: 4445,
      permission_id: 66,
      role_id: 8,
      permission_business_logic_id: 3,
    },
    {
      id: 4449,
      permission_id: 105,
      role_id: 8,
      permission_business_logic_id: 3,
    },
    {
      id: 4452,
      permission_id: 109,
      role_id: 8,
    },
    {
      id: 4453,
      permission_id: 120,
      role_id: 8,
      permission_business_logic_id: 1,
    },
    {
      id: 4457,
      permission_id: 604,
      role_id: 8,
    },
    {
      id: 4461,
      permission_id: 9,
      role_id: 11,
    },
    {
      id: 4465,
      permission_id: 14,
      role_id: 11,
    },
    {
      id: 4471,
      permission_id: 41,
      role_id: 11,
    },
    {
      id: 4476,
      permission_id: 46,
      role_id: 11,
      permission_business_logic_id: 2,
    },
    {
      id: 4481,
      permission_id: 53,
      role_id: 11,
      permission_business_logic_id: 2,
    },
    {
      id: 4487,
      permission_id: 60,
      role_id: 11,
    },
    {
      id: 4492,
      permission_id: 605,
      role_id: 11,
    },
    {
      id: 4500,
      permission_id: 83,
      role_id: 11,
      permission_business_logic_id: 2,
    },
    {
      id: 4506,
      permission_id: 90,
      role_id: 11,
    },
    {
      id: 4507,
      permission_id: 95,
      role_id: 11,
    },
    {
      id: 4510,
      permission_id: 108,
      role_id: 11,
    },
    {
      id: 4511,
      permission_id: 109,
      role_id: 11,
    },
    {
      id: 4513,
      permission_id: 119,
      role_id: 11,
    },
    {
      id: 4515,
      permission_id: 125,
      role_id: 11,
    },
    {
      id: 4517,
      permission_id: 595,
      role_id: 11,
    },
    {
      id: 4659,
      permission_id: 593,
      role_id: 9,
    },
    {
      id: 4660,
      permission_id: 594,
      role_id: 9,
    },
    {
      id: 4661,
      permission_id: 595,
      role_id: 9,
    },
    {
      id: 6000,
      permission_id: 602,
      role_id: 1,
    },
    {
      id: 6001,
      permission_id: 602,
      role_id: 8,
    },
    {
      id: 6002,
      permission_id: 606,
      role_id: 1,
    },
    {
      id: 6003,
      permission_id: 607,
      role_id: 1,
    },
    {
      id: 6004,
      permission_id: 608,
      role_id: 1,
    },
    {
      id: 6005,
      permission_id: 609,
      role_id: 1,
    },
    {
      id: 6006,
      permission_id: 610,
      role_id: 1,
    },
    {
      id: 6007,
      permission_id: 611,
      role_id: 1,
    },
    {
      id: 6008,
      permission_id: 612,
      role_id: 1,
    },
    {
      id: 6009,
      permission_id: 612,
      role_id: 7,
    },
    {
      id: 6010,
      permission_id: 612,
      role_id: 9,
    },
    {
      id: 6011,
      permission_id: 71,
      role_id: 3,
    },
    {
      id: 6012,
      permission_id: 105,
      role_id: 3,
      permission_business_logic_id: 5,
    },
    {
      id: 6013,
      permission_id: 106,
      role_id: 3,
    },
    {
      id: 6014,
      permission_id: 107,
      role_id: 3,
    },
    {
      id: 6015,
      permission_id: 108,
      role_id: 3,
    },
    {
      id: 6016,
      permission_id: 50,
      role_id: 3,
    },
    {
      id: 6017,
      permission_id: 51,
      role_id: 3,
      permission_business_logic_id: 5,
    },
    {
      id: 6018,
      permission_id: 54,
      role_id: 3,
    },
    {
      id: 6019,
      permission_id: 56,
      role_id: 3,
    },
    {
      id: 6020,
      permission_id: 60,
      role_id: 3,
    },
    {
      id: 6021,
      permission_id: 597,
      role_id: 3,
    },
    {
      id: 6022,
      permission_id: 66,
      role_id: 3,
      permission_business_logic_id: 5,
    },
    {
      id: 6023,
      permission_id: 68,
      role_id: 3,
    },
    {
      id: 6024,
      permission_id: 69,
      role_id: 3,
    },
    {
      id: 6025,
      permission_id: 42,
      role_id: 3,
    },
    {
      id: 6026,
      permission_id: 613,
      role_id: 1,
    },
    {
      id: 6027,
      permission_id: 614,
      role_id: 1,
    },
    {
      id: 6028,
      permission_id: 615,
      role_id: 1,
    },
    {
      id: 6029,
      permission_id: 616,
      role_id: 1,
    },
    {
      id: 6030,
      permission_id: 617,
      role_id: 1,
    },
    {
      id: 6031,
      permission_id: 40,
      role_id: 3,
      permission_business_logic_id: 5,
    },
    {
      id: 6032,
      permission_id: 618,
      role_id: 3,
    },
    {
      id: 6033,
      permission_id: 109,
      role_id: 3,
    },
    {
      id: 6034,
      permission_id: 41,
      role_id: 3,
    },
    {
      id: 6035,
      permission_id: 70,
      role_id: 3,
    },
    {
      id: 6036,
      permission_id: 120,
      role_id: 3,
      permission_business_logic_id: 2,
    },
    {
      id: 6037,
      permission_id: 619,
      role_id: 1,
      permission_business_logic_id: 1,
    },
    {
      id: 6038,
      permission_id: 620,
      role_id: 1,
    },
    {
      id: 6039,
      permission_id: 621,
      role_id: 1,
    },
    {
      id: 6040,
      permission_id: 622,
      role_id: 1,
    },
    {
      id: 6041,
      permission_id: 623,
      role_id: 1,
    },
    {
      id: 6042,
      permission_id: 619,
      role_id: 3,
      permission_business_logic_id: 5,
    },
    {
      id: 6043,
      permission_id: 619,
      role_id: 7,
      permission_business_logic_id: 1,
    },
    {
      id: 6044,
      permission_id: 619,
      role_id: 8,
      permission_business_logic_id: 3,
    },
    {
      id: 6045,
      permission_id: 620,
      role_id: 8,
    },
    {
      id: 6046,
      permission_id: 621,
      role_id: 8,
    },
    {
      id: 6047,
      permission_id: 622,
      role_id: 8,
    },
    {
      id: 6048,
      permission_id: 623,
      role_id: 8,
    },
    {
      id: 6049,
      permission_id: 619,
      role_id: 9,
      permission_business_logic_id: 1,
    },
    {
      id: 6050,
      permission_id: 619,
      role_id: 10,
      permission_business_logic_id: 4,
    },
    {
      id: 6051,
      permission_id: 619,
      role_id: 11,
      permission_business_logic_id: 2,
    },
    {
      id: 6052,
      permission_id: 624,
      role_id: 1,
    },
    {
      id: 6053,
      permission_id: 624,
      role_id: 3,
    },
    {
      id: 6054,
      permission_id: 625,
      role_id: 3,
    },
    {
      id: 6055,
      permission_id: 605,
      role_id: 3,
    },
    {
      id: 6056,
      permission_id: 626,
      role_id: 3,
    },
    {
      id: 6057,
      permission_id: 627,
      role_id: 1,
    },
    {
      id: 6058,
      permission_id: 628,
      role_id: 3,
    },
    {
      id: 6059,
      permission_id: 629,
      role_id: 1,
    },
    {
      id: 6060,
      permission_id: 630,
      role_id: 1,
    },
    {
      id: 6061,
      permission_id: 631,
      role_id: 1,
    },
  ]);

  await knex('up_permissions_role_links')
    .max('id as maxId')
    .then(result => {
      const maxId = result[0].maxId || 0;

      // Set the next value of the sequence to be greater than the maximum 'id'
      const rawQuery = `SELECT pg_catalog.setval(pg_get_serial_sequence('up_permissions_role_links', 'id'), ${maxId})`;

      return knex.raw(rawQuery);
    });
}
