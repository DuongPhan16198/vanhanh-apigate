import Knex, { Knex as KnexClass } from 'knex';
import { NODE_ENV, PG_CONNECTION_STRING } from '@config';
import { knexSnakeCaseMappers } from 'objection';

const dbConnection: KnexClass.Config = {
  client: 'pg',
  connection: PG_CONNECTION_STRING,
  searchPath: ['dev', 'public'],
  pool: {
    min: 2,
    max: 5,
  },
  debug: NODE_ENV !== 'production',
  ...knexSnakeCaseMappers(),
};

export default Knex(dbConnection);
