import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('fcm_tokens', table => {
    table.increments('id').notNullable().primary();
    table.integer('user_id');
    table.string('fcm_token', 500);
    table.dateTime('last_updated_at');
  });

  await knex.schema.raw(`
ALTER TABLE fcm_tokens
ADD CONSTRAINT fcm_tokens_user_id_fk
FOREIGN KEY (user_id)
REFERENCES up_users(id);
`);
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTable('fcm_tokens');
}
