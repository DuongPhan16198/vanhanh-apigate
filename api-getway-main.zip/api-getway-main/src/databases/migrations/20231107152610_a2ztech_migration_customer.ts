import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.table('customers', table => {
    table.string('tax_id', 255);
    table.renameColumn('shipping_cost', 'shipping_cost_old');
  });
  await knex.schema.table('customers', table => {
    table.integer('shipping_cost');
  });
  await knex('customers').update('shipping_cost', 1);

  await knex('customers')
    .select('id', 'id_customer')
    .then(rows => {
      const updatePromises = rows.map(row => {
        const newIdCustomer = 'DP' + row.id;
        return knex('customers')
          .where('id', row.id)
          .update({ id_customer: newIdCustomer });
      });

      return Promise.all(updatePromises);
    });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.table('customers', table => {
    table.dropColumn('tax_id');
    table.dropColumn('shipping_cost');
  });
  await knex.schema.table('customers', table => {
    table.renameColumn('shipping_cost_old', 'shipping_cost');
  });
}
