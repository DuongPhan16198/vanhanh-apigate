import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.table('up_permissions_role_links', table => {
    table.integer('permission_business_logic_id');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.table('up_permissions_role_links', table => {
    table.dropColumn('permission_business_logic_id');
  });
}
