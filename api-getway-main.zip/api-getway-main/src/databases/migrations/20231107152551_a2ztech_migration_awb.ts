import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.table('awbs', table => {
    table.string('sync_status', 255).notNullable().defaultTo('successful');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.table('awbs', table => {
    table.dropColumn('sync_status');
  });
}
