import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.table('up_permissions', table => {
    table.text('description');
    table.json('business_logic');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.table('up_permissions', table => {
    table.dropColumn('description');
    table.dropColumn('business_logic');
  });
}
