import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {

  await knex.schema.table('tracking_logs', function (table) {
    // table.dropColumn('tracking_code');
    table.integer('tracking_id').unsigned();
    table.foreign('tracking_id').references('trackings.id');
  });

    const sqlQuery = `
    UPDATE tracking_logs
    SET tracking_id = t.id
    FROM trackings AS t
    WHERE tracking_logs.tracking_code = LEFT(t.code, POSITION('-rn' IN t.code) - 1)
  `;


  await knex.schema.raw(sqlQuery);

  await knex.schema.table('tracking_logs', function(table) {
    table.index(['tracking_id'], 'idx_tracking_id');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.table('tracking_logs', table => {
    table.dropColumn('tracking_id');
  });
}
