import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.table('customer_transaction_logs', table => {
    table.string('status', 255).notNullable().defaultTo('chờ duyệt');
    table.text('bank_account');
    table.text('image');
  });

  await knex('customer_transaction_logs').whereNotNull('status').update({ status: 'hoàn thành' });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.table('customer_transaction_logs', table => {
    table.dropColumn('status');
    table.dropColumn('bank_account');
    table.dropColumn('image');
  });
}
