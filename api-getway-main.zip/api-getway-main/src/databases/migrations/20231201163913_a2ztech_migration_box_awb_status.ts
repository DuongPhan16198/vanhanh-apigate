import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  const result = await knex.raw(`
  SELECT
    awbs.id AS awb_id,
    awbs.code AS awb_code,
    JSON_AGG(JSON_BUILD_OBJECT(
      'box_id', boxes.id,
      'box_status', boxes.exploit_status
    )) AS boxes
  FROM awbs
  LEFT JOIN boxes_awb_links ON awbs.id = boxes_awb_links.awb_id
  LEFT JOIN boxes ON boxes_awb_links.box_id = boxes.id
  GROUP BY awbs.id
`);

  const awbsWithBoxes = result.rows;
  awbsWithBoxes.forEach(async awb => {
    let minStatus = 7;
    awb.boxes.forEach(async box => {
      let boxStatusAsNumber = 7;
      switch (box.box_status) {
        case 'Đang vận chuyển về vn':
          boxStatusAsNumber = 3;
          break;
        case 'Đã vận chuyển về vn':
          boxStatusAsNumber = 4;
          break;
        case 'Đang khai thác':
          boxStatusAsNumber = 5;
          break;
        case 'Đã khai thác':
          boxStatusAsNumber = 6;
          break;
        default:
          boxStatusAsNumber = 7;
          break;
      }
      if (boxStatusAsNumber < minStatus) {
        minStatus = boxStatusAsNumber;
      }
    });
    let awbStatus: string;
    switch (minStatus) {
      case 3:
        awbStatus = 'Đang vận chuyển về vn';
        break;
      case 4:
        awbStatus = 'Đã vận chuyển về vn';
        break;
      case 5:
        awbStatus = 'Đang khai thác';
        break;
      case 6:
        awbStatus = 'Đã khai thác';
        break;
      default:
        awbStatus = 'Đang vận chuyển về vn';
        break;
    }
    await knex.raw(
      `
    UPDATE awbs
    SET exploit_status = ?
    WHERE id = ?
  `,
      [awbStatus, awb.awb_id],
    );
  });
}

export async function down(knex: Knex): Promise<void> {}
