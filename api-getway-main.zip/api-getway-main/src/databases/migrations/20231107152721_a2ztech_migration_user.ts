import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.table('up_users', table => {
    table.string('code', 255);
    table.string('avatar_url',300);
  });

  await knex('up_users')
  .whereNull('fullname') // Chọn các bản ghi có fullname là null
  .update({
    fullname: knex.raw('username'), // Cập nhật giá trị fullname từ cột user_name
  })
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.table('up_users', table => {
    table.dropColumn('code');
    table.dropColumn('avatar_url');
  });
}
