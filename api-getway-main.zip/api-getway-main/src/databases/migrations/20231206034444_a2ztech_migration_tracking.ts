import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex('trackings').whereNull('tracking_total_money').orWhere('tracking_total_money', '=', 'NaN').update({ tracking_total_money: 0 });

  await knex('trackings')
    .whereNotNull('tracking_mining_weight')
    .update({
      tracking_calculation_weight: knex.raw('tracking_mining_weight * 1.05'),
    });

  await knex.schema.table('trackings', table => {
    table.boolean('is_renamed').defaultTo(false);
    table.text('ticket_response').defaultTo(null);
    table.integer('wh_tracking_id').defaultTo(null);
  });
}

export async function down(knex: Knex): Promise<void> {}
