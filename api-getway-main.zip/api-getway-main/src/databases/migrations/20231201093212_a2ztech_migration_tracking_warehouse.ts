import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.raw(
    `INSERT INTO trackings_warehouse_links (tracking_id, warehouse_id)
    SELECT id, 1
    FROM trackings
    WHERE id NOT IN (SELECT tracking_id FROM trackings_warehouse_links WHERE warehouse_id = 1);
    `,
  );
  await knex('trackings_warehouse_links')
  .max('id as maxId')
  .then(result => {
    const maxId = result[0].maxId || 0;

    // Set the next value of the sequence to be greater than the maximum 'id'
    const rawQuery = `SELECT pg_catalog.setval(pg_get_serial_sequence('trackings_warehouse_links', 'id'), ${maxId})`;

    return knex.raw(rawQuery);
  })
}

export async function down(knex: Knex): Promise<void> {

}
