import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('vn_delivery_units', table => {
    table.increments('id').notNullable().primary();
    table.string('name',255);
    table.string('code',255);
    table.string('logo_url',255);
    table.integer('status').defaultTo(0)
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTable('vn_delivery_units');
}
