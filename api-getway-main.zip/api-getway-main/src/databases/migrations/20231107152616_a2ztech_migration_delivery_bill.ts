import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.table('delivery_bills', table => {
    table.string('customer_name', 255);
    table.string('email', 255);
    table.string('name', 255);
  });
  await knex.schema.raw('ALTER TABLE delivery_bills DROP CONSTRAINT IF EXISTS delivery_bills_created_by_id_fk');
  await knex.schema.raw(`
    ALTER TABLE delivery_bills
    ADD CONSTRAINT delivery_bills_created_by_id_fk
    FOREIGN KEY (created_by_id)
    REFERENCES up_users(id);
  `);

  await knex.schema.raw('ALTER TABLE delivery_bills DROP CONSTRAINT IF EXISTS delivery_bills_updated_by_id_fk');
  await knex.schema.raw(`
    ALTER TABLE delivery_bills
    ADD CONSTRAINT delivery_bills_updated_by_id_fk
    FOREIGN KEY (updated_by_id)
    REFERENCES up_users(id);
  `);
  await knex('delivery_bills').where('delivery_bill_status', '=', 'Đang giao hàng').update({
    delivery_bill_status: 'Đã đóng hàng',
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.table('delivery_bills', table => {
    table.dropColumn('customer_name');
    table.dropColumn('email');
    table.dropColumn('name');
  });

  await knex.schema.raw('ALTER TABLE delivery_bills DROP CONSTRAINT IF EXISTS delivery_bills_created_by_id_fk');
  await knex.schema.raw(`
    ALTER TABLE delivery_bills
    ADD CONSTRAINT delivery_bills_created_by_id_fk
    FOREIGN KEY (created_by_id)
    REFERENCES admin_users(id);
  `);

  await knex.schema.raw('ALTER TABLE delivery_bills DROP CONSTRAINT IF EXISTS delivery_bills_updated_by_id_fk');
  await knex.schema.raw(`
    ALTER TABLE delivery_bills
    ADD CONSTRAINT delivery_bills_updated_by_id_fk
    FOREIGN KEY (updated_by_id)
    REFERENCES admin_users(id);
  `);
}
