import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('vn_delivery_boxes', table => {
    table.increments('id').notNullable().primary();
    table.string('code', 255);
    table.integer('vn_delivery_order_id');
    table.integer('status');
  });

  await knex.schema.raw(`
ALTER TABLE vn_delivery_boxes
ADD CONSTRAINT vn_delivery_boxes_vn_delivery_order_id_fk
FOREIGN KEY (vn_delivery_order_id)
REFERENCES vn_delivery_orders(id);
`);
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTable('vn_delivery_boxes');
}
