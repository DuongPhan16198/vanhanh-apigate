import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('pages', table => {
    table.increments('id').notNullable().primary();
    table.string('page_interface_file_name', 255).notNullable();
    table.text('page_metadata').notNullable();
    table.boolean('is_delete').defaultTo(false);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTable('pages');
}
