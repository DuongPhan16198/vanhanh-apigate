import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  const result = await knex.raw(`
  SELECT
    boxes.id AS box_id,
    boxes.code AS box_name,
    boxes.tracking_quantity AS box_tracking_count,
    JSON_AGG(JSON_BUILD_OBJECT(
      'tracking_id', trackings.id,
      'tracking_status', trackings.status,
      'tracking_exploit_status', trackings.exploit_status
    )) AS trackings
  FROM boxes
  LEFT JOIN trackings_box_links ON boxes.id = trackings_box_links.box_id
  LEFT JOIN trackings ON trackings_box_links.tracking_id = trackings.id
  GROUP BY boxes.id
`);

  const boxesWithTrackings = result.rows;
  boxesWithTrackings.forEach(async box => {
    let minStatus = 10;
    let trackingStatusArray: number[] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    let tracking_count = 0;
    box.trackings.forEach(async tr => {
      tracking_count++;
      let trackingStatusAsNumber = 1;
      switch (tr.tracking_status) {
        case 'Chờ nhập kho US':
        case 'Đã tiếp nhận':
        case 'Chưa nhập kho':
          trackingStatusAsNumber = 1;
          trackingStatusArray[1]++;
          break;
        case 'Đã nhập kho':
          trackingStatusAsNumber = 2;
          trackingStatusArray[2]++;
          break;
        case 'Đang vận chuyển về VN':
        case 'Đang đóng thùng':
        case 'Đã đóng thùng':
        case 'Đang xử lý awb':
        case 'Đang vận chuyển về VN':
        case 'Hoàn thành':
          if (tr.tracking_exploit_status === 'Đang vận chuyển về vn') trackingStatusAsNumber = 3;
          trackingStatusArray[3]++;
          break;
        case 'Hủy':
          trackingStatusAsNumber = 7;
          trackingStatusArray[7]++;
          break;
        default:
          trackingStatusAsNumber = 10;
          break;
      }
      switch (tr.tracking_exploit_status) {
        case 'Đã vận chuyển về vn':
          trackingStatusAsNumber = 4;
          trackingStatusArray[4]++;
          break;
        case 'Đã khai thác':
          trackingStatusAsNumber = 5;
          trackingStatusArray[5]++;
          break;
        case 'Hoàn thành':
          trackingStatusAsNumber = 6;
          trackingStatusArray[6]++;
          break;
        case 'Đã hủy bỏ':
          if (tr.tracking_status !== 'Hủy') trackingStatusAsNumber = 7;
          trackingStatusArray[7]++;
          break;
        case 'Đã đóng hàng':
          trackingStatusArray[8]++;
          break;
        case 'Đang giao hàng':
          trackingStatusArray[9]++;
          break;
        default:
          trackingStatusAsNumber = 10;
          break;
      }
      if (trackingStatusAsNumber < minStatus) {
        minStatus = trackingStatusAsNumber;
      }
    });
    // console.log(trackingStatusArray + ' ' + tracking_count + ' ' + box.box_name);
    // throw new Error(' break ');
    tracking_count = tracking_count - trackingStatusArray[7];
    let boxStatus: string = 'Đang vận chuyển về vn';

    if (
      trackingStatusArray[4] + trackingStatusArray[5] + trackingStatusArray[6] + trackingStatusArray[8] + trackingStatusArray[9] ===
      tracking_count
    ) {
      boxStatus = 'Đã vận chuyển về vn';
    }
    if (
      trackingStatusArray[4] > 0 &&
      trackingStatusArray[4] < tracking_count &&
      trackingStatusArray[5] + trackingStatusArray[6] + trackingStatusArray[8] + trackingStatusArray[9] > 0
    ) {
      boxStatus = 'Đang khai thác';
    }
    if (trackingStatusArray[5] + trackingStatusArray[6] + trackingStatusArray[8] + trackingStatusArray[9] === tracking_count)
      boxStatus = 'Đã khai thác';
    tracking_count = 0;

    await knex.raw(
      `
    UPDATE boxes
    SET exploit_status = ?
    WHERE id = ?
  `,
      [boxStatus, box.box_id],
    );
  });
}

export async function down(knex: Knex): Promise<void> {}
