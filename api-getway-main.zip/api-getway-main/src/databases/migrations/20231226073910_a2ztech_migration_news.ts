import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('news', function (table) {
    table.increments('id').primary();
    table.string('title');
    table.string('thumbnail');
    table.text('content');
    table.integer('status');
    table.dateTime('created_at');
    table.dateTime('updated_at');
  });

  await knex.schema.createTable('news_categories', function (table) {
    table.increments('id').primary();
    table.string('name');
    table.string('slug');
  });

  await knex.schema.createTable('news_category_links', function (table) {
    table.increments('id').primary();
    table.integer('news_id').unsigned().references('id').inTable('news');
    table.integer('category_id').unsigned().references('id').inTable('news_categories');
  });

  await knex('news_categories').insert([
    { name: 'Logistic', slug: 'logistic' },
    { name: 'Kinh tế', slug: 'kinh-te' },
    { name: 'Thương mại', slug: 'thuong-mai' },
    { name: 'Vĩ mô', slug: 'vi-mo' },
    { name: 'Xã hội', slug: 'xa-hoi' },
  ]);

  await knex('news_categories')
  .max('id as maxId')
  .then(result => {
    const maxId = result[0].maxId || 0;

    // Set the next value of the sequence to be greater than the maximum 'id'
    const rawQuery = `SELECT pg_catalog.setval(pg_get_serial_sequence('news_categories', 'id'), ${maxId})`;

    return knex.raw(rawQuery);
  })
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTable('news_category_links');
  await knex.schema.dropTable('news');
  await knex.schema.dropTable('news_categories');
}
