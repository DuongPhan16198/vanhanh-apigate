import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('general_configs', table => {
    table.increments('id').notNullable().primary();
    table.string('config_key', 255).notNullable();
    table.text('config_value').notNullable();
    table.boolean('is_delete').defaultTo(false);
  });
  await knex('general_configs').insert([
    {
      id: 1,
      config_key: 'PRICING_CONFIG',
      config_value: JSON.stringify({
        info: {
          title: 'Bảng giá cước vận chuyển',
          description: 'Khách hàng mới',
        },
        config: [
          {
            tracking_type: 2,
            warehouse_config_id: 1,
            cost: 205000,
          },
          {
            tracking_type: 2,
            warehouse_config_id: 2,
            cost: 210000,
          },
          {
            tracking_type: 3,
            warehouse_config_id: 1,
            cost: 220000,
          },
          {
            tracking_type: 3,
            warehouse_config_id: 2,
            cost: 230000,
          },
          {
            tracking_type: 4,
            warehouse_config_id: 1,
            cost: 225000,
          },
          {
            tracking_type: 4,
            warehouse_config_id: 2,
            cost: 220000,
          },
          {
            tracking_type: 5,
            warehouse_config_id: 1,
            cost: 210000,
          },
          {
            tracking_type: 5,
            warehouse_config_id: 2,
            cost: 215000,
          },
          {
            tracking_type: 6,
            warehouse_config_id: 1,
            cost: 205000,
          },
          {
            tracking_type: 6,
            warehouse_config_id: 2,
            cost: 225000,
          },
          {
            tracking_type: 7,
            warehouse_config_id: 1,
            cost: 200000,
          },
          {
            tracking_type: 7,
            warehouse_config_id: 2,
            cost: 195000,
          },
        ],
      }),
      is_delete: false,
    },
    {
      id: 2,
      config_key: 'PRICING_CONFIG',
      config_value: JSON.stringify({
        info: {
          title: 'Bảng giá cước vận chuyển',
          description: 'Khách hàng vip1',
        },
        config: [
          {
            tracking_type: 2,
            warehouse_config_id: 1,
            cost: 230000,
          },
          {
            tracking_type: 2,
            warehouse_config_id: 2,
            cost: 235000,
          },
          {
            tracking_type: 3,
            warehouse_config_id: 1,
            cost: 220000,
          },
          {
            tracking_type: 3,
            warehouse_config_id: 2,
            cost: 225000,
          },
          {
            tracking_type: 4,
            warehouse_config_id: 1,
            cost: 210000,
          },
          {
            tracking_type: 4,
            warehouse_config_id: 2,
            cost: 215000,
          },
          {
            tracking_type: 5,
            warehouse_config_id: 1,
            cost: 215000,
          },
          {
            tracking_type: 5,
            warehouse_config_id: 2,
            cost: 220000,
          },
          {
            tracking_type: 6,
            warehouse_config_id: 1,
            cost: 205000,
          },
          {
            tracking_type: 6,
            warehouse_config_id: 2,
            cost: 200000,
          },
          {
            tracking_type: 7,
            warehouse_config_id: 1,
            cost: 195000,
          },
          {
            tracking_type: 7,
            warehouse_config_id: 2,
            cost: 210000,
          },
        ],
      }),
      is_delete: false,
    },
    {
      id: 3,
      config_key: 'PRICING_CONFIG',
      config_value: JSON.stringify({
        info: {
          title: 'Bảng giá cước vận chuyển',
          description: 'Khách hàng VIP2',
        },
        config: [
          {
            tracking_type: 2,
            warehouse_config_id: 1,
            cost: 250000,
          },
          {
            tracking_type: 2,
            warehouse_config_id: 2,
            cost: 250000,
          },
          {
            tracking_type: 3,
            warehouse_config_id: 1,
            cost: 210000,
          },
          {
            tracking_type: 3,
            warehouse_config_id: 2,
            cost: 210000,
          },
          {
            tracking_type: 4,
            warehouse_config_id: 1,
            cost: 220000,
          },
          {
            tracking_type: 4,
            warehouse_config_id: 2,
            cost: 220000,
          },
          {
            tracking_type: 5,
            warehouse_config_id: 1,
            cost: 210000,
          },
          {
            tracking_type: 5,
            warehouse_config_id: 2,
            cost: 215000,
          },
          {
            tracking_type: 6,
            warehouse_config_id: 1,
            cost: 215000,
          },
          {
            tracking_type: 6,
            warehouse_config_id: 2,
            cost: 215000,
          },
          {
            tracking_type: 7,
            warehouse_config_id: 1,
            cost: 250000,
          },
          {
            tracking_type: 7,
            warehouse_config_id: 2,
            cost: 210000,
          },
        ],
      }),
      is_delete: false,
    },
    {
      id: 4,
      config_key: 'PRICING_CONFIG',
      config_value: JSON.stringify({
        info: {
          title: 'Bảng giá cước vận chuyển',
          description: 'Khách hàng VIP3',
        },
        config: [
          {
            tracking_type: 2,
            warehouse_config_id: 1,
            cost: 200000,
          },
          {
            tracking_type: 2,
            warehouse_config_id: 2,
            cost: 200000,
          },
          {
            tracking_type: 3,
            warehouse_config_id: 1,
            cost: 220000,
          },
          {
            tracking_type: 3,
            warehouse_config_id: 2,
            cost: 205000,
          },
          {
            tracking_type: 4,
            warehouse_config_id: 1,
            cost: 200000,
          },
          {
            tracking_type: 4,
            warehouse_config_id: 2,
            cost: 220000,
          },
          {
            tracking_type: 5,
            warehouse_config_id: 1,
            cost: 220000,
          },
          {
            tracking_type: 5,
            warehouse_config_id: 2,
            cost: 200000,
          },
          {
            tracking_type: 6,
            warehouse_config_id: 1,
            cost: 195000,
          },
          {
            tracking_type: 6,
            warehouse_config_id: 2,
            cost: 210000,
          },
          {
            tracking_type: 7,
            warehouse_config_id: 1,
            cost: 205000,
          },
          {
            tracking_type: 7,
            warehouse_config_id: 2,
            cost: 205000,
          },
        ],
      }),
      is_delete: false,
    },
    {
      id: 5,
      config_key: 'PRICING_CONFIG',
      config_value: JSON.stringify({
        info: {
          title: 'Bảng giá cước vận chuyển',
          description: 'Khách hàng VIP4',
        },
        config: [
          {
            tracking_type: 2,
            warehouse_config_id: 1,
            cost: 200000,
          },
          {
            tracking_type: 2,
            warehouse_config_id: 2,
            cost: 200000,
          },
          {
            tracking_type: 3,
            warehouse_config_id: 1,
            cost: 205000,
          },
          {
            tracking_type: 3,
            warehouse_config_id: 2,
            cost: 215000,
          },
          {
            tracking_type: 4,
            warehouse_config_id: 1,
            cost: 220000,
          },
          {
            tracking_type: 4,
            warehouse_config_id: 2,
            cost: 200000,
          },
          {
            tracking_type: 5,
            warehouse_config_id: 1,
            cost: 205000,
          },
          {
            tracking_type: 5,
            warehouse_config_id: 2,
            cost: 220000,
          },
          {
            tracking_type: 6,
            warehouse_config_id: 1,
            cost: 200000,
          },
          {
            tracking_type: 6,
            warehouse_config_id: 2,
            cost: 220000,
          },
          {
            tracking_type: 7,
            warehouse_config_id: 1,
            cost: 220000,
          },
          {
            tracking_type: 7,
            warehouse_config_id: 2,
            cost: 195000,
          },
        ],
      }),
      is_delete: false,
    },
    {
      id: 6,
      config_key: 'BOX_COEFFICIENT_CONFIG',
      config_value: JSON.stringify({
        info: {
          title: 'Cập nhật hệ số thùng',
          description: 'Hệ số thùng',
        },
        config: [
          {
            box_coefficiente: '1.05',
          },
        ],
      }),
      is_delete: false,
    },
  ]);

  await knex('general_configs')
  .max('id as maxId')
  .then(result => {
    const maxId = result[0].maxId || 0;

    // Set the next value of the sequence to be greater than the maximum 'id'
    const rawQuery = `SELECT pg_catalog.setval(pg_get_serial_sequence('general_configs', 'id'), ${maxId})`;

    return knex.raw(rawQuery);
  })
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTable('general_configs');
}
