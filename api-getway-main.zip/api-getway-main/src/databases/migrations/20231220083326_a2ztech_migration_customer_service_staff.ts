import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('customers_service_staff_links', table => {
    table.increments('id').notNullable().primary();
    table.integer('user_id').notNullable();
    table.integer('customer_id').notNullable();
  });
  await knex.schema.raw(`
    ALTER TABLE customers_service_staff_links
    ADD CONSTRAINT customers_service_staff_links_staff_id_inv_fk
    FOREIGN KEY (user_id)
    REFERENCES up_users(id);
  `);
  await knex.schema.raw(`
    ALTER TABLE customers_service_staff_links
    ADD CONSTRAINT customers_service_staff_links_customer_id_inv_fk
    FOREIGN KEY (customer_id)
    REFERENCES customers(id);
  `);
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTable('customers_service_staff_links');
}
