import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.raw('ALTER TABLE trackings_warehouse_links DROP CONSTRAINT IF EXISTS trackings_warehouse_links_inv_fk');
  await knex.schema.raw(`
    ALTER TABLE trackings_warehouse_links
    ADD CONSTRAINT trackings_warehouse_links_inv_fk
    FOREIGN KEY (warehouse_id)
    REFERENCES warehouse_configs(id);
  `);
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.raw('ALTER TABLE trackings_warehouse_links DROP CONSTRAINT IF EXISTS trackings_warehouse_links_inv_fk');
  await knex.schema.raw(`
    ALTER TABLE trackings_warehouse_links
    ADD CONSTRAINT trackings_warehouse_links_inv_fk
    FOREIGN KEY (warehouse_id)
    REFERENCES warehouses(id);
  `);
}
