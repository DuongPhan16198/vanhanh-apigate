import { Knex } from "knex";


export async function up(knex: Knex): Promise<void> {
  await knex.schema.table('customers', table => {
    table.integer('credit_amount').defaultTo(0)
  });
}


export async function down(knex: Knex): Promise<void> {
  await knex.schema.table('customers', table => {
    table.dropColumn('credit_amount');
  });
}

