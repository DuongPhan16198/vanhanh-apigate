import { Knex } from "knex";


export async function up(knex: Knex): Promise<void> {

 await knex.schema.table('tracking_logs', function (table) {
    table.index('tracking_code', 'idx_tracking_code', {
      indexType: 'FULLTEXT',
      storageEngineIndexType: 'hash',
    });
  });
}


export async function down(knex: Knex): Promise<void> {
  await knex.schema.table('tracking_logs', function (table) {
    table.dropIndex('tracking_code', 'idx_tracking_code')
  });
}

