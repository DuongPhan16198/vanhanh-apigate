import { Knex } from "knex";

export async function up(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('tracking_status_logs');

  await knex.schema.createTable('tracking_status_logs', function(table) {
    table.increments('id').primary();
    table.string('name').notNullable();

    // Defining a timestamp column without timezone
    table.timestamp('updated_time', { useTz: false }).notNullable().defaultTo(knex.fn.now());

    table.integer('tracking_id').unsigned().notNullable();
    table.foreign('tracking_id').references('id').inTable('trackings').onDelete('CASCADE');

    // Adding index to tracking_id column
    table.index('tracking_id');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('tracking_status_logs');
}
