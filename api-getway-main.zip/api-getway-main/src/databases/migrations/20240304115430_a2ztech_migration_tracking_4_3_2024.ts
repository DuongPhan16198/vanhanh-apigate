import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.table('trackings', table => {
    table.dateTime('vn_packed_date').defaultTo(null);
    table.dateTime('vn_import_date').defaultTo(null);
    table.dateTime('vn_export_date').defaultTo(null);
    table.integer('tracking_discount_amount').defaultTo(0);
  });
}

export async function down(knex: Knex): Promise<void> {}
