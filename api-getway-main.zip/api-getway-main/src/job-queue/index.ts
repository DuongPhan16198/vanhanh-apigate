export const JobQueueNames = {
  importExcelDataQueue: 'importExcelDataQueue',
  importSellerSDAPpQueue: 'seller-sda-pp:import:queue',
  importSellerSDAApQueue: 'seller-sda-ap:import:queue',
  importSellerSPAPpQueue: 'seller-spa-pp:import:queue',
  importSellerSPAApQueue: 'seller-spa-ap:import:queue',
  importSellerSBAAttributedQueue: 'seller-sba-attributed:import:queue',
  importSellerSBACampaginQueue: 'seller-sba-campagin:import:queue',
  importKDPQueue: 'kdp:import:*:queue*',
  importSellerQueue: 'seller:import:*:queue*',
  importEtsyQueue: 'etsy:import:*:queue*',
  importWebsiteQueue: 'website:import:*:queue*',
};

export const JobQueuePubSubChannel = {
  SELLER_IMPORT_CALLBACK_DONE: 'seller_import_cb_done',
  KDP_IMPORT_CALLBACK_DONE: 'kdp_import_cb_done',
  ETSY_IMPORT_CALLBACK_DONE: 'etsy_import_cb_done',
  WEBSITE_IMPORT_CALLBACK_DONE: 'website_import_cb_done',
}
