import AuthRoute from './auth.route';
import IndexRoute from './index.route';
import APIRoutes from './api/index';
import UsersRoute from './users.route';

export default () => [new IndexRoute(), new UsersRoute(), new AuthRoute(), APIRoutes];
