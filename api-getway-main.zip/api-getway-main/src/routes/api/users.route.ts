import UsersController from '@/controllers/users.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class APIUsersRoute implements Routes {
  public path = '/users';
  public router = Router();
  public controller = new UsersController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}/is_logged`, authMiddleware, this.controller.getUserLogged);
    // this.router.put(`${this.path}/update/`, authMiddleware, this.controller.updateEmployee);
    // this.router.get(`${this.path}/`, authMiddleware, this.controller.getUsers);
    // this.router.get(`${this.path}/:id`, authMiddleware, this.controller.getUserById);
    // this.router.put(`${this.path}/:id`, authMiddleware, this.controller.updateEmployee);
    // this.router.get(`${this.path}/info/`, authMiddleware, this.controller.findUserByCustomerByEmail);
    // this.router.post(`${this.path}`, authMiddleware, validationMiddleware(CreateUserDto, 'body'), adminValidation, this.controller.createUser);
    // this.router.get(`${this.path}/info/`, authMiddleware, this.controller.findOne);
    // this.router.delete(`${this.path}/:id`, authMiddleware, adminValidation, this.controller.deleteUser);
  }
}

export default APIUsersRoute;
