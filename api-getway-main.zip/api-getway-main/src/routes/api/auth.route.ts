import RefreshNewTokenRequestDto from '@/dtos/refresh-new-token-request.dto';
import { CreateUserDto } from '@/dtos/users.dto';
import authMiddleware from '@/middlewares/auth.middleware';
import validationMiddleware from '@/middlewares/validation.middleware';
import AuthController from '@controllers/auth.controller';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';
import { ChangePasswordDto } from '@/dtos/change-password.dto';
import { CreateUserPartnerDto } from '@/dtos/usersPartner.dto';
import ForgotPasswordDto from '@/dtos/forgot-password.dto';
import SetNewPasswordDto from '@/dtos/set-new-password.dto';
import ResetPasswordTokenDto from '@/dtos/reset-password-token.dto';

class AuthRoute implements Routes {
  public path = '/auth';
  public router = Router();
  public authController = new AuthController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    const userNav = [];

    this.router.post(`${this.path}/logout`, authMiddleware, this.authController.logOut);
    this.router.post(`${this.path}/login`, validationMiddleware(CreateUserDto, 'body'), this.authController.logIn);
    this.router.post(`${this.path}/signup`, this.authController.signUp);
    this.router.post(`${this.path}/signup-customer`, this.authController.signUpCustomer);
    this.router.post(
      `${this.path}/refresh-token`,
      validationMiddleware(RefreshNewTokenRequestDto, 'body'),
      authMiddleware,
      this.authController.refreshToken,
    );
    this.router.post(
      `${this.path}/reset-password-request`,
      validationMiddleware(ForgotPasswordDto, 'body'),
      this.authController.sendResetPasswordRequest,
    );
    this.router.post(
      `${this.path}/verify-reset-password-token`,
      validationMiddleware(ResetPasswordTokenDto, 'body'),
      this.authController.verifyResetPasswordToken,
    );
    this.router.post(`${this.path}/set-new-password`, validationMiddleware(SetNewPasswordDto, 'body'), this.authController.setNewPassword);
    this.router.post(`${this.path}/change_password`, authMiddleware, this.authController.changePassword);
  }
}

export default AuthRoute;
