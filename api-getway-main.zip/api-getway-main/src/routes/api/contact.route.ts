import ContactController from '@/controllers/contact.controller';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class ContactRoute implements Routes {
  public path = '/contacts';
  public router = Router();
  public controller = new ContactController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.post(`${this.path}`, this.controller.submitContact);
  }
}

export default ContactRoute;
