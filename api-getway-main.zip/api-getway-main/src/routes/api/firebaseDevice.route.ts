import FcmTokenController from '@/controllers/firebaseDevice.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class FcmTokenRoute implements Routes {
  public path = '/fcm_tokens';
  public router = Router();
  public controller = new FcmTokenController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.post(`${this.path}`, authMiddleware, this.controller.create);
    this.router.put(`${this.path}/dev_time_only/:fcm_token`, this.controller.testDeviceNotification);
    this.router.put(`${this.path}/dev_time_only/`, authMiddleware, this.controller.broadcastTestNotification);
  }
}

export default FcmTokenRoute;
