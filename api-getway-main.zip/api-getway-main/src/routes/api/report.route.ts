import OverviewReportController from '@/controllers/overview_report.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class OverviewReportRoute implements Routes {
  public path = '/report';
  public router = Router();
  public controller = new OverviewReportController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}/overview`, authMiddleware, this.controller.getOverviewReport);
    this.router.get(`${this.path}/revenue/warehouse`, authMiddleware, this.controller.getRevenueByWarehouseReport);
    this.router.get(`${this.path}/revenue/warehouse/:id/detail-by-type`, authMiddleware, this.controller.getRevenueByWarehouseDetailByTypeReport);
    this.router.get(`${this.path}/revenue/delivery_bill/sale`, authMiddleware, this.controller.getRevenueByDeliveryBillBySaleReport);
    this.router.get(`${this.path}/revenue/delivery_bill/sale/export_excel`, authMiddleware, this.controller.exportDeliveryBillReport);
    this.router.get(`${this.path}/revenue/delivery_bill/sale/:id`, authMiddleware, this.controller.getDetailDeliveryBillReport);
    this.router.get(`${this.path}/revenue/delivery_bill/customer`, authMiddleware, this.controller.getRevenueByDeliveryBillByCustomerReport);
    this.router.get(`${this.path}/revenue/delivery_bill/customer/export_excel`, this.controller.exportRevenueReportByCustomer);
    this.router.get(`${this.path}/revenue/awb`, authMiddleware, this.controller.getRevenueByAwbReport);
    this.router.get(`${this.path}/revenue/tracking`, authMiddleware, this.controller.getRevenueByTrackingReport);
    this.router.get(`${this.path}/exploitation`, authMiddleware, this.controller.getExploitationReport);
    this.router.post(`${this.path}/exploitation/export/`, authMiddleware, this.controller.exportExploitationReport);
  }
}

export default OverviewReportRoute;
