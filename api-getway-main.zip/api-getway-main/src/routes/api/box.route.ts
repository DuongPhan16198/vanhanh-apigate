import BoxController from '@/controllers/box.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class BoxsRoute implements Routes {
  public path = '/boxes';
  public router = Router();
  public controller = new BoxController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}/:id/trackings/`, authMiddleware, this.controller.getTracking)
    this.router.put(`${this.path}/:id/import`, authMiddleware, this.controller.importTracking);
    // this.router.put(`${this.path}/update/:id`, authMiddleware, this.controller.update);
    // this.router.get(`${this.path}/trackings`, authMiddleware, this.controller.list);
    // this.router.get(`${this.path}/find`, authMiddleware, this.controller.find);
    // this.router.delete(`${this.path}/delete/:id`, authMiddleware, this.controller.delete);
    // this.router.get(`${this.path}/suggestion/:code`, authMiddleware, this.controller.codeSuggestion)
  }
}

export default BoxsRoute;
