import DeliveryBillsController from '@/controllers/deliver_bills.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class DeliveryBillsRoute implements Routes {
  public path = '/delivery_bills';
  public router = Router();
  public controller = new DeliveryBillsController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    // this.router.get(`${this.path}/find`, this.controller.find);
    this.router.get(`${this.path}/status_update_bill`, authMiddleware, this.controller.getStatusUpdateBill);
    this.router.get(`${this.path}`, authMiddleware, this.controller.list);
    this.router.get(`${this.path}/status`, authMiddleware, this.controller.getDeliveryBillStatus);
    this.router.get(`${this.path}/search`, this.controller.search);
    this.router.get(`${this.path}/:id/search_tracking`, authMiddleware, this.controller.searchTracking);
    this.router.get(`${this.path}/waiting_create_delivery_bills`, authMiddleware, this.controller.waitingCreateDeliveryBills);
    this.router.get(`${this.path}/trackings`, authMiddleware, this.controller.getTrackingOfCurrentCustomer);
    this.router.get(`${this.path}/:id/tracking_customer_detail`, authMiddleware, this.controller.getTrackingCustomer);
    this.router.get(`${this.path}/:id/bill_customer_detail`, authMiddleware, this.controller.getBillCustomer);
    this.router.get(`${this.path}/:id`, authMiddleware, this.controller.getDetailDeliveryBill);
    this.router.put(`${this.path}/:id`, authMiddleware, this.controller.updateDeliveryBills);
    this.router.post(`${this.path}`, authMiddleware, this.controller.createDeliveryBill);
    this.router.post(`${this.path}/:id/create_many_tracking_in_bill`, authMiddleware, this.controller.createManyTrackingInBill);
    this.router.delete(`${this.path}/:id/delete_tracking_in_bill`, authMiddleware, this.controller.deleteTrackingInBill);
    this.router.put(`${this.path}/:id/pack_tracking_in_bill`, authMiddleware, this.controller.packTrackingInBill);
    this.router.put(`${this.path}/:id/print_delivery_bills`, authMiddleware, this.controller.printDeliveryBill);
    this.router.put(`${this.path}/:id/skip_approval`, authMiddleware, this.controller.skipApprovalToPrintDeliveryBill);
    this.router.put(`${this.path}/:id/sale_approve_delivery_bills`, authMiddleware, this.controller.saleApproveDeliveryBill);
    this.router.put(`${this.path}/:id/accountant_approve_delivery_bills`, authMiddleware, this.controller.accountantApproveDeliveryBill);
    this.router.put(`${this.path}/:id/export_delivery_bills`, authMiddleware, this.controller.exportDeliveryBill);
    this.router.put(`${this.path}/:id/pack_delivery_bills`, authMiddleware, this.controller.packDeliveryBill);
    this.router.put(`${this.path}/:id/finish_delivery_bills`, authMiddleware, this.controller.finishDeliveryBill);
    this.router.put(`${this.path}/:id/failed_delivery_bills`, authMiddleware, this.controller.failedDeliveryBill);
    this.router.put(`${this.path}/:id/cancel_delivery_bills`, authMiddleware, this.controller.cancelDeliveryBill);
    this.router.get(`${this.path}/:id/export_excel`, authMiddleware, this.controller.exportExcel);
    this.router.put(`${this.path}/:id/delivered_image`, authMiddleware, this.controller.updateDeliveredImageUrl);
    this.router.put(`${this.path}/:id/assign_shipper`, authMiddleware, this.controller.assignShipperToADeliveryBill);
    // this.router.post(`${this.path}/create/`, this.controller.create);
    // this.router.post(`${this.path}/update/:id(\\d+)`, this.controller.updateStore);
    // this.router.delete(`${this.path}/cancel/:id`, this.controller.deleteStore);
    // this.router.get(`${this.path}/suggestion/:code`, authMiddleware, this.controller.codeSuggestion);
  }
}

export default DeliveryBillsRoute;
