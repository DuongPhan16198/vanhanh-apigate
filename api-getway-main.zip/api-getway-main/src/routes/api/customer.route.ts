import CustomerController from '@/controllers/customer.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class CustomerRoute implements Routes {
  public path = '/customers';
  public router = Router();
  public controller = new CustomerController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}/`, authMiddleware, this.controller.listCustomer);
    this.router.get(`${this.path}/customer-tag`, authMiddleware, this.controller.listCustomerTag);
    this.router.post(`${this.path}/`, authMiddleware, this.controller.addCustomer);
    this.router.get(`${this.path}/export/`, authMiddleware, this.controller.exportCustomer);
    this.router.get(`${this.path}/search`, authMiddleware, this.controller.searchCustomer);
    this.router.get(`${this.path}/tracking-type`, authMiddleware, this.controller.findAllTrackingType);
    this.router.get(`${this.path}/:id`, authMiddleware, this.controller.getCustomerById);
    this.router.put(`${this.path}/:id`, authMiddleware, this.controller.updateCustomerInfo);
    this.router.get(`${this.path}/:id/trackings`, authMiddleware, this.controller.getTrackingsByCustomerId);
    this.router.get(`${this.path}/:id/orders`, authMiddleware, this.controller.getOrdersByCustomerId);
    this.router.get(`${this.path}/:id/transactions`, authMiddleware, this.controller.getTransactionsByCustomerId);
    this.router.delete(`${this.path}/:id`, authMiddleware, this.controller.deleteCustomer);
  }
}

export default CustomerRoute;
