import PageController from '@/controllers/page.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class PagesRoute implements Routes {
  public path = '/pages';
  public router = Router();
  public controller = new PageController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}/interfaces/`, this.controller.getPageInterfaces);
    this.router.get(`${this.path}`,  this.controller.getListPages);
    this.router.get(`${this.path}/:id`,  this.controller.getDetailPageById);
    this.router.post(`${this.path}`, authMiddleware, this.controller.create);
    this.router.put(`${this.path}/:id`, authMiddleware, this.controller.update);
    this.router.delete(`${this.path}/:id`, authMiddleware, this.controller.delete);
  }
}

export default PagesRoute;
