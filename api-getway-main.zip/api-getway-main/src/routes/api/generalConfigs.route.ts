import GeneralConfigController from '@/controllers/config.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class GeneralConfigRoute implements Routes {
  public path = '/general_configs';
  public router = Router();
  public controller = new GeneralConfigController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}/box-coefficient-config`, authMiddleware, this.controller.getBoxCoefficientConfig);
    this.router.put(`${this.path}/box-coefficient-update/:id`, authMiddleware, this.controller.updateBoxCoefficient);
    this.router.get(`${this.path}/interfaces/`, authMiddleware, this.controller.getConfigInterfaces);
    this.router.get(`${this.path}/list/`, authMiddleware, this.controller.getListConfigs);
    // public method
    this.router.get(`${this.path}/public`, this.controller.getPublicGeneralConfig);

    this.router.get(`${this.path}/:id`, authMiddleware, this.controller.getDetailConfig);
    this.router.post(`${this.path}`, authMiddleware, this.controller.create);
    this.router.put(`${this.path}/:id`, authMiddleware, this.controller.update);
    this.router.delete(`${this.path}/:id`, authMiddleware, this.controller.delete);
  }
}

export default GeneralConfigRoute;
