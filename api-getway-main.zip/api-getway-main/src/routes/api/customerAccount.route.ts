import CustomerController from '@/controllers/customer.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class CustomerAccountRoute implements Routes {
  public path = '/customer_accounts';
  public router = Router();
  public controller = new CustomerController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.put(`${this.path}`, authMiddleware, this.controller.updateCurrentCustomerAccountInfo);
    this.router.delete(`${this.path}`, authMiddleware, this.controller.deleteCurrentCustomerAccount);
  }
}

export default CustomerAccountRoute;
