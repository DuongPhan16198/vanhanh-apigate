import NewsCategoryController from '@/controllers/newsCategory.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class NewsCategoryRoute implements Routes {
  public path = '/news-categories';
  public router = Router();
  public controller = new NewsCategoryController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}`, this.controller.getAllNewsCategories);
  }
}

export default NewsCategoryRoute;
