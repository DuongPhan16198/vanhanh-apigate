import UsersController from '@/controllers/users.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class APIEmployeeRoute implements Routes {
  public path = '/employees';
  public router = Router();
  public controller = new UsersController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}/`, authMiddleware, this.controller.getUsers);
    this.router.get(`${this.path}/get-sale`, authMiddleware, this.controller.getAllSale);
    this.router.get(`${this.path}/get-employee-exploit`, authMiddleware, this.controller.getAllExploit);
    this.router.get(`${this.path}/search/`, authMiddleware, this.controller.searchUser);
    this.router.get(`${this.path}/role/`, authMiddleware, this.controller.employeeRole);
    this.router.get(`${this.path}/permissions/`, authMiddleware, this.controller.employeePermission);
    this.router.get(`${this.path}/:id/customers/`, authMiddleware, this.controller.getCustomerBelongToEmployee);
    this.router.get(`${this.path}/:id`, authMiddleware, this.controller.getUserById);
    this.router.put(`${this.path}/:id`, authMiddleware, this.controller.updateEmployee);
    this.router.post(`${this.path}/`, authMiddleware, this.controller.createEmployee);
    this.router.delete(`${this.path}/:id`, this.controller.deleteUser);
    // this.router.get(`${this.path}/info/`, authMiddleware, this.controller.findUserByCustomerByEmail);
    // this.router.get(`${this.path}/get-all`, authMiddleware, this.controller.getAllEmployee);
    // this.router.delete(`${this.path}/:id`, authMiddleware, adminValidation, this.controller.deleteUser);
  }
}

export default APIEmployeeRoute;
