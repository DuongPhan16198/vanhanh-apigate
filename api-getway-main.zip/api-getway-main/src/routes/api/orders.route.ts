import OrderController from '@/controllers/orders.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class OrdersRoute implements Routes {
  public path = '/orders';
  public router = Router();
  public controller = new OrderController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}`, authMiddleware, this.controller.list);
    this.router.get(`${this.path}/:id`, authMiddleware, this.controller.getOrderById);
    this.router.put(`${this.path}/:id`, authMiddleware, this.controller.updateOrderById);
    this.router.post(`${this.path}`, authMiddleware, this.controller.createOrder);
    // this.router.get(`${this.path}/suggestion/:code`, authMiddleware, this.controller.codeSuggestion);
    // this.router.post(`${this.path}/update/:id(\\d+)`, this.controller.updateStore);
    this.router.delete(`${this.path}/:id`, authMiddleware, this.controller.cancelOrder);
  }
}

export default OrdersRoute;
