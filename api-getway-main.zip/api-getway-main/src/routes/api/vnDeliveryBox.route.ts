import VnDeliveryBoxController from '@/controllers/vnDeliveryBox.controller';
import VnDeliveryOrderController from '@/controllers/vnDeliveryOrder.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class VnDeliveryBoxesRoute implements Routes {
  public path = '/vn_delivery_boxes';
  public router = Router();
  public controller = new VnDeliveryBoxController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}`, authMiddleware, this.controller.getListVnDeliveryBoxes);
    this.router.get(`${this.path}/status`, this.controller.getListVnDeliveryBoxesStatus);
    this.router.get(`${this.path}/:id`, authMiddleware, this.controller.getDetailVnDeliveryBox);
    this.router.put(`${this.path}/:id/note`, authMiddleware, this.controller.update);
    this.router.put(`${this.path}/success`, authMiddleware, this.controller.deliverySuccessfulBoxes);
    this.router.put(`${this.path}/failed`, authMiddleware, this.controller.deliveryFailedBoxes);
    this.router.put(`${this.path}/receiving`, authMiddleware, this.controller.receiveBoxes);
  }
}

export default VnDeliveryBoxesRoute;
