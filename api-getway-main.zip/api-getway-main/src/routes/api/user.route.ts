import UsersController from '@/controllers/users.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class APIUserRoute implements Routes {
  public path = '/user';
  public router = Router();
  public controller = new UsersController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    // this.router.get(`${this.path}/`, authMiddleware, this.controller.findOne);
    // this.router.put(`${this.path}/:id`, authMiddleware, this.controller.updateEmployee);
  }
}

export default APIUserRoute;
