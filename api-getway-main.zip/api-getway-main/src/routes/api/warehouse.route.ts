import UsersController from '@/controllers/users.controller';
import WarehouseController from '@/controllers/warehouse.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class WarehouseRoute implements Routes {
  public path = '/warehouses';
  public router = Router();
  public controller = new WarehouseController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}/warehouse-config`, authMiddleware, this.controller.getAllWarhouseConfig);
  }
}

export default WarehouseRoute;
