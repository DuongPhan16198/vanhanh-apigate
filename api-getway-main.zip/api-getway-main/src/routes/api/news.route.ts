import NewsController from '@/controllers/news.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class NewsRoute implements Routes {
  public path = '/news';
  public router = Router();
  public controller = new NewsController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}`, this.controller.list);
    this.router.get(`${this.path}/:id`, this.controller.newsDetail);
    this.router.post(`${this.path}`, authMiddleware, this.controller.create);
    this.router.put(`${this.path}/:id`, authMiddleware, this.controller.update);
    this.router.delete(`${this.path}/:id`, authMiddleware, this.controller.delete);
  }
}

export default NewsRoute;
