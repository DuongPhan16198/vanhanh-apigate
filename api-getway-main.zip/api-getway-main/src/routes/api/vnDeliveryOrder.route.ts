import VnDeliveryOrderController from '@/controllers/vnDeliveryOrder.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class VnDeliveryOrdersRoute implements Routes {
  public path = '/vn_delivery_orders';
  public router = Router();
  public controller = new VnDeliveryOrderController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}`, authMiddleware, this.controller.getListVnDeliveryOrders);
    this.router.get(`${this.path}/status`, this.controller.getVnDeliveryOrderStatus);
    this.router.get(`${this.path}/:id`, authMiddleware, this.controller.getDetailVnDeliveryOrder);
    this.router.post(`${this.path}`, authMiddleware, this.controller.create);
    this.router.put(`${this.path}/delivering-status/:id`, authMiddleware, this.controller.switchStatusOfAVnDeliveryOrder);
    this.router.put(`${this.path}/assign/:id`, authMiddleware, this.controller.assignShipperAVnDeliveryOrder);
    this.router.put(`${this.path}/:id`, authMiddleware, this.controller.update);
    this.router.delete(`${this.path}/:id`, authMiddleware, this.controller.delete);
  }
}

export default VnDeliveryOrdersRoute;
