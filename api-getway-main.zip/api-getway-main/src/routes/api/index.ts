import { Router } from 'express';
import { Routes } from '../../interfaces/routes.interface';
import AuthRoute from './auth.route';
import AWBRoute from './awb.route';
import BoxRoute from './box.route';
import RolesRoute from './role.route';
import TrackingRoute from './trackings.route';
import DeliveryBillsRoute from './deliver_bills.route';
import CustomerTransactionLogs from './customerTransactionLogs.route';
import APIUsersRoute from './users.route';
import APIUserRoute from './user.route';
import PermissionRoute from './permission.route';
import CustomerRoute from './customer.route';
import APIEmployeeRoute from './employees.route';
import OrdersRoute from './orders.route';
import WarehouseRoute from './warehouse.route';
import OverviewReportRoute from './report.route';
import GeneralConfigRoute from './generalConfigs.route';
import BusinessPartnerRoute from './businessPartner.route';
import NewsRoute from './news.route';
import NewsCategoryRoute from './categories.route';
import PagesRoute from './page.route';
import VnDeliveryUnitsRoute from './vnDeliveryUnit.route';
import ContactRoute from './contact.route';
import VnDeliveryOrdersRoute from './vnDeliveryOrder.route';
import FcmTokenRoute from './firebaseDevice.route';
import CustomerAccountRoute from './customerAccount.route';
import VnDeliveryBoxesRoute from './vnDeliveryBox.route';

class APIRoutes implements Routes {
  static readonly API_PREFIX = 'api';
  public path = '/api/';
  public router = Router();

  constructor(childRoutes: Routes[]) {
    childRoutes.forEach(item => {
      this.router.use(`${this.path}`, item.router);
    });
  }
}

export default new APIRoutes([
  new AuthRoute(),
  new AWBRoute(),
  new BoxRoute(),
  new RolesRoute(),
  new TrackingRoute(),
  new DeliveryBillsRoute(),
  new CustomerTransactionLogs(),
  new APIUsersRoute(),
  new APIUserRoute(),
  new RolesRoute(),
  new PermissionRoute(),
  new CustomerRoute(),
  new APIEmployeeRoute(),
  new OrdersRoute(),
  new WarehouseRoute(),
  new OverviewReportRoute(),
  new GeneralConfigRoute(),
  new BusinessPartnerRoute(),
  new NewsRoute(),
  new NewsCategoryRoute(),
  new PagesRoute(),
  new VnDeliveryUnitsRoute(),
  new ContactRoute(),
  new VnDeliveryOrdersRoute(),
  new FcmTokenRoute(),
  new CustomerAccountRoute(),
  new VnDeliveryBoxesRoute(),
]);
