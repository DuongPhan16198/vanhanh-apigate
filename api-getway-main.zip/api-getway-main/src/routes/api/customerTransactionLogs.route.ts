import CustomerTransactionLogs from '@/controllers/customerTransactionLogs.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import uploadFileMiddleware from '@/middlewares/customUploadFile.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class customerTransactionLogs implements Routes {
  public path = '/transactions';
  public router = Router();
  public controller = new CustomerTransactionLogs();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    // this.router.get(`${this.path}/find`, this.controller.find);
    this.router.get(`${this.path}`, authMiddleware, this.controller.list);
    this.router.get(`${this.path}/status`, authMiddleware,this.controller.getTransactionStatus);
    this.router.get(`${this.path}/:id/customer-detail`, authMiddleware, this.controller.getTransactionByCustomerId);
    this.router.get(`${this.path}/:id`, authMiddleware, this.controller.getTransactionById);
    this.router.post(`${this.path}`, authMiddleware, uploadFileMiddleware, this.controller.createTransaction);
    this.router.put(`${this.path}/:id`, authMiddleware, this.controller.approveTransaction);
    // this.router.post(`${this.path}/create`, this.controller.createStore);
    // this.router.post(`${this.path}/update/:id(\\d+)`, this.controller.updateStore);
    // this.router.delete(`${this.path}/delete/:id(\\d+)`, this.controller.deleteStore);
  }
}

export default customerTransactionLogs;
