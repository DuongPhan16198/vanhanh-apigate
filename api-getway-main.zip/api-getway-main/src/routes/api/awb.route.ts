import AwbController from '@/controllers/awb.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { validate } from '@/middlewares/validate.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';
import { syncAwb } from '@/schema/awb.schema';
import uploadFileMiddleware from '@/middlewares/customUploadFile.middleware';

class AwbsRoute implements Routes {
  public path = '/awbs';
  public router = Router();
  public controller = new AwbController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}/list`, authMiddleware, this.controller.list);
    this.router.get(`${this.path}/status`, authMiddleware, this.controller.listStatus);
    this.router.get(`${this.path}/check-ready`, authMiddleware, this.controller.checkReady);
    this.router.get(`${this.path}/search`, authMiddleware, this.controller.search);
    this.router.get(`${this.path}/:id`, authMiddleware, this.controller.getDetailAwb);
    this.router.put(`${this.path}/update/:id`, authMiddleware, this.controller.update);
    this.router.post(`${this.path}/sync`, authMiddleware, validate(syncAwb), this.controller.sync);
    this.router.post(`${this.path}/import_excel`, authMiddleware, uploadFileMiddleware, this.controller.importExcel);
  }
}

export default AwbsRoute;
