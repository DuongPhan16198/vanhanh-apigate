import BusinessPartnerController from '@/controllers/businessPartner.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class BusinessPartnerRoute implements Routes {
  public path = '/business_partners';
  public router = Router();
  public controller = new BusinessPartnerController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}`, authMiddleware, this.controller.getAllPartner);
  }
}

export default BusinessPartnerRoute;
