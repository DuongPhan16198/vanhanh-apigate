import TrackingsController from '@/controllers/trackings.controller';
import apiKeyAuthMiddleware from '@/middlewares/apiKeyAuth.middleware';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class TrackingsRoute implements Routes {
  public path = '/trackings';
  public router = Router();
  public controller = new TrackingsController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}/`, authMiddleware, this.controller.getListTrackings);
    this.router.get(`${this.path}/find-from-warehouse`, authMiddleware, this.controller.findFromDatabaseAndWarehouse);
    this.router.get(`${this.path}/public`, this.controller.findPublic);
    this.router.post(`${this.path}/create_many`, authMiddleware, this.controller.createMany);
    this.router.post(`${this.path}/create_many/:box_id`, authMiddleware, this.controller.createManyWithBox);
    this.router.get(`${this.path}/suggestion/:code`, authMiddleware, this.controller.codeSuggestion);
    this.router.get(`${this.path}/warehouse/`, authMiddleware, this.controller.getTrackingWarehouse);
    this.router.get(`${this.path}/type`, authMiddleware, this.controller.getTrackingType);
    this.router.get(`${this.path}/status`, authMiddleware, this.controller.getStatusTracking);
    this.router.get(`${this.path}/:id/detail-customer`, authMiddleware, this.controller.getTrackingByCustomer);
    this.router.post(`${this.path}/:id/create-order`, authMiddleware, this.controller.addOrderId);
    this.router.post(`${this.path}/:id/check-request`, authMiddleware, this.controller.requestCheck);
    this.router.get(`${this.path}/:id`, authMiddleware, this.controller.getDetailTracking);
    this.router.put(`${this.path}/:id`, authMiddleware, this.controller.updateTracking);
    this.router.put(`${this.path}/:id/exploit`, authMiddleware, this.controller.exploitTracking);
    this.router.post(`${this.path}/`, authMiddleware, this.controller.createTracking);
    this.router.delete(`${this.path}/:id`, authMiddleware, this.controller.delete);
    this.router.post(`${this.path}/sync-tracking`, authMiddleware, this.controller.syncTracking);
    this.router.post(`${this.path}/webhook/ticket-response`, apiKeyAuthMiddleware, this.controller.updateTicketResponse);
    // this.router.put(`${this.path}/webhook/wh-status`, apiKeyAuthMiddleware, this.controller.updateWhStatusOfTracking);
    this.router.post(`${this.path}/webhook/wh-change`, apiKeyAuthMiddleware, this.controller.findAndUpdateFromWarehouse);
  }
}

export default TrackingsRoute;
