import RoleController from '@/controllers/role.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';

class RolesRoute implements Routes {
  public path = '/roles';
  public router = Router();
  public controller = new RoleController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}/list`, authMiddleware, this.controller.list);
    this.router.get(`${this.path}/:id`, authMiddleware, this.controller.roleDetail);
    this.router.post(`${this.path}/create`, authMiddleware, this.controller.create);
    this.router.put(`${this.path}/update/:id`, authMiddleware, this.controller.update);
    this.router.delete(`${this.path}/delete/:id`, authMiddleware, this.controller.delete);

    // this.router.get(`${this.path}/`, authMiddleware, this.controller.update);
    // this.router.get(`${this.path}/checkReady`, authMiddleware, this.controller.checkReady)
    // this.router.delete(`${this.path}/delete/:id`, authMiddleware, this.controller.delete);
    // this.router.get(`${this.path}/suggestion/:code`, authMiddleware, this.controller.codeSuggestion)
  }
}

export default RolesRoute;
