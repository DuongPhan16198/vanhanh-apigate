import PermissionController from '@/controllers/permission.controller';
import authMiddleware from '@/middlewares/auth.middleware';
import { Routes } from '@interfaces/routes.interface';
import { Router } from 'express';


class PermissionRoute implements Routes {
  public path = '/permissions';
  public router = Router();
  public controller = new PermissionController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}/list`, authMiddleware, this.controller.list);
    this.router.post(`${this.path}/create`, authMiddleware, this.controller.create);
    // this.router.put(`${this.path}/:id`, authMiddleware, this.controller.update);
    // this.router.get(`${this.path}/checkReady`, authMiddleware, this.controller.checkReady)
    // this.router.delete(`${this.path}/delete/:id`, authMiddleware, this.controller.delete);
    // this.router.get(`${this.path}/suggestion/:code`, authMiddleware, this.controller.codeSuggestion)
  }
}

export default PermissionRoute;
