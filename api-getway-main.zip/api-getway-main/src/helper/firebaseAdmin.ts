// firebaseAdmin.js

import admin from "firebase-admin";
import serviceAccount from "./firebaseKeys/DPCTestProjThinhTT/serviceAccountKey.json";

// Initialize Firebase Admin SDK
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

export default admin;
