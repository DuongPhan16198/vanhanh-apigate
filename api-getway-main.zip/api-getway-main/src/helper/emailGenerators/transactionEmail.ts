function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

export const generateTransactionNotifiationEmail = (transaction, contactInformation) => {
  const { email: emailAdmin, phone_number, address_1, address_2, address_3 } = contactInformation;
  const { customerTransactionBalance, customerTransactionNote, customerTransactionDate } = transaction;
  const balanceColor = customerTransactionBalance > 0 ? `rgb(8, 177, 35)` : `rgb(255,92,117)`;
  return `
  <div style="background-color: rgb(245, 245, 245); font-family: 'Roboto', sans-serif">
    <div style="width: 500px; margin: 0px auto; line-height: 25px; padding: 32px 16px; color: rgb(35, 38, 47); background-color: rgb(255, 255, 255)">
      <div style="margin-bottom: 20px; font-size: 14px">
        <span style="margin-right: 10px">
          <img src="https://dp-cargo.com/assets/images/emails/logo.png" alt="" width="95px" style="margin-right: 10px; position: relative; top: 3px" />
        </span>
        <span style="margin-right: 10px"
          ><img src="https://dp-cargo.com/assets/images/emails/phone.png" alt="" style="margin-right: 10px; position: relative; top: 3px" /><a
            href="tel:${phone_number}"
            style="color: rgb(35, 38, 47); text-decoration: none"
            >${phone_number}</a
          ></span
        >
        <span
          ><img src="https://dp-cargo.com/assets/images/emails/email.png" alt="" style="margin-right: 10px; position: relative; top: 3px" /><a
            href="mailto:${emailAdmin}"
            style="color: rgb(35, 38, 47); text-decoration: none"
            >${emailAdmin}</a
          ></span
        >
      </div>
      <p style="font-size: 24px; font-weight: 700; line-height: 150%; color: rgb(25, 32, 56); text-align: center">Bạn có 1 giao dịch mới</p>
      <div style="margin-bottom: 20px">
        <table width="100%" style="border-collapse: collapse; text-align: left">
          <tbody>
            <tr>
              <td style="width: 200px; vertical-align: top; padding: 8px 0px">
                <span style="display: flex; align-items: center"
                  ><img
                    style="margin-right: 10px"
                    src ="https://dp-cargo.com/assets/images/emails/note.png"
                    alt=""
                  />Nội dung:</span
                >
              </td>
              <td style="padding: 8px 0px">${customerTransactionNote || ''}</td>
            </tr>
            <tr>
              <td style="width: 200px; vertical-align: top; padding: 8px 0px">
                <span style="display: flex; align-items: center"
                  ><img
                    style="margin-right: 10px"
                    src="https://dp-cargo.com/assets/images/emails/money.png"
                    alt=""
                  />Số dư sau giao dịch</span
                >
              </td>
              <td style="padding: 8px 0px">
                <strong style="color: ${balanceColor}">${customerTransactionBalance ? numberWithCommas(customerTransactionBalance) : ''} VND</strong>
              </td>
            </tr>
            <tr>
              <td style="width: 200px; vertical-align: top; padding: 8px 0px">
                <span style="display: flex; align-items: center"
                  ><img
                    style="margin-right: 10px"
                    src="https://dp-cargo.com/assets/images/emails/clock.png"
                    alt=""
                  />Thời gian xử lý</span
                >
              </td>
              <td style="padding: 8px 0px">${customerTransactionDate.toLocaleString('en-US', { timeZone: 'Asia/Ho_Chi_Minh' })}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div style="width: 532px; margin: 0px auto; line-height: 25px; padding: 0; color: rgb(35, 38, 47); background-color: rgb(255, 255, 255)">
      <img style="width: 100%" src="https://dp-cargo.com/assets/images/emails/line-footer.png" alt="" />
    </div>

    <div style="width: 500px; margin: 0px auto; line-height: 25px; padding: 32px 16px; color: rgb(35, 38, 47); background-color: rgb(255, 255, 255)">
      <div style="width: 300px; margin: 0px auto 20px; padding: 20px 0px; border-bottom: 1px solid rgb(228, 228, 228)">
        <p style="text-align: center">
          <img src="https://dp-cargo.com/assets/images/emails/logo.png" alt="" />
        </p>
        <div style="margin-top: 20px; text-align: center; font-size: 14px">
          <span style="margin-right: 10px"
            ><img src="https://dp-cargo.com/assets/images/emails/phone.png" alt="" style="margin-right: 10px; position: relative; top: 3px" /><a
              href="tel:0901323266"
              style="color: rgb(35, 38, 47); text-decoration: none"
              >${phone_number}</a
            ></span
          >
          <span
            ><img src="https://dp-cargo.com/assets/images/emails/email.png" alt="" style="margin-right: 10px; position: relative; top: 3px" /><a
              href="mailto:${emailAdmin}"
              style="color: rgb(35, 38, 47); text-decoration: none"
              >${emailAdmin}</a
            ></span
          >
        </div>
      </div>
      <p style="display: flex">
        <span style="width: 32px"><img src="https://dp-cargo.com/assets/images/emails/location.png" alt="" /></span
        ><span style="flex: 1 1 0%">${address_1}</span>
      </p>
      <p style="display: flex">
        <span style="width: 32px"><img src="https://dp-cargo.com/assets/images/emails/location.png" alt="" /></span
        ><span style="flex: 1 1 0%">${address_2}</span>
      </p>
      <p style="display: flex">
        <span style="width: 32px"><img src="https://dp-cargo.com/assets/images/emails/location.png" alt="" /></span
        ><span style="flex: 1 1 0%">${address_3}</span>
      </p>
      <div style="margin-top: 20px; text-align: center">
        <img src="https://dp-cargo.com/assets/images/emails/app-store.png" alt="" style="margin-right: 20px" /><img
          src="https://dp-cargo.com/assets/images/emails/ch-play.png"
          alt=""
        />
      </div>
    </div>
  </div>
  `;
};
