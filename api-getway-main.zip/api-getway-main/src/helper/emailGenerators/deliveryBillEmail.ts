export const generateDeliveryBillNotificationEmail = (deliveryBill, contactInformation) => {
  // public/assets/images/emails/app-store.png
  // public/assets/images/emails/ch-play.png
  // public/assets/images/emails/clock.png
  // public/assets/images/emails/email.png
  // public/assets/images/emails/line-footer.png
  // public/assets/images/emails/location.png
  // public/assets/images/emails/logo.png
  // public/assets/images/emails/money.png
  // public/assets/images/emails/note.png
  // public/assets/images/emails/phone.png

  const { email: emailAdmin, phone_number, address_1, address_2, address_3 } = contactInformation;
  const { id,code, name, customerAddress, deliveryBillStatus, email, note, tracking } = deliveryBill;
  return `<div style="background-color: rgb(245, 245, 245); font-family: 'Roboto', sans-serif">
  <div style="width: 500px; margin: 0px auto; line-height: 25px; padding: 32px 16px; color: rgb(35, 38, 47); background-color: rgb(255, 255, 255)">
    <div style="margin-bottom: 20px; font-size: 14px">
      <span style="margin-right: 10px">
        <img src="https://dp-cargo.com/assets/images/emails/logo.png" alt="" width="95px" style="margin-right: 10px; position: relative; top: 3px" />
      </span>
      <span style="margin-right: 10px"
        ><img src="https://dp-cargo.com/assets/images/emails/phone.png" alt="" style="margin-right: 10px; position: relative; top: 3px" /><a
          href="tel:${phone_number}"
          style="color: rgb(35, 38, 47); text-decoration: none"
          >${phone_number}</a
        ></span
      >
      <span
        ><img src="https://dp-cargo.com/assets/images/emails/email.png" alt="" style="margin-right: 10px; position: relative; top: 3px" /><a
          href="mailto:${emailAdmin}"
          style="color: rgb(35, 38, 47); text-decoration: none"
          >${emailAdmin}</a
        ></span
      >
    </div>
    <p style="font-size: 24px; font-weight: 700; line-height: 150%; color: #192038; text-align: center">Cập nhật thông tin phiếu xuất kho</p>
    <p style="text-align: center">Kính chào quý khách hàng!</p>
    <p style="text-align: center">DP-Cargo xin phép gửi đến quý khách hàng thông tin cập nhật của phiếu xuất kho</p>
    <div style="border: 1px solid rgb(204, 51, 51); padding: 16px; border-radius: 5px">
      <h3 style="font-size: 16px; color: rgb(204, 51, 51)">Thông tin Phiếu xuất kho</h3>
      <table width="100%" style="border-collapse: collapse">
        <tbody>
          <tr>
            <td style="width: 100px; padding: 6px 0px">Mã phiếu:</td>
            <td style="padding: 6px 0px"><strong>${code}</strong></td>
          </tr>
          <tr>
            <td style="width: 100px; padding: 6px 0px">Người nhận:</td>
            <td style="padding: 6px 0px"><strong>${name}</strong></td>
          </tr>
          <tr>
            <td style="width: 100px; padding: 6px 0px">Địa chỉ:</td>
            <td style="padding: 6px 0px"><strong>${customerAddress}</strong></td>
          </tr>
          <tr>
            <td style="width: 100px; padding: 6px 0px">Trạng thái:</td>
            <td style="padding: 6px 0px"><strong>${deliveryBillStatus}</strong></td>
          </tr>
          <tr>
            <td style="width: 100px; padding: 6px 0px">Email:</td>
            <td style="padding: 6px 0px"><strong>${email}</strong></td>
          </tr>
          <tr>
            <td style="width: 100px; padding: 6px 0px">Ghi chú:</td>
            <td style="padding: 6px 0px"><strong>${note || ''} </strong></td>
          </tr>
        </tbody>
      </table>
    </div>
    <div style="border: 1px solid rgb(204, 51, 51); padding: 16px; border-radius: 5px; margin-top: 20px">
      <h3 style="font-size: 16px; color: rgb(204, 51, 51)">Danh sách Tracking</h3>
      <table width="100%" style="border-collapse: collapse">
        <thead>
          <tr style="text-align: left">
            <th style="padding: 8px 0px; border-bottom: 1px solid rgb(182, 182, 182)"><strong>Mã Tracking</strong></th>
            <th style="padding: 8px 0px; border-bottom: 1px solid rgb(182, 182, 182)"><strong>Cân nặng</strong></th>
          </tr>
        </thead>
        <tbody>
          ${tracking
            .map(x => {
              if (x.code && x.trackingCalculationWeight)
                return `
          <tr>
            <td style="width: 50%; padding: 8px 0px; border-bottom: 1px solid rgb(182, 182, 182)">${x.code}</td>
            <td style="padding: 8px 0px; border-bottom: 1px solid rgb(182, 182, 182)">${x.trackingCalculationWeight}</td>
          </tr>
          `;
            })
            .join('')}
        </tbody>
      </table>
    </div>
    <div style="margin-top: 20px; text-align: center">
      <a
        href="${process.env.CUSTOMER_DOMAIN}/deliverybill"
        style="
          background-color: rgb(204, 51, 51);
          border-radius: 4px;
          color: rgb(255, 255, 255);
          min-width: 117px;
          display: inline-block;
          padding: 8px 0px;
          text-decoration: none;
        "
        >Xem chi tiết</a
      >
    </div>
  </div>

  <div style="width: 532px; margin: 0px auto; line-height: 25px; padding: 0; color: rgb(35, 38, 47); background-color: rgb(255, 255, 255)">
    <img style="width: 100%" src="https://dp-cargo.com/assets/images/emails/line-footer.png" alt="" />
  </div>

  <div style="width: 500px; margin: 0px auto; line-height: 25px; padding: 32px 16px; color: rgb(35, 38, 47); background-color: rgb(255, 255, 255)">
    <div style="width: 300px; margin: 0px auto 20px; padding: 20px 0px; border-bottom: 1px solid rgb(228, 228, 228)">
      <p style="text-align:center">
        <img src="https://dp-cargo.com/assets/images/emails/logo.png" alt="" />
      </p>
      <div style="margin-top: 20px; text-align: center; font-size: 14px">
        <span style="margin-right: 10px"
          ><img src="https://dp-cargo.com/assets/images/emails/phone.png" alt="" style="margin-right: 10px; position: relative; top: 3px" /><a
            href="tel:0901323266"
            style="color: rgb(35, 38, 47); text-decoration: none"
            >${phone_number}</a
          ></span
        >
        <span
          ><img src="https://dp-cargo.com/assets/images/emails/email.png" alt="" style="margin-right: 10px; position: relative; top: 3px" /><a
            href="mailto:${emailAdmin}"
            style="color: rgb(35, 38, 47); text-decoration: none"
            >${emailAdmin}</a
          ></span
        >
      </div>
    </div>
    <p style="display: flex">
      <span style="width: 32px"><img src="https://dp-cargo.com/assets/images/emails/location.png" alt="" /></span
      ><span style="flex: 1 1 0%">${address_1}</span>
    </p>
    <p style="display: flex">
      <span style="width: 32px"><img src="https://dp-cargo.com/assets/images/emails/location.png" alt="" /></span
      ><span style="flex: 1 1 0%">${address_2}</span>
    </p>
    <p style="display: flex">
      <span style="width: 32px"><img src="https://dp-cargo.com/assets/images/emails/location.png" alt="" /></span
      ><span style="flex: 1 1 0%">${address_3}</span>
    </p>
    <div style="margin-top: 20px; text-align: center">
      <img src="https://dp-cargo.com/assets/images/emails/app-store.png" alt="" style="margin-right: 20px" /><img
        src="https://dp-cargo.com/assets/images/emails/ch-play.png"
        alt=""
      />
    </div>
  </div>
</div>

`;
};

// export const generateDeliveryBillNotificationEmail = DeliveryBill=>{
//   return `<div style="background-color: rgb(245, 245, 245); font-family: 'Roboto', sans-serif">
//   <div style="width: 500px; margin: 0px auto; line-height: 25px; padding: 32px 16px; color: rgb(35, 38, 47); background-color: rgb(255, 255, 255)">
//     <div style="margin-bottom: 20px; font-size: 14px">
//       <span style="margin-right: 10px">
//         <img src="https://dp-cargo.com/assets/images/emails/logo.png" alt="" width="95px" style="margin-right: 10px; position: relative; top: 3px" />
//       </span>
//       <span style="margin-right: 10px"
//         ><img src="https://dp-cargo.com/assets/images/emails/phone.png" alt="" style="margin-right: 10px; position: relative; top: 3px" /><a
//           href="tel:0901323266"
//           style="color: rgb(35, 38, 47); text-decoration: none"
//           >${phone_number}</a
//         ></span
//       >
//       <span
//         ><img src="https://dp-cargo.com/assets/images/emails/email.png" alt="" style="margin-right: 10px; position: relative; top: 3px" /><a
//           href="mailto:${emailAdmin}"
//           style="color: rgb(35, 38, 47); text-decoration: none"
//           >${emailAdmin}</a
//         ></span
//       >
//     </div>
//     <p style="font-size: 24px; font-weight: 700; line-height: 150%; color: #192038; text-align: center">Cập nhật thông tin phiếu xuất kho</p>
//     <p style="text-align: center">Kính chào quý khách hàng!</p>
//     <p style="text-align: center">
//       Lorem Ipsum&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum&nbsp;is simply dummy text of the printing and
//       typesetting industry.
//     </p>
//     <div style="border: 1px solid rgb(204, 51, 51); padding: 16px; border-radius: 5px">
//       <h3 style="font-size: 16px; color: rgb(204, 51, 51)">Thông tin Phiếu xuất kho</h3>
//       <table width="100%" style="border-collapse: collapse">
//         <tbody>
//           <tr>
//             <td style="width: 100px; padding: 6px 0px">Mã phiếu:</td>
//             <td style="padding: 6px 0px"><strong>DPOP21032400012</strong></td>
//           </tr>
//           <tr>
//             <td style="width: 100px; padding: 6px 0px">Người nhận:</td>
//             <td style="padding: 6px 0px"><strong>Thư Anh</strong></td>
//           </tr>
//           <tr>
//             <td style="width: 100px; padding: 6px 0px">Địa chỉ:</td>
//             <td style="padding: 6px 0px"><strong>黒髪７丁目７６３ー熊本大学国際会館Ｃ203-2</strong></td>
//           </tr>
//           <tr>
//             <td style="width: 100px; padding: 6px 0px">Trạng thái:</td>
//             <td style="padding: 6px 0px"><strong>Đã đóng hàng</strong></td>
//           </tr>
//           <tr>
//             <td style="width: 100px; padding: 6px 0px">Email:</td>
//             <td style="padding: 6px 0px"><strong>lethu260902@gmail.com</strong></td>
//           </tr>
//           <tr>
//             <td style="width: 100px; padding: 6px 0px">Ghi chú:</td>
//             <td style="padding: 6px 0px"><strong>ABC</strong></td>
//           </tr>
//         </tbody>
//       </table>
//     </div>
//     <div style="border: 1px solid rgb(204, 51, 51); padding: 16px; border-radius: 5px; margin-top: 20px">
//       <h3 style="font-size: 16px; color: rgb(204, 51, 51)">Danh sách Tracking</h3>
//       <table width="100%" style="border-collapse: collapse">
//         <thead>
//           <tr style="text-align: left">
//             <th style="padding: 8px 0px; border-bottom: 1px solid rgb(182, 182, 182)"><strong>Mã Tracking</strong></th>
//             <th style="padding: 8px 0px; border-bottom: 1px solid rgb(182, 182, 182)"><strong>Cân nặng</strong></th>
//           </tr>
//         </thead>
//         <tbody>
//           <tr>
//             <td style="width: 50%; padding: 8px 0px; border-bottom: 1px solid rgb(182, 182, 182)">DPTEST16030011</td>
//             <td style="padding: 8px 0px; border-bottom: 1px solid rgb(182, 182, 182)">2.63</td>
//           </tr>
//           <tr>
//             <td style="width: 50%; padding: 8px 0px; border-bottom: 1px solid rgb(182, 182, 182)">DPTEST16030011</td>
//             <td style="padding: 8px 0px; border-bottom: 1px solid rgb(182, 182, 182)">2.63</td>
//           </tr>
//           <tr>
//             <td style="width: 50%; padding: 8px 0px; border-bottom: 1px solid rgb(182, 182, 182)">DPTEST16030011</td>
//             <td style="padding: 8px 0px; border-bottom: 1px solid rgb(182, 182, 182)">2.63</td>
//           </tr>
//           <tr>
//             <td style="width: 50%; padding: 8px 0px; border-bottom: 1px solid rgb(182, 182, 182)">DPTEST16030011</td>
//             <td style="padding: 8px 0px; border-bottom: 1px solid rgb(182, 182, 182)">2.63</td>
//           </tr>
//         </tbody>
//       </table>
//     </div>
//     <div style="margin-top: 20px; text-align: center">
//       <a
//         href="#"
//         style="
//           background-color: rgb(204, 51, 51);
//           border-radius: 4px;
//           color: rgb(255, 255, 255);
//           min-width: 117px;
//           display: inline-block;
//           padding: 8px 0px;
//           text-decoration: none;
//         "
//         >Xem chi tiết</a
//       >
//     </div>
//     <div style="margin-top: 20px; position: relative; left: -16px; width: calc(100% + 32px)">
//       <img
//         style="width: 100%"
//         src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAfQAAAAeCAYAAADafuzaAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAG5SURBVHgB7du7bRRRGIbh/yAKcOACXAMyksMtxVQADoh3SQHLdgWGDlwCpBC4BRewK620JmHPcJjBIBH5upe5PE80Hbyamf9LAQze9/39UUrlvJTYC6CTUgCD1YQ8oozrx1EAnSboMEBCDv0j6DAglwcHe1W1HNef1g8D6BVBhwG4HI12qsViUlK8DqCXBB16rAl5vr5+U39eb0K+E0BvCTr0kJDD8Ag69My3ly8On0Uam6DBsAg69ITLdRg2QYeOE3KgIejQUc0ELefleQg5EIIOnfNngvZjcWJLDvxP0KEjXK4DtxF0aDkhB+5D0KHFmglaKukkhBy4Q3q7u1sCgHYo5dOyqo5O5/N5wAM8DwC2rn6z+pJzflWH/CrgEQQdYIuakNf/Picfp9OvAU8g6ABbIOSsmqADbFIpV7/qkB/PZp8DVkjQATZjXr+Vn+aqOnPwxjoIOsB63YQ8ZyFnrQQdYE3+hvydkLMJgg6wYini4mfORyZobJKgA6zIv8v19y7X2QJBB3giEzTaQNABHutmgnZ0PJtdBGyZoAM83DxSmnyYTs8CWkLQAe7PBI3WEnSAuwk5rfcbLG29ppTYoaYAAAAASUVORK5CYII="
//         alt=""
//       />
//     </div>
//     <div style="width: 275px; margin: 0px auto 20px; padding: 20px 0px; border-bottom: 1px solid rgb(228, 228, 228)">
//       <p>
//         <img
//           src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPAAAAAqCAYAAACN8NbbAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAACd+SURBVHgB7X17bFzXmd93zr1DUbK9GtlSomAda2gIQSw/NFTsRQpko6HSV9DWolwgBVo0orzZFruoI9JrOQu0aw7dLbKxnYg0GmSBRSzKKPrHArXJGNsAu405NBZYN7askeN4Xaexho7ilW3KHsYSnzP39Ped170zHA5nRpTldP1Jw5l773l855zvfR5XvHDnvuNEYpA+wrBcrZYuLC/TSxfeo/lqla4WKKVK+FMSRAXgNDlaLpfpCsGxHTuy+NqPTw8+WyVRJlKKUHdZCDUjSZ6uEJ159N13i9QB5HM5WigWM9QBLAGH9dqez+eRaDS9iShNHQLaSn9SLpfoCsBwJkNLFy/mlBB7cdkTRdFWkjIj0cdK97GYiarVs4GUZxYrleJGjXWyXtBTRiiVjoTI8DMztqKkoqioUG8rYyteuPNzin6NoHTxIr1SnqP5SoWuKjAjCzG+XKmMbdTgfmP79hzK7MfPr+KzDb9tVQrjbS4UM3F8H7+pJBQVkGDym++8M9FqXcPp9LalVOo9LkbfEPhnKSFZvnmkb7qsoHB15JvvvnuyWfn5G28Ui0tLUA501JWpWSNZhymf/7rCa9tpkcP3+/g6AyE2/l/Wqbdpmy3zSCEOo9x+IJH2bWT8bD/X1e2+mZkKeDbZLkPX1XtQGaGmG6qE7XqDiKjrg7P4OaKWl6fXEmRg4DvzSLqfPnRQaITIUgdwCcw7df7tq8/EDGBkWa32fesyNMV/BOPKIBiGhuVx8JxiiUrfEZRkWstrhtIc4/HfMohkelmIoW+dP19qVud/2r69j4LgWeUoOEGrjpjJExQJjYbhuUhI+aU/Pn++0Kz8PIi2Mj+fx8+HnERgBrbESmQJ1dXvGSeu2+HkBYpt8lnUf+969SdheMcOqoB5UFAeJWVc/Yl6axiXEoIz0R81TI77U3/89tsHmtaLPqiCcdHPw2h7zjOqLcD1h6srwbg1StVq5ZFGwiu868UX83SV4H/fuS8vSQxTm3BNGFLfzk/SX771d7QSRXRVAeZPFIanYfL2tWvO5tPpNG3aNBxZLQVzTbOIoHggQayesPlhZAe5RnoLTQh8axvS7l2PeRkgMPZ6wWCJ1woDW5hwhCxU/FfXKxYXW2qnlNJzvtG+wvVZrNyEiLlXtz/mLKolZGEFVw8SPZvfufNAfj0hAjeBXnutB3meCIlyzmSp5Q7GyrY1ISgsHhZHncCpar6IwG1rWgLsPtDo6Da1sPCEDIN+06cyKZlt00TMzK7PKWmkCKf9e2BSnxjeuTMzcv78SLIuSVcR4McVqENgJr41vZU+IpDGiEx9I53OtJoBBJgRmzefBoMOBlCb+oORCjBc+Kk/zNAYIIVvd08EuA7dc4Hn5psHUvEnBZOrlfpR5kHUpUy5fC0UlxO48lCXx4NxQNrQ3Kd8C+bjtUtLAkyzS5o2cLt0O0J8uF2oR4X8bX4zs5tv3W5bJy58GmnaaPuCy/y+FoBrAGs/MG8f0p1C+pxvCz4eB1On8G3lPkRfJPrf4ipdPp0en9LD5883ZGAtNP70T3swti+hjIOBHUfXNtvfSve3vo/fuo95LEhZHHX/OHwZJ64b18MP79xZo/DCRkj8eN++AVBDhlqEQImzd546pRv042w2i5HpXy+PUIKJ/iAJ6hg+8xu/QT+FP3zVtbCBNDTxCXz3rZfwm2DeSMopSNdMfNfKX/tl/UWnobx9a0El7UrnOHGQrbqwMNlK/VUQdX05pjBjKDNJKyf/vV2paJWaWgPUli0ULCxoBlOx0WAfOm2rfINrVC2r6GQtzlXQT6yRIGSP3LJpP5VpVXu/u2cPzc3NDaCPT8T5hXDaDq4KM4cxnblM6Uz82KLVOCTjDc4iQLfISD1MDWAKzPs8NH4kxbPImbHNSpjM1m2o6QwhbHviIENtfynnRBj8xPB/3rlz+o+s9bGKgV/83Of6gf2JdviKO/v5O/dt+/yLL42KIHhaUAvMfxmMm4Sea6+h13/1QesZQORg90mM2VHaeMj9AfzZb8/OFtZKwMwDn2hK1vZR7GF6A1abxpZ7rCOs+UqKyPhLvkEUc1nhj1oJrgRBLiAiEfumytvLpEqgUma8tK1TOQr3hnoLoDBbEHCQKL4T12GExPto4Jyp34BnZLglLpO2XZ0J6/vDmL2Kwhx+1zDwn4N5S3NzvUh1InDNSzqxRCSdpLTM5PHTtoJutG2uXCXcwNWlPzz/dyepDhzzQjD9CL2VcQ1NlE+x8Iv7IvmQPB0knyRiHmRluQgews8CX69iYFBGuVYetgahEu+bGqhErTDwBsGO7u72GNgQxwRVKuMg5KcTxLIhABJgE6ew1vMQWhq9u8vQFFsOMU2rWgXnAihlJDPTC9yvwFdagraZPJFUq9URagECCRyVYxfhKnWu1ziKHiC2kBxmTn1Q69AF83NFimzsxYpEJfxXFh785bl7GuW1TJhlbYO0sOakYWRTjtHQpsgaH4qZqMhMlAqeCpRnBt/BMf5GKKKcuapSJzFmxaqQJfcUxipbh3oaDylzzgDBeEVQ32ONcH6hVBIY2yeUmfargbj7XEk+xlEi5jcFYSlo1yoGT8QF4l7UBeUevfHG3LFz5wqrGBhBrcLfZLM9QCZDLQIz/V0vvlA0+U/1IbKdq3mu1AAqPkxXANJdXdQuYK7vxApR7yZEj6MgOE5m6majIDcI36zRNMO3P/3pAX7ubwgXgrBWVRygKoOwQCiicOwX5wrJMtjvu/a667iMfqQ+iDTODxx/sIXg1XEMfETQENKQsAWvAVaC4MlUpZIDLrtqos8OU/w+DhyGmmh6hSDO6Ph4WjJuCfKzQksZb1NNr5X/K6++ymUUUca9mJ/NIW3aEPUqjVhz+fpbbwlKpR6CdbHLG8Nx20wWc6OM0sYuhuFYvlRaqx0TOhg1Npa+7tpr+0HDh8HYe5dVtaHJvvjBBwPAZ39cnwlGKo+DZ9rToL+xX6VSk8m6uYyFubnDsLBQqcisbp8ZCTcW6MG78VVo0SC6fMB8M2vojif114Ly8rKORrcLaPjEI7Ozh/g3zN681ZwbAhig/m9duLBqoEdvuuksvjLWWE6A419tt01AIB4ZWpuwPBzPZDIyivYj/SA+h5CntF6e0Zs+ze7RYRN5TlRu4MTm7u7fWVhcfAK/B+rsN8/kiIje3KyuE5kMlSuVPhnIZ1Wy9ISjAGV2YOhcrXCqh+9mMmJFVZ9Frlys/h0hC/ZlR4befDOv04IBKhcvDqDoE2v7Z5qpzsI3/lIrfbWqTVTJDZVW4/z47t0iWl5+A7XucmaMf1hrdowMvvnmyFp1sOAbGx/fhoFBv0VZQWZ6ITGF54rkX5NH33zzUEgfAkCjZ+gKMC/DcocBLPRA/4Pbtw+CiUfhs+aPpdMTG2VSI0C0yoz6rzfddBiRk4w3VCV559OYhXrW6Mn73pwZoBbBEiF/TraSnhk+gDXkicoYANpUYzpZEeLhANH9ULKGcn64JxhvdeNrr623IaRQRoooWztr46aTTGMrYbjuVFS0aRMFS4tpjvKoZIzPzsdCeBV84vl59tQPO95JGA1ebsDyKGFs2mZehiMmS6H+PguO6vwHA5gZ2GWdbBO4ojj6pM1noUbuK63NvBpnMDAExfsXhbgfVz+ixGyeW/Mi4j7kMaCOGJgZMgiD46JVplTU0YKNVuByFnOgI4Yx9TPBizAeLZeL+L3KpAadlGHWlO1FpsVyV/ULtNGg7nmZHF1bg3HQZn5vpnXm7QQ2CTrulYMnDB+kGv8PIOz/tns3LZGckcZ7FEnmsaEy5uNMs3oWu7qErFRu8tEil9mH4qh839nmFgZrvMWlpRxy7FWizgQ2bnv592eMNmTf97VSCZYNNLXwYT8X+vKhBalo5OsdMG8z6K5WxRIF9wnhBJxygk8IJ6AFnf390sxIK+WxoPiz3bsLK5XKjNbobqEOly1dSDxO3xEDy1AOCF6K1ipcQUN9S3hZRkQ6SqWexncvX9jVVIf+4IYb+mW1WoKfXEr6sg9s3z6MpuTXK5R92OT191jzCZk1IWb7xxClV3EwB4/QFYQ/253JRZHo99MwZBdXGNdbURQ9zum6EFMA883xPKR+wJHfpBls5jv2NquLI9zQSFkbG1N+/sSqetiEa2pfNiPH4T9DQ/diDJ6g2Aj1GFibxS8b/eW5czyP3G8Una3QhemlnachVfh3pdJJ2kBwggNzur1G0GmJ4ZnMCmv0beNpp7UgxBggil9CSRkX1YrlnwFHY50xsF6AoXga5oqYxe3AJxCF5gUdv5xfqDGnOQqasjGPFH7ztYNrLNMvV6MSNHgRpmUWZpUnqm9fuFCzppinhgQH4qi1QJwy62Y9BJi2kTENen2iB11qTir9+9LZAl1BECoYDilew2gQFZrA8WPqa7b9lz7xCQrPnSsJFRlkwcEquYhI6VxNLSq5uMjKIiuszWe1bsKdFr3fv/nmsxoFipcTMnz/ySc5TJ5B/XpBh05N3hl0ukdhrD1TrEDjB0sLd2tcTZC6rvH6ehXzsrWxGEWDyHHcWRrWWq1pr1slpWJv4OmvvfHGPe++8w7GlnKBWQpnTXta5QGv0NoBuzX70Lfc/nBizD9UnTMwR6pPI1JN3d0bw8CLi+XeYrGMQNcUJaO0LcKt6bT+NAWYwujgIjqYF8UXgmq1wHWulZyZloNREO379ZRCqxOggCqEQvK6S6i9mgpkTByWqF2h6y6+uBw4sXt3jrhfE8asMj6w0PqB4mWBGXxKlUoJlGmmfYVdaGAJmK1t1cSV4CmgSysr2YB39zjzT7p5WM8I/CxtV2TERm+treavdfxZI25Ub0Tq4d97IzaFzTOZtUkUxaU5bcjTMWfqcYW1IVaWljKU1JwUM6tuuCQ/O0/mIoJcceMlUhTsde3TAsqvMzH8jtvFr7VptsMsp8WAZxdMoCRhe/hGoVzdno7tT0v86y8aaA82zlfm3UJSFKCUixi86d+y01z1wFM+XUFw8JELFzwRI7g1rNhUXh0ubgVWbbXT5rPpfOEiV/E6JH1ZoisIgXCRWevYkvJrb/E989Wf/cy3PQezECZsOZBJiSVqv4VIw0fNHGlAmKzB6dy5tM/vsyZWXjk/wgembLirpj6VYD4/P8r/80f+789HXEovMHjuVtg0FCtDJ0DQxobjH0q9nVBziaqZMJNEyYU0TuyCS6srK9M1+U1lwpThmmcCUFDOM9QGOBciSKWytsZkENr1Ef/U5X4oUehWgJdgUqcmeQfaFX7afmW0PeZFdXRREzGvZ8Yc7KBoQ+PWoFJnPjMEUmZM75u1eG6o7aY1XpHxPl0h+O+f+cxhpRWrqrHhLUUyhY4k03MkFExRXq6slJEuHfOBEImZJOratKlhJDoN2TUveR+zdVm86WdVvtDhYKsqvflsCTS5D0qKuFatId/Dn4f/zf/5Wc1Cih0QGEvnz6dlVLXVCUfowpnw1ATgO+8V1mvG/5IN/DIyaDttNUEoKRL9V/yqFVwcsQ8qlYxy7TQlutlfJ5TaGttnnnmGQna5hEgItoRAIz8KBf79kWFgEYbpmvBaM9CRYTHB2hXjcyasVovNGJbBmcSIKB9kE7CuJm/CVoMgjzI7dg1Q7nT9Pb1sUjhCFcoNgdUVTCPb6AoBSC/vNIMPgNvdP0Y5SfHnn/3sQPKYhCqiXSlhmdw7rt4m5S1SHNHNNKoP87v8dK9fkmKY0BOiJkp2bq0NHwsFp7Hd1igT8eJoM26MzS+ujB1pMDf+wQcfUFcUpVWCT2MxEK9sgsWQbpAfM3vyflRf+NevvVZyNyHARFTl+WfKxXa9wV+vnrKwvLzMC6UypiTyDr2ItblqlaQTDRKpILjbLiJLKGDbl6ams//q9de1otgwBoZPzJHDNU1gJSrl33qhuGb0MYTfWAlkqfE8rIJ2FdNoSzHV1VXoff75Eq0DbBqnUql+4oUOvGqJtbuo36FmS7dak7VvpOcSO4dQqdP19wK7ok84So7tO0dkB/EZpQ0GZkzhta9FwjlVLpZLiiO95CI/3plLms02NqT8Dc0kDSPRcmmJI9BWYDkmjS1BNP85KODx2GIWIhTqO7x002scaTuI+TxSJ7/y2usjtAYsLixAMsm0TLbRk7u7KcXW7m7Gt0a48oovYlwaQCDZndPbIRPmPdsO4jmXphufClmr2XYPK+uIRZw3WGSGWgSOapfPn8/AOhyIvbcEtXinXsQmPF0m8M4lYHu4os3RJuImkmz6DK71mDUo5pf7ELHNA8utKKqgtSsYez3t6kAzrZSHSU8p6P2f5EyiZuA2H2AOeIouEyIpZ+rv8fYzIJLRF8ZyNWPhFssryj19yy2Dh/72b9ti4qehVWjLlsyhV19t7N+ZtcRUu+VIxPOjJuriIjB2+OwPkdxpmtyca7gjWmNuX23eTMHSUta0USamoIzNDBae+sqrr437NsBzihYXednmsE/P4KxWjCfaOXJojZVpbELPnj9f4i2WfmU5UbyG2NkcZt/5AVoHXoFP/TP41AoWoUioPOf/hlEsoCNM9wQryzNa6TizRohkBJnlYu7pz342d+i11wrN6rXM2wNJ+awksi60F6YJj147CT4C3zEDG40b8BxqrpX0CMutyxz/oFgskV7C1xmkwrBlfBwo60scu+GGgcbav53CVOnR2dlVzCS1b8Vzeta78mt6YwmD/9/5wS230N0tMPHTt92WQ5T3KAYb01vEU15HVqXZs2dAcp1K1M6L6mopvvZ3Rbw7XPlHfhtUMpTMEAjqaYjc4uL+IJCGZ6g2Wmf+ipr+OQSjDEw8KpeXh2PhJlw0iC+2yc2b2SpquImgr1AgMMhZve/YWzWxL2xPCuA+7ntmz57hf/HqqyPUBG6DVv7B7bfvUubsNVET18JVtXvBR7P/5csvqx/ceksJXJaJDRZBcR5r1Ah6AjgeOJQw0+uhPDubQxNOmHiFLys+BsB6IBjvE6ARX07HDAxzGQypWo4aQ5OeoQ0AZ6rzYWB3njpVM1+Locq2G3xCOWcGzcbwYbp8KDS6CX+yAGcrFxOCpWYl4tCEJjf5nb+49daj+DURyWgac7da60gRQcLTLqTPRbxAghf3exe68bFErH09i1qCSs6GmPrtVJaKzRS7MMsVI/yNJNMbSIMoM/VECf8t6xnRai2/gIWnoKg6V48rmLj8P2+7tcBBxcS+2xgvpVfGNWRgnR84PHPrrSWkztg+EYl4G8W+O+XRv5nlanWkETOxRdN13XX98OOPxjKWEoJNvX+wWKqbYcDYksiJhK43dat4H4iUPaGiN/5iz55J/C7AUtC8wOOK2FvWuCMqR9JHKay7oYwRH0+Hvb8SVWsWhXTEwC/cuW+4HeZlzdRrtGtHwEy7EgSH0Rv9FW26qXRFqKFkmmPpNM/Vth18QpdNdYXh0RrJ1yHItbfzTQaI78aTmeQG2RJWHMAhg8dgQMGg8qk9x6nAL1QQjk0y9ZX98PbbB4SKdukM0rK6jhcJ50adhTt3ks3kSLttkSabSJ91YfYKaYLiTQTSh6Pc9ho4goazNqXkqkh0wKu0TABMiKRWsupoMehuaO5De04quxTS6U0vSGBp/BBWx5dfeaVAawAE1jiZgF1sWdjteE5QWZEy0J0KB354+60lIKk/qCet9PlsPL+t6jY9Jf0wsUoJIWA3Xb/qIuk16J8u/icFH6/TL52VQXzihxOiyk89+TZY40cYJuarkX9eJ3g608BKDKzrWCYAWqNt7Xv685/PVCrLh5mIKm5PJoP9EZCsJQSW/B2A0my0/vLI9QtSY2sdbPfP4KP+5e23TwD3fh9TdE5lLfPGoRgrfmtQrTcvjKZK/xCa8MuJgQ2cP0m15TjlEFH0+D/9yatNTfW/uuM2rjDnbziXTApdnCGt1QEamM+5GF+niy0FC6NtG9WnUqmJIKoeT/SBiuvWUoUtpAKtAd1hOAbtxOvNt5JnA22DK79xRCYYhUSG3RpKrFIxPK58nU64ulPvIqFW0TELFYxtgYUMucYa64FiK4TiQEySQf0ct6oVeCaZsoLM7jVVI//kJ6+sskLaZmCz17e1Rf0OgF6hlXRctuKpHlIHK5WVDDWREmHdaidokqyk9gED8zRdLsDCWKlW882SYHpqqEtFrNHSInEsI8XHTCo30Maarmu8X/RgqcJNIyNrKrEibuqOO45GIulHxfl8dFSkCrQOQLNscxaAr9MLGUNuqm7hzVQ2m4kimPtUJ3y8y6DOrlXfl2GhPbv3Dj4tJSNqtJBng/1/lc3m/lGxWGiUvw+C4X/dcUceWB2nWk6INbL7IeJGJJ7bwG/SQrICiMx2j5QITjeqG2N7BGP7Erl1DNZf9ZUmJ7z1ONiejBfVxvgpa4W72RL27FV15EsvvzLSqO62aR7SO0dtAky0QrPnvLvJLKNUU0D+6PrBJLUqMi3XmNa44mCPlV3vnGAmUIRZ+JC1sj1ETeiDzOyBZ8lPyAee8epld4/ia2YcmIv6wDebF4ol0m1nBkLBg+6wumSZnFMf5ibE2X9cXHs6zwHKTjs8pKvTfmw5vMIsV5ctZw6CczibQ+jcAW1SNic3JJn2B9uJ+BC4UJqD3lKkjjfL/w9ffnkMXfKwbbOq6Veyh8dJc4BdUNfvNvIrfL9Jkz807eXfPL5n1hrblFSH9OF9vm8SY6cPLPTtEdye+vHxBwpKLVXsgXuS++3+tZhXjxO1CRCs+6k9aDr/yxCa6ZsctQiRXUZWBzn6kIEj2O2cCQ0tUUyR6MOglNxgGWaU2lUzRCfNqYQyQVz+1EpzoqJmfkNc/OxkxH4YIEV0FPd38emWYZI4hT3pURNqPIfYDEJBu6TBQyROdKwh+hBznBAaXvvDnDusT9YU+uguQ4Skl5IKi09TxwstK4Z1DBAm2yBk9q/37TvevI9fznO8wfaRw1clT70MPXPLhNCU+tTNkGoYn81qXpH2MJRmT18TwffF0z+B8JGHeMbBnurpGTJRL9ULFYeLNP1mBI8Omosp/O5FnaPN+6x9aNfXbMq82iRPmnwtQL1Jzqus6EME3iMM5h16bHa27QPdvwAiqCoCE9N4UktYRk4yiKgjYqPNSB89WgajjMKG7f3iS8UjGOQSWzG859gwvxRJLaa1iK0rFaztRyYB+dK+3lp8EtqYz/gy9KDrl7XHt8YCJD6qtRmIICgZhq9lXtc/uhxSR5/PZg82K+e3i8URGJ69elltHS5hTVuUE5i2jWQFnWR3uQBCG8Jk0s37i8V8XwtrEb5YLE4i/QG0YRz1RIH5OMuF6sZEWwEiFsYRjy9QwOwD9aHOA799+vS6saO2fOBOTtbg9ckckHLX8BXZB0zHz9XRdcZ1FdQHsEQUZUl2Ios4My+yWB/0xn6ligjInaxWq5f1rpw+E5E/gv5k02g/1NQAmbdUpG3Mw8aokz6vXhRfgPCa3hzRxCoXIqCsqlnhRCaaGqnadlRb29oGokIf88fHVGNxHynvsoU22FRNUTqMEAluCMLkrcOlHtCvha5UMO7q8HldYEm3hytVOcxMTDdb4PMFoy37/vqubDal5GGUl+PpGkW10+DuaFm9RDKQBcz/PtcdqYlWFw/VQ3JsMSb7lQhQd5S1y3OTjXIXZXYJqaomVbea/MLz7c3WtMU69sjZyw/6XCaEleq2ZAc/cMMN46LNJZBs/lYqlUNX8gVl7YKJvFcy7prPGkF0tUTdi+XeQvEjg+evM/z4rruyVa9AKqzCSt2LVO6UYVuFv8HYIvCa4TFlrbkMK2pLEJRbWRbcDNpi4B9/bt+ouDLnKbcBqnjXiy/1Ju8c276do4NtzUvDEuj9KDHvx/AxdAJt2Z3iakV6E1AfwLKrqNr1ywsfM+/H8P8DtDsP3NFiiY2E+gBW0GQH1FogqLVAzsfw4YJeTRcEiImI8iOzs0P0EYf8nj108cIFcc3mzWpkY8/Kaxla1sCXteF+A6FhAKtNUA2OV/kYrj6smGWZZcSp5mgDgA9m1y8526Cy6uHSW29lRaXy1KVyOUdXCVo3oaW86tqXoX4FlhBtz0tTp2+1bwUG0+mrIuRYex274YYTD27fvqFBxvWm6FppL7/sW39/6lNiePduGr7+enrw059eFX/pCsNhxCYeBlF2/NpJZrRjO3aIb+zcKcqjo+lLFy/2NUq3Fg5r4Y+yVh26wFsOoQymr81mC7rMT31qFaM/+Ju/Kfj9xKvqx71k2kZ5W4GWg1gfhQAW5lXG7zx16kjyXrsBLI4+8/xto2fMAHW3ppH+eICAVyvzvcjPB8OLR2dn+6kDOHb99UdhQg5AwPggHdo3haDbmUcvXBhslpcZKUylRmUUTSXP97oc4ON1Mae5tVF5LDBUEEwJKVe9F5lNy7zZLK+3aXLsZMu11w5d+uCDE1AEmDKp8qLpATzeJ7q6aMvWrYrm5/l0jVEQZFpUq6Nb0uni/KVL4pprrlELS0uiG9/ixhvp0k9/KnSeVErNV6vikV/8Qrk65+fmxPKlS+lUGD5F5jSNEUz9Hd6iVI/YskVcWloiiYnr7k2b1PyvfnW0HgeHMzP3wubNmJmNqLtSUQtKHbdLdQ/Qpk205Xd/V1383veEqlSOs7kfVCrjm9PpEvA/xFNhW6V8f+S99zRDzn/3u2cxjZSn7u4nuQ6Fdi6srAi1uHgYwmqi65prtLVRXVw8yHnTmzfr6wV8uG4BRp9/5x2BMmgzyPdSKiUee/ttPx/Xsg/8UQhgBXW7fToJYAmlGprPTpMoc3oHB7g0UerfqdTwA3xWNB9IIPiFXSoNhjpiGfYMGDZvChcZMNs00r7P+TjSzQcMiCAY5Pdi4V5e6a2A+szkDJlNGkP8dgjOjjnmHon5ZmZa9DefzXVEb5GEaanLxNws6upjRtdlog605yQIqUBheBx158icr3WSy5BCTET8JgbU6XBR5i31E0T6zKeTj9gjdPkgP+Qd4DKRZ4hfNcN1Q8OU0DeTm+zrUzU+uIfvIWH68yALUeA29Mi7746yZrkEAZTP5U7nCwXuk8Moc27+4kXuo/0rKytDiFvkzcmo6lkQcubS8vIhlHcQ5X1VsPkMQQTNyX0zjHwF4DO4UKmMyNnZCWIcFhd3zS8tnVTmAH4t7GDO9opU6qlUEPDGg+eA16Q0Z1oV5vkF6gsLPcBlb3V5OXtpZeUQ2tVTjwOPOQuCS+fPD4rl5aPVKNoKRhpSZgvnDL5fosXFNLRxL+phYb8f7Z4BnuPAcxj9nYeAKMxHEffpGFsAECYZdgmC5eU30C/czjTSnUBZY7wLjpZ5w45ea31GSrkLeGR5ySnqPqjrfuutl9HmJ4D71nmlHpfV6heR3r8Urp0odI6uKoiR+i2JnQSwePtgo/sclWamtJeT+H0osmuyK1Gkz8wCMfTaI1WNj4bndQv0mTHLPDj8jM+DhsYZRf4RNrVQ3gAzKbsjIMoxlHUyMsfpGNyskMS9EWZ4WamU7QKAOWUO3cvZgweYeTnNGV4IIw3TjeF6CPcHwXAZZrQoinpw7yTjYk8qGVVm8/807vUzc3J9XCa/gA5EMwRJPxbysbIgQn7fEvJnQKz9+t3HZgXaEWimEV6coPitfiwQMS2HdBp3EC8LjFPlYjHDGojxwB9eQDGM+u/hfpa85TCKSsRvuQdusBp26WNShbiH+w/POJDF/cxztmcEv5kRwqnCp7UAB/TP/Sxo7eIW81LtIHgKOPCWxHuR/6DS+3T1eMxFYFY+HjhS9s2CYEiHg75nceBH7Nci7XEFKwD574U1MG33mZd9X6ZSjNsk48v9UwnDfowr0wT3z0hg6SU09FnWeUE32lLhfuNDGDG+ts/v50UkyLdV4wmh4OhN0wraRbyAB+3C5yGlak+5bImB6982+OGDGLnrxRfzq+62G8BCRy1hQNZ6zFqYGcYxObThXl55xQe9MxHp+4aw+DUs/J11ATEdQQWsVCqjZN48UCYjuUt2iVyB30rHTAqimXSHx4tEwEaZV1py/ewL9kb6oD9iwTIozGFqRaXPdxYlEMO41rZMHGF4GGXvYgnO5UBbbtWML+W4kiboZzb0UJHrjexxwM70VUY4F4Lu7knUOwnTmLXsNlErtHPA6ySn2XLddRPcNsbpuvvu498l1w98IijuHwGjllgDaTyEmNTLT5XqZw2nNTuEHLTxhMMtMLEMX19k+mLa9hMzBuN6UOOwZYsTqBr/BQgLHhfgPgZzdsZ2ZlH3pVL8LmYWICev++QnJ9wzhwObrbo+exQS+pK1elFu2vR42NU1uWQYkNswTrYvQXcZK2ByMn7tDr8LuVipVs/8iXO3rJDjb6YD9ofJHMAww4crcr9wfzJTssWm8QS9cb2s2aV5/egulDFZqVReZlqRdTMoLTFwldqP9G4I6OWLdKgR8zK0E8DSUq9abbrySmtMQMVIU4Ysd6JjVr6vNTBMIK2RACDCks2spa0tP6cHjonImNVsJh01u8QUE/7RB3fsYM3Ng5jn7FwHEwqesZuQg5SfsgKqlGjrjCXMnM7Pb4tAejYx+RwwdygBNBVLcs2gwhKPMLtpspwPg35cJQnB4HkY5twb0Lan2Crg12kiz934OAvjNITZU5zmIsxh3L8DxDbDTIpn+6F1dDomXuczWw3Em+fG0fYpfL6uI7cwB7XvaPqb33aYtiY0m4f6GFbLdEWrxfnoV27DWXjPT8DkPcXjENgDBJeMQFIhcFep1I+4fGlWW2WrZiz3cxtd3fysHoeEH8/9wqb2Bf64NjjtiXIYh5zrH2hgPrSojPu7eMtjKOXPXbfymAl3iiUYEX33c91vRhCzIvk69ye+74a1NeTaCXM/Q+b1NWVlyn6qK5U6xWXUn7nWkg8sFYinrTVbHYLSr4tgE7TIh9qlqtHJZkvc2LdqaU4XZhg0w+h6gSg+nhbmUB+/WYG1MQj2iHvLAoI5+j60W2+USuXkykoBaTNeICAv/vbxT/gp4/z9WLlcRCCIt5nl+IXi+tA1aFV89zGzQVpPjF64oPMzEXId0DgFMHMPa0FtZto38AEXbdpyGxAZLkqXH/VD+5fgN2ZZo8GtGEM7StwOzidM/gJP0YA5BepmRvhO0vR/7L33Rh9AmcQCAO0I+f3EqdQ0l8cEzOXpMoATb3KANuD7BcanYsbhwJJpf21/8vMwPPAYiP8P0+n7ub+4bORx98r8vLKyUgQjlSWb7qavyzotrllAoK57YNkUu4Jgjt9FjTaxRvwfwh7TxH2Asm6uJsYl4HdbBQFr2GLIdSB/NzQy171i7yVx8H0xO1twZbFp69qQ7MuU6Z+i7x+Dd4H7jPvGk50ds0UeW1gprGWBc5n7gAXdA9dfz1Yaj2NeL7GESb5i6Q1p+jC//Nz8wsLv8OlckWHuf1t/5tqHwZZ/r0EHuowZfES/NA3+FaR5D33IYN82MazsIfggtHt+nVaj6Sh7ELxhzVn2iR9/zAb/GoGOFRA9hH6/mT6iABzZv50BjqsWrfD8NQfyWPvaNhdh7t3Lb9FMpvt/ZAi7uidn4F0AAAAASUVORK5CYII="
//           alt=""
//         />
//       </p>
//       <div style="margin-top: 20px; text-align: center; font-size: 14px">
//         <span style="margin-right: 10px"
//           ><img
//             src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAGJSURBVHgBpVNBTsJQEJ35JZFlj9CtO2JCGtm0nkC8ge4MmlC4QNudKygLCDvxBMYTWFaibriBcAOWBqTfN0hJJSFtwiz+nz/TvHnzZkp0pLEcnudbS8V+JrhYJ7o3jMJZHoCSY6W4SZrcTPzakFgBK21vE2XjQSe4kUejHczAwoPbygNQGd9MnSTRT/K+93y3EIAmmuGq7GgZZOFaJIqdPIBNC4r1WGsOIKb5Y5AL/xmocaI3TPIZlNY0lYpL4ib8WHxoMi0yBUOOyWT8XT13y8zkGZp6a01zZn6wbYc/JuNYxnxWu2hu3/9AOXWEPsb5BXfU7wQtTMJHMsA7wlcVtCQamVu9YggdCkMjBRAWds15B+ZQKvW7YVi1nTkT3yJdwWKdnmzYsVSts2Lr8y1+4f2e7jzfg6pdVBpJlTJiS1QeROF09007eESeZG/UPkA/CiNO9BVjM5Xi15WhnEREPWB8KCHCreT/kBVn7IX+mxQ6kC2tp1odBMhaoxVeEmsR0UpjqYh0rP0CmBigY8fEkNIAAAAASUVORK5CYII="
//             alt=""
//             style="margin-right: 10px; position: relative; top: 3px"
//           /><a href="tel:0901323266" style="color: rgb(35, 38, 47); text-decoration: none">${phone_number}</a></span
//         >
//         <span
//           ><img
//             src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEmSURBVHgBxVJLTgJBEK03zCTu4AZwA/UGcgK5gbIzGRYNszXpmcSlSrOAuJwj6Ak8gtwAvcGwMw502a0ZbCR0ZgUvqXRVp96rT4ro2IAbCCFbn0QtH+GEqFAqK3YE4qHMCbg0bkF+2AL59DEdbgQGieyxhoyYu676PsRJ+sqAmt3Ll8B+aMYp1YQdk7TpQvOZjQO3ta8AbzdCdjzkTmly2NlTWDkMyqF52TAJAyEnKzPnk8req6orkCiBK2YoAm8E3A5oqjIVaT7nAG0rFI/ShTVTdWFmbq41d2djOXE54f821W/VvrU4uWv/CD/cftAehOSBj7g1QsiYg+mCasDuA6CeWdrcxn+HNErH5rmmeof0bA6pvyVQqZeNqOljR+tyWefYDodvlfBuhg8kTOEAAAAASUVORK5CYII="
//             alt=""
//             style="margin-right: 10px; position: relative; top: 3px"
//           /><a href="mailto:${emailAdmin}" style="color: rgb(35, 38, 47); text-decoration: none">${emailAdmin}</a></span
//         >
//       </div>
//     </div>
//     <p style="display: flex">
//       <span style="width: 32px"
//         ><img
//           src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAHJSURBVHgB5VWxUsJAEN29qDVoQRtFkY74B9DZqV+gfoFQWil/QGslllbyB2BnZ9CGcQITOyxEbcHcuic4I7lLCI6N45tJcre3u+/u3u0F4K8DZzms552iDOQOCtwFAlvZCMDllyssvPA6butHBLbtpKwlOufmLsSACOpyhFXfd/3EBPm8Y48kNRUPJACvyJdD3GKS1/CYMAVw8pOkySeztK1FuooYm0Y25/CWmJ1nEkksed60JoYV0L4pmCTV5GhoBzTa4m7d6CPoKGxbMPgVtUAWsufdVSbdR34Os7mCah9M+QE44ViTBqmwAZFaGqmQ15qfQTcTgXYSyBQYYAF0xwSniAsobELCsr3p7Hz1VfER4gHo0GI1DVioBicsTjNAyiJqrOUKLnKbBbfBBKS6ZgobJhV8C3PUwefEuNh6D+3VsF3bIlWNgnAP5oQVEWOZjINBv7+Szrzx8dmGBOAtO+167cvEBGOSp5vllQwvGR2IT17jGjmOGhdxwcFQlPnjRyZXl9y7qMakiCdQeiwKLIG5NtQNWjLdoIkJFDoddc/jYdiOgaxE/QO+w4IEeHnud9LpDGs+rg8laq97fwa/jexGoake+Ff4APNns+oH1q8YAAAAAElFTkSuQmCC"
//           alt="" /></span
//       ><span style="flex: 1 1 0%">4 Peabody Rd Anx BLDG B Unit 8, Derry, NH, United States, New Hampshire</span>
//     </p>
//     <p style="display: flex">
//       <span style="width: 32px"
//         ><img
//           src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAHJSURBVHgB5VWxUsJAEN29qDVoQRtFkY74B9DZqV+gfoFQWil/QGslllbyB2BnZ9CGcQITOyxEbcHcuic4I7lLCI6N45tJcre3u+/u3u0F4K8DZzms552iDOQOCtwFAlvZCMDllyssvPA6butHBLbtpKwlOufmLsSACOpyhFXfd/3EBPm8Y48kNRUPJACvyJdD3GKS1/CYMAVw8pOkySeztK1FuooYm0Y25/CWmJ1nEkksed60JoYV0L4pmCTV5GhoBzTa4m7d6CPoKGxbMPgVtUAWsufdVSbdR34Os7mCah9M+QE44ViTBqmwAZFaGqmQ15qfQTcTgXYSyBQYYAF0xwSniAsobELCsr3p7Hz1VfER4gHo0GI1DVioBicsTjNAyiJqrOUKLnKbBbfBBKS6ZgobJhV8C3PUwefEuNh6D+3VsF3bIlWNgnAP5oQVEWOZjINBv7+Szrzx8dmGBOAtO+167cvEBGOSp5vllQwvGR2IT17jGjmOGhdxwcFQlPnjRyZXl9y7qMakiCdQeiwKLIG5NtQNWjLdoIkJFDoddc/jYdiOgaxE/QO+w4IEeHnud9LpDGs+rg8laq97fwa/jexGoake+Ff4APNns+oH1q8YAAAAAElFTkSuQmCC"
//           alt="" /></span
//       ><span style="flex: 1 1 0%">Phan Huy Ích, Phường 15, Tân Bình, Hồ Chí Minh</span>
//     </p>
//     <p style="display: flex">
//       <span style="width: 32px"
//         ><img
//           src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAHJSURBVHgB5VWxUsJAEN29qDVoQRtFkY74B9DZqV+gfoFQWil/QGslllbyB2BnZ9CGcQITOyxEbcHcuic4I7lLCI6N45tJcre3u+/u3u0F4K8DZzms552iDOQOCtwFAlvZCMDllyssvPA6butHBLbtpKwlOufmLsSACOpyhFXfd/3EBPm8Y48kNRUPJACvyJdD3GKS1/CYMAVw8pOkySeztK1FuooYm0Y25/CWmJ1nEkksed60JoYV0L4pmCTV5GhoBzTa4m7d6CPoKGxbMPgVtUAWsufdVSbdR34Os7mCah9M+QE44ViTBqmwAZFaGqmQ15qfQTcTgXYSyBQYYAF0xwSniAsobELCsr3p7Hz1VfER4gHo0GI1DVioBicsTjNAyiJqrOUKLnKbBbfBBKS6ZgobJhV8C3PUwefEuNh6D+3VsF3bIlWNgnAP5oQVEWOZjINBv7+Szrzx8dmGBOAtO+167cvEBGOSp5vllQwvGR2IT17jGjmOGhdxwcFQlPnjRyZXl9y7qMakiCdQeiwKLIG5NtQNWjLdoIkJFDoddc/jYdiOgaxE/QO+w4IEeHnud9LpDGs+rg8laq97fwa/jexGoake+Ff4APNns+oH1q8YAAAAAElFTkSuQmCC"
//           alt="" /></span
//       ><span style="flex: 1 1 0%">Sunshine Ciputra Phạm Văn Đồng, Xã Cổ Nhuế, Bắc Từ Liêm, Hà Nội</span>
//     </p>
//     <div style="margin-top: 20px; text-align: center">
//       <img
//         src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHkAAAAoCAYAAADaKFUbAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAeqSURBVHgB7Zy/UhRPEMfnKEr8V+VZJbFHqAn4AgKhkaKRJMILiD4B+ATCEyCBZaKCmZnoC3AEmgoxVnEmlhpwv/lM8b1q5rfH7c7dIXe136qp3Z2d6Zme7pnu6dm7iovw5s2bmWazuVSpVKb8teqzqq7EIKDu055PW/Pz8xv2RUU36+vr1YsXL25+/fp15suXL+7bt2/u169fIZU4/7h582ZIjx49cuPj49t+ki4+fvx4j3dByAh4bGxs5+3bt7X379+7EoONhw8fIuz6379/ZxcXFxsjZF64cGHl8+fPpYCHBMjx48ePU35lXuK5cjyLD58+fep+/PjhSgwHLl++7NbW1hqjo6MTI17aU9jfUsDDBXyp/f396qVLl6ZHvIGe9A+uxPCBiXt0dFQdYZtUetDDiYODA+cncW3E9QnVatXVajVXFFNTU25mZiaklPqnAZoPHjxwqXj58qXrNfpBM0ZfhLyysuK+f//ulpeXXVFsbm66+/fvh/Tp0yf37Nkz1yugNJOTky4V3SiIBWPTa5qnoedCXl1dDcJlJm9vb7sUQOP58+dudna2pSgICKHv7Oy0tJ9n2mGgUA7w6tWrsBpQxu8cTpS3QHl4R6K8zYNunAetLGTRoT6KTh5Xi6WlpRYvQlzW8hrXT4IPYy77jXPT33ad/HLYFLy2Nn1nC9Ogno/c/O/ZC7HpZ3fI8wMQ2vLCC1cvgJDHOz8w4UqeH9BWHjQWFhaaXmlCv6DrFSTcq47oe6UJ9XkvPkiHh4cn+tqODnle4K36WTzae5UVfdq2vPI+RR7IFfmOuh6CJRY0Go0wE/f29ly3YKb+/PkzzJJ6vR7yWCEI4X348MFNT0+HMltbW+7Jkycn2lR5+mPBTIEG+STNQFYOrwiBHnR0Fc28dGzbeeCF26IhuvSDFYq2/Zxx3aAvy/WdO3fCoKdiYmIiMAot6MA8gzk3N9danmGegdS9j9iFpTNPu6pHGzhjPHOPwtAGygNol3wSAowdwSw6eXGaUwkd+PEhyXBFybtBkpBhCJuBBpKwV+Qxexkg7Cj5aCBOBu/zesq7u7uhPnYUGtAEL168CE4Tthe7C/MIgQHhmSvP5AP2/poZvGOgoKd8BpB+YSMRLIqCgsAXq4To0T7lWKVQOossOuLB8hMDOvITeC8hqqyPVAVe6cu1a9e6XxGL2mTvCDRTkGqjy5SeZJMLzWQ8vZRtkcBSW+LsUcjxwrFJBU5NLxyxfwEFdrhqGR8k5J7J3USgsJkpAsZGyqb/CyBU7Cd90P4Zu86119G4fiK3kPE8U5HiaTOIODtc8WD/xVKPk4dDxcxF2JgrvHw5nrZPPJ9FiDIFfYtddwsGErA8MpjdmIrU9kmsQGwJ8bLx8DE7CBzlQwFsebtPPk84EyGnLG2aQQwqyIrxUkYDzZWZR4oVIm+5rD4r2GGBsAlWsF1DsDb0yr2lSx4zvF2bKIfCwNC0Zchj9SCPlYL8JDORdwtFSDAVCjnmTWy1AOE9nqkPCP3ZcmzLSH5mhfeEBQW2ekXL2UQoUWX94BYaF/FLeFRt0b69Fy+EWYH3W1r1behV5QmZxnU7JW2hcgtZA5+KdoOZlYhJA+8HhGdi0GI+FjJgAMS4YsxAeXnLxckOvIRHH7JiyVa4cf/Eh+VNvEjIlFU5+oOCA6tgPqIX8qDRFyHbGZUKBf07taOZp2fqnDaIcZBFA6cDirzl2s3ULL5jXuL+6bBGq5HlBeXSYYT6EK8WWfyKl/igpJOQC9nk1KNDAfvTaY+prRrlsFE2UC9nyIJy8fZM4UFrv/KWi8H2D7/g+vXroW2eAf2yjlcMnVvH8Wz1A3trvXPbN/UHe8/2zaa4Xh4UCoYQU+UQIHU7k+dsVE4HDGbtj9lWdVK2vMGKIkENxcVJGxsbwRFC0DhhWTjtUCFvu4qnd4tCQqZzMJWyH6TDDE4naLZnedMIl4HVoQVA4ewxJNCRp50dp5XLOj2CR/rAAUSsVBJSLKysmQk/TA4L+sH7dsK2x47tlKgQUj4a4AC/KPIcTshTje2Yi3wC7J2LHCrR550cKuXlLWcTh/aAumqPhNMlT9c6QLKzlpbaxWFyx/ZYHr7qyiZb58zyah1W9TnvbiXJ8XLGeRCjAg0jHBTAblGynIpOyhMzrCQvW0ogBy32goH1xPOWi5M8YcHyBb/W8bLOmYSAQqiOrWu9/HZCtlso6tr7vKd5XX0ZwlJCFIilk/NOHXILLFuEQXEgyM97mE65mJYFyz2042WOfrCk0ibvsGNZNPKWEzALlKGenCHZSX1YIOirEs6itVTDC+Nkgxjk2eWb9vFV4m/fFWnDZCikTF3GoPABSS+/8TrrFG+1ui03bClpC1ViMDF6dHS0Pz4+7gYR8ec43ZYbNvCjNy/fxmilUmncuHHDDSLirUm35YYN+AFevvWRP3/+bHtnoYHUSwwPWJ1v3brlvHx3R/gl+tWrV1f5G4ISw4Njea62/mng9+/fa/fu3auXgh4OIMe7d+/u+VkcwmX2j2FqY2Nj6wcHBzPv3r0L+7byd8uDAUztlStX3O3btxEuy/S2F/Acs5j3lbjC69evF7yxJqhb8+l8fs9SIkbjOBF1Wp2fnz8R4fkP4vUSh4rRmf0AAAAASUVORK5CYII="
//         alt=""
//         style="margin-right: 20px"
//       /><img
//         src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIgAAAAoCAYAAAAlprK8AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAsXSURBVHgB7Vx9bFVnGX/OpWnKh7PtitlMaW9RB5nTgmOMkCxtzQZ0DgExGqahNJsyPyYlbiiCKf3DiMlMQSPqYkYxC8x/BDQZJFNbgkPGQKiQIehoQZB+QFuYK/3iPj6/997n8HJ223vO7Qe0vb/k4T33nPfrvO/vPO/zPO9LHYph+/btmenp6RWhUKiMmcOUwnhEo+M4dZJWrVixohE3HPyza9eusJCidt++fWERunLlCqUw/pCTk0OlpaUQEKVESUI7d+5sWLRoEctlSlLC4IJwolauyRHtUdzY2Fi7fv16SiEFxcaNG2nGjBklIbkuOnr0KKWQgo3z58+T2KOFIUohhTjo7OwEQTLTaJRh1qxZJj1x4oR7LxwOu9cdHR2UmZl5WxncgwB4hmu7jDdPorZkSXZ/a31jFmKDVC5fvjyx8XJfmLNfeZ7vffWrPHne9BE3nGRiuKGhgY8fP861tbXmWibH3AfwG1JdXc3isptrvb9mzRq3HjwrKioydbS3txtBniVLlrh5hBgfaAvt4BlQUVHh9gnPR3osRkLACXDDN0HSnqnk0JttPPn0j3hSwwv8oerF7OR+eMQ6jElaunTpbZNoE6c/QnnvK0FwXVxcHHeCUU7zQCorK918SijUPx4I4tsG6ROJUBbdaPsG3aRs6vrSDJpy7Fs0aV0RZeTdS8MJmUij1vfs2eP+hmpHCuBaJtGILguDbevAgQPuvaqqKlMv2oFs3boVgUUaD/BvpCKkNiFKkp7m50TXZlNnqJdufG8udf/xi5TxlcFNzECw7QqkZWVlRuTrpaFGPBvGiy1btphUCTqW4Z8gyBlickT4Zhbd/M9qivRlE08Q5uTdQ12/WECZJytoylOfpKEGjERMmtgJZgLLy8upvr7eNR5xD185xDYokwG0h62dgE2bNpl6bWN07dq1JPYOjXX492KEB46IIYQsUxzJltH8OtHHXiZKbyeHmTqmpRO9+jlK21lAfZsPEl24RkOFkpISozHEQHRVPe4B8CzELjDXWIYweckCJFi2bBnt3r3bJYuS0gYIA00y1rVIIIIYckTkkh1jyRBIcm410fRfE8dIwsKim08/SBkrPk0Zr52hrs111HX+Kg0WmKyCggIS45GuXbvWr5uLZ5o/3uTZ5Kmrq3OJZQN1+2kLGqumpobGMgIRBDaI0SL6GyLLDZ0TTTL9ZUMSAM+7qJe6n/448fwcop8ckg2fkzQUsI1HBaJ+8RDvvjdm0V9Zv20NVH4sIJiR6kRLOBNiErNLXE3Sk23ldxA0MPYJbSs19knuiuEzZFMYHgQKtYMQDA3ipkKAkBO1T25mRjVJT5bLpWih6FXWfTfo4AsNtPulNArfTymMEvhfYkJRgfXBwg5jhThOLLISvY4uN6uJp8NwbZMH0fsF3R30l8bfUT5fo3AR0dLHM6jm9Qyq2tZFjRe7KChWrVpl3FzYAxDYCBDYBHYYfKQhEVtj1KIfQYAyKOsFPDWN/QASKKTCwkLasWPHyL2n71D7tyuZTsuMvyP0OCVyMsJUL+nfJT0q94/I9d/k+q8ih9uYWn7M1P4ih5tXc8Ohezjyppiwh8X5edvhyHGhzkmJWP6JuGJVmu/onkYuFRrVtCHEuWPRR+1L0HK6XRAPdpgfUWDAjvIOlwSOpJplBEuKu8Q4rlZR4Zh9opok/L8JVHv2NcrvvR71cMiJtU9mjcr/qEPVP+ijsuWJm4emgJsLzwTeB9KsrCzjbSCFG4qvCl/daAW0IN5LBR6Svnei4N1wIZibG4pZFuLqGlJEYqSILjJCghhxBOHWbqr9+VkKf6GHOEeriOWL1ee4ZEncPMLoGCyoXMQpbMAzwWCOdpcT72F7TrjGO4Msg91CSBbJeTEoBTao5kB8RMSk8jvc0UR/3vYi5Z17j+iVh4naJpoqXHJQ1Dxpk5DFNzcR7fj9wE1jkGB3YACTDYLpQHu3+W1oBHWgyUAePPc7YZo/2YAatCWQn5/fb/2qcYZDywQkyK0lRr2XWymZOEm4vYne+Nk6ymtrMSRgkOM3QpL2ibEFxqGIaJ7q3zIVPE70y52Jm9bJwGAFNc5QFsEwCFQ1Umy02URRNS42jUllm9/k85IAUVzcx3MIoq0oEy/Y5s2vbQfVBPgwgHjvrfWjbu03tgVAFPQL4iUN8sNMGuhDsRHsRFkoZnfEtIkjhHFUk8jv/KvNtP+n36dpV1ooAnKInYEUGoR/FdUkb7zFVPhlou++RHT9fX/NwnIH4u2zYGDwwl5RLwfPkSIsjgFFHRh0ezfWtm2Qx177dSAx8Nh7gRZDHg2z9/fVog3dq0FZlNG2+psc3NddaYjmRb+8QTu0bfcHbQC6o43+6cam3SfUh/fz/aH59mIqxIsRI93IOZF/i/xL5J8Rdk5HOP9AE7+zcBV3zinlG48s4q65C7nn0YXc++gC7pv3BJ+eNZ/nT52SlEUtL2asdxwG8j7Tw0Eq8GzUm1Gr3z4wBFFPCIeEtG7ktfPgUJDex8Ekr0cBwXkSvU8eL0avNT/y4gBSvPcYyIsRLWXapzhejJ5JwTkZ1I/U22e06X1vP15Q4ANDIIjTIPqgkU3qvCsSI0newct86olyvj77SX7/4ScNSTrnLOSuRxbyxc+U8LMfyU2KGCo4HMQxtzZRXgy+DoKSxZtHBxJ57fx2HpsUSgRMlrcuJaZNCnty5Mt2iYHnOHykE+4lCPKhHyrefF6CiJaISyolO/oLoP92G37GXAkS6Eyq8WKwZiBAFopWld/UTH+o2kC5sqzgfoRvObPVTY20+b/v0nuRPhoMsCyoa6vqPR6gUhFMAuDu+jkrap8zsaFl7Tri1TfQ+RE1ZrXv8fZ2vHUlyqPAcoHgGsYGywvKzp49+7YjCDjYhPHAsqNLSn9j1x+CGakmdZ1Tymtppj0/3EDTWlpj9oZj0tfbW2jmPw7QhotnBk0OhXovGABdz2147Q0MmG7Xe/PruoyJU7tGjUGFltEoLerDYHuN23hGJ/JqvSiDYwmYeK9NMBhgp1n7uXfv3rjEwvspOfWkHKKwgeB7iVkrNsgFUQ/nozLtrWY+9tlnufWhz/OVTy3mtsLFXPeJx3ju5KxAy0cQgb2gywbUNVQolgg9gAzYZ0SxNOl9qF3YIroO2+dVdQlAfcijqhxl1YZQm0QPQWPpsPtCdLsNosuYLisoo+14o72q/hOdb7WXGNRp90ef2UsM0S07CfDaYjSkNogSRGTakWY+Uvw1bnpwCbc8tIRPzVzAZdn5w0YM72Dag6HAZGHQvPn1hLoNTIS9vserE5OpB6NVdFLseuLZIDah7bb762MyBMFvtZ8U+ttrcCtsA3vYCAJyHC5azZdmLuUzM5/itTkP8OSQ//2UoRJMsBpzEkRKmB+THc/w805Uovq0XSWPn4nV/AO1PZgPZqD3Ug3iJc3QE+SZNZz7djMfeuw5bnxgGdfkzuP70yYO+QvfrYKv0+vm2q7w3dpvXVKDaA+bIP69mP27aV39ZTp7+RI9f/U0Hetqo/EEnBxTQ1gPUcPw0wPTdyN0eyGZCLTCP0EuXaDviIxXqGcEl1FdaQw8vKs7eQZlIKCf6CPc3WQx6v5v7p2E7hiPlv+PC1IHjXt4EXIcp2PSpEmUgn+M6f+s7UGot7e3vr+t5BTGL+bMmQMXrc78wJ8bSv0JqpSolJaW4k9QNch11Abp7u4uX7lyZe3UqVPD+/fvp9bWVkph/EHmn0RRmD9iJ5wowT33fyeILx9OT0+vFJukWH6GKYXxCNmr55qenp6t5eXlxtD6PxQJIsgJc82RAAAAAElFTkSuQmCC"
//         alt=""
//       />
//     </div>
//   </div>
// </div>
// `
// }
