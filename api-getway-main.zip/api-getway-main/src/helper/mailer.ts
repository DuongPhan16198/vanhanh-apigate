/* eslint-disable consistent-return */
import nodemailer from 'nodemailer';
import handlebars from 'handlebars';
import { readFileSync } from 'fs';
import { GeneralConfigs } from '@/models/generalConfig.model';
import { HttpException } from '@/exceptions/HttpException';
import { generateDeliveryBillNotificationEmail } from './emailGenerators/deliveryBillEmail';
import { generateTransactionNotifiationEmail } from './emailGenerators/transactionEmail';
interface EmailServerConfigInterface {
  port: string;
  host: string;
  mail_server_user: string;
  mail_server_password: string;
  sender_email_address: string;
  sender_email_name: string;
  admin_contact_receiver_email_address: string;
}

interface ContactConfigInterface {
  address_1: string;
  address_2: string;
  address_3: string;
  email: string;
  facebook_page_url: string;
  logo_url: string;
  page_title: string;
  phone_number: string;
  script_footer: string;
  script_head: string;
  zalo_url: string;
}
class Mailer {
  public static async getEmailServerConfigs(): Promise<EmailServerConfigInterface> {
    try {
      const configs: any = await GeneralConfigs.query().where('config_key', 'MAIL_SERVER_CONFIG').first();
      const configValue = JSON.parse(configs.configValue);
      if (!configs || !configValue || !configValue.config || !configValue.config.length) {
        throw new Error(`Mail server configuration is missing or incorrect!`);
      }
      const requiredParams = [
        'port',
        'host',
        'mail_server_user',
        'mail_server_password',
        'sender_email_address',
        'sender_email_name',
        'admin_contact_receiver_email_address',
      ];

      for (let param of requiredParams) {
        if (!configValue.config[0].hasOwnProperty(param)) {
          throw new Error(`Mail server configuration is missing parameter: ${param}`);
        }
      }
      const values: EmailServerConfigInterface = {
        port: null,
        host: null,
        mail_server_user: null,
        mail_server_password: null,
        sender_email_address: null,
        sender_email_name: null,
        admin_contact_receiver_email_address: null,
      };
      Object.keys(configValue.config[0]).forEach(key => {
        values[key] = configValue.config[0][key];
      });
      return values;
    } catch (error) {
      if (error instanceof SyntaxError && error.message.startsWith('Unexpected')) {
        throw new HttpException(400, `Mail server JSON configuration is missing or incorrect!`);
      } else {
        throw new HttpException(400, error.message);
      }
    }
  }

  public static async getContactConfigs(): Promise<ContactConfigInterface> {
    try {
      const configs: any = await GeneralConfigs.query().where('config_key', 'CONTACT_INFORMATION_CONFIG').first();
      const configValue = JSON.parse(configs.configValue);
      if (!configs || !configValue || !configValue.config || !configValue.config.length) {
        throw new Error(`Contact configuration is missing or incorrect!`);
      }
      const requiredParams = [
        'address_1',
        'address_2',
        'address_3',
        'email',
        'facebook_page_url',
        'logo_url',
        'page_title',
        'phone_number',
        'script_footer',
        'script_head',
        'zalo_url',
      ];

      for (let param of requiredParams) {
        if (!configValue.config[0].hasOwnProperty(param)) {
          throw new Error(`Contact configuration is missing parameter: ${param}`);
        }
      }
      const values: ContactConfigInterface = {
        address_1: null,
        address_2: null,
        address_3: null,
        email: null,
        facebook_page_url: null,
        logo_url: null,
        page_title: null,
        phone_number: null,
        script_footer: null,
        script_head: null,
        zalo_url: null,
      };
      Object.keys(configValue.config[0]).forEach(key => {
        values[key] = configValue.config[0][key];
      });

      return values;
    } catch (error) {
      if (error instanceof SyntaxError && error.message.startsWith('Unexpected')) {
        throw new HttpException(400, `Contact JSON configuration is missing or incorrect!`);
      } else {
        throw new HttpException(400, error.message);
      }
    }
  }

  public static async resetPassword(receiver: string, name: string, active_token: string, isCustomer: boolean) {
    const { port, host, mail_server_user, mail_server_password, sender_email_address, sender_email_name } = await this.getEmailServerConfigs();
    const filePath = `${process.env.HTML_FILES_ROOT}/resetPasswordTemplate.html`;
    const source = readFileSync(filePath, 'utf-8').toString();
    const template = handlebars.compile(source);
    const replacements = {
      user_name: `${name}`,
      user_email: `${receiver}`,
      verify_token_site: `${isCustomer ? process.env.CUSTOMER_DOMAIN : process.env.ADMIN_DOMAIN}/auth/forgot-password/verify/${active_token}`,
    };
    const htmlToSend = template(replacements);
    const transporter = nodemailer.createTransport({
      host,
      port: parseInt(port, 10),
      secure: false,
      auth: {
        user: mail_server_user,
        pass: mail_server_password,
      },
      tls: { rejectUnauthorized: false },
    });
    const option = {
      from: `"${sender_email_name}" <${sender_email_address}>`,
      to: receiver,
      subject: 'Reset mật khẩu tài khoản',
      html: htmlToSend,
    };
    try {
      await transporter.sendMail(option);
    } catch (e) {
      console.error('Có lỗi xảy ra:', e);
    }
  }

  public static async notifyNewContactToAdmin(customerEmail: string, customerPhoneNumber: string) {
    const { port, host, mail_server_user, mail_server_password, sender_email_address, sender_email_name, admin_contact_receiver_email_address } =
      await this.getEmailServerConfigs();
    const filePath = `${process.env.HTML_FILES_ROOT}/newContactSendToAdmin.html`;
    const source = readFileSync(filePath, 'utf-8').toString();
    const template = handlebars.compile(source);
    const replacements = {
      customerEmail,
      customerPhoneNumber,
    };
    const htmlToSend = template(replacements);
    const transporter = nodemailer.createTransport({
      host,
      port: parseInt(port, 10),
      secure: false,
      auth: {
        user: mail_server_user,
        pass: mail_server_password,
      },
      tls: { rejectUnauthorized: false },
    });
    const option = {
      from: `"${sender_email_name}" <${sender_email_address}>`,
      to: admin_contact_receiver_email_address,
      subject: 'Thông tin liên hệ khách hàng mới',
      html: htmlToSend,
    };
    try {
      await transporter.sendMail(option);
    } catch (e) {
      console.error('Có lỗi xảy ra:', e);
    }
  }

  public static async notifyDeliveryBillStatus(receiver: string, deliveryBill: any) {
    const { port, host, mail_server_user, mail_server_password, sender_email_address, sender_email_name } = await this.getEmailServerConfigs();
    const transporter = nodemailer.createTransport({
      host,
      port: parseInt(port, 10),
      secure: false,
      auth: {
        user: mail_server_user,
        pass: mail_server_password,
      },
      tls: { rejectUnauthorized: false },
    });
    const option = {
      from: `"${sender_email_name}" <${sender_email_address}>`,
      to: receiver,
      subject: `Thông báo trạng thái Phiếu xuất kho ${deliveryBill.code}`,
      html: generateDeliveryBillNotificationEmail(deliveryBill, await this.getContactConfigs()),
    };
    try {
      await transporter.sendMail(option);
    } catch (e) {
      console.error('Có lỗi xảy ra:', e);
    }
  }

  public static async notifyTransactionApprovalStatus(receiver: string, transaction: any) {
    const { port, host, mail_server_user, mail_server_password, sender_email_address, sender_email_name } = await this.getEmailServerConfigs();
    const transporter = nodemailer.createTransport({
      host,
      port: parseInt(port, 10),
      secure: false,
      auth: {
        user: mail_server_user,
        pass: mail_server_password,
      },
      tls: { rejectUnauthorized: false },
    });
    const option = {
      from: `"${sender_email_name}" <${sender_email_address}>`,
      to: receiver,
      subject: 'Thông báo Giao dịch mới',
      html: generateTransactionNotifiationEmail(transaction, await this.getContactConfigs()),
    };
    try {
      await transporter.sendMail(option);
    } catch (e) {
      console.error('Có lỗi xảy ra:', e);
    }
  }
}

export { Mailer };
