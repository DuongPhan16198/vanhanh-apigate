import { IsNotEmpty, IsString } from 'class-validator';

export default class RefreshNewTokenRequestDto {
  @IsString()
  @IsNotEmpty()
  refreshToken: string;
}
