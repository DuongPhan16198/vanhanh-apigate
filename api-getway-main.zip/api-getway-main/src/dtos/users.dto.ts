import { IsBoolean, IsEmail, IsString, ValidateIf } from 'class-validator';

export class CreateUserDto {
  @IsEmail()
  @ValidateIf((_object, value) => value)
  public email!: string | null;

  @IsString()
  public password: string;

  @IsString()
  @ValidateIf((_object, value) => value)
  public mobile!: string | null;

  @IsBoolean()
  @ValidateIf((_object, value) => value)
  public rememberMe!: boolean | null;

  @IsEmail()
  @ValidateIf((_object, value) => value)
  public username!: string | null;
}
