import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export default class CreateVnDeliveryUnitDto {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsString()
  @IsNotEmpty()
  code: string;

  @IsString()
  @IsOptional()
  logo_url: number;
}
