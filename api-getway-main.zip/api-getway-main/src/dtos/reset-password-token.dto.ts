import { IsNotEmpty, IsString } from 'class-validator';

export default class ResetPasswordTokenDto {
  @IsString()
  @IsNotEmpty()
  resetPasswordToken: string;
}
