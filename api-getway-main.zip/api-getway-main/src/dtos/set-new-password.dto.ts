import { IsNotEmpty, IsString } from 'class-validator';

export default class SetNewPasswordDto {
  @IsString()
  @IsNotEmpty()
  resetPasswordToken: string;

  @IsString()
  @IsNotEmpty()
  newPassword: string;
}
