import { IsNotEmpty, IsNumber, IsString } from 'class-validator';

export default class CreateVnDeliveryOrder {
  @IsString()
  @IsNotEmpty()
  code: string;

  @IsNumber()
  @IsNotEmpty()
  deliveryBillId: number;

  @IsNumber()
  @IsNotEmpty()
  quantity: number;

  @IsNumber()
  @IsNotEmpty()
  deliveryUnitId: number;
}
