import { IsBoolean, IsEmail, IsNumber, IsString, ValidateIf } from 'class-validator';

export class CreateUserPartnerDto {
  @IsEmail()
  public email: string;
  @IsString()
  public password: string;
  @IsNumber()
  public businessPartnerId: number;
  @IsString()
  public confirmPassword: string;
  @IsBoolean()
  public confirmed: boolean;
  @IsString()
  public phone: string;
  @IsNumber()
  public role: number;
  @IsString()
  public type: string;
  @IsString()
  public username: string;
  @IsNumber()
  public warehouseVn: number;
}
