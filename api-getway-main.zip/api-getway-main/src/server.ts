import App from '@/app';
import validateEnv from '@utils/validateEnv';
import getRoutes from './routes/routes';
import gracefulShutdown from 'http-graceful-shutdown';
import { logger } from './utils/logger';
import { boss } from './config/pgBoss.conf';

validateEnv();

const app = new App(getRoutes());

const server = app.listen();

gracefulShutdown(server, {
  onShutdown: async function (signal) {
    logger.info('Called Signal ::: %s', signal);
    await app.killAllWorkers();
    await boss.deleteAllQueues();
    await boss.clearStorage();
    await boss.stop({
      destroy: true,
      graceful: true,
    });
  },
  forceExit: true,
});
