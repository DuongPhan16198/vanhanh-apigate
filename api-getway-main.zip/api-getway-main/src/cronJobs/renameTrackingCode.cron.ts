import { Tracking } from '@/models/tracking.model';
import { generateRandomString } from '@/utils/util';
import { CronJob } from 'cron';

export const renameTrackingCode = new CronJob('0 0 * * *', async () => {
  const currentDate = new Date();
  currentDate.setDate(currentDate.getDate() - 90);

  const trackings = await Tracking.query().where('created_at', '<', currentDate).andWhere('is_renamed', false);
  await Promise.all(
    trackings.map(async tr => {
      await Tracking.query()
        .patch({ code: `${tr.code}-rn${generateRandomString(8)}`, isRenamed: true })
        .where('id', tr.id);
    }),
  );
});
