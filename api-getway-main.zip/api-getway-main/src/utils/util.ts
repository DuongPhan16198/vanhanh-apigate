import { Customer } from '@/models/customer.model.';
import { DeliveryBill } from '@/models/deliveryBill.model';
import { GeneralConfigs } from '@/models/generalConfig.model';
import { Tracking } from '@/models/tracking.model';
import dayjs, { Dayjs } from 'dayjs';
import moment from 'moment';

/**
 * @method isEmpty
 * @param {String | Number | Object} value
 * @returns {Boolean} true & false
 * @description this value is Empty Check
 */
export const isEmpty = (value: string | number | object): boolean => {
  if (value === null) {
    return true;
  } else if (typeof value !== 'number' && value === '') {
    return true;
  } else if (typeof value === 'undefined' || value === undefined) {
    return true;
  } else if (value !== null && typeof value === 'object' && !Object.keys(value).length) {
    return true;
  } else {
    return false;
  }
};
/**
 * @method getRangePreviousPeriod
 * @param {Dayjs | Dayjs | string} value
 * @returns {Dayjs}
 * @description this value is get range previous period
 */
export const getRangePreviousPeriod = (startDate: Dayjs, endDate: Dayjs, viewBy: string) => {
  let dataRangeOld: Dayjs = dayjs();
  const numberOfDays: number = Math.abs(endDate.diff(startDate, 'day'));
  switch (viewBy) {
    case 'Day': {
      dataRangeOld = startDate.subtract(numberOfDays + 1, 'day'); // Lấy day trước đó
      break;
    }
    case 'Month': {
      endDate = dayjs(endDate.endOf('month').endOf('day').format('YYYY-MM-DD')); // Lấy ngày cuối cùng của endDate
      startDate = dayjs(startDate.startOf('month').startOf('day').format('YYYY-MM-DD')); //  Lấy ngày đầu tiên của startDate
      const numberOfMonths: number = Math.abs(endDate.diff(startDate, 'month'));
      dataRangeOld = startDate.subtract(numberOfMonths, 'month'); // Lấy month trước đó
      break;
    }
    case 'Year': {
      endDate = dayjs(endDate.endOf('year').startOf('month').endOf('day').format('YYYY-MM-DD')); // Lấy ngày cuối cùng của endDate
      startDate = dayjs(startDate.startOf('year').startOf('month').startOf('day').format('YYYY-MM-DD')); // Lấy ngày đầu tiên của startDate
      const numberOfYears: number = Math.abs(endDate.diff(startDate, 'year'));
      dataRangeOld = startDate.subtract(numberOfYears, 'year'); // Lấy year trước đó
      break;
    }
    case 'YearRange': {
      dataRangeOld = startDate.subtract(numberOfDays + 1, 'day'); // Lấy range trước đó
      break;
    }
    default: {
      dataRangeOld = startDate.subtract(numberOfDays + 1, 'day'); // Lấy day trước đó
      break;
    }
  }
  return dataRangeOld;
};

export const getSelectQueryByViewBy = (viewBy: string) => {
  let queryByViewBy = '';
  switch (viewBy) {
    case 'Day': {
      queryByViewBy = `EXTRACT('day' FROM st.date) as year`;
      break;
    }
    case 'Month': {
      queryByViewBy = `EXTRACT('day' FROM st.date) as year`;
      break;
    }
    case 'Year': {
      queryByViewBy = `EXTRACT('year' FROM st.date) as year`;
      break;
    }
    case 'YearRange': {
      queryByViewBy = `EXTRACT('year' FROM st.date) as year`;
      break;
    }
    default: {
      queryByViewBy = `EXTRACT('day' FROM st.date) as year`;
      break;
    }
  }
  return queryByViewBy;
};

export const generateNextOrderId = async () => {
  let prefix = '';
  try {
    prefix =
      JSON.parse(((await GeneralConfigs.query().where('config_key', 'CODE_PREFIX_CONFIG').first()) as any)?.configValue).config[0]
        ?.order_code_prefix || '';
  } catch (e) {
    prefix = '';
  }
  const date = moment().format('DDMMYY');
  let code = '';
  const lastTracking = await Tracking.query()
    .select()
    .whereLike('order_id', prefix + date + '%')
    .orderBy('order_id', 'DESC')
    .first();
  if (!lastTracking) {
    return {
      code: prefix + date + '00001',
      prefix,
      date,
      count: 1,
    };
  } else {
    const lastCode = lastTracking.orderId?.slice(-5);
    const newCode = parseInt(lastCode) + 1;
    code = `0000${newCode}`.slice(-5);
    return {
      code: prefix + date + code,
      prefix,
      date,
      count: newCode,
    };
  }
};

export const generateNextDeliveryBillsId = async () => {
  let prefix = '';
  try {
    prefix =
      JSON.parse(((await GeneralConfigs.query().where('config_key', 'CODE_PREFIX_CONFIG').first()) as any)?.configValue).config[0]
        ?.delivery_bill_code_prefix || '';
  } catch (e) {
    prefix = '';
  }
  const date = moment().format('DDMMYY');
  let code = '';
  const lastDeliveryBill = await DeliveryBill.query()
    .select()
    .whereLike('code', prefix + date + '%')
    .orderBy('code', 'DESC')
    .first();
  if (!lastDeliveryBill) {
    return {
      code: prefix + date + '00001',
      prefix,
      date,
      count: 1,
    };
  } else {
    const lastCode = lastDeliveryBill.code?.slice(-5);
    const newCode = parseInt(lastCode) + 1;
    code = `0000${newCode}`.slice(-5);
    return {
      code: prefix + date + code,
      prefix,
      date,
      count: newCode,
    };
  }
};

export const generateNextCustomerCode = async () => {
  const prefix = '';
  const latestCustomer = await Customer.query().orderBy('id', 'DESC').first();

  if (!latestCustomer) {
    return {
      code: prefix + '1',
    };
  } else {
    const lastCode: string = latestCustomer.idCustomer?.split('_')?.[1] || '0';
    const newCode = parseInt(lastCode) + 1;
    return {
      code: prefix + newCode,
    };
  }
};

export const makeId = (length: number) => {
  let result = '';
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const charactersLength = characters.length;
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
};

export const generateRandomString = length => {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let randomString = '';

  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    randomString += characters.charAt(randomIndex);
  }

  return randomString;
};

export const filterArray = (dataArray: any, filterObject: any) => {
  return dataArray.filter((item: any) => {
    for (const key in filterObject) {
      if (filterObject.hasOwnProperty(key)) {
        if (item[key] !== filterObject[key]) {
          return true;
        }
      }
    }
    return false;
  });
};

export const toSlug = (title: string): string => {
  let slug: string = '';
  slug = title.toLowerCase();

  slug = slug.replace(/á|à|ả|ạ|ã|ă|ắ|ằ|ẳ|ẵ|ặ|â|ấ|ầ|ẩ|ẫ|ậ/gi, 'a');
  slug = slug.replace(/é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ/gi, 'e');
  slug = slug.replace(/i|í|ì|ỉ|ĩ|ị/gi, 'i');
  slug = slug.replace(/ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ/gi, 'o');
  slug = slug.replace(/ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự/gi, 'u');
  slug = slug.replace(/ý|ỳ|ỷ|ỹ|ỵ/gi, 'y');
  slug = slug.replace(/đ/gi, 'd');
  slug = slug.replace(/\`|\~|\!|\@|\#|\||\$|\%|\^|\&|\*|\(|\)|\+|\=|\,|\.|\/|\?|\>|\<|\'|\"|\:|\;|_/gi, '');
  slug = slug.replace(/ /gi, '-');
  slug = slug.replace(/\-\-\-\-\-/gi, '-');
  slug = slug.replace(/\-\-\-\-/gi, '-');
  slug = slug.replace(/\-\-\-/gi, '-');
  slug = slug.replace(/\-\-/gi, '-');
  slug = '@' + slug + '@';
  slug = slug.replace(/\@\-|\-\@|\@/gi, '');
  return slug;
};

export function getChangedFields(obj1, obj2) {
  function isObject(obj) {
    return obj !== null && typeof obj === 'object';
  }

  function deepCompare(o1, o2) {
    const changedFields = {};
    for (const key in o1) {
      if (o1.hasOwnProperty(key) && o2.hasOwnProperty(key)) {
        if (isObject(o1[key]) && isObject(o2[key])) {
          const nestedChanges = deepCompare(o1[key], o2[key]);
          if (Object.keys(nestedChanges).length > 0) {
            changedFields[key] = nestedChanges;
          }
        } else if (o1[key] !== o2[key]) {
          changedFields[key] = {
            before_value: o1[key],
            after_value: o2[key],
          };
        }
      }
    }
    return changedFields;
  }

  return deepCompare(obj1, obj2);
}
