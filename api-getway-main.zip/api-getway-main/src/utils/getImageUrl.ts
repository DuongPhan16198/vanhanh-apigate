import axios from 'axios';
import FormData from 'form-data';
import fs from 'fs';
import { randomBytes } from 'crypto';

export async function getImageUrl(bearerToken: string, filePath: string, objectType: string, objectId: string): Promise<string> {
  const url = `${process.env.MEDIA_BACKEND_URL}/file`; // Replace with your actual endpoint

  // Create a FormData object
  const formData = new FormData();
  formData.append('objectType', objectType);
  formData.append('objectId', objectId);
  formData.append('file', fs.createReadStream(filePath));
  formData.append('type', 'regular_image');
  // Append the file to the FormData object

  try {
    // Make a POST request to the server
    const response = await axios.post(url, formData, {
      headers: {
        ...formData.getHeaders(),
        Authorization: `Bearer ${bearerToken}`,
      },
    });

    // Assuming the server responds with the URL of the uploaded image
    const imageUrl: string = response.data;

    return imageUrl;
  } catch (error) {
    // Handle errors
    console.error('Error uploading file:', error);
    throw error;
  }
}
