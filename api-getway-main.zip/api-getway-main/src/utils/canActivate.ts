import { RequestWithUser } from '@interfaces/auth.interface';
import { Users } from '@models/users.model';

const canActivate = async (req: RequestWithUser, apiUrl: string): Promise<boolean> => {
  const { user } = req;
  const findUser: any = await Users.query()
    .select('up_users.*')
    .withGraphFetched('role')
    .modifyGraph('role', builder => builder.withGraphFetched('actions'))
    .findById(user.id);
  if (findUser) {
    const userActionsArray = findUser.role[0].actions?.map(ac => ac.action + '/');
    const currentAction = apiUrl;
    if (!userActionsArray.some(str => str.includes(currentAction))) {
      return false;
    }
    return true;
  }
};

export default canActivate;
