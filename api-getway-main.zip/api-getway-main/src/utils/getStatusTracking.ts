export const getStatusTrackingReal = (tr: any) => {
  let status;
  if (tr.exploitStatus === 'Đã hủy bỏ' || tr.isDeleted) {
    status = 'Đã hủy bỏ';
  } else if (tr.status === 'Chờ nhà cung cấp' || tr.status === 'Đã tiếp nhận' || tr.status === 'Chưa nhập kho') {
    status = 'Chờ nhập kho US';
  } else if (tr.status === 'Đã nhập kho') {
    status = 'Đã nhập kho US';
  } else if (
    (tr.status === 'Đang đóng thùng' ||
      tr.status === 'Đã đóng thùng' ||
      tr.status === 'Đang xử lý awb' ||
      tr.status === 'Đang vận chuyển về VN' ||
      tr.status === 'Hoàn thành') &&
    tr.exploitStatus === 'Đang vận chuyển về vn'
  ) {
    status = 'Đang vận chuyển về VN';
  } else if (tr.exploitStatus === 'Đã vận chuyển về vn') {
    status = 'Đã nhập kho VN';
  } else if (tr.exploitStatus === 'Đã khai thác') {
    status = 'Đã khai thác';
  } else if (tr.exploitStatus === 'Đã đóng hàng') {
    status = 'Đã đóng hàng';
  } else if (tr.exploitStatus === 'Đang giao hàng') {
    status = 'Đang giao hàng';
  } else if (tr.exploitStatus === 'Hoàn thành') {
    status = 'Hoàn thành';
  } else if (tr.exploitStatus === 'Đã hủy bỏ' || tr.isDeleted) {
    status = 'Đã hủy bỏ';
  } else {
    status = 'Lỗi';
  }
  return status;
};

//['Đang đồng bộ', 'Đồng bộ thất bại', 'Đang vận chuyển về vn', 'Đã vận chuyển về vn', 'Đang khai thác', 'Đã khai thác'];
export const getStatusAwbReal = (tr: any) => {
  let status;
  if (tr.syncStatus === 'processing') {
    status = 'Đang đồng bộ';
  } else if (tr.syncStatus === 'failed') {
    status = 'Đồng bộ thất bại';
  } else if (tr.syncStatus === 'successful') {
    status = tr.exploitStatus;
  }
  return status;
};
