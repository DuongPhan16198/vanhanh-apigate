import { createHmac } from 'crypto';
import axios from 'axios';
import BadRequestException from '@/exceptions/BadRequestException';
import { Tracking } from '@/models/tracking.model';

export const generateSignature = (data, key) => {
  const hmac = createHmac('sha256', key);
  hmac.update(data);
  return hmac.digest('hex');
};

const getRequestHeader = () => {
  const publicKey = process.env.WAREHOUSE_PUBLIC_KEY;
  const privateKey = process.env.WAREHOUSE_PRIVATE_KEY;
  const timestamp = new Date().getTime();
  const signature = generateSignature(timestamp.toString(), privateKey);
  const headers = {
    'Content-Type': 'application/json',
    timestamp: timestamp,
    signature: signature,
    'dpc-api-key': publicKey,
  };
  return headers;
};

export const getListAwbs = async (query: any) => {
  const apiUrl = `${process.env.WAREHOUSE_API_URL}/partner/awbs`;
  const headers = getRequestHeader();
  try {
    const queryParams = {
      ...query,
      page: 1,
      limit: 100,
    };
    const response = await axios.get(apiUrl, { headers, params: queryParams });
    return response.data;
  } catch (error) {
    console.log(error);
    throw new BadRequestException('Cannot GET to wh_api /awbs');
  }
};

export const getListTrackings = async (page: number, query) => {
  const headers = getRequestHeader();
  const apiUrl = `${process.env.WAREHOUSE_API_URL}/partner/trackings`;

  try {
    const response = await axios.get(apiUrl, {
      headers,
      params: {
        ...query,
        page,
        limit: 100,
      },
    });
    return response.data;
  } catch (error) {
    console.log(error);
    throw new BadRequestException('Cannot GET to wh_api /trackings');
  }
};
export const sendCreateTicketRequest = async (trackingId, ticketContent) => {
  const headers = getRequestHeader();
  const apiUrl = `${process.env.WAREHOUSE_API_URL}/partner/tickets`;

  try {
    const response = await axios.post(
      apiUrl,
      { trackingId, ticketContent },
      {
        headers,
      },
    );
    return response.data;
  } catch (error) {
    console.log(error);
    throw new BadRequestException('Cannot POST to wh_api');
  }
};

export const sendCreateTrackingToWh = async (trackingCodes: string[]) => {
  const headers = getRequestHeader();
  const apiUrl = `${process.env.WAREHOUSE_API_URL}/partner/trackings`;
  const body = trackingCodes.map(code => [code, '']);
  try {
    const response = await axios.post(
      apiUrl,
      { listTrackings: body },
      {
        headers,
      },
    );
    if (response?.data?.data?.success?.length > 0) {
      response.data.data.success.map(async successTracking => {
        await Tracking.query().patch({ whTrackingId: successTracking.id }).where('code', successTracking.code);
      });
    }
    return response.data;
  } catch (error) {
    console.log(error);
    throw new BadRequestException('Cannot POST to wh_api');
  }
};

export const getTimelineOfATrackingFromWh = async trackingWhId => {
  const headers = getRequestHeader();
  const apiUrl = `${process.env.WAREHOUSE_API_URL}/partner/trackings/timeline`;
  try {
    const response = await axios.get(apiUrl, {
      headers,
      params: {
        trackingId: trackingWhId,
      },
    });
    if (response?.data?.data?.length > 0) {
      return response.data.data.map(response => ({
        name: response.name,
        updatedTime: response.time,
      }));
    } else return null;
  } catch (error) {
    console.log(error);
    throw new BadRequestException('Cannot GET to wh_api');
  }
};
