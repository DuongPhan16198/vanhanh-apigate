import { PermissionsRoleLinks } from '@/models/permissionRoleLinks.model';
import { RequestWithUser } from '@interfaces/auth.interface';
import { Users } from '@models/users.model';

const getReqPerrmissionBusinessLogic = async (req: RequestWithUser, apiUrl: string): Promise<void> => {
  const { user } = req;
  const findUser: any = await Users.query()
    .select('up_users.*')
    .withGraphFetched('role')
    .modifyGraph('role', builder => builder.withGraphFetched('actions'))
    .findById(user.id);
  if (findUser) {
    const userActionsArray = findUser.role[0].actions?.map(ac => ac.action + '/');
    const currentAction = apiUrl;
    const targetId = (
      (await PermissionsRoleLinks.query()
        .where('role_id', findUser.role[0].id)
        .where(
          'permission_id',
          findUser.role[0].actions?.filter(p => p.action + '/' === currentAction || p.action === currentAction)[0]?.id,
        )) as any
    )[0]?.permissionBusinessLogicId;
    req.permission_business_logic = targetId;
  }
};

export default getReqPerrmissionBusinessLogic;
