import { NextFunction, Request, Response } from 'express';
import { HttpException } from '@exceptions/HttpException';
import { logger } from '@utils/logger';
import { NODE_ENV } from '@config';


const HTTP_SERVER_ERROR = 500;
const errorMiddleware = (error: HttpException, req: Request, res: Response, next: NextFunction) => {
  try {
    const status: number = error.status || 500;
    const message: string = status === 500 && NODE_ENV === 'production' ? 'Something went wrong' : error.message || 'Something went wrong';

    if (res.headersSent) {
      return next(error);
    }

    logger.error(`[${req.method}] ${req.path} >> StatusCode:: ${status}, Message:: ${message}`, error);
    return res.status(error.status || HTTP_SERVER_ERROR).json({ message });
  } catch (error) {
    return res.status(error.status || HTTP_SERVER_ERROR).json({ message: 'Internal error' });
  }
};

export default errorMiddleware;
