import BadRequestException from '@/exceptions/BadRequestException';
import { NextFunction, Request, Response } from 'express';


export default async function (req: Request, res: Response, next: NextFunction) {
    const { file } = req;

    if (!file) {
        next(new BadRequestException("File isn't existed"));
        return;
    }

    const generatedChecksum = null;

    if (!generatedChecksum) {
        next(new BadRequestException("File isn't existed"));
        return;
    }

    const isTheSameFile = null;
    if (isTheSameFile) {
        next(new BadRequestException("This file is in progress!!!"));
        return;
    }

    next();
}
