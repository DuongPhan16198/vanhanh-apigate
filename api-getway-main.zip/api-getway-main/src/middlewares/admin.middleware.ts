import { NextFunction, Response } from 'express';
import { HttpException } from '@exceptions/HttpException';
import { RequestWithUser } from '@interfaces/auth.interface';
import { User } from '@interfaces/users.interface';

const adminValidation = async (req: RequestWithUser, res: Response, next: NextFunction) => {
  const userData: User = req.user;
  if (userData.role !== 'admin') {
    next(new HttpException(403, "Forbiden Denied. User don't have admin role"));
  }
  next();
};

export default adminValidation;
