import { NextFunction, Response } from 'express';
import { TokenExpiredError, verify } from 'jsonwebtoken';
import { SECRET_KEY } from '@config';
import { HttpException } from '@exceptions/HttpException';
import { DataStoredInToken, RequestWithUser } from '@interfaces/auth.interface';
import { Users } from '@models/users.model';
import { UserRoleLinks } from '@/models/userRoleLinks.model';
import { PermissionsRoleLinks } from '@/models/permissionRoleLinks.model';

const authMiddleware = async (req: RequestWithUser, res: Response, next: NextFunction) => {
  const isRefreshTokenUrl = req.url.includes('/auth/refresh-token');

  try {
    const Authorization = req.cookies?.['Authorization'] || (req.header('Authorization') ? req.header('Authorization').split('Bearer ')[1] : null);
    const baseUrl = req.baseUrl.slice(1, req.baseUrl.length);
    const method = req.method;
    const controller = req.path.split('/')[1];
    if (Authorization) {
      const secretKey: string = SECRET_KEY;
      const verificationResponse = verify(Authorization, secretKey) as DataStoredInToken;
      const findUser: any = await Users.query()
        .select('up_users.*', 'customer.id as customerId')
        .leftJoinRelated('customer')
        .modifyGraph('customer', builder => builder.withGraphFetched('sale'))
        .withGraphFetched('customer')
        .withGraphFetched('warehouseVN')
        .withGraphFetched('businessPartner')
        .withGraphFetched('role')
        .modifyGraph('role', builder => builder.withGraphFetched('actions'))
        .findById(verificationResponse.id);
      if (findUser) {
        const userActionsArray = findUser.role[0].actions?.map(ac => ac.action + '/');
        const currentAction = `${baseUrl}:: ${method} /api${req.route.path}`;
        if (!userActionsArray.some(str => str.includes(currentAction))) {
          next(new HttpException(403, 'Permission denied'));
        }

        req.user = {
          ...findUser,
          role: findUser.role[0] || null,
          customer: findUser.customer[0] || null,
          businessPartner: findUser.businessPartner[0] || null,
        };
        req.accessToken = Authorization;
        const targetId = (
          (await PermissionsRoleLinks.query()
            .where('role_id', findUser.role[0].id)
            .where(
              'permission_id',
              findUser.role[0].actions?.filter(p => p.action + '/' === currentAction || p.action === currentAction)[0]?.id,
            )) as any
        )[0]?.permissionBusinessLogicId;
        req.permission_business_logic = targetId;

        next();
      } else {
        next(new HttpException(401, 'Wrong authentication token'));
      }
    } else {
      next(new HttpException(404, 'Authentication token missing'));
    }
  } catch (error) {
    if (error instanceof TokenExpiredError) {
      if (!isRefreshTokenUrl) {
        return next(new HttpException(401, error.name));
      }

      return next();
    }
    console.log(error);

    next(new HttpException(401, 'Wrong authentication token'));
  }
};

export default authMiddleware;
