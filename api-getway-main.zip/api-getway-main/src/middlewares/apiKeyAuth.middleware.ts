import { NextFunction, Response } from 'express';
import { SECRET_KEY } from '@config';
import { HttpException } from '@exceptions/HttpException';
import { RequestWithUser } from '@interfaces/auth.interface';
import { createHmac } from 'crypto';
export const generateSignature = (data, key) => {
  const hmac = createHmac('sha256', key);
  hmac.update(data);
  return hmac.digest('hex');
};
const apiKeyAuthMiddleware = async (req: RequestWithUser, res: Response, next: NextFunction) => {
  try {
    const publicKey = process.env.WAREHOUSE_PUBLIC_KEY;
    const privateKey = process.env.WAREHOUSE_PRIVATE_KEY;
    const timestamp = req.header('timestamp');
    const signature = req.header('signature');
    const dpcApiKey = req.header('dpc-api-key');
    if (publicKey && privateKey && timestamp) {
      const checkingSignature = generateSignature(timestamp, privateKey);
      if (signature === checkingSignature && dpcApiKey === publicKey) {
        next();
      } else {
        next(new HttpException(401, 'Wrong authentication token'));
      }
    } else {
      next(new HttpException(401, 'Authentication token missing'));
    }
  } catch (error) {
    console.log(error);
    next(new HttpException(401, 'Wrong authentication token'));
  }
};

export default apiKeyAuthMiddleware;
