import BadRequestException from '@/exceptions/BadRequestException';
// import BaseImportService from '@/services/base-import.service';
import { NextFunction, Request, Response } from 'express';
import { mkdirSync } from 'fs';
import multer from 'multer';
import { resolve } from 'path';

// const simpleImportService = BaseImportService.getInstance();

export default async function uploadFileMiddleware(req: Request, res: Response, next: NextFunction) {
  mkdirSync('./temp', { recursive: true });
  const upload = multer({
    dest: './temp/',
    storage: multer.diskStorage({
      destination: resolve('./temp/'),
      filename(req, file, cb) {
        cb(null, `${file.originalname}`);
      },
    }),
  });

  return upload.single('file')(req, res, next);
}
