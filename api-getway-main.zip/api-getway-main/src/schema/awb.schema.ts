import { boolean, object, string, TypeOf, ZodIssueCode } from 'zod';
import AwbService from '@/services/awb.service';
import { Awb } from '@/models/awb.model';

export const syncAwb = object({
  body: object({
    awbs: string({
      required_error: 'awbs is required',
      invalid_type_error: 'awbs must be a array',
    })
      .min(1, { message: 'awb code must contain at least 1 character' })
      .max(100)
      .array()
      .min(1, { message: 'awbs must contain at least 1 element' })
      // TODO: confirm max value
      .max(10),
    resync: boolean().optional(),
  }).superRefine(async (arg, ctx): Promise<boolean> => {
    const rs: Array<string> = await AwbService.validateAwbs(arg.awbs, arg.resync);
    let invalidAwbCodes = arg.awbs;
    if (rs?.length) {
      invalidAwbCodes = arg.awbs.filter(item => !rs?.includes(item));
    }
    if (invalidAwbCodes.length) {
      const customIssue = {
        code: ZodIssueCode.custom,
        message: `[${invalidAwbCodes.join(', ')}] already synced`,
      };
      ctx.addIssue(customIssue);

      return false;
    }
    return true;
  }),
});

export type SyncAwbInput = TypeOf<typeof syncAwb>['body'];
