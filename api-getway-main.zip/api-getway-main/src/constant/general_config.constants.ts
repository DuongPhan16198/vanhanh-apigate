export interface DefaultConfigModelInterface {
  title: string;
  key: string;
  data_type: string;
  class: string;
  options?: any | null;
}

export interface ListConfigModelInterface {
  view: ConfigType;
  fields: DefaultConfigModelInterface[];
}

export interface GeneralConfigInterface {
  configInformation: {
    variant: string;
    url: string;
    icon: string;
    name: string;
    key: string;
    description: string;
    config_type: ConfigType;
  };
  models: DefaultConfigModelInterface | ListConfigModelInterface;
}

export enum ConfigType {
  LIST = 'list',
  DEFAULT = 'default',
}
export const AllGeneralConfigInterfaces: GeneralConfigInterface[] = [
  {
    configInformation: {
      icon: 'dollar-sign',
      variant: 'primary',
      url: '/settings/price',
      name: 'Cấu hình bảng giá',
      key: 'PRICING_CONFIG',
      description: 'Bảng giá cước vận chuyển',
      config_type: ConfigType.LIST,
    },
    models: {
      view: ConfigType.LIST,
      fields: [
        {
          title: 'Loại hàng hóa',
          key: 'tracking_type',
          data_type: 'select',
          class: '',
          options: {
            2: 'Hàng thường',
            3: 'Đồng hồ',
            4: 'Hàng điện tử',
            5: 'Laptop',
            6: 'Cigars',
            7: 'BBW',
            8: 'Quần áo',
            9: 'Mỹ Phẩm - Nước Hoa',
          },
        },
        {
          title: 'Kho',
          key: 'warehouse_config_id',
          data_type: 'select',
          class: '',
          options: {
            1: 'HCM',
            2: 'Hà Nội',
          },
        },
        {
          title: 'Giá cước',
          key: 'cost',
          class: '',
          data_type: 'number',
        },
      ],
    },
  },
  {
    configInformation: {
      icon: 'archive',
      variant: 'warning',
      url: 'settings/box-coefficient',
      name: 'Cấu hình hệ số thùng',
      key: 'BOX_COEFFICIENT_CONFIG',
      description: 'Hệ số thùng để tính tiền',
      config_type: ConfigType.DEFAULT,
    },
    models: {
      view: ConfigType.DEFAULT,
      fields: [
        {
          title: 'Hệ số thùng',
          key: 'box_coefficient',
          class: '',
          data_type: 'number',
        },
      ],
    },
  },
  {
    configInformation: {
      icon: 'clipboard',
      variant: 'primary',
      url: '/settings/bank-accounts',
      name: 'Cấu hình tài khoản ngân hàng',
      key: 'BANK_ACCOUNT_CONFIG',
      description: 'Thông tin tài khoản ngân hàng để khách hàng nạp tiền',
      config_type: ConfigType.DEFAULT,
    },
    models: {
      view: ConfigType.DEFAULT,
      fields: [
        {
          title: 'Tên ngân hàng',
          key: 'bank_name',
          data_type: 'string',
          class: '',
        },
        {
          title: 'Số tài khoản',
          key: 'account_number',
          data_type: 'string',
          class: '',
        },
        {
          title: 'Tên chủ số tài khoản',
          key: 'account_name',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Tên chi nhánh ngân hàng',
          key: 'bank_branch',
          class: '',
          data_type: 'string',
        },
        {
          title: 'URL Logo Ngân hàng',
          key: 'logo',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Mã QR tới Tài khoản Ngân hàng',
          key: 'qr_code',
          class: '',
          data_type: 'string',
        },
      ],
    },
  },
  {
    configInformation: {
      icon: 'phone',
      variant: 'success',
      url: '/settings/contact-information',
      name: 'Cấu hình thông tin liên hệ',
      key: 'CONTACT_INFORMATION_CONFIG',
      description: 'Thông tin liên hệ hiển thị trên website',
      config_type: ConfigType.DEFAULT,
    },
    models: {
      view: ConfigType.DEFAULT,
      fields: [
        {
          title: 'Logo',
          key: 'logo_url',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Tiêu đề trang',
          key: 'page_title',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Số điện thoại',
          key: 'phone_number',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Email',
          key: 'email',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Địa chỉ 1',
          key: 'address_1',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Địa chỉ 2',
          key: 'address_2',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Địa chỉ 3',
          key: 'address_3',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Đường dẫn Facebook',
          key: 'facebook_page_url',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Đường dẫn Zalo',
          key: 'zalo_url',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Mã nhúng HEAD',
          key: 'script_head',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Mã nhúng FOOTER',
          key: 'script_footer',
          class: '',
          data_type: 'string',
        },
      ],
    },
  },
  {
    configInformation: {
      icon: 'mail',
      variant: 'secondary',
      url: '/settings/mail-server',
      name: 'Cấu hình thông tin mail server',
      key: 'MAIL_SERVER_CONFIG',
      description: 'Thông tin máy chủ email',
      config_type: ConfigType.DEFAULT,
    },
    models: {
      view: ConfigType.DEFAULT,
      fields: [
        {
          title: 'Port TCP',
          key: 'port',
          class: '',
          data_type: 'number',
        },
        {
          title: 'Host',
          key: 'host',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Mail Server User',
          key: 'mail_server_user',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Mail Server Password',
          key: 'mail_server_password',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Địa chỉ email (sender) hiển thị khi gửi',
          key: 'sender_email_address',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Địa chỉ email nhận thông báo khi có khách hàng để lại thông tin liên hệ',
          key: 'admin_contact_receiver_email_address',
          class: '',
          data_type: 'string',
        },
      ],
    },
  },
  {
    configInformation: {
      icon: 'terminal',
      variant: 'secondary',
      url: '/settings/code-prefix',
      name: 'Cấu hình tiền tố',
      key: 'CODE_PREFIX_CONFIG',
      description: 'Cấu hình tiền tố (prefix) cho các loại mã',
      config_type: ConfigType.DEFAULT,
    },
    models: {
      view: ConfigType.DEFAULT,
      fields: [
        {
          title: 'Mã Order',
          key: 'order-code',
          class: '',
          data_type: 'string',
        },
        {
          title: 'Mã PXK',
          key: 'delivery-bill-code',
          class: '',
          data_type: 'string',
        },
      ],
    },
  },
];
