export interface FieldConfigInterface {
  name: string;
  description: string;
  fields: classFieldInterface[];
}

export interface PageInfoInterface {
  title: string;
  description: string;
}

export interface classFieldInterface {
  name: string;
  key: string;
  type: string;
  ext?: string;
  class: string;
  required: boolean;
  placeholder?: string;
}
export interface PageMetadataInterface {
  pageInfo: PageInfoInterface;
  field_config: FieldConfigInterface[];
}
export const pageMetadataSampleInterface: PageMetadataInterface = {
  pageInfo: {
    title: 'string',
    description: 'string',
  },
  field_config: [
    {
      name: 'string',
      description: 'string',
      fields: [
        {
          name: 'string',
          key: 'string',
          type: 'string',
          ext: 'string,string,string',
          class: 'string',
          required: true,
          placeholder: 'string',
        },
      ],
    },
  ],
};
