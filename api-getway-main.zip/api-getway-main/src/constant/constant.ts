export enum ImportJobStatus {
  DONE,
  FAILED,
  PENDING,
}

export const MAX_DATE_NUMBER_FOR_REPORT = 14;
export const DATE_FORMAT = 'YYYY-MM-DD';

export const ITEM_NUMBER_PER_PAGE = 10;

export const TRACKING_STATUS = [
  'Chờ nhập kho US',
  'Đã nhập kho US',
  'Đang vận chuyển về VN',
  'Đã nhập kho VN',
  'Đã khai thác',
  'Đã đóng hàng',
  'Đang giao hàng',
  'Hoàn thành',
  'Đã hủy bỏ',
];

export const TRACKINGS_EXPLOIT_STATUS = ['Đang vận chuyển về vn', 'Đã vận chuyển về vn', 'Đã khai thác', 'Hoàn thành', 'Đã huỷ bỏ'];

export const STATUS_AWB = ['Đang đồng bộ', 'Đồng bộ thất bại', 'Đang vận chuyển về vn', 'Đã vận chuyển về vn', 'Đang khai thác', 'Đã khai thác'];

export const SALE_ROLE_ID = 11;
export const CUSTOMER_SERVICE_STAFF_ROLE_ID = 10;
export const EXPLOITATION_STAFF_ROLE_ID = 8;

export const CUSTOMER_TRANSACTION_STATUS = ['chờ duyệt', 'hoàn thành', 'hủy'];

export const DELIVERY_BILL_STATUS = [
  'Phiếu mới tạo',
  'Sale duyệt',
  'Kế toán duyệt',
  'Yêu cầu xuất kho',
  'Đã đóng hàng',
  'Đang giao hàng',
  'Hoàn thành đơn hàng',
  'Đơn hàng giao không thành công',
  'Hủy PXK',
];

export const TRACKING_UPDATABLE_STATUS = ['Chờ nhập kho US', 'Đã nhập kho US', 'Đang vận chuyển về VN', 'Đã nhập kho VN', 'Đã khai thác'];
export const TRACKING_CHANGEBOX_STATUS = ['Chờ nhập kho US', 'Đã nhập kho US', 'Đang vận chuyển về VN', 'Đã nhập kho VN'];
export const TRACKING_STATUS_ORDER = {
  'Chờ nhập kho US': 1,
  'Đã nhập kho US': 2,
  'Đang vận chuyển về VN': 3,
  'Đã nhập kho VN': 4,
  'Đã khai thác': 5,
  'Đã đóng hàng': 6,
  'Đang giao hàng': 7,
  'Hoàn thành': 8,
  'Đã hủy bỏ': 9,
};

export const AWB_STATUS_ORDER = {
  'Đang đồng bộ': 1,
  'Đồng bộ thất bại': 2,
  'Đang vận chuyển về vn': 3,
  'Đã vận chuyển về vn': 4,
  'Đang khai thác': 5,
  'Đã khai thác': 6,
};
export const CUSTOMER_TRANSACTION_STATUS_ORDER = {
  'chờ duyệt': 0,
  'hoàn thành': 1,
  hủy: 2,
};
export const DELIVERY_BILL_STATUS_ORDER = {
  'Phiếu mới tạo': 0,
  'Sale duyệt': 1,
  'Kế toán duyệt': 2,
  'Yêu cầu xuất kho': 3,
  'Đã đóng hàng': 4,
  'Đang giao hàng': 5,
  'Hoàn thành đơn hàng': 6,
  'Đơn hàng giao không thành công': 7,
  'Hủy PXK': 8,
};

export const TRACKING_BEFORE_EXPLOITATION_STATUS = ['Chờ nhập kho US', 'Đã nhập kho US', 'Đang vận chuyển về VN'];
