import { config } from 'dotenv';
import path from 'path';
import fs from 'fs';

config({
  path: fs.existsSync(path.resolve(`.env`))
    ? `.env`
    : '',
});

export const CREDENTIALS = process.env.CREDENTIALS === 'true';
export const {
  NODE_ENV,
  PORT,
  PG_CONNECTION_STRING,
  SECRET_KEY,
  LOG_FORMAT,
  LOG_DIR,
  ORIGIN,
  BULL_WORKERS_CONCURRENCY,
  BULL_WORKERS_TEAM_SIZE,
  REFRESH_TOKEN_PRIVATE_KEY,
  TZ,
  WAREHOUSE_API_URL,
  WAREHOUSE_API_TOKEN,
} = process.env;

