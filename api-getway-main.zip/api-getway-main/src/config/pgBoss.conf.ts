import PgBoss from 'pg-boss';
import { PG_CONNECTION_STRING } from '@config';

export const boss = new PgBoss({
  connectionString: PG_CONNECTION_STRING,
  deleteAfterHours: 1,
  archiveFailedAfterSeconds: 60 * 60 * 1000,
  archiveCompletedAfterSeconds: 60 * 60 * 1000,
});
