import { AWB_STATUS_ORDER, CUSTOMER_TRANSACTION_STATUS, CUSTOMER_TRANSACTION_STATUS_ORDER } from '@/constant/constant';
import { RequestWithUser } from '@/interfaces/auth.interface';
import { Customer } from '@/models/customer.model.';
import { CustomerTransactionLinks } from '@/models/customerTransactionLinks.model';
import { CustomerTransactionLogs } from '@/models/customerTransactionLogs.model';
import { DeliveryBill } from '@/models/deliveryBill.model';
import canActivate from '@/utils/canActivate';
import getReqPerrmissionBusinessLogic from '@/utils/getReqPerrmissionBusinessLogic';
import { HttpException } from '@exceptions/HttpException';
import Objection from 'objection';
import FcmPushNotificationService from './fcmPushNotification.service';
import BadRequestException from '@/exceptions/BadRequestException';
import { Mailer } from '@/helper/mailer';

class CustomerTransactionLogsService {
  private readonly fcmPushNotificationService = new FcmPushNotificationService();
  static getInstant(): CustomerTransactionLogsService {
    return new CustomerTransactionLogsService();
  }
  private async transactionAdditionalFilterByPermissionBusinessLogic(
    req: RequestWithUser,
    queryBuilder: Objection.QueryBuilder<CustomerTransactionLogs, CustomerTransactionLogs[]>,
    user,
    customer_id,
  ) {
    if (req.permission_business_logic) {
      switch (req.permission_business_logic) {
        case 1:
          break;
        case 2:
          if (customer_id)
            queryBuilder
              .innerJoin('customers_sale_links', 'customers_sale_links.customer_id', '=', 'customer.id')
              .where('customers_sale_links.user_id', user.id);
          else
            queryBuilder
              .joinRelated('customer')
              .innerJoin('customers_sale_links', 'customers_sale_links.customer_id', '=', 'customer.id')
              .where('customers_sale_links.user_id', user.id);
          break;
        case 3:
          queryBuilder.where('created_by_id', user.id);
          break;
        case 4:
          if (customer_id)
            queryBuilder
              .innerJoin('customers_service_staff_links', 'customers_service_staff_links.customer_id', '=', 'customer.id')
              .where('customers_service_staff_links.user_id', user.id);
          else
            queryBuilder
              .joinRelated('customer')
              .innerJoin('customers_service_staff_links', 'customers_service_staff_links.customer_id', '=', 'customer.id')
              .where('customers_service_staff_links.user_id', user.id);
          break;
        case 5:
          queryBuilder.joinRelated('customer').where('customer.id', user.customer.id);
        default:
          break;
      }
    }
  }

  private filterTransaction(req, user, query, queryBuilder, statusOnly) {
    let { type, customer_id, fromDate, toDate, status } = query;
    if (statusOnly) status = null;
    if (customer_id) queryBuilder.joinRelated('customer').where('customer.id', customer_id);
    if (req.permission_business_logic) {
      this.transactionAdditionalFilterByPermissionBusinessLogic(req, queryBuilder, req.user, customer_id);
    }
    if (type) {
      queryBuilder.where('customerLogs.customer_transaction_type', type);
    }

    if (fromDate && toDate) {
      queryBuilder
        .where('customerLogs.created_at', '>=', new Date(fromDate))
        .where('customerLogs.created_at', '<=', new Date(toDate))
        .orderBy('customerLogs.created_at', 'desc');
    }

    if (status) {
      queryBuilder.where('customerLogs.status', status);
    }
  }
  public async find(req, user, query) {
    const { page, pageSize = 10 } = query;
    const queryBuilder = CustomerTransactionLogs.query()
      .from(`${CustomerTransactionLogs.getTableName()} as customerLogs`)
      .withGraphFetched('customer');
    this.filterTransaction(req, user, query, queryBuilder, false);

    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }

    const listTransactionLogs = await queryBuilder.select().orderBy('updated_at', 'DESC').page(pageIndex, pageSize);
    if (!listTransactionLogs) throw new HttpException(404, "Bill doesn't exist");
    const dataResult = await Promise.all(
      listTransactionLogs.results.map(async item => {
        const deliveryBill = await DeliveryBill.query().where('code', item.customerTransactionNote);
        return {
          ...item,
          customerTransactionBalance: item.status === 'chờ duyệt' ? null : item.customerTransactionBalance,
          billCode: deliveryBill.length > 0 && item.customerTransactionType === 'THANH TOÁN' ? deliveryBill[0].code : null,
        };
      }),
    );

    return {
      paginations: {
        page: Number(pageIndex) + 1,
        pageSize: Number(pageSize),
        total: listTransactionLogs.total,
        totalPage: Math.ceil(listTransactionLogs.total / pageSize),
      },
      data: dataResult,
    };
  }

  public async getTransactionById(req, id: string) {
    const queryBuilder = CustomerTransactionLogs.query()
      .from(`${CustomerTransactionLogs.getTableName()} as customerLogs`)
      .withGraphFetched('customer')
      .where('customerLogs.id', id);

    if (req) {
      await getReqPerrmissionBusinessLogic(req, 'api:: GET /api/transactions');
      if (req.permission_business_logic) this.transactionAdditionalFilterByPermissionBusinessLogic(req, queryBuilder, req.user, null);
    }
    const transaction: CustomerTransactionLogs = await queryBuilder.first();
    if (!transaction) {
      throw new HttpException(404, "Customer doesn't exist");
    }

    return {
      ...transaction,
    };
  }

  public async getTransactionByCustomerId(id: string, params: any) {
    const { page = 0, pageSize = 10 } = params;

    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }

    const transaction = await CustomerTransactionLogs.query()
      .select('customer_transaction_logs.*')
      .join(
        'customer_transaction_logs_customer_id_links',
        'customer_transaction_logs.id',
        '=',
        'customer_transaction_logs_customer_id_links.customer_transaction_log_id',
      )
      .where('customer_transaction_logs_customer_id_links.customer_id', id)
      .orderBy('customer_transaction_logs.id')
      .withGraphFetched('customer')
      .withGraphFetched('employee')
      .page(pageIndex, pageSize);

    if (!transaction) {
      throw new HttpException(404, "Customer doesn't exist");
    }
    const { results, total } = transaction;

    return {
      pagination: {
        page: Number(pageIndex) + 1,
        pageSize,
        total,
        totalPage: Math.ceil(total / pageSize),
      },
      data: results,
    };
  }

  public async createTransaction(req: any, data: any, imageFileUrl: string, isAutoApprove: boolean) {
    if (!data.customer_id) {
      throw new HttpException(400, 'Customer_id is required');
    } else {
      data.customer_transaction_money = Math.round(data.customer_transaction_money);
      const customer = await Customer.query().findById(data.customer_id);
      const totalBalance = Number(customer.balance || 0) + Number(customer.creditAmount || 0);
      if (
        totalBalance - Number(data.customer_transaction_money) < 0 &&
        data.customer_transaction_type !== 'NẠP TIỀN' &&
        data.customer_transaction_type !== 'HOÀN TIỀN'
      ) {
        throw new HttpException(400, `The customer's total credit makes it impossible to perform any transactions other than deposits or refund`);
      } else {
        const updateData: any = {};
        let moneyTransfer;
        if (data.customer_transaction_type) {
          updateData.customer_transaction_type = data.customer_transaction_type;
        }

        if (data.customer_transaction_money >= 0) {
          updateData.customer_transaction_money = data.customer_transaction_money;
        }

        if (data.customer_transaction_note) {
          updateData.customer_transaction_note = data.customer_transaction_note;
        }

        if (data.customer_transaction_type === 'NẠP TIỀN') {
          moneyTransfer = Number(updateData.customer_transaction_money);
          if (data.bank_account) {
            updateData.bank_account = data.bank_account;
          }
          if (imageFileUrl) {
            updateData.image = imageFileUrl;
          }
        } else if (data.customer_transaction_type === 'THANH TOÁN') {
          moneyTransfer = 0 - Number(updateData.customer_transaction_money);
        } else if (data.customer_transaction_type === 'HOÀN TIỀN') {
          moneyTransfer = Number(updateData.customer_transaction_money);
        } else if (data.customer_transaction_type === 'RÚT TIỀN') {
          moneyTransfer = 0 - Number(updateData.customer_transaction_money);
          if (imageFileUrl) {
            updateData.image = imageFileUrl;
          }
        }
        updateData.customer_transaction_balance = Number(customer.balance) + moneyTransfer;
        updateData.customer_transaction_date = new Date();
        updateData.created_at = new Date();
        updateData.updated_at = new Date();

        const res = await CustomerTransactionLogs.query().insert(updateData).into('customer_transaction_logs');

        await CustomerTransactionLinks.query()
          .insert({
            customerTransactionLogId: res.id,
            customerId: data.customer_id,
          })
          .into('customer_transaction_logs_customer_id_links');
        if (isAutoApprove && (await canActivate(req, 'api:: PUT /api/transactions/:id'))) {
          await this.approveTransaction(req, res.id, { status: 'hoàn thành' });
          return await this.getTransactionById(req, res.id.toString());
        }
        return res;
      }
    }
  }

  public async customerBalancePayableCheck(data: any) {
    if (!data.customer_id) {
      throw new HttpException(400, 'Customer_id is required');
    } else {
      const customer = await Customer.query().findById(data.customer_id);
      const totalBalance = Number(customer.balance || 0) + Number(customer.creditAmount || 0);
      if (totalBalance - Number(data.customer_transaction_money) < 0) {
        throw new HttpException(400, 'The customer does not have enough balance to make payment !');
      }
      return true;
    }
  }

  public async approveTransaction(req, id, data) {
    const transaction = await this.getTransactionById(req, id);
    await getReqPerrmissionBusinessLogic(req, 'api:: GET /api/transactions');
    if (
      (req.permission_business_logic && req.permission_business_logic === 5) ||
      req.user.role.type === 'khach_hang' ||
      req.user.type === 'customer'
    ) {
      if (data.status != 'hủy') delete data.status;
    }
    if (!transaction) {
      throw new HttpException(404, 'Transaction is not found!');
    } else if (transaction && transaction.status !== 'chờ duyệt') {
      throw new HttpException(400, 'Transaction was already approved !');
    } else if (transaction && transaction.status === 'chờ duyệt') {
      const customerId: any = (await CustomerTransactionLinks.query().where('customer_transaction_log_id', id).first())?.customerId;
      const customer: any = await Customer.query().findById(customerId).withGraphFetched('user');
      if (data.status === 'hoàn thành') {
        const customerBalance = Number((await Customer.query().findById(customerId))?.balance || 0) || 0;
        let customerNewBalance = 0;
        if (transaction.customerTransactionType === 'HOÀN TIỀN' || transaction.customerTransactionType === 'NẠP TIỀN') {
          customerNewBalance = Number(Number(customerBalance) + Number(transaction.customerTransactionMoney));
        } else {
          customerNewBalance = Number(Number(customerBalance) - Number(transaction.customerTransactionMoney));
        }
        await CustomerTransactionLogs.query()
          .findById(id)
          .patch({ customerTransactionBalance: customerNewBalance, status: 'hoàn thành', updatedAt: new Date() });
        await Customer.query().findById(customerId).patch({ balance: customerNewBalance });
      } else if (data.status === 'hủy') {
        await CustomerTransactionLogs.query().findById(id).patch({ status: 'hủy', updatedAt: new Date() });
      } else {
        throw new BadRequestException(`The status must be 'hủy' or 'hoàn thành'`);
      }
      if (customer.user && customer.user[0]) {
        setTimeout(async () => {
          try {
            if (customer.isSubcribeToFcmNotification)
              await this.fcmPushNotificationService.sendNotificationToGroupOfUser(
                [customer.user[0].id],
                `[DP Cargo]-Thông báo`,
                `Giao dịch ${transaction.id} đã ${data.status === 'hoàn thành' ? 'được DUYỆT' : 'bị HỦY'}`,
              );
            if (customer?.isSubcribeToEmailNotification) await Mailer.notifyTransactionApprovalStatus(customer.email, transaction);
          } catch (e) {}
        }, 0);
      }
    }
  }

  public async getTransactionStatus(req) {
    let queryBuilder: any = CustomerTransactionLogs.query()
      .select('customer_transaction_logs.id', 'customer_transaction_logs.status')
      .whereIn('status', CUSTOMER_TRANSACTION_STATUS);
    this.filterTransaction(req, req.user, req.query, queryBuilder, true);
    queryBuilder = await queryBuilder;
    const frequency = {};
    queryBuilder.forEach(record => {
      frequency[record.status] = (frequency[record.status] || 0) + 1;
    });
    queryBuilder = frequency;

    const allStatuses = Object.keys(CUSTOMER_TRANSACTION_STATUS_ORDER);
    const statusList = allStatuses.map(name => ({
      name,
      total: frequency[name] || 0,
      id: AWB_STATUS_ORDER[name],
    }));

    statusList.sort((a, b) => a.id - b.id);

    return statusList;
  }
}

export default CustomerTransactionLogsService;
