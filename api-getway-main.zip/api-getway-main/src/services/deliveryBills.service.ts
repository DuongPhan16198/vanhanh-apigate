import { DeliveryBill } from '@/models/deliveryBill.model';
import { HttpException } from '@exceptions/HttpException';
import { Customer } from '@/models/customer.model.';
import { BusinessPartner } from '@/models/businessPartner.model';
import { Tracking } from '@/models/tracking.model';
import { TrackingsDeliveryBillLinks } from '@/models/trackingsDeliveryBillLinks.model';
import BadRequestException from '@/exceptions/BadRequestException';
import { generateNextDeliveryBillsId } from '@/utils/util';
import { DeliveryBillCustomerLinks } from '@/models/deliveryBillCustomerLinks.model';
import CustomerTransactionLogsService from './customerTransactionLogs.service';
import { CustomerTransactionLogs } from '@/models/customerTransactionLogs.model';
import { RequestWithUser } from '@/interfaces/auth.interface';
import Objection from 'objection';
import getReqPerrmissionBusinessLogic from '@/utils/getReqPerrmissionBusinessLogic';
import { DELIVERY_BILL_STATUS, DELIVERY_BILL_STATUS_ORDER } from '@/constant/constant';
import FcmPushNotificationService from './fcmPushNotification.service';
import { VnDeliveryOrderStatus, VnDeliveryOrders } from '@/models/vnDeliveryOrder.model';
import { TrackingStatusLogs } from '@/models/trackingStatusLog.model';
import * as ExcelJS from 'exceljs';
import { Mailer } from '@/helper/mailer';
import { VnDeliveryBoxStatus } from '@/models/vnDeliveryBox.model';
import VnDeliveryOrdersCommonService from './vnDeliveryOrderCommon.service';
import VnDeliveryBoxesCommonService from './vnDeliveryBoxCommon.service';
class DeliveryBillsService {
  private readonly customerTransactionLogsService = new CustomerTransactionLogsService();
  private readonly fcmPushNotificationService = new FcmPushNotificationService();
  private readonly deliveryOrderCommonService = new VnDeliveryOrdersCommonService();
  private readonly deliveryBoxCommonService = new VnDeliveryBoxesCommonService();
  static getInstant(): DeliveryBillsService {
    return new DeliveryBillsService();
  }

  private DVB_UPDATABLE_STATUS = ['Phiếu mới tạo', 'Sale duyệt', 'Kế toán duyệt', 'Yêu cầu xuất kho', 'Đã đóng hàng'];
  private async dvbAdditionalFilterByPermissionBusinessLogic(
    req: RequestWithUser,
    queryBuilder: Objection.QueryBuilder<DeliveryBill, DeliveryBill[]>,
    user,
    customer,
    statusOnly: boolean,
    isFilterByCodeBefore?,
  ) {
    if (req.permission_business_logic) {
      if (req.permission_business_logic !== 6 && statusOnly === false) {
        queryBuilder.withGraphFetched('tracking as trackings');
      }
      switch (req.permission_business_logic) {
        case 1:
          break;
        case 2:
          if (customer)
            queryBuilder
              .innerJoin('customers_sale_links', 'customers_sale_links.customer_id', '=', 'customer.id')
              .where('customers_sale_links.user_id', user.id);
          else
            queryBuilder
              .joinRelated('customer')
              .innerJoin('customers_sale_links', 'customers_sale_links.customer_id', '=', 'customer.id')
              .where('customers_sale_links.user_id', user.id);
          break;
        case 3:
          queryBuilder
            .innerJoin('trackings_warehouse_vn_links', 'tr.id', '=', 'trackings_warehouse_vn_links.tracking_id')
            .where('trackings_warehouse_vn_links.warehouse_config_id', user.warehouseVN[0].id);
          break;
        case 4:
          if (customer)
            queryBuilder
              .innerJoin('customers_service_staff_links', 'customers_service_staff_links.customer_id', '=', 'customer.id')
              .where('customers_service_staff_links.user_id', user.id);
          else
            queryBuilder
              .joinRelated('customer')
              .innerJoin('customers_service_staff_links', 'customers_service_staff_links.customer_id', '=', 'customer.id')
              .where('customers_service_staff_links.user_id', user.id);
          break;
        case 5:
          queryBuilder
            .innerJoin('delivery_bills_customer_links', 'delivery_bills_customer_links.delivery_bill_id', '=', 'dvb.id')
            .where('delivery_bills_customer_links.customer_id', user.customer.id);
          break;
        case 6:
          queryBuilder.modifyGraph('vnDeliveryBoxes', builder => builder.where('delivered_by_id', user.id).orWhereNull('delivered_by_id'));
          if (isFilterByCodeBefore) queryBuilder.where('vnDeliveryBoxes.delivered_by_id', user.id);
          else
            queryBuilder
              .innerJoin('vn_delivery_orders', 'vn_delivery_orders.delivery_bill_id', '=', 'dvb.id')
              .innerJoin('vn_delivery_boxes', 'vn_delivery_boxes.vn_delivery_order_id', '=', 'vn_delivery_orders.id')
              .where('vn_delivery_boxes.delivered_by_id', user.id);

          break;
        default:
          break;
      }
    }
  }
  private filterDeliveryBill(req, user, param, queryBuilder, statusOnly) {
    let { deliveryBillStatus, code, fromDate, toDate, customer, filterDateBy, warehouse_id, orderBy } = param;
    if (statusOnly) {
      deliveryBillStatus = orderBy = null;
    }
    if (code) {
      queryBuilder.leftJoinRelated('vnDeliveryBoxes');
      queryBuilder.andWhere(builder => {
        builder.whereILike('dvb.code', `%${code}%`).orWhereILike('vnDeliveryBoxes.code', `%${code}`);
      });
    }
    if (customer) {
      queryBuilder.where('customer.id', customer);
    }

    if (deliveryBillStatus) {
      switch (deliveryBillStatus) {
        case '1':
          queryBuilder.where('deliveryBillStatus', 'Phiếu mới tạo');
          break;
        case '2':
          queryBuilder.where('deliveryBillStatus', 'Sale duyệt');
          break;
        case '3':
          queryBuilder.where('deliveryBillStatus', 'Kế toán duyệt');
          break;
        case '4':
          queryBuilder.where('deliveryBillStatus', 'Yêu cầu xuất kho');
          break;
        case '5':
          queryBuilder.where('deliveryBillStatus', 'Đã đóng hàng');
          break;
        case '6':
          queryBuilder.where('deliveryBillStatus', 'Đang giao hàng');
          break;
        case '7':
          queryBuilder.where('deliveryBillStatus', 'Hoàn thành đơn hàng');
          break;
        case '8':
          queryBuilder.where('deliveryBillStatus', 'Đơn hàng giao không thành công');
          break;
        case '9':
          queryBuilder.where('deliveryBillStatus', 'Hủy PXK');
          break;
        default:
          break;
      }
    }
    if (
      (warehouse_id && (!req.permission_business_logic || req.permission_business_logic == 1)) ||
      (orderBy && orderBy?.split('-')[0] === 'trackingTotalMoney') ||
      req.permission_business_logic == 3
    ) {
      if (orderBy?.split('-')[1] === 'desc') queryBuilder.innerJoinRelated('tracking as tr');
      else queryBuilder.leftJoinRelated('tracking as tr');
    }
    if (warehouse_id && (!req.permission_business_logic || req.permission_business_logic == 1)) {
      queryBuilder
        .innerJoin('trackings_warehouse_vn_links', 'tr.id', '=', 'trackings_warehouse_vn_links.tracking_id')
        .where('trackings_warehouse_vn_links.warehouse_config_id', warehouse_id);
    }

    if (fromDate && toDate) {
      queryBuilder.whereBetween('dvb.created_at', [fromDate, toDate]);
    }
    if (filterDateBy && fromDate && toDate) {
      queryBuilder.where(filterDateBy, '>=', new Date(fromDate)).where(filterDateBy, '<=', new Date(toDate));
    }

    if (customer) {
      queryBuilder.joinRelated('customer').where('customer.id', customer);
    }

    if (req.permission_business_logic) {
      this.dvbAdditionalFilterByPermissionBusinessLogic(req, queryBuilder, user, customer, statusOnly, Boolean(code));
    }
    if (orderBy) {
      const [field, sortOrder] = orderBy.split('-');
      if (['id', 'createdAt'].includes(field)) {
        queryBuilder.orderBy(`dvb.${field}`, sortOrder);
      } else if (field === 'trackingTotalMoney') {
        queryBuilder.groupBy('dvb.id').orderByRaw('SUM(tr.tracking_total_money) ' + sortOrder);
      }
    } else if (!statusOnly) {
      queryBuilder.orderBy('dvb.createdAt', 'desc');
    }
  }
  public async findAll(req, user, param) {
    const queryBuilder = DeliveryBill.query().from('delivery_bills as dvb');
    const { page, pageSize = 10 } = param;

    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }
    this.filterDeliveryBill(req, user, param, queryBuilder, false);
    const listDeliveryBills = await queryBuilder
      .withGraphFetched('customer')
      .page(pageIndex, pageSize)
      .withGraphFetched('vnDeliveryOrder')
      .withGraphFetched('vnDeliveryBoxes')
      .modifyGraph('vnDeliveryBoxes', box => box.withGraphFetched('deliveredBy'))
      .modifyGraph('vnDeliveryOrder', order => order.withGraphFetched('vnDeliveryUnit'))
      .groupBy('dvb.id');
    if (!listDeliveryBills) throw new HttpException(404, "Bill doesn't exist");

    const results = listDeliveryBills.results.map(bill => {
      let totalTrackingMiningWeight = 0;
      let totalTrackingCalculationWeight = 0;
      let trackingTotalMoney = 0;

      bill?.trackings?.forEach(tr => {
        totalTrackingMiningWeight += Number(tr.trackingMiningWeight);
        totalTrackingCalculationWeight += Number(tr.trackingCalculationWeight);
        trackingTotalMoney += Number(tr.trackingTotalMoney);
      });
      return {
        ...bill,
        totalTrackingMiningWeight,
        totalTrackingCalculationWeight,
        trackingTotalMoney,
      };
    });

    return {
      meta: {
        page: pageIndex + 1,
        pageSize,
        total: listDeliveryBills.total,
        totalPage: Math.ceil(listDeliveryBills.total / pageSize),
      },
      data: results,
    };
  }

  public async findDeliveryBillById(req, user, deliveryBillId, isNonRestrictedAuthorization?) {
    const queryBuilder = DeliveryBill.query()
      .from('delivery_bills as dvb')
      .withGraphFetched('tracking as trackings')
      .withGraphFetched('customer')
      .withGraphFetched('employee')
      .withGraphFetched('vnDeliveryOrder')
      .withGraphFetched('vnDeliveryBoxes')
      .modifyGraph('vnDeliveryBoxes', box => box.withGraphFetched('deliveredBy'))
      .modifyGraph('vnDeliveryOrder', order => order.withGraphFetched('vnDeliveryUnit'))
      .modifyGraph('trackings', builder => {
        builder.withGraphFetched('trackingType');
      })
      .where('dvb.id', deliveryBillId);
    if (req) {
      await getReqPerrmissionBusinessLogic(req, 'api:: GET /api/delivery_bills/');
      if (req.permission_business_logic) {
        this.dvbAdditionalFilterByPermissionBusinessLogic(req, queryBuilder, user, null, false, false);
      }
    }
    const deliveryBill: DeliveryBill = await queryBuilder.first();

    if (!deliveryBill) {
      throw new HttpException(404, "Delivery bill doesn't exist");
    }

    let totalTrackingMiningWeight = 0;
    let totalTrackingCalculationWeight = 0;
    let trackingTotalMoney = 0;

    deliveryBill.trackings.forEach(tr => {
      totalTrackingMiningWeight += Number(tr.trackingMiningWeight);
      totalTrackingCalculationWeight += Number(tr.trackingCalculationWeight);
      trackingTotalMoney += Number(tr.trackingTotalMoney);
    });

    const transaction = await CustomerTransactionLogs.query().where('customer_transaction_note', deliveryBill.code);

    return {
      ...deliveryBill,
      totalTrackingMiningWeight,
      totalTrackingCalculationWeight,
      trackingTotalMoney,
      customer: deliveryBill.customer[0],
      transaction: transaction[0],
    };
  }

  public codeSuggestion = async (user, deliveryBillsCode, param) => {
    const { fromDate, toDate, deliveryBillStatus } = param;
    const queryBuilder = DeliveryBill.query().from('delivery_bills as dvb');

    if (fromDate && toDate) {
      queryBuilder.whereBetween('dvb.created_at', [fromDate, toDate]);
    }

    if (deliveryBillStatus) {
      switch (deliveryBillStatus) {
        case '0':
          queryBuilder.where('deliveryBillStatus', 'Phiếu mới tạo');
          break;
        case '1':
          queryBuilder.where('deliveryBillStatus', 'Đang đóng hàng');
          break;
        case '2':
          queryBuilder.where('deliveryBillStatus', 'Đang giao hàng');
          break;
        case '3':
          queryBuilder.where('deliveryBillStatus', 'Hoàn thành đơn hàng');
          break;
        case '4':
          queryBuilder.where('deliveryBillStatus', 'Đơn hàng giao không thành công');
          break;
        default:
          break;
      }
    }

    const codes = await queryBuilder
      .select('code')
      .joinRelated('customer')
      .where('customer.email', user.email)
      .andWhereLike('code', `%${deliveryBillsCode}`);
    return codes.length > 0 ? codes.map(c => c.code) : [];
  };

  public waitingCreateDeliveryBills = async (req, user, params) => {
    const { page, pageSize = 10, customer, warehouse_id } = params;

    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }

    const queryBuilder = Customer.query().from('customers');

    if (customer) {
      queryBuilder.where('customers.id', customer);
    }

    if (user.businessPartner) {
      const CustomerBelongToBusinessPartner: any = await BusinessPartner.query().where('id', user.businessPartner.id).withGraphFetched('customerIn');
      const CustomerIdBelongToBusinessPartner = CustomerBelongToBusinessPartner[0].customerIn.map(cus => cus.id);
      queryBuilder.whereIn('customers.id', CustomerIdBelongToBusinessPartner);
    }

    if (req.permission_business_logic) {
      const { user } = req;
      switch (req.permission_business_logic) {
        case 1:
          break;
        case 2:
          queryBuilder.where('sale.id', user.id);
          break;
        case 3:
          queryBuilder.where('customerServiceStaff.id', user.id);
          break;
        default:
          break;
      }
    }

    const { results, total } = await queryBuilder
      .whereExists(function () {
        if (warehouse_id && (!req.permission_business_logic || req.permission_business_logic == 1)) {
          this.innerJoin('trackings_warehouse_vn_links', 'trackings.id', '=', 'trackings_warehouse_vn_links.tracking_id').where(
            'trackings_warehouse_vn_links.warehouse_config_id',
            warehouse_id,
          );
        }
        this.select('trackings.id')
          .from('trackings')
          .leftJoin('trackings_customer_links', 'trackings.id', '=', 'trackings_customer_links.tracking_id')
          .leftJoin('trackings_delivery_bill_links', 'trackings_delivery_bill_links.tracking_id', '=', 'trackings.id')
          .whereRaw('trackings_customer_links.customer_id = customers.id')
          .where('trackings.exploit_status', 'Đã khai thác')
          .whereNot('trackings.is_deleted', true)
          .whereNull('trackings_delivery_bill_links.delivery_bill_id');
      })
      .withGraphFetched('trackings')
      .withGraphFetched('boxStag as tags')
      .withGraphFetched('user')
      .modifyGraph('trackings', builder => {
        builder.distinct('trackings.*');
        if (warehouse_id) {
          builder
            .innerJoin('trackings_warehouse_vn_links', 'trackings.id', '=', 'trackings_warehouse_vn_links.tracking_id')
            .where('trackings_warehouse_vn_links.warehouse_config_id', warehouse_id);
        }
        return builder
          .leftJoin(TrackingsDeliveryBillLinks.tableName, 'trackings.id', 'trackings_delivery_bill_links.tracking_id')
          .where('trackings.exploit_status', 'Đã khai thác')
          .whereNot('trackings.is_deleted', true)
          .whereNull('trackings_delivery_bill_links.delivery_bill_id')
          .withGraphFetched('deliveryBill')
          .modifyGraph('deliveryBill', billQuery => billQuery.whereNull('delivery_bills.id'))
          .withGraphFetched('box')
          .withGraphFetched('awb')
          .withGraphFetched('warehouseVn');
      })
      .leftJoinRelated('sale')
      .groupBy('customers.id')
      .page(pageIndex, pageSize);

    return {
      pagination: {
        page: Number(pageIndex) + 1,
        pageSize: Number(pageSize),
        total: total,
        totalPage: Math.ceil(total / pageSize),
      },
      data: results.map(u => {
        let totalExploitWeight = 0;
        let totalFlyingWeight = 0;
        let moneyTemporary = 0;
        u.trackings.forEach((tr: any) => {
          totalExploitWeight += Number(tr.trackingCalculationWeight);
          totalFlyingWeight += Number(tr.trackingMiningWeight);
          moneyTemporary += Number(tr.trackingTotalMoney || 0);
        });
        return {
          id: u.id,
          name: u.name,
          phone: u.phone,
          nickName: u.nickName,
          balance: u.balance,
          moneyTemporary: moneyTemporary, //TODO :  (u.shippingCost *) calculate by tracking type, config pricing
          tags: u.tags,
          quantityTracking: u.trackings.length,
          trackings: u.trackings,
          totalExploitWeight,
          totalFlyingWeight,
        };
      }),
    };
  };

  private updateManyTrackingStatus = async (status, listTrackingId) => {
    return await Tracking.query().patch({ exploitStatus: status }).whereIn('id', listTrackingId);
  };

  private updateTrackingStatusById = async (status, trackingId, additionalUpdate?) => {
    if (additionalUpdate)
      await Tracking.query()
        .patch({ ...additionalUpdate, exploitStatus: status })
        .where('id', trackingId);
    else await Tracking.query().patch({ exploitStatus: status }).where('id', trackingId);
  };

  private deleteDeliveryBillOfTrackings = async listTrackingId => {
    return await TrackingsDeliveryBillLinks.query().delete().whereIn('tracking_id', listTrackingId);
  };

  public updateDeliveryBills = async (req, billId, data) => {
    const bill: any = await DeliveryBill.query()
      .withGraphFetched('tracking')
      .modifyGraph('tracking', builder => builder.select('trackings.id'))
      .findById(billId);

    if (!bill && !(await this.findDeliveryBillById(req, req.user, billId))) {
      throw new HttpException(404, 'Delivery bill is not found');
    }

    const listTrackingId = bill.tracking.map(tr => tr.id);

    const updateData: any = {};

    if (data.deliveryBillStatus) {
      updateData.deliveryBillStatus = data.deliveryBillStatus;
      switch (data.deliveryBillStatus) {
        case 'Hoàn thành':
          await this.updateManyTrackingStatus('Hoàn thành', listTrackingId);
          break;
        case 'Đơn hàng giao không thành công':
          await this.updateManyTrackingStatus('Đã khai thác', listTrackingId);
          break;
        case 'Hủy PXK':
          await Promise.all([this.updateManyTrackingStatus('Đã khai thác', listTrackingId), this.deleteDeliveryBillOfTrackings(listTrackingId)]);
          break;
        default:
          break;
      }
    }

    if (data.description) {
      updateData.description = data.description;
    }

    if (data.customerPhone) {
      updateData.customer_phone = data.customerPhone;
    }

    if (data.customerAddress) {
      updateData.customer_address = data.customerAddress;
    }

    if (data.note) {
      updateData.note = data.note;
    }

    if (data.isConfirmedByCustomer) {
      updateData.isConfirmedByCustomer = data.isConfirmedByCustomer;
    }

    if (data.isPackaged) {
      updateData.isPackaged = data.isPackaged;
    }

    if (data.isCharged) {
      updateData.isCharged = data.isCharged;
    }

    if (data.customerName) {
      updateData.customer_name = data.customerName;
    }

    await DeliveryBill.query().patch(updateData).where('id', billId);

    return await this.findDeliveryBillById(req, req.user, billId);
  };

  public updateNewlyCreatedDeliveryBills = async (req, billId, data) => {
    const bill: any = await DeliveryBill.query().findById(billId);

    if (!bill && !(await this.findDeliveryBillById(req, req.user, billId))) {
      throw new HttpException(404, 'Delivery bill is not found');
    }
    if (!this.DVB_UPDATABLE_STATUS.includes(bill.deliveryBillStatus)) {
      throw new HttpException(400, `Bill is not in modifiable statuses : ${this.DVB_UPDATABLE_STATUS}`);
    }
    const updateData: any = {};

    if (data.description) {
      updateData.description = data.description;
    }

    if (data.customerAddress) {
      updateData.customer_address = data.customerAddress;
    }

    if (data.customerName) {
      updateData.name = data.customerName;
    }

    if (data.customerPhone) {
      updateData.customer_phone = data.customerPhone;
    }

    if (data.email) {
      updateData.email = data.email;
    }

    if (data.note) {
      updateData.note = data.note;
    }

    await DeliveryBill.query().patch(updateData).where('id', billId);

    return await this.findDeliveryBillById(req, req.user, billId);
  };

  public updateDeliveredImageUrl = async (req, billId, data) => {
    await this.findDeliveryBillById(req, req.user, billId);
    const { deliveredImageUrl, shipper_note } = data;
    const updateData: any = {};

    if (shipper_note) {
      updateData.shipper_note = data.shipper_note;
    }

    if (deliveredImageUrl) {
      updateData.deliveredImageUrl = data.deliveredImageUrl;
    }

    await DeliveryBill.query().patch(updateData).where('id', billId).whereIn('deliveryBillStatus', ['Đang giao hàng', 'Hoàn thành đơn hàng']);

    return await this.findDeliveryBillById(req, req.user, billId);
  };

  public statusUpdateBill = async () => {
    return ['Hoàn thành', 'Đơn hàng giao không thành công', 'Hủy PXK'];
  };

  public createDeliveryBill = async (req, deliveryBillData: any, user: any) => {
    await getReqPerrmissionBusinessLogic(req, 'api:: GET /api/delivery_bills/');
    if (
      (req.permission_business_logic && req.permission_business_logic === 5) ||
      req.user.role.type === 'khach_hang' ||
      req.user.type === 'customer'
    ) {
      delete deliveryBillData.customerId;
      deliveryBillData.customerId = req.user.customer.id;
    }
    const { customerId, trackingIds, description, phone, note, address, name, email } = deliveryBillData;
    if (!customerId || !trackingIds || trackingIds?.length === 0) throw new BadRequestException('customerId and trackingIds are required');

    const trackingHasDeliveryBill = await TrackingsDeliveryBillLinks.query().whereIn('tracking_id', trackingIds);
    if (trackingHasDeliveryBill.length !== 0) {
      let message = '';
      trackingHasDeliveryBill.forEach((b: any) => {
        message += `Tracking ${b.trackingId} is belongs to bill ${b.deliveryBillId}; `;
      });
      throw new BadRequestException(message);
    }

    const insertData: any = {};

    if (description) {
      insertData.description = description;
    }

    if (phone) {
      insertData.customerPhone = phone;
    }

    if (note) {
      insertData.note = note;
    }

    if (email) {
      insertData.email = email;
    }

    if (address) {
      insertData.customerAddress = address;
    }

    if (name) {
      insertData.name = name;
    }

    const { code } = await generateNextDeliveryBillsId();
    insertData.createdAt = new Date();
    insertData.updatedAt = new Date();
    insertData.code = code;
    insertData.deliveryBillStatus = 'Phiếu mới tạo';
    insertData.isConfirmedByCustomer = false;
    insertData.isPackaged = false;
    insertData.isCharged = false;
    insertData.createdById = user.id;
    const deliveryBill = await DeliveryBill.query().insert(insertData).into('delivery_bills');

    const deliveryBillCustomerLinkInsertData = {
      delivery_bill_id: deliveryBill.id,
      customer_id: customerId,
    };

    await DeliveryBillCustomerLinks.query().insert(deliveryBillCustomerLinkInsertData).into('delivery_bills_customer_links');
    await Promise.all(
      trackingIds.map(async tr => {
        await TrackingsDeliveryBillLinks.query().insert({ delivery_bill_id: deliveryBill.id, tracking_id: tr }).into('trackings_delivery_bill_links');
      }),
    );

    const res = await DeliveryBill.query().findById(deliveryBill.id);
    return res;
  };

  public getTrackingCustomer = async (id: number, user: any, params: any) => {
    const { code, warehouse_id } = params;
    const queryBuilder = Tracking.query().from('trackings').withGraphFetched('trackingType');
    if (code) {
      queryBuilder.whereLike('trackings.code', `%${code}%`);
    }

    if (user.businessPartner) {
      const CustomerBelongToBusinessPartner: any = await BusinessPartner.query().where('id', user.businessPartner.id).withGraphFetched('customerIn');
      const CustomerIdBelongToBusinessPartner = CustomerBelongToBusinessPartner[0].customerIn.map(cus => cus.id);
      queryBuilder.whereIn('customer.id', CustomerIdBelongToBusinessPartner);
    }
    if (warehouse_id) {
      queryBuilder
        .innerJoin('trackings_warehouse_vn_links', 'trackings.id', '=', 'trackings_warehouse_vn_links.tracking_id')
        .where('trackings_warehouse_vn_links.warehouse_config_id', warehouse_id);
    }
    const trackingOfCustomer = await queryBuilder
      .leftJoin(TrackingsDeliveryBillLinks.tableName, 'trackings.id', 'trackings_delivery_bill_links.tracking_id')
      .where('trackings.exploit_status', 'Đã khai thác')
      .whereNot('trackings.is_deleted', true)
      .whereNull('trackings_delivery_bill_links.delivery_bill_id')
      .withGraphFetched('deliveryBill')
      .withGraphFetched('box')
      .withGraphFetched('awb')
      .leftJoinRelated('customer')
      .leftJoin('trackings_customer_links', 'customer.id', 'trackings_customer_links.customer_id')
      .where('customer.id', id)
      .groupBy('trackings.id')
      .orderBy('trackings.id');
    return {
      data: trackingOfCustomer.map(item => item),
    };
  };

  public async search(req, kw: string) {
    const keyword = kw ? kw : '';
    const queryBuilder = DeliveryBill.query();
    const deliveryBills = await queryBuilder.whereILike('code', `%${keyword}%`);
    return deliveryBills;
  }

  public searchTrackingCustomer = async (id: number, user: any, params: any) => {
    const { code } = params;

    const queryBuilder = Tracking.query().from('trackings');

    if (user.businessPartner) {
      const CustomerBelongToBusinessPartner: any = await BusinessPartner.query().where('id', user.businessPartner.id).withGraphFetched('customerIn');
      const CustomerIdBelongToBusinessPartner = CustomerBelongToBusinessPartner[0].customerIn.map(cus => cus.id);
      queryBuilder.withGraphFetched('customer').whereIn('customer.id', CustomerIdBelongToBusinessPartner);
    }

    if (code) {
      queryBuilder.whereILike('trackings.code', `%${code}%`);
      const trackingOfCustomer = await queryBuilder
        .leftJoin(TrackingsDeliveryBillLinks.tableName, 'trackings.id', 'trackings_delivery_bill_links.tracking_id')
        .where('trackings.exploit_status', 'Đã khai thác')
        .withGraphFetched('deliveryBill')
        .withGraphFetched('box')
        .withGraphFetched('awb')
        .leftJoinRelated('customer')
        .leftJoin('trackings_customer_links', 'customer.id', 'trackings_customer_links.customer_id')
        .where('customer.id', id)
        .groupBy('trackings.id')
        .orderBy('trackings.id');

      return {
        data: trackingOfCustomer[0] || {},
      };
    } else {
      throw new HttpException(404, 'Not found tracking!');
    }
  };

  public printBill = async (req, id: string, isSkipping: boolean) => {
    this.validateEmptyTrackingList(await this.findDeliveryBillById(req, req.user, id));
    const validatedStates = ['Kế toán duyệt'];
    if (isSkipping) {
      validatedStates.push('Phiếu mới tạo', 'Sale duyệt');
    }
    const updateStatus = await DeliveryBill.query()
      .findById(id)
      .whereIn('deliveryBillStatus', validatedStates)
      .patch({ deliveryBillStatus: 'Yêu cầu xuất kho' });
    if (updateStatus === 0) {
      throw new HttpException(404, 'Delivery bill is not approved by accountant or not found!');
    }
    const updatedBill = await DeliveryBill.query()
      .findById(id)
      .withGraphFetched('customer')
      .modifyGraph('customer', builder => builder.withGraphFetched('user'));
    if (updatedBill?.customer[0]?.isSubcribeToFcmNotification)
      await this.sendPushNotificationToUser([updatedBill.customer[0].user[0].id], updatedBill.code, 'Yêu cầu xuất kho');
    return updatedBill;
  };

  public saleApproveBill = async (req, id: string) => {
    this.validateEmptyTrackingList(await this.findDeliveryBillById(req, req.user, id));
    const updateStatus = await DeliveryBill.query()
      .findById(id)
      .where({ deliveryBillStatus: 'Phiếu mới tạo' })
      .patch({ deliveryBillStatus: 'Sale duyệt' });
    if (updateStatus === 0) {
      throw new HttpException(404, 'Delivery bill is not approved by sale or not found!');
    }
    const updatedBill = await DeliveryBill.query()
      .findById(id)
      .withGraphFetched('customer')
      .modifyGraph('customer', builder => builder.withGraphFetched('user'));
    if (updatedBill?.customer[0]?.isSubcribeToFcmNotification)
      await this.sendPushNotificationToUser([updatedBill.customer[0].user[0].id], updatedBill.code, 'Sale duyệt');
    return updatedBill;
  };

  public accountantApproveBill = async (id: string) => {
    const deliveryBill: any = await DeliveryBill.query().withGraphFetched('tracking').withGraphFetched('customer').findById(id);
    this.validateEmptyTrackingList(deliveryBill);
    const trackingIds = deliveryBill.tracking.map(item => item.id);
    let trackingTotalMoney = 0;
    for (let i = 0; i < trackingIds.length; i++) {
      const tr = await Tracking.query().findById(trackingIds[i]);
      trackingTotalMoney += Number(tr.trackingTotalMoney);
    }
    if (
      !(await this.customerTransactionLogsService.customerBalancePayableCheck({
        customer_id: deliveryBill.customer[0].id,
        customer_transaction_money: trackingTotalMoney,
      }))
    ) {
      throw new HttpException(400, 'The customer does not have enough balance to make payment !');
    }
    const updateStatus = await DeliveryBill.query()
      .findById(id)
      .where({ deliveryBillStatus: 'Sale duyệt' })
      .patch({ deliveryBillStatus: 'Kế toán duyệt' });
    if (updateStatus === 0) {
      throw new HttpException(404, 'Delivery bill is not approved by accountant or not found!');
    }
    const updatedBill = await DeliveryBill.query()
      .findById(id)
      .withGraphFetched('customer')
      .modifyGraph('customer', builder => builder.withGraphFetched('user'));
    if (updatedBill?.customer[0]?.isSubcribeToFcmNotification)
      await this.sendPushNotificationToUser([updatedBill.customer[0].user[0].id], updatedBill.code, 'Kế toán duyệt');
    return updatedBill;
  };

  public cancelBill = async (req, id: string) => {
    // 'deliveryBillStatus', 'Hoàn thành đơn hàng'

    const cancelableState = ['Phiếu mới tạo', 'Sale duyệt', 'Kế toán duyệt', 'Yêu cầu xuất kho', 'Đơn hàng giao không thành công'];
    let isCancelingPackedBill = false;
    if (req.permission_business_logic) {
      switch (req.permission_business_logic) {
        case 1:
          cancelableState.push('Đã đóng hàng');
          break;
        case 2:
        default:
          break;
      }
    }
    const bill: any = await this.findDeliveryBillById(req, req.user, id);
    if (bill.deliveryBillStatus === 'Đã đóng hàng' || bill.deliveryBillStatus === 'Đơn hàng giao không thành công') isCancelingPackedBill = true;

    if (bill.deliveryBillStatus === 'Hoàn thành đơn hàng' || bill.deliveryBillStatus === 'Đã huỷ') {
      throw new HttpException(404, 'Delivery bill cannot be cancel!');
    }

    const updateStatus = await DeliveryBill.query()
      .findById(id)
      .whereIn('delivery_bill_status', cancelableState)
      .patch({ deliveryBillStatus: 'Hủy PXK' });
    if (updateStatus === 0) {
      throw new HttpException(404, 'Cannot cancel : Delivery bill is not in cancelable state!');
    }

    const dvb: any = await DeliveryBill.query().withGraphFetched('tracking').findById(id);
    const existingIds = dvb?.tracking.map(item => item.id);

    await Promise.all(
      existingIds.map(async trId => {
        await TrackingsDeliveryBillLinks.query().delete().where('tracking_id', trId);
        await this.updateTrackingStatusById('Đã khai thác', trId);
        if (isCancelingPackedBill) {
          await TrackingStatusLogs.query()
            .insert({
              name: 'Đơn hàng đã bị hủy khỏi PXK',
              updatedTime: new Date(),
              trackingId: trId,
            })
            .into('tracking_status_logs');
        }
      }),
    );

    const updatedBill = await DeliveryBill.query()
      .findById(id)
      .withGraphFetched('customer')
      .modifyGraph('customer', builder => builder.withGraphFetched('user'));
    if (isCancelingPackedBill) {
      await this.refundMoneyToCustomer(req, dvb?.tracking, updatedBill);
    }
    if (updatedBill?.customer[0]?.isSubcribeToFcmNotification)
      await this.sendPushNotificationToUser([updatedBill.customer[0].user[0].id], updatedBill.code, 'Hủy PXK');
    return updatedBill;
  };

  public exportBill = async (req, id: string, body: any) => {
    const delivery: any = await DeliveryBill.query()
      .withGraphFetched('customer')
      .withGraphFetched('tracking')
      .withGraphFetched('vnDeliveryOrder')
      .findById(id);
    this.validateEmptyTrackingList(delivery);
    if (delivery.deliveryBillStatus === 'Yêu cầu xuất kho') {
      const bill: any = delivery;
      const existingIds = bill.tracking.filter(item => item.exploitStatus === 'Đã đóng hàng').map(item => item.id);
      if (existingIds?.length === 0) {
        throw new BadRequestException('Cannot export with empty packed trackings');
      }
      const trackingIdToDelete = bill.tracking.filter(item => item.exploitStatus !== 'Đã đóng hàng').map(item => item.id);

      trackingIdToDelete.map(async trId => {
        await TrackingsDeliveryBillLinks.query().delete().where('tracking_id', trId);
      });
      let trackingTotalMoney = 0;
      const trackingsToExport = await Tracking.query().whereIn('id', existingIds);
      trackingsToExport.forEach((tr: any) => {
        trackingTotalMoney += Number(tr.trackingTotalMoney);
      });
      if (!trackingTotalMoney) trackingTotalMoney = 0;
      const updateStatus = await DeliveryBill.query()
        .findById(id)
        .where({ deliveryBillStatus: 'Yêu cầu xuất kho' })
        .patch({ deliveryBillStatus: 'Đã đóng hàng' });

      if (updateStatus === 0) {
        throw new HttpException(404, 'Delivery bill is not packed or not found!');
      }
      await this.customerTransactionLogsService.createTransaction(
        req,
        {
          customer_id: delivery.customer[0].id,
          customer_transaction_type: 'THANH TOÁN',
          customer_transaction_money: Number(trackingTotalMoney ?? 0) || 0,
          customer_transaction_note: `Thanh toán cho PXK ${delivery.code}`,
          bank_account: body.bank_account || null,
          image: body.image || null,
        },
        null,
        true,
      );
      const updatedBill = await DeliveryBill.query()
        .findById(id)
        .withGraphFetched('customer')
        .modifyGraph('customer', builder => builder.withGraphFetched('user'));
      if (updatedBill?.customer[0]?.isSubcribeToFcmNotification)
        await this.sendPushNotificationToUser([updatedBill.customer[0].user[0].id], updatedBill.code, 'Đã đóng hàng');
      return updatedBill;
    } else if (delivery.deliveryBillStatus === 'Đơn hàng giao không thành công') {
      const updateStatus = await DeliveryBill.query()
        .findById(id)
        .where({ deliveryBillStatus: 'Đơn hàng giao không thành công' })
        .patch({ deliveryBillStatus: 'Đã đóng hàng' });
      if (updateStatus === 0) {
        throw new HttpException(404, 'Delivery bill is not packed or not found!');
      }
      await Promise.all(
        delivery.vnDeliveryOrder.map(async order => {
          await this.updateDeliveringStatusOfVnDeliveryOrder(order.id, VnDeliveryOrderStatus.NEWLYCREATED);
        }),
      );
      const updatedBill = await DeliveryBill.query()
        .findById(id)
        .withGraphFetched('customer')
        .modifyGraph('customer', builder => builder.withGraphFetched('user'));

      if (updatedBill?.customer[0]?.isSubcribeToFcmNotification)
        await this.sendPushNotificationToUser([updatedBill.customer[0].user[0].id], updatedBill.code, 'Đã đóng hàng');
      return updatedBill;
    } else {
      throw new HttpException(400, 'Delivery bill exported');
    }
  };

  private refundMoneyToCustomer = async (req, trackings, delivery_bill) => {
    if (trackings?.length) {
      let trackingTotalMoney = 0;
      trackings.forEach((tr: any) => {
        trackingTotalMoney += Number(tr.trackingTotalMoney);
      });
      await this.customerTransactionLogsService.createTransaction(
        req,
        {
          customer_id: delivery_bill.customer[0].id,
          customer_transaction_type: 'HOÀN TIỀN',
          customer_transaction_money: trackingTotalMoney,
          customer_transaction_note: `Hoàn tiền cho PXK ${delivery_bill.code}`,
        },
        null,
        true,
      );
    }
  };

  public packBill = async (id: string) => {
    const updateStatus = await DeliveryBill.query()
      .findById(id)
      .where({ deliveryBillStatus: 'Đã đóng hàng' })
      .patch({ deliveryBillStatus: 'Đang giao hàng' });
    if (updateStatus === 0) {
      throw new HttpException(404, 'Delivery bill is not delivering or not found!');
    }

    // update exploit_status tracking
    const bill: any = await DeliveryBill.query().withGraphFetched('tracking').findById(id);
    const existingIds = bill?.tracking.map(item => item.id);
    await Promise.all(
      existingIds.map(async trId => {
        await this.updateTrackingStatusById('Đang giao hàng', trId, { vnExportDate: new Date() });
        await TrackingStatusLogs.query()
          .insert({
            name: 'Đơn hàng đã được bàn giao cho đơn vị vận chuyển, chuyển sang trạng thái Đang giao hàng',
            updatedTime: new Date(),
            trackingId: trId,
          })
          .into('tracking_status_logs');
      }),
    );

    const updatedBill: any = await DeliveryBill.query()
      .findById(id)
      .withGraphFetched('customer')
      .modifyGraph('customer', builder => builder.withGraphFetched('user'));
    setTimeout(async () => {
      try {
        if (updatedBill?.customer[0]?.isSubcribeToFcmNotification)
          await this.sendPushNotificationToUser([updatedBill.customer[0].user[0].id], updatedBill.code, 'Đang giao hàng');
        updatedBill.tracking = bill.tracking;
        if (updatedBill?.customer[0]?.isSubcribeToEmailNotification)
          await Mailer.notifyDeliveryBillStatus(updatedBill.customer[0].email, updatedBill);
      } catch (e) {
        console.log(e);
      }
    }, 0);

    return updatedBill;
  };

  public finishBill = async (id: string) => {
    const updateStatus = await DeliveryBill.query()
      .findById(id)
      .where({ deliveryBillStatus: 'Đang giao hàng' })
      .patch({ deliveryBillStatus: 'Hoàn thành đơn hàng' });
    if (updateStatus === 0) {
      throw new HttpException(404, 'Delivery bill is not delivering or not found!');
    }

    // update exploit_status tracking
    const dvb: any = await DeliveryBill.query().withGraphFetched('tracking').withGraphFetched('vnDeliveryOrder').findById(id);
    const existingIds = dvb?.tracking.map(item => item.id);
    await Promise.all(
      existingIds.map(async trId => {
        await this.updateTrackingStatusById('Hoàn thành', trId);
        await TrackingStatusLogs.query()
          .insert({
            name: 'Đơn hàng được giao thành công',
            updatedTime: new Date(),
            trackingId: trId,
          })
          .into('tracking_status_logs');
      }),
    );
    await Promise.all(
      dvb.vnDeliveryOrder.map(async order => {
        if (order.status === VnDeliveryOrderStatus.ONDELIVERING || order.status === VnDeliveryOrderStatus.NEWLYCREATED)
          await this.updateDeliveringStatusOfVnDeliveryOrder(order.id, VnDeliveryOrderStatus.COMPLETED);
      }),
    );
    const updatedBill = await DeliveryBill.query()
      .findById(id)
      .withGraphFetched('customer')
      .withGraphFetched('tracking')
      .modifyGraph('customer', builder => builder.withGraphFetched('user'));

    setTimeout(async () => {
      try {
        if (updatedBill?.customer[0]?.isSubcribeToFcmNotification)
          await this.sendPushNotificationToUser([updatedBill.customer[0].user[0].id], updatedBill.code, 'Hoàn thành đơn hàng');
        if (updatedBill?.customer[0]?.isSubcribeToEmailNotification)
          await Mailer.notifyDeliveryBillStatus(updatedBill.customer[0].email, updatedBill);
      } catch (error) {
        console.error('Error inside setTimeout:', error);
      }
    }, 0);

    return updatedBill;
  };

  public failedBill = async (req, id: string) => {
    const updateStatus = await DeliveryBill.query()
      .findById(id)
      .where({ deliveryBillStatus: 'Đang giao hàng' })
      .patch({ deliveryBillStatus: 'Đơn hàng giao không thành công' });
    if (updateStatus === 0) {
      throw new HttpException(404, 'Delivery bill is not found!');
    }

    // update exploit_status tracking
    const dvb: any = await DeliveryBill.query().withGraphFetched('tracking').withGraphFetched('vnDeliveryOrder').findById(id);
    const existingIds = dvb?.tracking.map(item => item.id);
    await Promise.all(
      existingIds.map(async trId => {
        await this.updateTrackingStatusById('Đã đóng hàng', trId);
        await TrackingStatusLogs.query()
          .insert({
            name: 'Đơn hàng giao hàng thất bại, chuyển về kho',
            updatedTime: new Date(),
            trackingId: trId,
          })
          .into('tracking_status_logs');
      }),
    );

    await Promise.all(
      dvb.vnDeliveryOrder.map(async order => {
        if (order.status !== VnDeliveryOrderStatus.FAILED) await this.updateDeliveringStatusOfVnDeliveryOrder(order.id, VnDeliveryOrderStatus.FAILED);
      }),
    );

    const updatedBill = await DeliveryBill.query()
      .findById(id)
      .withGraphFetched('customer')
      .modifyGraph('customer', builder => builder.withGraphFetched('user'));
    if (updatedBill?.customer[0]?.isSubcribeToFcmNotification)
      await this.sendPushNotificationToUser([updatedBill.customer[0].user[0].id], updatedBill.code, 'Đơn hàng giao không thành công');
    return updatedBill;
  };

  private async updateDeliveringStatusOfVnDeliveryOrder(vnDeliveryOrdersId, newStatus) {
    await this.deliveryOrderCommonService.updateDeliveringStatusOfVnDeliveryOrder(vnDeliveryOrdersId, newStatus);
  }

  public getBillCustomer = async (id: number, param: any) => {
    const { page, pageSize = 10 } = param;
    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }

    const customer = await DeliveryBill.query()
      .join('delivery_bills_customer_links', 'delivery_bills.id', 'delivery_bills_customer_links.delivery_bill_id')
      .where('delivery_bills_customer_links.customer_id', id)
      .withGraphFetched('tracking')
      .withGraphFetched('vnDeliveryOrder')
      .withGraphFetched('vnDeliveryBoxes')
      .modifyGraph('vnDeliveryOrder', order => order.withGraphFetched('vnDeliveryUnit'))
      .orderBy('delivery_bills.id')
      .withGraphFetched('customer')
      .page(pageIndex, pageSize);

    const { results, total } = customer;

    return {
      pagination: {
        page: pageIndex + 1,
        pageSize,
        total: total,
        totalPage: Math.ceil(total / pageSize),
      },
      data: results.map((u: any) => {
        let totalTrackingCalculationWeight = 0;
        let totalTrackingMiningWeight = 0;
        let quantityTracking = 0;
        let trackingTotalMoney = 0;
        u.tracking.forEach((tr: any) => {
          totalTrackingCalculationWeight += Number(tr.trackingCalculationWeight);
          totalTrackingMiningWeight += Number(tr.trackingMiningWeight);
          quantityTracking++;
          trackingTotalMoney += Number(tr.trackingTotalMoney);
        });
        delete u.tracking;
        return {
          ...u,
          totalTrackingMiningWeight: parseFloat(parseFloat(totalTrackingMiningWeight.toString()).toFixed(2)),
          totalTrackingCalculationWeight: parseFloat(parseFloat(totalTrackingCalculationWeight.toString()).toFixed(2)),
          quantityTracking: parseInt(quantityTracking.toString()),
          trackingTotalMoney: parseInt(trackingTotalMoney.toString()),
        };
      }),
    };
  };

  public createManyTrackingInBill = async (user: any, id: number, trackingIds: number[]) => {
    const dvbTrackingAddableState = ['Phiếu mới tạo', 'Sale duyệt', 'Kế toán duyệt', 'Yêu cầu xuất kho'];
    const billDetail = await DeliveryBill.query()
      .withGraphFetched('customer')
      .where('id', id)
      .whereIn('deliveryBillStatus', dvbTrackingAddableState)
      .first();
    const queryBuilder = Tracking.query();

    if (user.businessPartner) {
      const CustomerBelongToBusinessPartner: any = await BusinessPartner.query().where('id', user.businessPartner.id).withGraphFetched('customerIn');
      const CustomerIdBelongToBusinessPartner = CustomerBelongToBusinessPartner[0].customerIn.map(cus => cus.id);
      queryBuilder.whereIn('customer.id', CustomerIdBelongToBusinessPartner);
    }

    const trackingOfCustomer = await queryBuilder
      .from('trackings')
      .leftJoin(TrackingsDeliveryBillLinks.tableName, 'trackings.id', 'trackings_delivery_bill_links.tracking_id')
      .where('trackings.exploit_status', 'Đã khai thác')
      .where('trackings_delivery_bill_links.delivery_bill_id', null)
      .withGraphFetched('deliveryBill')
      .withGraphFetched('box')
      .withGraphFetched('awb')
      .leftJoinRelated('customer')
      .leftJoin('trackings_customer_links', 'customer.id', 'trackings_customer_links.customer_id')
      .where('customer.id', billDetail.customer[0].id)
      .groupBy('trackings.id')
      .orderBy('trackings.id');

    const listTrackingIdExist = trackingOfCustomer.map(item => item.id);
    trackingIds.forEach(item => {
      if (!listTrackingIdExist.includes(item)) {
        throw new HttpException(400, 'An invalid tracking exists');
      }
    });
    await Promise.all(
      trackingIds.map(async trId => {
        await TrackingsDeliveryBillLinks.query().insert({ delivery_bill_id: id, tracking_id: trId }).into('trackings_delivery_bill_links');
      }),
    );
    await DeliveryBill.query().findById(id).patch({ deliveryBillStatus: 'Phiếu mới tạo' });
    return await DeliveryBill.query().findById(id);
  };

  public deleteTrackingInBill = async (id: number, trackingId: number) => {
    const dvbTrackingDeletableState = ['Phiếu mới tạo', 'Sale duyệt', 'Kế toán duyệt', 'Yêu cầu xuất kho'];
    const dvb: any = await DeliveryBill.query()
      .where('id', id)
      .whereIn('deliveryBillStatus', dvbTrackingDeletableState)
      .withGraphFetched('tracking')
      .first();
    if (!dvb) {
      throw new HttpException(404, 'Cannot cancel : Delivery bill is not in tracking deletable state!');
    }
    const listTrackingIdDetail = dvb.tracking.map(item => item.id);

    if (!listTrackingIdDetail.includes(trackingId)) {
      throw new HttpException(400, 'Tracking id is invalid');
    } else {
      await TrackingsDeliveryBillLinks.query().delete().where('tracking_id', trackingId);
      await this.updateTrackingStatusById('Đã khai thác', trackingId);
      await DeliveryBill.query().findById(id).patch({ deliveryBillStatus: 'Phiếu mới tạo' });
    }

    return await DeliveryBill.query().findById(id);
  };

  public packTrackingInBill = async (id: number, trackingId: number, user) => {
    const dvb: any = await DeliveryBill.query().where('id', id).where('deliveryBillStatus', 'Yêu cầu xuất kho').withGraphFetched('tracking').first();
    if (!dvb) {
      throw new HttpException(404, 'Cannot pack : Delivery bill is not in State : Yêu cầu xuất kho!');
    }
    const listTrackingIdDetail = dvb.tracking.map(item => item.id);

    if (!listTrackingIdDetail.includes(trackingId)) {
      throw new HttpException(400, 'Tracking id is invalid');
    } else {
      if (await Tracking.query().where('id', trackingId).whereNull('vnPackedDate').first())
        await this.updateTrackingStatusById('Đã đóng hàng', trackingId, { vnPackedDate: new Date(), updatedAt: new Date(), vnPackedById: user.id });
      else await this.updateTrackingStatusById('Đã đóng hàng', trackingId, { updatedAt: new Date(), vnPackedById: user.id });
    }

    return await DeliveryBill.query().findById(id);
  };

  public logStatusTracking = async (trackingId: number, content: string) => {
    await TrackingStatusLogs.query()
      .insert({
        name: content,
        updatedTime: new Date(),
        trackingId: trackingId,
      })
      .into('tracking_status_logs');
  };

  public getDeliveryBillStatus = async (req, param) => {
    // Lấy tất cả các trạng thái từ đối tượng DELIVERY_BILL_STATUS_ORDER
    const allStatuses = Object.keys(DELIVERY_BILL_STATUS_ORDER);

    let queryBuilder: any = DeliveryBill.query()
      .select('deliveryBillStatus', 'dvb.id')
      .from('delivery_bills as dvb')
      .whereIn('deliveryBillStatus', allStatuses)
      .groupBy('dvb.id'); // Bao gồm cả cột dvb.id trong mệnh đề GROUP BY
    await getReqPerrmissionBusinessLogic(req, 'api:: GET /api/delivery_bills/');
    this.filterDeliveryBill(req, req.user, param, queryBuilder, true);
    queryBuilder = await queryBuilder;
    const frequency = {};
    queryBuilder.forEach(record => {
      const deliveryBillStatus = record.deliveryBillStatus;
      // Nếu giá trị chưa tồn tại trong đối tượng frequency, khởi tạo nó bằng 1, ngược lại tăng giá trị lên 1
      frequency[deliveryBillStatus] = (frequency[deliveryBillStatus] || 0) + 1;
    });
    queryBuilder = frequency;

    // Tạo một mảng chứa tất cả các trạng thái và số lượng, với số lượng là 0 cho những trạng thái không có trong kết quả truy vấn
    const summaryArray = allStatuses.map(status => ({
      name: status,
      total: frequency[status] || 0, // Nếu không có số lượng, gán là 0
    }));

    // Ánh xạ id vào danh sách và sắp xếp theo thứ tự id
    const summaryArrayWithId = summaryArray
      .map(item => ({
        ...item,
        id: DELIVERY_BILL_STATUS_ORDER[item.name],
      }))
      .sort((a, b) => a.id - b.id);

    return summaryArrayWithId;
  };

  private sendPushNotificationToUser = async (userId, billCode: string, newStatus: string) => {
    await this.fcmPushNotificationService.sendNotificationToGroupOfUser(
      userId,
      `Thông báo`,
      `Phiếu xuất kho ${billCode} có thay đổi với trạng thái mới: ${newStatus}`,
    );
  };

  public async exportExcel(req, bill_id, res) {
    try {
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Sheet 1');
      const bill: any = await this.findDeliveryBillById(req, req.user, bill_id);
      // Add headers
      worksheet.addRow(['MÃ PHIẾU', bill.code]);
      worksheet.addRow(['TÊN KHÁCH HÀNG', bill.name]);
      worksheet.addRow(['SỐ ĐT', bill.customerPhone]);
      worksheet.addRow(['EMAIL', bill.email]);
      worksheet.addRow(['ĐỊA CHỈ NHẬN', bill.customerAddress]);
      worksheet.addRow(['NOTE', bill.note || '']);
      worksheet.addRow([]);
      worksheet.addRow([]);
      worksheet.addRow([
        'STT',
        'Mã đơn hàng',
        'Mã tracking',
        'Sản phẩm',
        'Số lượng',
        'TLTT',
        'TLKT',
        'Giá cước VC',
        'Phí vận chuyển',
        'Phí khác',
        'Phụ thu',
        'Giảm giá',
        'Thành tiền',
        'Thời gian đóng hàng',
      ]);
      let i = 1;
      bill.trackings.forEach(tracking => {
        const trackingRow = [
          i++,
          tracking.orderId,
          tracking.code,
          tracking.productName,
          tracking.trackingAmount,
          Number(tracking.trackingCalculationWeight),
          Number(tracking.trackingMiningWeight),
          Number(tracking.trackingShippingCost),
          Number(tracking.trackingShippingFee),
          Number(tracking.trackingOtherFee),
          Number(tracking.trackingSurcharge),
          Number(tracking.trackingDiscountAmount),
          Number(tracking.trackingTotalMoney),
          new Date(tracking.packedDate).toLocaleString('en-US', { timeZone: 'Asia/Ho_Chi_Minh' }),
        ];
        worksheet.addRow(trackingRow);
        // Định dạng các ô tài khoản
        const accountColumns = [8, 9, 10, 11, 12, 13]; // Cột F (cột 8) đến cột M (cột 13)
        accountColumns.forEach(col => {
          const cell = worksheet.getCell(worksheet.rowCount, col);
          cell.numFmt = '#,##0.00'; // Định dạng số tiền với dấu phẩy phân tách hàng nghìn
        });
      });

      worksheet.addRow([]);
      worksheet.addRow(['Tổng số lượng tracking', bill.trackings.length]);
      worksheet.addRow(['Tổng tiền', bill.trackingTotalMoney]);
      const cell = worksheet.getCell(worksheet.rowCount, 2);
      cell.numFmt = '#,##0.00'; // Định dạng số tiền với dấu phẩy phân tách hàng nghìn
      worksheet.addRow(['Tổng trọng lượng khai thác', bill.totalTrackingMiningWeight]);
      worksheet.addRow(['Tổng trọng lượng tính toán', bill.totalTrackingCalculationWeight]);

      // Adjust column widths based on the length of the values
      worksheet.columns.forEach((column, colNumber) => {
        let maxLength = 0;
        column.eachCell({ includeEmpty: true }, cell => {
          const len = cell.value ? String(cell.value).length : 0;
          if (len > maxLength) {
            maxLength = len;
          }
          if (cell.type === ExcelJS.ValueType.Date) {
            // Định dạng ngày giờ theo định dạng tùy chỉnh
            cell.numFmt = 'dd/mm/yyyy hh:mm:ss';
          }
        });
        column.width = maxLength < 10 ? 10 : maxLength + 2; // Adjust as needed
      });
      // Set response headers
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=excel-export.xlsx');

      // Pipe the workbook to the response
      await workbook.xlsx.write(res);

      res.end();
    } catch (error) {
      console.error(error);
      res.status(500).send('Internal Server Error');
    }
  }

  private validateEmptyTrackingList(bill) {
    if (!bill.trackings?.length && !bill.tracking?.length) {
      throw new BadRequestException('Empty tracking list ! Please add trackings or cancel bill !');
    }
  }

  public async assignShipperToADeliveryBill(req, billId, deliveredById) {
    const bill: any = await this.findDeliveryBillById(req, req.user, billId);
    await this.deliveryBoxCommonService.assignShipperToBoxes(deliveredById, { ids: bill.vnDeliveryBoxes.map(box => box.id) });
  }
}

export default DeliveryBillsService;
