import { hash } from 'bcrypt';
import { HttpException } from '@exceptions/HttpException';
import { User } from '@interfaces/users.interface';
import { Users } from '@models/users.model';
import { generateRandomString, isEmpty } from '@utils/util';
import { Customer } from '@/models/customer.model.';
import { Role } from '@/models/role.model';
import { UpUsersRoleLinks } from '@/models/upUsersRoleLinks.model';
import { UpUsersBusinessPartnerLinks } from '@/models/upUsersBusinessPartnerLinks.model';
import { UpUsersWarehouseVnLinks } from '@/models/upUsersWarehouseVnLinks.model';

class UserService {
  public async findAllUser(params: any) {
    const { page = 0, pageSize = 10, email, username, fullname, phone, role, type, warehouseVn } = params;

    let pageIndex = 0;

    if (page) {
      pageIndex = page - 1;
    }

    const queryBuilder = Users.query().where('up_users.type', 'partner');

    if (email) {
      queryBuilder.whereILike('email', `%${email}%`);
    }

    if (username) {
      queryBuilder.whereILike('username', `%${username}%`);
    }

    if (phone) {
      queryBuilder.whereILike('phone', `%${phone}%`);
    }

    if (fullname) {
      queryBuilder.whereILike('fullname', `%${fullname}%`);
    }

    if (role || type) {
      queryBuilder
        .leftJoin('up_users_role_links as role_join', 'role_join.user_id', 'up_users.id')
        .leftJoin('up_roles as role', 'role_join.role_id', 'role.id');
      if (role) queryBuilder.where('role.id', role);
      if (type) queryBuilder.where('role.type', type);
    }

    if (warehouseVn) {
      queryBuilder
        .leftJoin('up_users_warehouse_vn_links', 'up_users_warehouse_vn_links.user_id', 'up_users.id')
        .leftJoin('warehouse_configs', 'up_users_warehouse_vn_links.warehouse_config_id', 'warehouse_configs.id')
        .where('warehouse_configs.id', warehouseVn);
    }

    const results = await queryBuilder
      .from('up_users')
      .where('up_users.blocked', false)
      .withGraphFetched('role')
      .withGraphFetched('warehouseVN')
      .modifyGraph('role', builder => builder.withGraphFetched('actions'))
      .orderBy('updatedAt', 'desc')
      .page(pageIndex, pageSize);

    return {
      paginations: {
        page: Number(pageIndex) + 1,
        pageSize: Number(pageSize),
        total: results.total,
        totalPage: Math.ceil(results.total / pageSize),
      },
      data: results.results.map(u => {
        delete u['password'];
        delete u['resetPasswordToken'];
        delete u['confirmationToken'];
        delete u['confirmPassword'];
        delete u['tmpPassword'];
        return {
          ...u,
          role: u.role[0]
            ? {
                ...u.role[0],
                actions: undefined, //  u.role[0].actions?.map(ac => ac.action)
              }
            : null,
          warehouseVN: u.warehouseVN ? u.warehouseVN[0] : null,
        };
      }),
    };
  }

  public async findUserById(userId: string): Promise<User> {
    const user: Users = await Users.query()
      .where('blocked', false)
      .where('type', 'partner')
      .withGraphFetched('role')
      .withGraphFetched('businessPartner')
      .withGraphFetched('warehouseVN')
      .modifyGraph('role', builder => builder.withGraphFetched('actions'))
      .findById(userId);
    if (!user) {
      throw new HttpException(404, "User doesn't exist");
    }

    delete user['password'];
    delete user['resetPasswordToken'];
    delete user['confirmationToken'];
    delete user['confirmPassword'];
    delete user['tmpPassword'];
    return {
      ...user,
      businessPartner: user.businessPartner[0],
      warehouseVN: user.warehouseVN[0],
      role: user.role[0]
        ? {
            ...user.role[0],
            actions: user.role[0].actions?.map(ac => ac.action),
          }
        : null,
    };
  }

  public async findUserByCustomerByEmail(email: string): Promise<Customer> {
    const findCustomer: Customer = await Customer.query().select().where('email', email).first();
    if (!findCustomer) throw new HttpException(404, "User doesn't exist");

    return findCustomer;
  }

  public async createEmployee(employeeData: any, user: any): Promise<User> {
    if (isEmpty(employeeData)) throw new HttpException(400, 'employee data is empty');

    await this.validationUniqueUser(employeeData.email);

    const hashedPassword = await hash(employeeData.password, 10);
    const data = {
      username: employeeData.username,
      email: employeeData.email.toLowerCase(),
      phone: employeeData.phone,
      password: hashedPassword,
      type: 'partner',
      fullname: employeeData.fullname,
      blocked: false,
      confirmed: true,
      confirm_password: employeeData.confirm_password,
      avatar_url: employeeData.avatar_url,
      created_at: new Date(),
      updated_at: new Date(),
    };
    const createEmployeeData: User = await Users.query()
      .insert({
        ...data,
      })
      .into('up_users');

    // link user_role
    await UpUsersRoleLinks.query().insert({
      user_id: createEmployeeData.id,
      role_id: employeeData.role,
    });

    // link warehouse
    if (employeeData.warehouse_id) {
      await UpUsersWarehouseVnLinks.query().insert({
        user_id: createEmployeeData.id,
        warehouse_config_id: employeeData.warehouse_id,
      });
    }

    // link business partner
    if (employeeData.partner) {
      await UpUsersBusinessPartnerLinks.query().insert({
        user_id: createEmployeeData.id,
        business_partner_id: employeeData.partner,
      });
    } else if (user.businessPartner) {
      await UpUsersBusinessPartnerLinks.query().insert({
        user_id: createEmployeeData.id,
        business_partner_id: user.businessPartner.id,
      });
    }

    return createEmployeeData;
  }

  public async updateEmployee(id: number, employeeData: any): Promise<User> {
    if (isEmpty(employeeData)) throw new HttpException(400, 'employee data is empty');
    const { phone, fullname, email, password, role_id, warehouse_id, avatar_url } = employeeData;

    const findEmployee: User = await Users.query()
      .where('type', 'partner')
      .where('confirmed', true)
      .where('blocked', false)
      .withGraphFetched('role')
      .withGraphFetched('warehouseVN')
      .findById(id);
    if (!findEmployee) throw new HttpException(409, "Employee doesn't exist or removed");

    const updateData: any = { updatedAt: new Date() };

    if (phone) {
      updateData.phone = phone;
    }

    if (fullname) {
      updateData.fullname = fullname;
    }

    if (password) {
      const hashedPassword = await hash(password, 10);
      updateData.password = hashedPassword;
    }

    if (email) {
      updateData.email = email;
    }

    if (avatar_url) {
      updateData.avatar_url = avatar_url;
    }

    await Users.query().patch(updateData).where('id', '=', id).into('up_users');

    // link user_role
    if (findEmployee.role.length === 0) {
      await UpUsersRoleLinks.query()
        .insert({
          role_id: role_id,
          user_id: id,
        })
        .into('up_users_role_links');
    } else {
      await UpUsersRoleLinks.query().update({ role_id: role_id }).where('user_id', id);
    }

    // link business_partner
    if (warehouse_id && findEmployee.warehouseVN.length > 0) {
      await UpUsersWarehouseVnLinks.query()
        .update({
          warehouse_config_id: warehouse_id,
        })
        .where('user_id', id);
    } else if (warehouse_id && findEmployee.warehouseVN.length === 0) {
      await UpUsersWarehouseVnLinks.query().insert({
        user_id: id,
        warehouse_config_id: warehouse_id,
      });
    } else if (!warehouse_id && findEmployee.warehouseVN.length > 0) {
      await UpUsersWarehouseVnLinks.query().delete().where('user_id', id);
    }

    return await Users.query().findById(id);
  }

  private async validationUniqueUser(email: string) {
    const emailUser: User = await Users.query().whereILike('email', email).first();
    if (emailUser) throw new HttpException(409, `This email ${email} already existed or removed`);
  }

  public async detail(id) {
    const user: Users = await Users.query()
      .withGraphFetched('role')
      .modifyGraph('role', builder => builder.withGraphFetched('actions'))
      .where('blocked', false)
      .findById(id);
    if (!user) {
      throw new HttpException(404, 'User is not found');
    }

    delete user['password'];
    delete user['resetPasswordToken'];
    delete user['confirmationToken'];
    delete user['confirmPassword'];
    delete user['tmpPassword'];
    return {
      ...user,
      role: user.role[0]
        ? {
            ...user.role[0],
            actions: user.role[0].actions?.map(ac => ac.action),
          }
        : null,
    };
  }

  public async suggestion(keyword: string, role_id: number) {
    const queryBuilder = Users.query().where('type', 'partner');

    const users = await queryBuilder
      .select('id', 'fullname', 'username')
      .whereILike('fullname', `%${keyword}%`)
      .orWhereILike('username', `%${keyword}%`)
      .orWhereILike('email', `%${keyword}%`)
      .orWhereILike('phone', `%${keyword}%`);
    return users;
  }

  public async updateCustomer(email: string, customerData: any): Promise<Customer> {
    if (isEmpty(customerData)) throw new HttpException(400, 'userData is empty');
    const { name, phone, gender, birthday, taxId } = customerData;
    const updateData: any = {};
    if (gender) {
      updateData.gender = gender;
    }

    if (birthday) {
      updateData.birthday = birthday;
    }

    if (taxId) {
      updateData.taxId = taxId;
    }

    await Customer.query().update(updateData).where('email', email).into('customers');

    const updateUserData: Customer = await Customer.query().select().where('email', email).first();
    return updateUserData;
  }

  public async getBusinessPartner(id: number): Promise<any> {
    return await Users.relatedQuery('businessPartner').for(id);
  }

  public async getRole(): Promise<any> {
    return await Role.query().whereILike('type', `nhan_vien%`).orWhereILike('type', 'quan_ly');
  }

  public async getPermission(): Promise<any> {
    const data: any = await Role.query().whereILike('type', `nhan_vien%`).orWhereILike('type', 'quan_ly').withGraphFetched('actions');

    return data.map(role => ({
      ...role,
      actions: role.actions?.[0]?.map(ac => ac.action) ?? [],
    }));
  }

  public async getCustomerBelongToEmployee(eId: string, params): Promise<any> {
    const { page = 0, pageSize = 10, email, username, fullname, phone } = params;

    let pageIndex = 0;

    if (page) {
      pageIndex = page - 1;
    }
    const data: any = await Users.query()
      .findById(eId)
      .withGraphFetched('saleOfCustomer')
      .modifyGraph('saleOfCustomer', builder => builder.withGraphFetched('user'))
      .page(pageIndex, pageSize);

    if (!data) {
      throw new HttpException(404, 'Not found customer');
    }

    const { results, total } = data;

    return {
      pagination: {
        page: Number(pageIndex) + 1,
        pageSize: Number(pageSize),
        total: total,
        totalPage: Math.ceil(results.total / pageSize),
      },
      data: results.saleOfCustomer.map(cus => {
        const userInfo = cus.user[0];
        delete cus.user;
        return {
          id: userInfo.id,
          username: userInfo.username,
          email: userInfo.email,
          customer: cus,
        };
      }),
    };
  }

  public async deleteUser(eId: string): Promise<any> {
    const findUser: User = await this.findUserById(eId);
    if (!findUser) throw new HttpException(409, "User doesn't exist");
    delete findUser['role'];
    await Users.query()
      .update({ email: findUser.email + 'DELETED' + generateRandomString(8), blocked: true })
      .where('id', eId)
      .into('up_users');
  }

  public async getAllEmployee(params: any) {
    const { search } = params;
    let queryBuilder;
    if (search === undefined) {
      queryBuilder = Users.query().where('type', 'partner');
    } else {
      queryBuilder = Users.query()
        .where('type', 'partner')
        .whereILike('fullname', `%${search}%`)
        .orWhereILike('username', `%${search}%`)
        .orWhereILike('phone', `%${search}%`)
        .orWhereILike('email', `%${search}%`);
    }

    const results = await queryBuilder
      .from('up_users')
      .withGraphFetched('role')
      .modifyGraph('role', builder => builder.withGraphFetched('actions'))
      .where('type', 'partner')
      .where('blocked', false)
      .withGraphFetched('customer');

    return {
      data: results.map(u => {
        delete u['password'];
        delete u['resetPasswordToken'];
        delete u['confirmationToken'];
        delete u['confirmPassword'];
        delete u['tmpPassword'];
        return {
          ...u,
          role: u.role[0]
            ? {
                ...u.role[0],
                actions: undefined,
              }
            : null,
        };
      }),
    };
  }

  public async getAllSale(params: any) {
    const { search, role_id } = params;

    let queryBuilder;
    if (search === undefined) {
      queryBuilder = Users.query().where('type', 'partner');
    } else {
      queryBuilder = Users.query()
        .where('type', 'partner')
        .whereILike('fullname', `%${search}%`)
        .orWhereILike('username', `%${search}%`)
        .orWhereILike('phone', `%${search}%`)
        .orWhereILike('email', `%${search}%`);
    }
    if (role_id) {
      queryBuilder.withGraphFetched('role').modifyGraph('role', builder => builder.withGraphFetched('actions').where('up_roles.id', Number(role_id)));
    } else {
      queryBuilder
        .withGraphFetched('role')
        .modifyGraph('role', builder =>
          builder.withGraphFetched('actions').andWhere('type', 'nhan_vien_kinh_doanh').orWhere('type', 'nhan_vien_cskh'),
        );
    }
    const results = await queryBuilder.from('up_users').where('type', 'partner').where('blocked', false).withGraphFetched('customer');

    const res = results.map(u => {
      delete u['password'];
      delete u['resetPasswordToken'];
      delete u['confirmationToken'];
      delete u['confirmPassword'];
      delete u['tmpPassword'];
      return {
        ...u,
        role: u.role[0]
          ? {
              ...u.role[0],
              actions: undefined,
            }
          : null,
      };
    });
    return {
      data: res.filter(u => u.role !== null),
    };
  }

  public async getUserLogged(user) {
    delete user.password;
    delete user.confirmPassword;
    delete user.provider;
    delete user.username;
    delete user.tmpPassword;
    delete user.role.actions;
    return user;
  }

  public async getAllExploit(params: any) {
    const { search } = params;
    let queryBuilder;
    if (search === undefined) {
      queryBuilder = Users.query().where('type', 'partner');
    } else {
      queryBuilder = Users.query()
        .where('type', 'partner')
        .whereILike('fullname', `%${search}%`)
        .orWhereILike('username', `%${search}%`)
        .orWhereILike('phone', `%${search}%`)
        .orWhereILike('email', `%${search}%`);
    }

    const results = await queryBuilder
      .from('up_users')
      .withGraphFetched('role')
      .modifyGraph('role', builder => builder.withGraphFetched('actions').where('type', 'nhan_vien_khai_thac'))
      .where('type', 'partner')
      .where('blocked', false)
      .withGraphFetched('customer');

    const res = results.map(u => {
      delete u['password'];
      delete u['resetPasswordToken'];
      delete u['confirmationToken'];
      delete u['confirmPassword'];
      delete u['tmpPassword'];
      return {
        ...u,
        role: u.role[0]
          ? {
              ...u.role[0],
              actions: undefined,
            }
          : null,
      };
    });
    return {
      data: res.filter(u => u.role !== null),
    };
  }
}

export default UserService;
