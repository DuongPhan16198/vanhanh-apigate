import { Box } from '@/models/box.model';
import { HttpException } from '@exceptions/HttpException';
import { isEmpty } from '@utils/util';
import axios from 'axios';
import qs from 'qs';
import { WAREHOUSE_API_URL, WAREHOUSE_API_TOKEN } from '@config';
import { Tracking } from '@/models/tracking.model';
import { TRACKING_STATUS } from '@/constant/constant';
import AwbService from './awb.service';
import { Awb } from '@/models/awb.model';
import { BoxWarehouseVnLinks } from '@/models/boxWarehouseVnLinks.model';
import { TrackingsWarehouseVnLinksLink } from '@/models/trackingsWarehouseVnLinksLink.model';
import FcmPushNotificationService from './fcmPushNotification.service';
import { TrackingStatusLogs } from '@/models/trackingStatusLog.model';

class BoxService {
  private awbService = new AwbService();
  private readonly fcmPushNotificationService = new FcmPushNotificationService();

  static getInstant(): BoxService {
    return new BoxService();
  }

  public async findBox(user, param) {
    const queryBuilder = Box.query().from('boxes as box');
    const { page = 0, pageSize = 10, boxIds, exploitStatus } = param;
    let status = null;
    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }
    if (boxIds && boxIds.length) {
      queryBuilder.findByIds(boxIds.split(','));
    }
    if (exploitStatus !== undefined) {
      switch (exploitStatus) {
        case '0':
          break;
        case '1':
          status = TRACKING_STATUS[0];
          queryBuilder.whereIn('tr.status', ['Chờ nhập kho US', 'Chưa nhập kho']);
          break;
        case '2':
          status = TRACKING_STATUS[1];
          queryBuilder.where('tr.status', 'Đã nhập kho');
          break;
        case '3':
          status = TRACKING_STATUS[2];
          queryBuilder.where('tr.status', 'Đang đóng thùng');
          queryBuilder.orWhere('tr.status', 'Đã đóng thùng');
          queryBuilder.orWhere('tr.status', 'Đang xử lý awb');
          queryBuilder.orWhere('tr.status', 'Đang vận chuyển về VN');
          queryBuilder.orWhere('tr.status', 'Hoàn thành');
          queryBuilder.orWhere('tr.exploit_status', 'Đang vận chuyển về VN');
          break;
        case '4':
          status = TRACKING_STATUS[3];
          queryBuilder.where('tr.exploit_status', 'Đã vận chuyển về vn');
          break;
        case '5':
          status = TRACKING_STATUS[4];
          queryBuilder.where('tr.exploit_status', 'Đã khai thác');
          break;
        case '6':
          status = TRACKING_STATUS[5];
          queryBuilder.where('tr.exploit_status', 'Hoàn thành');
          break;
        case '7':
          status = TRACKING_STATUS[6];
          queryBuilder.where('tr.status', 'Hủy');
          queryBuilder.orWhere('tr.exploit_status', 'Đã hủy bỏ');
          break;
        default:
          status = 'Lỗi';
          break;
      }
    }

    const listTracking = await queryBuilder
      .withGraphFetched('warehouseVN')
      .withGraphFetched('trackingBoxes as trackings')
      .modifyGraph('trackings', builder =>
        builder
          .withGraphFetched('boxTrackingType as trackingType')
          .withGraphFetched('warehouseVn')
          .withGraphFetched('boxBusinessPartner as businessPartner')
          .withGraphFetched('boxCustomer as customer')
          .modifyGraph('customer', builder => builder.withGraphFetched('boxStag as stag')),
      )
      .page(pageIndex, pageSize);
    if (!listTracking) throw new HttpException(404, "Boxes doesn't exist");
    const { results, total } = listTracking;

    return {
      meta: {
        page: Number(pageIndex) + 1,
        pageSize,
        total,
        totalPage: Math.ceil(total / pageSize),
      },
      data: results,
    };
  }

  public async updateBox(user, id, param) {
    if (isEmpty(param) || isEmpty(id)) throw new HttpException(400, 'BoxData is empty');
    const IGNORE_FIELDS = [
      'weight',
      'completedAt',
      'exploitStatus',
      'exploitStartDate',
      'exploitEndDate',
      'warehouse_vn',
      'boxRate',
      'uid',
      'isSynced',
      'id',
    ];
    const data = { ...param } as any;

    Object.keys(data).map(key => {
      if (data[key] == null || IGNORE_FIELDS.includes(key)) {
        delete data[key];
      }
    });
    await Box.query().update(data).where('id', id).into('boxes');
  }

  public async findNewBox(partnerUID, params) {
    const { keywords, page = 1, pageSize = 10 } = params;
    if (isEmpty(keywords)) throw new HttpException(400, 'keywords is empty');
    const code = keywords.split(',') || [keywords];

    const queryCode = code.map(c => ({
      code: {
        $contains: c.trim(),
      },
    }));

    const apiUrl: string = WAREHOUSE_API_URL || '';
    const apiToken: string = WAREHOUSE_API_TOKEN || '';

    const query = {
      filters: {
        $or: queryCode,
        business_partners: {
          uid: {
            $eq: partnerUID,
          },
        },
      },
      pagination: {
        pageSize,
        page,
      },
    };
    const { data } = await axios.get(apiUrl + '/api/boxes?' + qs.stringify(query), {
      headers: {
        Authorization: `Bearer ${apiToken}`,
      },
    });
    return {
      data: data.data,
      pagination: data.meta.pagination,
    };
  }

  public async findTrackings(user, boxId, params) {
    const { exploitStatus, code } = params;

    let status = null;
    const boxInfo: any = await Box.query().findById(boxId).withGraphFetched('warehouseVN');
    const queryBuilder = Tracking.query().from('trackings as tr');
    if (code) {
      queryBuilder.whereLike('tr.code', `%${code}%`).orWhereLike('tr.code', `%${code?.slice(-8)}%`);
    } else if (exploitStatus !== undefined) {
      switch (exploitStatus) {
        case '0':
          break;
        case '1':
          status = TRACKING_STATUS[0];
          queryBuilder.whereIn('tr.status', ['Chờ nhập kho US', 'Chưa nhập kho']);
          break;
        case '2':
          status = TRACKING_STATUS[1];
          queryBuilder.whereIn('tr.status', ['Đã nhập kho', 'Đã tiếp nhận']);
          break;
        case '3':
          status = TRACKING_STATUS[2];
          queryBuilder
            .whereIn('tr.status', ['Đang đóng thùng', 'Đã đóng thùng', 'Đang xử lý awb', 'Đang vận chuyển về VN', 'Hoàn thành'])
            .andWhere('tr.exploit_status', 'Đang vận chuyển về vn');
          break;
        case '4':
          status = TRACKING_STATUS[3];
          queryBuilder.where('tr.exploit_status', 'Đã vận chuyển về vn');
          break;
        case '5':
          status = TRACKING_STATUS[4];
          queryBuilder.where('tr.exploit_status', 'Đã khai thác');
          break;
        case '6':
          status = TRACKING_STATUS[5];
          queryBuilder.where('tr.exploit_status', 'Đã đóng hàng');
          break;
        case '7':
          status = TRACKING_STATUS[6];
          queryBuilder.where('tr.exploit_status', 'Đang giao hàng');
          break;
        case '8':
          status = TRACKING_STATUS[7];
          queryBuilder.where('tr.exploit_status', 'Hoàn thành');
          break;
        case '9':
          status = TRACKING_STATUS[8];
          queryBuilder.where('tr.status', 'Hủy');
          queryBuilder.orWhere('tr.exploit_status', 'Đã hủy bỏ');
          break;
        default:
          status = 'Lỗi';
          break;
      }
    }
    if (exploitStatus !== '9') {
      queryBuilder.whereNot('tr.is_deleted', true);
    }
    if (user.businessPartner) {
      queryBuilder.where('businessPartner.id', user.businessPartner.id);
    }

    const results = await queryBuilder
      .joinRelated('box')
      .where('box.id', boxId)
      .joinRelated('businessPartner')
      .withGraphFetched('customer')
      .modifyGraph('customer', builder => builder.withGraphFetched('boxStag as tags').withGraphFetched('sale'))
      .withGraphFetched('businessPartner')
      .withGraphFetched('warehouse')
      .withGraphFetched('warehouseVn')
      .withGraphFetched('exploitedBy')
      .withGraphFetched('deliveryBill')
      .withGraphFetched('trackingType')
      .withGraphFetched('sale')
      .orderBy('updatedAt', 'desc')
      .whereNot('exploitStatus', 'Đã hủy bỏ');

    const exploitedTrackingCount = await Tracking.query()
      .joinRelated('box')
      .where('box.id', boxId)
      .joinRelated('businessPartner')
      .whereIn('trackings.exploitStatus', ['Đã khai thác', 'Đã huỷ bỏ', 'Hoàn thành'])
      .count();

    const resultFiter = new Map();
    const filteredArray = results.filter(obj => {
      if (!resultFiter.has(obj.code)) {
        resultFiter.set(obj.code, true);
        return true;
      }
      return false;
    });

    return {
      data: {
        boxInfo: {
          ...boxInfo,
          warehouseVN: boxInfo.warehouseVN[0] || null,
        },
        exploitedTrackingCount: exploitedTrackingCount || 0,
        trackings: filteredArray.map(tr => {
          if (status === null) {
            if (tr.status === 'Chờ nhà cung cấp' || tr.status === 'Đã tiếp nhận' || tr.status === 'Chưa nhập kho') {
              status = 'Chờ nhập kho US';
            } else if (tr.status === 'Đã nhập kho') {
              status = 'Đã nhập kho US';
            } else if (
              (tr.status === 'Đang đóng thùng' ||
                tr.status === 'Đã đóng thùng' ||
                tr.status === 'Đang xử lý awb' ||
                tr.status === 'Đang vận chuyển về VN' ||
                tr.status === 'Hoàn thành') &&
              tr.exploitStatus === 'Đang vận chuyển về vn'
            ) {
              status = 'Đang vận chuyển về VN';
            } else if (tr.exploitStatus === 'Đã vận chuyển về vn') {
              status = 'Đã nhập kho VN';
            } else if (tr.exploitStatus === 'Đã khai thác') {
              status = 'Đã khai thác';
            } else if (tr.exploitStatus === 'Đã đóng hàng') {
              status = 'Đã đóng hàng';
            } else if (tr.exploitStatus === 'Đang giao hàng') {
              status = 'Đang giao hàng';
            } else if (tr.exploitStatus === 'Hoàn thành') {
              status = 'Hoàn thành';
            } else if (tr.exploitStatus === 'Đã hủy bỏ' || tr.status === 'Hủy') {
              status = 'Đã hủy bỏ';
            } else {
              status = 'Lỗi';
            }
          }
          delete tr.status;
          if (tr.customer[0]) {
            tr.sale = tr.customer[0]?.sale ? tr.customer[0]?.sale : null;
            delete tr.customer[0]?.sale;
          }
          return {
            ...tr,
            status,
            businessPartner: tr.businessPartner[0] || null,
            warehouse: tr.warehouse[0] || null,
            warehouseVn: tr.warehouseVn[0] || null,
            exploitedBy: tr.exploitedBy[0] || null,
            deliveryBill: tr.deliveryBill[0] || null,
            customer: tr.customer[0] || null,
            trackingType: tr.trackingType[0] || null,
            sale: tr.sale[0]
              ? {
                  id: tr.sale[0].id,
                  username: tr.sale[0].username,
                  fullname: tr.sale[0].fullname,
                }
              : null,
          };
        }),
      },
    };
  }

  public async importTrackings(boxId, warehouseId, passWords) {
    if (!passWords || passWords !== 'dpcargo@123456') {
      throw new HttpException(404, 'Password is not correct');
    }

    const box = await Box.query().findById(boxId);
    const awb = await Awb.query()
      .select('awbs.*')
      .join('boxes_awb_links', 'awbs.id', 'boxes_awb_links.awb_id')
      .where('boxes_awb_links.box_id', boxId);
    if (box.exploitStatus === 'Đã khai thác') {
      throw new HttpException(404, 'Boxes was import warehouse');
    }
    const trackings = await Tracking.query()
      .from('trackings as tr')
      .leftJoin('trackings_box_links', 'tr.id', 'trackings_box_links.tracking_id')
      .withGraphFetched('customer')
      .modifyGraph('customer', builder => builder.withGraphFetched('user'))
      .where('trackings_box_links.box_id', boxId);
    const trackingCustomerUserId = trackings
      .map(tr => {
        if (tr.customer && tr.customer[0] && tr.customer[0].user && tr.customer[0].user[0] && tr.customer[0]?.isSubcribeToFcmNotification)
          return tr.customer[0].user[0]?.id;
      })
      .filter(Boolean);
    const freqDict = {};
    trackingCustomerUserId.forEach(element => {
      freqDict[element] = (freqDict[element] || 0) + 1;
    });
    const resultArray = Object.keys(freqDict).map(key => ({ userId: parseInt(key), count: freqDict[key] }));
    await Promise.all(resultArray.map(async element => await this.sendPushNotificationToUser(element.userId, element.count)));
    await Promise.all(
      trackings.map(async tr => {
        if (tr.exploitStatus === 'Đang vận chuyển về vn') {
          const trackingWarehouseLink = await TrackingsWarehouseVnLinksLink.query().where('tracking_id', tr.id).first();
          if (!trackingWarehouseLink) {
            await TrackingsWarehouseVnLinksLink.query()
              .insert({ tracking_id: tr.id, warehouse_config_id: warehouseId })
              .into('trackings_warehouse_vn_links');
          } else {
            await TrackingsWarehouseVnLinksLink.query().patch({ warehouse_config_id: warehouseId }).where('tracking_id', tr.id);
          }
          await Tracking.query()
            .patch({ exploitStatus: 'Đã vận chuyển về vn', status: 'Hoàn thành', vnImportDate: new Date() })
            .where('id', tr.id)
            .into('trackings');
          await TrackingStatusLogs.query()
            .insert({
              name: 'Đơn hàng đã được nhập kho tại Việt Nam',
              updatedTime: new Date(),
              trackingId: tr.id,
            })
            .into('tracking_status_logs');
        }
      }),
    );

    //update box
    const boxUpdate = await Box.query().patch({ exploitStatus: 'Đã vận chuyển về vn', status: 'Hoàn thành' }).where('id', boxId).into('boxes');

    //update awb
    let check = 0;
    const listBoxInAwb = await Awb.query().findById(awb[0].id).withGraphFetched('box');
    listBoxInAwb.box.forEach(item => {
      if (item.exploitStatus === 'Đang vận chuyển về vn') {
        check++;
      }
    });
    if (check === 0) {
      await Awb.query().patch({ exploitStatus: 'Đã vận chuyển về vn', status: 'Hoàn thành' }).where('id', awb[0].id);
    }

    // warehouse link
    const boxLinkWarehouse = await BoxWarehouseVnLinks.query().where('boxId', boxId).first();
    if (boxLinkWarehouse) {
      await BoxWarehouseVnLinks.query().patch({ warehouse_config_id: warehouseId }).where('box_id', boxId);
    } else {
      await BoxWarehouseVnLinks.query()
        .insert({
          box_id: boxId,
          warehouse_config_id: warehouseId,
        })
        .into('boxes_warehouse_vn_links');
    }

    return boxUpdate;
  }
  private sendPushNotificationToUser = async (userId, billCode: string) => {
    await this.fcmPushNotificationService.sendNotificationToGroupOfUser(
      [userId],
      `Thông báo`,
      `Bạn có ${billCode} trackings mới đã được vận chuyển về Việt Nam`,
    );
  };
}

export default BoxService;
