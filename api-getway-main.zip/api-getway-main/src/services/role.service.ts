import { UpRole } from '@/models/upRole.model';
import { HttpException } from '@exceptions/HttpException';
import BadRequestException from '@/exceptions/BadRequestException';
import { Permission } from '@/models/permission.model';
import { PermissionsRoleLinks } from '@/models/permissionRoleLinks.model';
import { Users } from '@/models/users.model';
import { toSlug } from '@/utils/util';

class RoleService {
  static getInstant(): RoleService {
    return new RoleService();
  }

  public async findRoles(user, param) {
    const targetUser: any = await Users.query().findById(user.id).withGraphFetched('role');
    const permissionTypes = targetUser.role.map(c => c.type);
    const permissionType = permissionTypes && permissionTypes.length ? permissionTypes[0] : '';
    const { type, account, phone, isAdmin } = param;

    let queryBuilder;
    if (isAdmin) {
      queryBuilder = UpRole.query().from('up_roles as role').where('role.is_delete', false);
    } else {
      queryBuilder = UpRole.query().from('up_roles as role').where('role.is_delete', false).orderBy('createdAt', 'desc');
    }

    if (type) {
      queryBuilder.whereLike('role.type', `%${type}%`);
    }

    const listRoles = await queryBuilder;
    if (!listRoles) throw new HttpException(404, "Role doesn't exist");

    return listRoles;
  }

  public async roleDetail(id) {
    const role = await UpRole.query().withGraphFetched('actions').findById(id);
    if (role.isDelete) {
      throw new HttpException(404, "Role doesn't exist");
    }
    return role;
  }

  public async create(body) {
    const { name, description, actions, type } = body;
    if (!name) {
      throw new BadRequestException('Name is required');
    }
    if (actions && !(actions instanceof Array)) {
      throw new BadRequestException('actions must be an array');
    }
    const isExist = await UpRole.query().where('name', name).first();
    if (isExist) {
      throw new BadRequestException(`Role ${name} is exist`);
    }
    const insertData: any = {
      name,
    };

    if (description) {
      insertData.description = description;
    }

    if (type) {
      insertData.type = type;
    } else {
      insertData.type = toSlug(name);
    }

    insertData.createdAt = new Date();
    insertData.updatedAt = new Date();

    const role = await UpRole.query().insert(insertData).into('up_roles');

    if (actions) {
      for (const actionObject of actions) {
        const ac = await Permission.query().findById(actionObject.id);
        if (ac) {
          await PermissionsRoleLinks.query().insert({
            permission_id: ac.id,
            role_id: role.id,
            permission_business_logic_id: actionObject.permission_business_logic_id,
          });
        }
      }
    }

    const newRole: any = await UpRole.query().findById(role.id);
    return newRole;
  }

  public async update(roleId, body) {
    const roleData: any = {};
    const { name, description, actions, type } = body;
    if (name) {
      roleData.name = name;
    }
    if (description) {
      roleData.description = description;
    }
    if (type) {
      roleData.type = type;
    } else roleData.type = toSlug(name);
    await UpRole.query().patch(roleData).where('id', roleId);

    if (actions) {
      await PermissionsRoleLinks.query().delete().where('role_id', roleId);
      actions.forEach(async actionObject => {
        await PermissionsRoleLinks.query().insert({
          permission_id: actionObject.id,
          role_id: roleId,
          permission_business_logic_id: actionObject.permission_business_logic_id,
        });
      });
    }

    const updateRole: any = await UpRole.query().withGraphFetched('actions').where('id', roleId).first();
    updateRole.actions = updateRole.actions.map(ac => ac.action);

    return updateRole;
  }

  public async delete(roleId) {
    const role = await UpRole.query().findById(roleId);
    if (role.isDelete) {
      throw new HttpException(404, 'Role has been deleted');
    }
    await UpRole.query()
      .patch({
        isDelete: true,
      })
      .findById(roleId);
    return await UpRole.query().findById(roleId);
  }
}

export default RoleService;
