// import { DeliveryBill } from '@/models/deliveryBill.model';
import { HttpException } from '@exceptions/HttpException';
// import { Users } from '@/models/users.model';
// import { Customer } from '@/models/customer.model.';
// import { BusinessPartner } from '@/models/businessPartner.model';
import { Tracking } from '@/models/tracking.model';
import { TRACKING_STATUS, TRACKING_UPDATABLE_STATUS } from '@/constant/constant';
import { TrackingType } from '@/models/trackingType.model';
import { TrackingsTrackingTypeLinks } from '@/models/trackingsTrackingTypeLinks.model';
import { TrackingsWarehouseVnLinksLink } from '@/models/trackingsWarehouseVnLinksLink.model';
import TrackingService from './trackings.service';
import { TrackingCustomerLinks } from '@/models/trackingCustomerLinks.model';
import { generateNextOrderId, getChangedFields } from '@/utils/util';
import { Customer } from '@/models/customer.model.';
import { Config } from '@/models/config.model';
import { TrackingBusinessPartnerLink } from '@/models/trackingBusinessPartnerLink.model';
import { TrackingsWarehouseLinksLink } from '@/models/trackingsWarehouseLinksLink.model';
import CustomerService from './customer.service';
import { TrackingLogs } from '@/models/trackingLogs.model';
import { Box } from '@/models/box.model';
import { Awb } from '@/models/awb.model';
import { RequestWithUser } from '@/interfaces/auth.interface';
import Objection from 'objection';
import getReqPerrmissionBusinessLogic from '@/utils/getReqPerrmissionBusinessLogic';
import BadRequestException from '@/exceptions/BadRequestException';
import { getStatusTrackingReal } from '@/utils/getStatusTracking';
import { getTimelineOfATrackingFromWh, sendCreateTrackingToWh } from '@/utils/requestsToWarehouseApi';
import { TrackingsDeliveryBillLinks } from '@/models/trackingsDeliveryBillLinks.model';
import FcmPushNotificationService from './fcmPushNotification.service';
import { CustomerSaleLinks } from '@/models/customerSaleLinks.model';
import { TrackingSaleLinks } from '@/models/trackingSaleLinks.model';
// import { TrackingsDeliveryBillLinks } from '@/models/trackingsDeliveryBillLinks.model';

class OrdersService {
  private readonly TrackingService = new TrackingService();
  private readonly fcmPushNotificationService = new FcmPushNotificationService();
  static getInstant(): OrdersService {
    return new OrdersService();
  }

  private async trackingAdditionalFilterByPermissionBusinessLogic(
    req: RequestWithUser,
    queryBuilder: Objection.QueryBuilder<Tracking, Tracking[]>,
    user,
    customer,
  ) {
    switch (req.permission_business_logic) {
      case 1:
        break;
      case 2:
        if (customer)
          queryBuilder
            .innerJoin('customers_sale_links', 'customers_sale_links.customer_id', '=', 'customers.id')
            .where('customers_sale_links.user_id', user.id);
        else
          queryBuilder
            .innerJoin('trackings_customer_links', 'tr.id', '=', 'trackings_customer_links.tracking_id')
            .innerJoin('customers', 'trackings_customer_links.customer_id', '=', 'customers.id')
            .innerJoin('customers_sale_links', 'customers_sale_links.customer_id', '=', 'customers.id')
            .where('customers_sale_links.user_id', user.id);
        break;
      case 3:
        queryBuilder
          .innerJoin('trackings_warehouse_vn_links', 'tr.id', '=', 'trackings_warehouse_vn_links.tracking_id')
          .where('trackings_warehouse_vn_links.warehouse_config_id', user.warehouseVN[0].id);
        break;
      case 4:
        if (customer)
          queryBuilder
            .innerJoin('customers_service_staff_links', 'customers_service_staff_links.customer_id', '=', 'customers.id')
            .where('customers_service_staff_links.user_id', user.id);
        else
          queryBuilder
            .innerJoin('trackings_customer_links', 'tr.id', '=', 'trackings_customer_links.tracking_id')
            .innerJoin('customers', 'trackings_customer_links.customer_id', '=', 'customers.id')
            .innerJoin('customers_service_staff_links', 'customers_service_staff_links.customer_id', '=', 'customers.id')
            .where('customers_service_staff_links.user_id', user.id);
        break;
      case 5:
        queryBuilder
          .innerJoin('trackings_customer_links', 'tr.id', '=', 'trackings_customer_links.tracking_id')
          .where('trackings_customer_links.customer_id', user.customer.id);
        break;
      default:
        break;
    }
  }

  public async findAll(req: RequestWithUser, user, param) {
    const queryBuilder = Tracking.query().from('trackings as tr');
    const { page, pageSize = 10, exploitStatus, fromDate, toDate, filterDateBy, code, trackingCode, exploitedBy, customer, warehouse_id } = param;

    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }

    if (code) {
      queryBuilder.whereILike('tr.order_id', `%${code}%`);
    }

    if (trackingCode) {
      queryBuilder.whereILike('tr.code', `%${trackingCode}%`);
    }

    if (warehouse_id && (!req.permission_business_logic || req.permission_business_logic == 1)) {
      queryBuilder
        .innerJoin('trackings_warehouse_vn_links', 'tr.id', '=', 'trackings_warehouse_vn_links.tracking_id')
        .where('trackings_warehouse_vn_links.warehouse_config_id', warehouse_id);
    }

    if (fromDate && toDate) {
      queryBuilder.where(filterDateBy, '>=', new Date(fromDate)).where(filterDateBy, '<=', new Date(toDate)).orderBy('created_at', 'desc');
    } else {
      queryBuilder.orderBy('created_at', 'desc');
    }

    if (exploitStatus !== undefined && exploitStatus !== null && customer) {
      queryBuilder
        .innerJoin('trackings_customer_links', 'tr.id', '=', 'trackings_customer_links.tracking_id')
        .innerJoin('customers', 'trackings_customer_links.customer_id', '=', 'customers.id')
        .where('trackings_customer_links.customer_id', customer);
      switch (exploitStatus) {
        case '0':
          queryBuilder.whereILike('tr.status', '%%').where('trackings_customer_links.customer_id', customer);
          break;
        case '1':
          queryBuilder
            .whereIn('tr.status', ['Chờ nhập kho US', 'Đã tiếp nhận', 'Chưa nhập kho'])
            .where('trackings_customer_links.customer_id', customer);
          break;
        case '2':
          queryBuilder.where('tr.status', 'Đã nhập kho').where('trackings_customer_links.customer_id', customer);
          break;
        case '3':
          queryBuilder
            .whereIn('tr.status', ['Đang đóng thùng', 'Đã đóng thùng', 'Đang xử lý awb', 'Đang vận chuyển về VN', 'Hoàn thành'])
            .andWhere('tr.exploit_status', 'Đang vận chuyển về vn')
            .andWhere('trackings_customer_links.customer_id', customer);
          break;
        case '4':
          queryBuilder.where('tr.exploit_status', 'Đã vận chuyển về vn').where('trackings_customer_links.customer_id', customer);
          break;
        case '5':
          queryBuilder.where('tr.exploit_status', 'Đã khai thác').where('trackings_customer_links.customer_id', customer);
          break;
        case '6':
          queryBuilder.where('tr.exploit_status', 'Đã đóng hàng').where('trackings_customer_links.customer_id', customer);
          break;
        case '7':
          queryBuilder.where('tr.exploit_status', 'Đang giao hàng').where('trackings_customer_links.customer_id', customer);
          break;
        case '8':
          queryBuilder.where('tr.exploit_status', 'Hoàn thành').where('trackings_customer_links.customer_id', customer);
          break;
        case '9':
          queryBuilder.where('tr.is_deleted', true).where('trackings_customer_links.customer_id', customer);
          break;
        default:
          break;
      }
    } else if (exploitStatus !== undefined && exploitStatus !== null && !customer) {
      switch (exploitStatus) {
        case '0':
          queryBuilder.whereILike('tr.status', '%%');
          break;
        case '1':
          queryBuilder.whereIn('tr.status', ['Chờ nhập kho US', 'Đã tiếp nhận', 'Chưa nhập kho']);
          break;
        case '2':
          queryBuilder.where('tr.status', 'Đã nhập kho');
          break;
        case '3':
          queryBuilder
            .whereIn('tr.status', ['Đang đóng thùng', 'Đã đóng thùng', 'Đang xử lý awb', 'Đang vận chuyển về VN', 'Hoàn thành'])
            .andWhere('tr.exploit_status', 'Đang vận chuyển về vn');
          break;
        case '4':
          queryBuilder.where('tr.exploit_status', 'Đã vận chuyển về vn');
          break;
        case '5':
          queryBuilder.where('tr.exploit_status', 'Đã khai thác');
          break;
        case '6':
          queryBuilder.where('tr.exploit_status', 'Đã đóng hàng');
          break;
        case '7':
          queryBuilder.where('tr.exploit_status', 'Đang giao hàng');
          break;
        case '8':
          queryBuilder.where('tr.exploit_status', 'Hoàn thành');
          break;
        case '9':
          queryBuilder.where('tr.is_deleted', true);
          break;
        default:
          break;
      }
    } else if (customer) {
      queryBuilder
        .innerJoin('trackings_customer_links', 'tr.id', '=', 'trackings_customer_links.tracking_id')
        .innerJoin('customers', 'trackings_customer_links.customer_id', '=', 'customers.id')
        .where('trackings_customer_links.customer_id', customer);
    }

    if (exploitedBy) {
      queryBuilder.joinRelated('exploitedBy');
      queryBuilder.where('exploitedBy.id', exploitedBy);
    }

    if (user.businessPartner) {
      queryBuilder.where('businessPartner.id', user.businessPartner.id);
    }

    if (req.permission_business_logic) {
      this.trackingAdditionalFilterByPermissionBusinessLogic(req, queryBuilder, user, customer);
    }

    if (exploitStatus !== '9') {
      queryBuilder.whereNot('tr.is_deleted', true);
    }
    const listOrder = await queryBuilder
      .withGraphFetched('trackingType')
      .withGraphFetched('awb')
      .withGraphFetched('box')
      .withGraphFetched('businessPartner')
      .withGraphFetched('warehouse')
      .withGraphFetched('warehouseVn')
      .withGraphFetched('exploitedBy')
      .withGraphFetched('deliveryBill')
      .withGraphFetched('customer')
      .withGraphFetched('vnPackedBy')
      .modifyGraph('customer', builder => builder.withGraphFetched('boxStag as tags').withGraphFetched('generalConfigs as shippingCost'))
      .leftJoinRelated('businessPartner')
      .whereNotNull('tr.order_id')
      .distinct('tr.*')
      .page(pageIndex, pageSize);

    let { results, total } = listOrder;
    if (!results) throw new HttpException(404, "Orders list doesn't exist");

    results = results.map(tr => {
      tr.status = getStatusTrackingReal(tr);

      return {
        ...tr,
        box: tr.box[0] || null,
        awb: tr.awb[0] || null,
        businessPartner: tr.businessPartner[0] || null,
        warehouse: tr.warehouse[0] || null,
        warehouseVn: tr.warehouseVn[0] || null,
        exploitedBy: tr.exploitedBy[0] || null,
        deliveryBill: tr.deliveryBill[0] || null,
        customer: tr.customer[0] || null,
        trackingType: tr.trackingType[0] || null,
      };
    }) as any;

    return {
      meta: {
        page: Number(pageIndex) + 1,
        pageSize: Number(pageSize),
        total: Number(total),
        totalPage: Math.ceil(total / pageSize),
      },
      data: results,
    };
  }

  public async findById(req, user, id, isGettingBacklogs: boolean, isGettingStatusLog: string) {
    const queryBuilder = Tracking.query()
      .from('trackings as tr')
      .withGraphFetched('trackingType')
      .withGraphFetched('awb')
      .withGraphFetched('box')
      .withGraphFetched('businessPartner')
      .withGraphFetched('warehouse')
      .withGraphFetched('warehouseVn')
      .withGraphFetched('exploitedBy')
      .withGraphFetched('deliveryBill')
      .withGraphFetched('customer')
      .withGraphFetched('sale')
      .withGraphFetched('exploitedBy')
      .withGraphFetched('vnPackedBy')
      .modifyGraph('customer', builder =>
        builder.withGraphFetched('boxStag as tags').withGraphFetched('sale').withGraphFetched('customersServiceStaff').withGraphFetched('user'),
      )
      .whereNotNull('tr.order_id')
      .where('tr.id', id);

    if (req) {
      await getReqPerrmissionBusinessLogic(req, 'api:: GET /api/orders/');
      if (req.permission_business_logic) this.trackingAdditionalFilterByPermissionBusinessLogic(req, queryBuilder, user, null);
    }
    let tr;
    // get backlog
    let timelineFromWh = null;
    if (isGettingStatusLog === 'true') {
      queryBuilder.withGraphFetched('statusLogs');
      tr = await queryBuilder.first();
      timelineFromWh = tr.whTrackingId ? await getTimelineOfATrackingFromWh(tr.whTrackingId) : null;
      tr.statusLogs = timelineFromWh ? timelineFromWh.concat(tr.statusLogs) : tr.statusLogs;
    } else {
      tr = await queryBuilder.withGraphFetched('statusLogs').first();
    }
    // get statusLogs
    tr.statusLogs = tr.statusLogs[0] ? tr.statusLogs : null;

    if (!tr) throw new HttpException(404, "Orders list doesn't exist");
    let backlogs = null;
    if (isGettingBacklogs)
      backlogs = await TrackingLogs.query()
        .select('id', 'actionTime', 'actionType', 'trackingCode', 'changedField', 'trackingId', 'createdAt', 'createdById')
        .where('tracking_id', tr.id)
        .whereNotIn('actionType', ['entry.createOrder', 'entry.createTracking'])
        .withGraphFetched('createdBy')
        .orderBy('action_time', 'asc');
    let status;
    if (tr.status === 'Chờ nhà cung cấp' || tr.status === 'Đã tiếp nhận' || tr.status === 'Chưa nhập kho') {
      status = 'Chờ nhập kho US';
    } else if (tr.status === 'Đã nhập kho') {
      status = 'Đã nhập kho US';
    } else if (
      (tr.status === 'Đang đóng thùng' ||
        tr.status === 'Đã đóng thùng' ||
        tr.status === 'Đang xử lý awb' ||
        tr.status === 'Đang vận chuyển về VN' ||
        tr.status === 'Hoàn thành') &&
      tr.exploitStatus === 'Đang vận chuyển về vn'
    ) {
      status = 'Đang vận chuyển về VN';
    } else if (tr.exploitStatus === 'Đã vận chuyển về vn') {
      status = 'Đã nhập kho VN';
    } else if (tr.exploitStatus === 'Đã khai thác') {
      status = 'Đã khai thác';
    } else if (tr.exploitStatus === 'Đã đóng hàng') {
      status = 'Đã đóng hàng';
    } else if (tr.exploitStatus === 'Đang giao hàng') {
      status = 'Đang giao hàng';
    } else if (tr.exploitStatus === 'Hoàn thành') {
      status = 'Hoàn thành';
    } else if (tr.exploitStatus === 'Đã hủy bỏ' || tr.status === 'Hủy') {
      status = 'Đã hủy bỏ';
    } else {
      status = 'Lỗi';
    }
    delete tr['status'];

    if (tr.customer[0]) {
      tr.sale = tr.customer[0]?.sale ? tr.customer[0]?.sale[0] : null;
      delete tr.customer[0]?.sale;
    } else {
      tr.sale = null;
    }

    return {
      ...tr,
      box: tr.box[0] || null,
      awb: tr.awb[0] || null,
      businessPartner: tr.businessPartner[0] || null,
      warehouse: tr.warehouse[0] || null,
      warehouseVn: tr.warehouseVn[0] || null,
      exploitedBy: tr.exploitedBy[0] || null,
      deliveryBill: tr.deliveryBill[0] || null,
      trackingType: tr.trackingType[0] || null,
      customer: tr.customer[0] || null,
      backlogs: backlogs[0] ? backlogs : null,
      status: status,
    };
  }

  public updateOrderById = async (req: RequestWithUser, orderId: number, user, data) => {
    const order: any = await this.findById(req, user, orderId, false, null);
    const trackingId = order.id;

    if (!order) {
      throw new HttpException(404, 'Order is not found');
    }
    if (!TRACKING_UPDATABLE_STATUS.includes(order.status)) {
      throw new HttpException(400, 'Order is not in updateable status!');
    }

    const validField = [
      'description',
      'importDate',
      'repackDate',
      'packedDate',
      'exportDate',
      'arrivalDate',
      'completedAt',
      'exploitedDate',
      'invoicedDate',
      'checkingDate',
      'isRepack',
      'isSplit',
      'parentTracking',
      'isDeleted',
      'imageUrl',
      'note',
      'exploitStatus',
      'shippingFee',
      'trackingMiningWeight',
      'trackingCalculationWeight',
      'trackingBarrelCoefficient',
      'trackingShippingCost',
      'trackingSurcharge',
      'trackingDeliveryFee',
      'trackingOtherFee',
      'trackingDiscountAmount',
      'trackingTotalMoney',
      'weight',
      'trackingAmount',
      'orderId',
      'optionalImage',
      'productName',
      'price',
      'uid',
    ];
    const updateData: any = {};
    for (const field of validField) {
      if (data[field] != undefined || data[field] != null) {
        updateData[field] = data[field];
      }
    }
    data['updatedAt'] = new Date();

    // customer
    if (data.customer) {
      const trackingCustomerLink = await TrackingCustomerLinks.query().where('tracking_id', trackingId).first();
      if (trackingCustomerLink && data.customer !== order?.customer?.id) {
        await TrackingCustomerLinks.query()
          .update({
            customer_id: data.customer,
          })
          .where('tracking_id', trackingId);
        await TrackingsDeliveryBillLinks.query().delete().where('tracking_id', order.id);
        updateData.vnPackedDate = null;
        const sale: CustomerSaleLinks = await CustomerSaleLinks.query().select().where('customer_id', data.customer).first();
        if (sale && sale.userId) {
          const isExistLink = await TrackingSaleLinks.query().where('tracking_id', trackingId).first();
          if (isExistLink)
            await TrackingSaleLinks.query()
              .patch({
                user_id: sale.userId,
              })
              .where('tracking_id', trackingId);
          else
            await TrackingSaleLinks.query().insert({
              tracking_id: trackingId,
              user_id: sale.userId,
            });
        }
      } else if (!trackingCustomerLink) {
        await TrackingCustomerLinks.query()
          .insert({
            customer_id: data.customer,
            tracking_id: trackingId,
          })
          .into('trackings_customer_links');
      }
    }

    // trackingType
    if (data.trackingType) {
      const tracking = await TrackingsTrackingTypeLinks.query().where('tracking_id', trackingId).first();
      if (tracking) {
        await TrackingsTrackingTypeLinks.query()
          .update({
            tracking_type_id: data.trackingType,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingsTrackingTypeLinks.query()
          .insert({
            tracking_type_id: data.trackingType,
            tracking_id: trackingId,
          })
          .into('trackings_tracking_type_links');
      }
      const customer_id = data.customer | order.customer.id;
      const warehouse_vn_id = data.tracking_warehouse_config_id | order.warehouseVn?.id;
      if (customer_id && warehouse_vn_id) {
        const customer = await Customer.query()
          .findById(customer_id)
          .leftJoinRelated('generalConfigs')
          .withGraphFetched('generalConfigs as shippingCost');
        updateData.trackingShippingCost = (JSON.parse(customer.shippingCost.configValue) as any).config.find(
          object => object.tracking_type === data.trackingType && object.warehouse_config_id === warehouse_vn_id,
        ).cost;
        updateData.trackingMiningWeight = data.trackingMiningWeight ?? order.trackingMiningWeight;
        const trackingBarrelCoefficient =
          data.trackingBarrelCoefficient ?? order.trackingBarrelCoefficient ?? (await Config.query().select().first()).trackingBarrelCoefficient;
        updateData.trackingBarrelCoefficient = Number(trackingBarrelCoefficient);
        const trackingCalculationWeight = Number(
          Number(Number((Number(data.trackingMiningWeight ?? order.trackingMiningWeight) || 0) * Number(trackingBarrelCoefficient))).toFixed(2),
        );
        updateData.trackingCalculationWeight = trackingCalculationWeight;
        updateData.trackingShippingFee = updateData.trackingCalculationWeight * updateData.trackingShippingCost;
      }
    }

    // businessPartner
    if (data.businessPartner) {
      const tracking = await TrackingBusinessPartnerLink.query().where('tracking_id', trackingId).first();
      if (tracking) {
        await TrackingBusinessPartnerLink.query()
          .update({
            business_partner_id: data.businessPartner,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingBusinessPartnerLink.query()
          .insert({
            business_partner_id: data.businessPartner,
            tracking_id: trackingId,
          })
          .into('trackings_business_partner_links');
      }
    }

    // warehouse
    if (data.warehouse) {
      const tracking = await TrackingsWarehouseLinksLink.query().where('tracking_id', trackingId).first();
      if (tracking) {
        await TrackingsWarehouseLinksLink.query()
          .update({
            warehouse_id: data.warehouse,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingsWarehouseLinksLink.query()
          .insert({
            warehouse_id: data.warehouse,
            tracking_id: trackingId,
          })
          .into('trackings_warehouse_links');
      }
    }

    // warehouseVn
    if (data.warehouseVn) {
      const tracking = await TrackingsWarehouseVnLinksLink.query().where('tracking_id', trackingId).first();
      if (tracking) {
        await TrackingsWarehouseVnLinksLink.query()
          .update({
            warehouse_config_id: data.warehouseVn,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingsWarehouseVnLinksLink.query()
          .insert({
            warehouse_config_id: data.warehouseVn,
            tracking_id: trackingId,
          })
          .into('trackings_warehouse_vn_links');
      }
    }

    updateData.trackingSurcharge = data.trackingSurcharge ?? (order.trackingSurcharge || 0);
    updateData.trackingDeliveryFee = data.trackingDeliveryFee ?? (order.trackingDeliveryFee || 0);
    updateData.trackingOtherFee = data.trackingOtherFee ?? (order.trackingOtherFee || 0);
    updateData.trackingShippingFee = updateData.trackingShippingFee ?? (order.trackingShippingFee || 0);
    updateData.trackingDiscountAmount = data.trackingDiscountAmount ?? (order.trackingDiscountAmount || 0);
    updateData.trackingTotalMoney =
      Number(updateData.trackingShippingFee) +
      Number(updateData.trackingSurcharge) +
      Number(updateData.trackingDeliveryFee) +
      Number(updateData.trackingOtherFee) -
      Number(updateData.trackingDiscountAmount);
    if (updateData.trackingTotalMoney < 0) {
      throw new BadRequestException('Discount amount must smaller than trackingTotalMoney!');
    }
    if (data.trackingWarehouseConfigId) {
      await TrackingsWarehouseVnLinksLink.query().patch({ warehouse_config_id: data.trackingWarehouseConfigId }).where('tracking_id', trackingId);
    }

    if (data.note) {
      updateData.note = data.note;
    }
    updateData.updated_at = new Date();

    await Tracking.query().patch(updateData).where('id', orderId);
    const res = await this.findById(req, user, orderId, false, null);

    setTimeout(async () => {
      try {
        // create backlog
        await TrackingLogs.query()
          .insert({
            trackingCode: order.code,
            actionType: 'entry.updateOrder',
            actionTime: new Date(),
            changedField: JSON.stringify(getChangedFields(order, res)),
            updatedAt: new Date(),
            trackingId: orderId,
            createdById: user?.id,
          })
          .into('tracking_logs');
        if (order?.customer?.isSubcribeToFcmNotification) await this.sendPushNotificationToUser([order.customer?.user[0]?.id], order.code);
      } catch (e) {
        console.log(e);
      }
    }, 0);

    return res;
  };

  private insertOrder = async code => {
    const insertedTracking = await Tracking.query()
      .insert({
        code,
        isDeleted: false,
        status: 'Đã tiếp nhận',
        exploitStatus: 'Đang vận chuyển về vn',
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .into('trackings');
    await TrackingBusinessPartnerLink.query()
      .insert({ business_partner_id: 1, tracking_id: insertedTracking.id })
      .into('trackings_business_partner_links');
    await sendCreateTrackingToWh([code]);
  };

  public createOrder = async (req, user, requestBody) => {
    await getReqPerrmissionBusinessLogic(req, 'api:: GET /api/orders');
    let data;
    if (
      (req.permission_business_logic && req.permission_business_logic === 5) ||
      req.user.role.type === 'khach_hang' ||
      req.user.type === 'customer'
    ) {
      delete requestBody.customer_id;
      requestBody.customer_id = req.user.customer.id;

      data = {
        tracking_code: requestBody.tracking_code,
        customer_id: requestBody.customer_id,
        product_name: requestBody.product_name,
        note: requestBody.note,
        description: requestBody.description,
        tracking_type: requestBody.tracking_type,
        tracking_amount: requestBody.tracking_amount,
        price: requestBody.price,
        warehouseVnId: requestBody.warehouse_vn_id,
      };
    } else {
      delete requestBody.goods_value;
      delete requestBody.tracking_amount;
      data = requestBody;
    }
    if (!data.tracking_code) {
      throw new HttpException(400, 'Tracking code is required');
    }
    if (!/^[a-zA-Z0-9-_]+$/.test(data.tracking_code)) {
      throw new HttpException(400, 'Trackig code is not allow to contain special character');
    }
    if (
      !(await Tracking.query()
        .where('code', data.tracking_code)
        .orWhereLike('code', `%${data.tracking_code.slice(-8)}`)
        .where('is_deleted', false)
        .first())
    ) {
      await this.insertOrder(data.tracking_code);
    }
    const tracking: any = await this.TrackingService.searchTrackingAlongId(data.tracking_code);
    // if (tracking.orderId) {
    //   throw new HttpException(400, 'tracking has been created order');
    // } else
    if (!data.customer_id) {
      throw new HttpException(400, 'Customer_id is required');
    } else {
      const updateData: any = {};
      if (!tracking.customer)
        await TrackingCustomerLinks.query()
          .insert({
            tracking_id: tracking.id,
            customer_id: data.customer_id,
          })
          .into(TrackingCustomerLinks.tableName);
      else
        await TrackingCustomerLinks.query()
          .patch({
            customer_id: data.customer_id,
          })
          .where('tracking_id', tracking.id);
      const sale: CustomerSaleLinks = await CustomerSaleLinks.query().select().where('customer_id', data.customer_id).first();
      if (sale && sale.userId) {
        const isExistLink = await TrackingSaleLinks.query().where('tracking_id', tracking.id).first();
        if (isExistLink)
          await TrackingSaleLinks.query()
            .patch({
              user_id: sale.userId,
            })
            .where('tracking_id', tracking.id);
        else
          await TrackingSaleLinks.query().insert({
            tracking_id: tracking.id,
            user_id: sale.userId,
          });
      }
      if (data.product_name) {
        updateData.product_name = data.product_name;
      }

      if (data.price) {
        updateData.price = data.price;
      }

      if (data.tracking_amount) {
        updateData.tracking_amount = data.tracking_amount;
      }

      if (data.tracking_type) {
        const trackingTypeLink = await TrackingsTrackingTypeLinks.query().where('tracking_id', tracking.id).first();
        if (trackingTypeLink) {
          await TrackingsTrackingTypeLinks.query()
            .patch({
              tracking_type_id: Number(data.tracking_type),
            })
            .where('tracking_id', tracking.id);
        } else {
          await TrackingsTrackingTypeLinks.query()
            .insert({
              tracking_type_id: Number(data.tracking_type),
              tracking_id: Number(tracking.id),
            })
            .into('trackings_tracking_type_links');
        }
        if (data.warehouseVnId || tracking.warehouseVn) {
          if (data.warehouseVnId) {
            const trackingWarehouse = await TrackingsWarehouseVnLinksLink.query().where('tracking_id', tracking.id).first();
            if (trackingWarehouse) {
              await TrackingsWarehouseVnLinksLink.query()
                .update({
                  warehouse_config_id: data.warehouseVnId,
                })
                .where('tracking_id', tracking.id);
            } else {
              await TrackingsWarehouseVnLinksLink.query()
                .insert({
                  warehouse_config_id: data.warehouseVnId,
                  tracking_id: tracking.id,
                })
                .into('trackings_warehouse_vn_links');
            }
          }
          const warehouseVnId = data.warehouseVnId || tracking.warehouseVn.id;
          const customer = await Customer.query()
            .findById(data.customer_id)
            .leftJoinRelated('generalConfigs')
            .withGraphFetched('generalConfigs as shippingCost');
          updateData.tracking_shipping_cost = (JSON.parse(customer.shippingCost.configValue) as any).config.find(
            object => object.tracking_type === data.tracking_type && object.warehouse_config_id === warehouseVnId,
          ).cost;
          updateData.tracking_mining_weight = tracking.trackingMiningWeight;
          const trackingBarrelCoefficient = (await Config.query().select().first()).trackingBarrelCoefficient;
          updateData.tracking_barrel_coefficient = Number(trackingBarrelCoefficient);
          updateData.tracking_calculation_weight = tracking.trackingMiningWeight * trackingBarrelCoefficient;
          updateData.tracking_shipping_fee = updateData.tracking_calculation_weight * updateData.tracking_shipping_cost;
          updateData.tracking_surcharge = data.tracking_surcharge || 0;
          updateData.tracking_delivery_fee = data.tracking_delivery_fee || 0;
          updateData.tracking_other_fee = data.tracking_other_fee || 0;
          updateData.tracking_total_money =
            updateData.tracking_shipping_fee + (data.tracking_surcharge || 0) + (data.tracking_delivery_fee || 0) + (data.tracking_other_fee || 0);
        } else {
          updateData.tracking_mining_weight = tracking.trackingMiningWeight || 0;
          const trackingBarrelCoefficient = (await Config.query().select().first()).trackingBarrelCoefficient;
          updateData.tracking_barrel_coefficient = Number(trackingBarrelCoefficient);
          updateData.tracking_calculation_weight = updateData.tracking_mining_weight * trackingBarrelCoefficient;
          updateData.tracking_shipping_fee = 0;
          updateData.tracking_surcharge = data.tracking_surcharge || 0;
          updateData.tracking_delivery_fee = data.tracking_delivery_fee || 0;
          updateData.tracking_other_fee = data.tracking_other_fee || 0;
          updateData.tracking_total_money =
            updateData.tracking_shipping_fee + (data.tracking_surcharge || 0) + (data.tracking_delivery_fee || 0) + (data.tracking_other_fee || 0);
        }
      }

      if (data.note) {
        updateData.note = data.note;
      }

      if (data.description) {
        updateData.description = data.description;
      }

      if (!tracking.orderId) {
        const { code } = await generateNextOrderId();
        updateData.order_id = code;
      }

      await Tracking.query()
        .patch({ ...updateData })
        .where('id', tracking.id);

      const res = await this.findById(null, user, tracking.id, false, null);

      // create backlog
      await TrackingLogs.query()
        .insert({
          trackingCode: tracking.code,
          actionType: 'entry.createOrder',
          actionTime: new Date(),
          extraData: JSON.stringify(res),
          createdAt: new Date(),
          updatedAt: new Date(),
          trackingId: tracking.id,
          createdById: user?.id,
        })
        .into('tracking_logs');

      return res;
    }
  };

  private sendPushNotificationToUser = async (userId, trackingCode) => {
    await this.fcmPushNotificationService.sendNotificationToGroupOfUser(userId, `Thông báo`, `Tracking ${trackingCode} của bạn đã có sự thay đổi`);
  };

  public cancelOrderById = async (req: RequestWithUser, orderId: number, user) => {
    const order: any = await this.findById(req, user, orderId, false, null);

    if (!order) {
      throw new HttpException(404, 'Order is not found');
    }

    if (!['Chờ nhập kho US', 'Đã tiếp nhận', 'Chờ nhà cung cấp', 'Chưa nhập kho'].includes(order.status)) {
      throw new BadRequestException('Cannot cancel : Order is not in cancelable state !');
    }
    await Tracking.query().patch({ exploitStatus: 'Đã hủy bỏ' }).where('id', orderId);
    const res = await this.findById(req, user, orderId, false, null);

    await TrackingLogs.query()
      .insert({
        trackingCode: order.code,
        actionType: 'entry.cancelOrder',
        actionTime: new Date(),
        extraData: JSON.stringify(res),
        updatedAt: new Date(),
        trackingId: order.id,
        createdById: user?.id,
      })
      .into('tracking_logs');

    return res;
  };
}

export default OrdersService;
