import admin from '@/helper/firebaseAdmin';
import { FcmTokens } from '@/models/fcmToken.model';

class FcmPushNotificationService {
  static getInstant(): FcmPushNotificationService {
    return new FcmPushNotificationService();
  }

  public async createFcmTokenUserLink(user, body) {
    const { fcmToken } = body;
    const currentDate = new Date();
    const checkCurrentToken = await FcmTokens.query().where('fcmToken', fcmToken).andWhere('userId', user.id).first();
    let docId: number;
    if (checkCurrentToken) {
      docId = checkCurrentToken.id;
      await FcmTokens.query().patch({ lastUpdatedAt: currentDate }).where('id', docId);
    } else {
      const fcmTokenDoc = await FcmTokens.query().insert({
        userId: user.id,
        fcmToken,
        lastUpdatedAt: currentDate,
      });
      docId = fcmTokenDoc.id;
    }
    const newConfig: any = await FcmTokens.query().findById(docId);
    return newConfig;
  }

  public async sendTestNotificationToAllDevice() {
    const tokens = (await FcmTokens.query()).map(x => x.fcmToken);
    await admin.messaging().sendEachForMulticast({
      notification: {
        title: 'TEST_Tiêu đề thông báo_broadcast',
        body: 'TEST_Nội dung thông báo_broadcast.',
      },
      // Specify the target registration tokens as an array
      tokens,
    });
  }
  public async sendTestNotificationToDevice(fcmToken: string) {
    await admin.messaging().send({
      notification: {
        title: 'TEST_Tiêu đề thông báo_single',
        body: 'TEST_Nội dung thông báo_single.',
      },
      // Specify the target registration tokens as an array
      token: fcmToken,
    });
  }

  public async sendNotificationToGroupOfUser(userIds: number[], notiTitle: string, notiBody: string) {
    const tokens = (await FcmTokens.query().whereIn('user_id', userIds)).map(x => x.fcmToken);
    if (tokens && tokens.length !== 0)
      await admin.messaging().sendEachForMulticast({
        notification: {
          title: notiTitle,
          body: notiBody,
        },
        tokens,
      });
  }
}

export default FcmPushNotificationService;
