import { WAREHOUSE_API_URL, WAREHOUSE_API_TOKEN } from '@config';
import { Awb } from '@/models/awb.model';
import { Box } from '@/models/box.model';
import { Tracking } from '@/models/tracking.model';
import { TrackingType } from '@/models/trackingType.model';
import { transaction } from 'objection';
import { HttpException } from '@exceptions/HttpException';
import { isEmpty } from '@utils/util';
import axios from 'axios';
import moment from 'moment';
import qs from 'qs';
import * as _ from 'lodash';
import { AWB_STATUS_ORDER, STATUS_AWB, TRACKING_BEFORE_EXPLOITATION_STATUS } from '@/constant/constant';
import * as XLSX from 'xlsx';
import BadRequestException from '@/exceptions/BadRequestException';
import { Response } from 'express';
import { getListAwbs, getListTrackings } from '@/utils/requestsToWarehouseApi';
import { getStatusAwbReal, getStatusTrackingReal } from '@/utils/getStatusTracking';
import { TrackingsBoxLinks } from '@/models/trackingBoxLinks.model';
import { TrackingsAwbLinks } from '@/models/trackingAwbLinks.model';
import { BoxesAwbLinks } from '@/models/awbBoxLink.model';
class AwbService {
  static getInstant(): AwbService {
    return new AwbService();
  }
  private filterAwb(req, user, param, queryBuilder, onlyStatus) {
    let { exploitStatus, keyWords, box_code, tracking_code, sync_status } = param;
    if (onlyStatus) exploitStatus = sync_status = null;
    if (exploitStatus !== undefined) {
      switch (exploitStatus) {
        case '0': // Tất cả
          break;
        case '1':
          queryBuilder.where('aw.syncStatus', 'processing');
          break;
        case '2':
          queryBuilder.where('aw.syncStatus', 'failed');
          break;
        case '3':
          queryBuilder.where('aw.exploitStatus', STATUS_AWB[2]);
          break;
        case '4':
          queryBuilder.where('aw.exploitStatus', STATUS_AWB[3]);
          break;
        case '5':
          queryBuilder.where('aw.exploitStatus', STATUS_AWB[4]);
          break;
        case '6':
          queryBuilder.where('aw.exploitStatus', STATUS_AWB[5]);
          break;
        default:
          break;
      }
    }

    if (keyWords) {
      queryBuilder.whereLike('aw.code', `%${keyWords}%`);
    }

    if (req.permission_business_logic) {
      switch (req.permission_business_logic) {
        case 1:
          break;
        case 2:
          queryBuilder
            .leftJoinRelated('box')
            .leftJoin('boxes_warehouse_vn_links', 'box.id', '=', 'boxes_warehouse_vn_links.box_id')
            .where('boxes_warehouse_vn_links.warehouse_config_id', user.warehouseVN[0].id)
            .orWhereNull('boxes_warehouse_vn_links.warehouse_config_id');
        default:
          break;
      }
    }

    if (box_code) {
      queryBuilder
        .innerJoin('boxes_awb_links', 'aw.id', '=', 'boxes_awb_links.awb_id')
        .innerJoin('boxes', 'boxes.id', '=', 'boxes_awb_links.box_id')
        .whereLike('boxes.code', `%${box_code}%`);
    }
    if (tracking_code) {
      queryBuilder
        .innerJoin('trackings_awb_links', 'aw.id', '=', 'trackings_awb_links.awb_id')
        .innerJoin('trackings', 'trackings.id', '=', 'trackings_awb_links.tracking_id')
        .whereLike('trackings.code', `%${tracking_code}%`);
    }
    if (sync_status) {
      queryBuilder.where('aw.sync_status', sync_status);
    }
  }
  public async findAll(req, user, param) {
    const queryBuilder = Awb.query()
      .from('awbs as aw')
      .withGraphFetched('tracking')
      .modifyGraph('tracking', builder => builder.whereNot('exploitStatus', 'Đã hủy bỏ'))
      .withGraphFetched('box');
    const { page = 0, pageSize = 10, exploitStatus } = param;
    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }
    this.filterAwb(req, user, param, queryBuilder, false);
    const listAwb = await queryBuilder.page(pageIndex, pageSize).orderBy('createdAt', 'desc').groupBy('aw.id');
    if (!listAwb) throw new HttpException(404, "Awb doesn't exist");
    const { results, total } = listAwb;

    const customResults = results.map((item: any) => {
      let trackingTotalMoney = 0;
      let trackingCalculationWeight = 0;
      let trackingMiningWeight = 0;
      const trackingCode = [];
      const boxCode = [];
      let boxQuantity = 0;
      const resultFiter = new Map();
      const filteredArray = item.tracking.filter(obj => {
        if (!resultFiter.has(obj.code)) {
          resultFiter.set(obj.code, true);
          return true;
        }
        return false;
      });
      filteredArray.forEach(track => {
        if (track.exploitStatus !== 'Đã hủy bỏ') {
          trackingTotalMoney += Number(track.trackingTotalMoney);
          trackingCalculationWeight += Number(track.trackingCalculationWeight);
          trackingMiningWeight += Number(track.trackingMiningWeight);
          trackingCode.push(track.code);
        }
      });
      item.box.forEach(b => {
        boxCode.push(b.code);
        boxQuantity++;
      });
      delete item.tracking;
      delete item.box;
      delete item.trackingQuantity;
      return {
        ...item,
        trackingTotalMoney,
        trackingCalculationWeight,
        trackingMiningWeight,
        trackingCode,
        boxCode,
        boxQuantity,
        trackingQuantity: trackingCode.length,
      };
    });

    let result;
    if (exploitStatus === '1') {
      result = customResults.map(item => {
        return {
          ...item,
          exploitStatus: 'Đang đồng bộ',
        };
      });
    } else if (exploitStatus === '2') {
      result = customResults.map(item => {
        return {
          ...item,
          exploitStatus: 'Đồng bộ thất bại',
        };
      });
    } else {
      result = customResults.filter(item => item.syncStatus !== 'processing');
    }

    return {
      meta: {
        page: Number(pageIndex) + 1,
        pageSize,
        total,
        totalPage: Math.ceil(total / pageSize),
      },
      data: result,
    };
  }

  public async getStatusAwb(req, param) {
    let queryBuilder: any = Awb.query().select('exploitStatus', 'sync_status', 'id').from('awbs as aw').groupBy('aw.id');
    this.filterAwb(req, req.user, param, queryBuilder, true);
    queryBuilder = await queryBuilder;
    const frequency = {};
    queryBuilder.forEach(record => {
      const status = getStatusAwbReal(record);
      // Nếu giá trị chưa tồn tại trong đối tượng frequency, khởi tạo nó bằng 1, ngược lại tăng giá trị lên 1
      frequency[status] = (frequency[status] || 0) + 1;
    });
    queryBuilder = frequency;

    const allStatuses = Object.keys(AWB_STATUS_ORDER);
    const statusList = allStatuses.map(name => ({
      name,
      total: frequency[name] || 0,
      id: AWB_STATUS_ORDER[name],
    }));

    statusList.sort((a, b) => a.id - b.id);

    return statusList;
  }

  public async updateAwb(user, id, param) {
    if (isEmpty(param) || isEmpty(id)) throw new HttpException(400, 'AwbData is empty');
    const {
      code,
      flyingWeight,
      totalCalculationWeight,
      flyingFee,
      exchangeRate,
      totalFlyingFee,
      clearanceWeight,
      clearanceFee,
      totalClearanceFee,
      totalFee,
    } = param;
    const data = {} as any;
    if (code) {
      data.code = code;
    }
    if (flyingWeight) {
      data.flyingWeight = flyingWeight;
    }
    if (totalCalculationWeight) {
      data.totalCalculationWeight = totalCalculationWeight;
    }
    if (flyingFee) {
      data.flyingFee = flyingFee;
    }
    if (exchangeRate) {
      data.exchangeRate = exchangeRate;
    }
    if (totalFlyingFee) {
      data.totalFlyingFee = totalFlyingFee;
    }
    if (clearanceWeight) {
      data.clearance_weight = clearanceWeight;
    }
    if (clearanceFee) {
      data.clearanceFee = clearanceFee;
    }
    if (totalClearanceFee) {
      data.totalClearanceFee = totalClearanceFee;
    }
    if (totalFee) {
      data.totalFee = totalFee;
    }
    await Awb.query().update(data).where('id', id).into('awbs');
  }

  /**
   * Get awbs from warehouse
   */
  private async getAwbsFromWarehouse(partnerUID: string) {
    const apiUrl: string = WAREHOUSE_API_URL || '';
    const apiToken: string = WAREHOUSE_API_TOKEN || '';
    // Just get code
    const query = {
      fields: ['code'],
      filters: {
        status: 'Đang vận chuyển',
        completed_at: {
          $gte: moment().subtract(30, 'days').toISOString(),
        },
        boxes: {
          business_partners: {
            uid: {
              $eq: partnerUID,
            },
          },
        },
      },
      pagination: {
        pageSize: 100,
      },
    };
    const { data } = await axios.get(apiUrl + '/api/awbs?' + qs.stringify(query), {
      headers: {
        Authorization: `Bearer ${apiToken}`,
      },
    });
    return data;
  }

  /**
   * Check awbs
   */
  public async checkAwb(partnerUID: string) {
    const warehouseAwbs = await getListAwbs({ status: 'Đang vận chuyển về VN' });
    const warehouseAwbCodes: string[] = warehouseAwbs.data.rows.map(e => e.code);
    const processingAwbs: Awb[] = await Awb.query().select('code').whereIn('code', warehouseAwbCodes).andWhere('sync_status', 'processing');
    const processingAwbCodes: string[] = processingAwbs.map(e => e.code);
    const syncedAndNotProcessingAwbs: Awb[] = await Awb.query()
      .select('code')
      .whereIn('code', warehouseAwbCodes)
      .whereIn('sync_status', ['processing', 'successful']);
    const syncedAndNotProcessingAwbsCodes: string[] = syncedAndNotProcessingAwbs.map(e => e.code);
    return {
      processing: _.intersection(warehouseAwbCodes, processingAwbCodes),
      notSynced: _.difference(warehouseAwbCodes, syncedAndNotProcessingAwbsCodes),
    };
  }

  /**
   * Validate awbs
   */
  static async validateAwbs(awbs: string[], isResync: boolean): Promise<Array<string>> {
    const existCode = (await Awb.query().select('code').whereIn('code', awbs))?.map(x => x.code) || [];
    const nonExistCode: string[] = awbs.filter(x => !existCode.includes(x));
    const query = Awb.query().select('awbs.code').whereIn('awbs.code', awbs).where('awbs.exploit_status', 'Đang vận chuyển về vn').groupBy('awbs.id');
    if (isResync) {
      query.where(builder => {
        builder.orWhere('sync_status', 'failed').orWhere(nestedBuilder => {
          nestedBuilder.andWhere('sync_status', 'successful').whereNotExists(function () {
            this.select('*')
              .from('boxes')
              .leftJoin('boxes_awb_links', 'boxes_awb_links.box_id', '=', 'boxes.id')
              .whereRaw('boxes_awb_links.awb_id = awbs.id')
              .whereNot('boxes.exploit_status', 'Đang vận chuyển về vn');
          });
        });
      });
    } else {
      query.where('sync_status', 'failed');
    }
    return nonExistCode.concat((await query)?.map(x => x.code));
  }

  /**
   * Sync awb
   */
  public async sync(partner: any, awbs: string[], res: Response) {
    const awbData = (await getListAwbs({ status: 'Đang vận chuyển về VN', awbCodes: awbs })).data.rows;
    res.status(200).json({ data: [], message: 'success' });
    // Save data
    await Promise.all(
      awbData.map(async awb => {
        const boxes: any[] = awb.Boxes;
        const boxQuantity: number = awb.boxQuantity;
        // Insert awb
        delete awb.id;
        delete awb.Boxes;
        delete awb.flightDatePlan;
        delete awb.arrivalDatePlan;
        delete awb.stations;
        delete awb.currentStation;
        delete awb.statusLastEvent;
        delete awb.statusTrackChangedDate;
        delete awb.lastEvent;
        if (!awb.exploitStatus) awb.exploitStatus = 'Đang vận chuyển về vn';
        const existedAwbs: Awb = await Awb.query().where('code', awb.code).first();
        let _awb: Awb;
        if (existedAwbs) {
          _awb = await existedAwbs.$query().patchAndFetch({ sync_status: 'processing' }).where('code', awb.code).withGraphFetched('box as boxes');
        } else {
          _awb = await Awb.query().insert({ ...awb, sync_status: 'processing' });
        }
        let reached = false;
        try {
          await transaction(
            Box,
            Tracking,
            BoxesAwbLinks,
            TrackingsBoxLinks,
            TrackingsAwbLinks,
            async (Box, Tracking, BoxesAwbLinks, TrackingsBoxLinks, TrackingsAwbLinks) => {
              let awbStatus: string;
              let awbMinStatus = 7;
              const boxCodeToSync: Set<string> = new Set(boxes.map(item => item.code));
              const boxToDelete = _awb?.boxes?.filter(item => !boxCodeToSync.has(item.code)) || [];
              await Promise.all(
                boxes.map(async box => {
                  let boxStatus = 'Đang vận chuyển về vn';
                  const boxId = box.id;
                  // Insert box
                  delete box.id;
                  delete box.isSynced;
                  delete box.partnerId;
                  const existedBox: Box = await Box.query()
                    .where('code', box.code)
                    .withGraphFetched('awb')
                    .withGraphFetched('businessPartner')
                    .first();
                  let _box: Box;
                  if (existedBox) {
                    _box = existedBox;
                  } else {
                    _box = await Box.query().insert(box);
                  }
                  // Update box - awb
                  if (!existedBox || !_box.awb[0]) {
                    await BoxesAwbLinks.query().insert({ box_id: _box.id, awb_id: _awb.id });
                  } else {
                    await BoxesAwbLinks.query().patch({ awb_id: _awb.id }).where('box_id', _box.id);
                  }
                  // Update box - business partner
                  if (!existedBox || !_box.businessPartner[0]) await _box.$relatedQuery('businessPartner').relate(partner.id);

                  let page = 0;
                  let totalPage = 0;
                  const syncedTracking = [];

                  let minStatus = 10;
                  const trackingStatusArray: number[] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
                  let tracking_count = 0;

                  do {
                    page++;
                    // Fetch trackings
                    const trackingData = (await getListTrackings(page, { boxIds: boxId })).data;
                    totalPage = Math.ceil(trackingData.count / 100);
                    await Promise.all(
                      trackingData.rows.map(async tracking => {
                        if (!syncedTracking.includes(tracking.code)) {
                          const existedTracking = await Tracking.query()
                            .where('code', tracking.code)
                            .orWhereLike('code', `%${tracking.code?.slice(-8)}`)
                            .where('is_deleted', false)
                            .withGraphFetched('awb')
                            .withGraphFetched('box')
                            .withGraphFetched('businessPartner')
                            .withGraphFetched('warehouse')
                            .first();
                          tracking.wh_tracking_id = tracking.id;
                          const warehouse = tracking.Warehouse ? tracking.Warehouse.id : null;
                          delete tracking.id;
                          delete tracking.tracking_type;
                          delete tracking.isSynced;
                          delete tracking.Author;
                          delete tracking.Tickets;
                          delete tracking.Images;
                          delete tracking.Awb;
                          delete tracking.Warehouse;
                          delete tracking.Partner;
                          delete tracking.TrackingType;
                          delete tracking.Box;

                          if (
                            !existedTracking ||
                            (existedTracking && TRACKING_BEFORE_EXPLOITATION_STATUS.includes(getStatusTrackingReal(existedTracking)))
                          )
                            tracking.exploitStatus = 'Đang vận chuyển về vn';
                          tracking.isDeleted = false;
                          const trackingTypeUID = tracking.tracking_type?.uid;
                          let _tracking;
                          if (!existedTracking) {
                            _tracking = await Tracking.query().insert(tracking);
                          } else {
                            const __tracking = await Tracking.query()
                              .where('code', tracking.code)
                              .orWhereLike('code', `%${tracking.code?.slice(-8)}`)
                              .where('is_deleted', false)
                              .first();
                            _tracking = await __tracking
                              .$query()
                              .updateAndFetch(tracking)
                              .where('code', tracking.code)
                              .orWhereLike('code', `%${tracking.code?.slice(-8)}`);
                          }
                          if (!existedTracking || !existedTracking.awb[0]) await _tracking.$relatedQuery('awb').relate(_awb.id);
                          else {
                            await TrackingsAwbLinks.query().patch({ awb_id: _awb.id }).where('tracking_id', existedTracking.id);
                          }
                          if (!existedTracking || !existedTracking.box[0]) await _tracking.$relatedQuery('box').relate(_box.id);
                          else {
                            await TrackingsBoxLinks.query().patch({ box_id: _box.id }).where('tracking_id', existedTracking.id);
                          }
                          if (!existedTracking || !existedTracking.businessPartner[0])
                            await _tracking.$relatedQuery('businessPartner').relate(partner.id);
                          if (warehouse && (!existedTracking || !existedTracking.warehouse[0]))
                            await _tracking.$relatedQuery('warehouse').relate(warehouse);
                          if (trackingTypeUID) {
                            const trackingType: TrackingType = await TrackingType.query().findOne('uid', trackingTypeUID);
                            if (trackingType) {
                              await _tracking.$relatedQuery('trackingType').relate(trackingType.id);
                            }
                          }
                          syncedTracking.push(tracking.code);

                          _tracking = await Tracking.query()
                            .where('code', tracking.code)
                            .orWhereLike('code', `%${tracking.code?.slice(-8)}`)
                            .where('is_deleted', false)
                            .first();
                          tracking_count++;
                          let trackingStatusAsNumber = 1;
                          switch (_tracking.status) {
                            case 'Chờ nhập kho US':
                            case 'Đã tiếp nhận':
                            case 'Chưa nhập kho':
                              trackingStatusAsNumber = 1;
                              trackingStatusArray[1]++;
                              break;
                            case 'Đã nhập kho':
                              trackingStatusAsNumber = 2;
                              trackingStatusArray[2]++;
                              break;
                            case 'Đang vận chuyển về VN':
                            case 'Đang đóng thùng':
                            case 'Đã đóng thùng':
                            case 'Đang xử lý awb':
                            case 'Đang vận chuyển về VN':
                            case 'Hoàn thành':
                              if (_tracking.exploitStatus === 'Đang vận chuyển về vn') trackingStatusAsNumber = 3;
                              trackingStatusArray[3]++;
                              break;
                            case 'Hủy':
                              trackingStatusAsNumber = 7;
                              trackingStatusArray[7]++;
                              break;
                            default:
                              trackingStatusAsNumber = 10;
                              break;
                          }
                          switch (_tracking.exploitStatus) {
                            case 'Đã vận chuyển về vn':
                              trackingStatusAsNumber = 4;
                              trackingStatusArray[4]++;
                              break;
                            case 'Đã khai thác':
                              trackingStatusAsNumber = 5;
                              trackingStatusArray[5]++;
                              break;
                            case 'Hoàn thành':
                              trackingStatusAsNumber = 6;
                              trackingStatusArray[6]++;
                              break;
                            case 'Đã hủy bỏ':
                              if (_tracking.status !== 'Hủy') trackingStatusAsNumber = 7;
                              trackingStatusArray[7]++;
                              break;
                            case 'Đã đóng hàng':
                              trackingStatusArray[8]++;
                              break;
                            case 'Đang giao hàng':
                              trackingStatusArray[9]++;
                              break;
                            default:
                              trackingStatusAsNumber = 10;
                              break;
                          }
                          if (trackingStatusAsNumber < minStatus) {
                            minStatus = trackingStatusAsNumber;
                          }
                          // console.log(trackingStatusArray + ' ' + tracking_count + ' ' + box.box_name);
                          // throw new Error(' break ');
                        }
                      }),
                    );
                  } while (page < totalPage);
                  tracking_count = tracking_count - trackingStatusArray[7];

                  if (
                    trackingStatusArray[4] + trackingStatusArray[5] + trackingStatusArray[6] + trackingStatusArray[8] + trackingStatusArray[9] ===
                    tracking_count
                  ) {
                    boxStatus = 'Đã vận chuyển về vn';
                  }
                  if (
                    trackingStatusArray[4] > 0 &&
                    trackingStatusArray[4] < tracking_count &&
                    trackingStatusArray[5] + trackingStatusArray[6] + trackingStatusArray[8] + trackingStatusArray[9] > 0
                  ) {
                    boxStatus = 'Đang khai thác';
                  }
                  if (trackingStatusArray[5] + trackingStatusArray[6] + trackingStatusArray[8] + trackingStatusArray[9] === tracking_count)
                    boxStatus = 'Đã khai thác';
                  tracking_count = 0;
                  let boxStatusAsNumber = 7;

                  const patchedBox = await _box.$query().patchAndFetch({ exploitStatus: boxStatus }).where('id', _box.id);

                  switch (patchedBox.exploitStatus) {
                    case 'Đang vận chuyển về vn':
                      boxStatusAsNumber = 3;
                      break;
                    case 'Đã vận chuyển về vn':
                      boxStatusAsNumber = 4;
                      break;
                    case 'Đang khai thác':
                      boxStatusAsNumber = 5;
                      break;
                    case 'Đã khai thác':
                      boxStatusAsNumber = 6;
                      break;
                    default:
                      boxStatusAsNumber = 7;
                      break;
                  }
                  if (boxStatusAsNumber < awbMinStatus) {
                    awbMinStatus = boxStatusAsNumber;
                  }
                }),
              );
              switch (awbMinStatus) {
                case 3:
                  awbStatus = 'Đang vận chuyển về vn';
                  break;
                case 4:
                  awbStatus = 'Đã vận chuyển về vn';
                  break;
                case 5:
                  awbStatus = 'Đang khai thác';
                  break;
                case 6:
                  awbStatus = 'Đã khai thác';
                  break;
                default:
                  awbStatus = 'Đang vận chuyển về vn';
                  break;
              }
              if (boxToDelete.length)
                await Promise.all(
                  boxToDelete?.map(async box => {
                    const _box = await Box.query().findById(box.id).withGraphFetched('trackingBoxes as trackings');
                    const trackingIds = _box.trackings.map(x => x.id);
                    await BoxesAwbLinks.query().delete().where('box_id', box.id);
                    await TrackingsBoxLinks.query().delete().where('box_id', box.id);
                    await TrackingsAwbLinks.query().delete().whereIn('tracking_id', trackingIds);
                  }),
                );
              await Awb.query().patch({ exploitStatus: awbStatus, status: 'Hoàn thành' }).where('id', _awb.id);

              reached = true;
            },
          );
          reached = true;
        } catch (e) {
          // await Awb.query().patch({ sync_status: 'failed' }).where('code', awb.code);
          throw new BadRequestException('Error on ' + e);
        } finally {
          if (reached) {
            await Awb.query().patch({ sync_status: 'successful' }).where('code', awb.code);
          } else {
            await Awb.query().patch({ sync_status: 'failed' }).where('code', awb.code);
          }
        }
      }),
    );
  }

  private nestedTrackingType(trackingType) {
    const nestedTrackingType = {};
    for (const [key, value] of Object.entries(trackingType)) {
      if (key.startsWith('tracking_type/')) {
        nestedTrackingType[key.substring('tracking_type/'.length)] = value;
        delete trackingType[`${key}`];
      }
    }
    return { ...trackingType, tracking_type: nestedTrackingType };
  }

  public async importExcel(partner: any, filePath: any) {
    const workbook = XLSX.readFile(filePath, { sheetStubs: true });
    const awbs: any = XLSX.utils.sheet_to_json(workbook.Sheets['AWB']);
    const boxes: any = XLSX.utils.sheet_to_json(workbook.Sheets['BOX']);
    let trackings: any = XLSX.utils.sheet_to_json(workbook.Sheets['TRACKING']);
    trackings = trackings.map(tr => {
      return this.nestedTrackingType(tr);
    });
    await Promise.all(
      awbs.map(async awb => {
        const boxQuantity: number = awb.boxQuantity;
        // Insert awb
        const awb_id = awb.id;
        delete awb.id;
        delete awb.boxes;
        delete awb.isSynced;
        const existedAwbs: Awb = await Awb.query().where('code', awb.code).first();
        let _awb: Awb;
        if (existedAwbs) {
          _awb = await existedAwbs.$query().patchAndFetch({ sync_status: 'processing' }).where('code', awb.code);
        } else {
          _awb = await Awb.query().insert({ ...awb, sync_status: 'processing' });
        }
        let reached = false;
        try {
          await transaction(Box, Tracking, async (Box, Tracking) => {
            await Promise.all(
              boxes
                .filter(x => x.awb_id === awb_id)
                .map(object => {
                  Object.keys(object).forEach(key => {
                    if (object[key] === '') {
                      object[key] = null;
                    }
                  });
                  return object;
                })
                .map(async box => {
                  // Insert box
                  const box_id = box.id;
                  delete box.id;
                  delete box.isSynced;
                  delete box.awb_id;
                  const _box = await Box.query().insert(box);
                  // Update box - awb
                  await _box.$relatedQuery('awb').relate(_awb.id);
                  // Update box - business partner
                  await _box.$relatedQuery('businessPartner').relate(partner.id);

                  await Promise.all(
                    trackings
                      .filter(x => x.box_id === box_id)
                      .map(object => {
                        Object.keys(object).forEach(key => {
                          if (object[key] === '') {
                            object[key] = null;
                          }
                        });
                        return object;
                      })
                      .map(async tracking => {
                        const existedTracking = await Tracking.query().findOne('code', tracking.code).withGraphFetched('businessPartner');
                        if (!existedTracking) {
                          const trackingTypeUID = tracking.tracking_type?.uid;
                          delete tracking.id;
                          delete tracking.tracking_type;
                          delete tracking.isSynced;
                          delete tracking.box_id;

                          const _tracking: Tracking = await Tracking.query().insert(tracking);
                          await _tracking.$relatedQuery('awb').relate(_awb.id);
                          await _tracking.$relatedQuery('box').relate(_box.id);
                          await _tracking.$relatedQuery('businessPartner').relate(partner.id);
                          if (trackingTypeUID) {
                            const trackingType: TrackingType = await TrackingType.query().findOne('uid', trackingTypeUID);
                            if (trackingType) {
                              await _tracking.$relatedQuery('trackingType').relate(trackingType.id);
                            }
                          }
                        } else {
                          const trackingTypeUID = tracking.tracking_type?.uid;
                          delete tracking.id;
                          delete tracking.tracking_type;
                          delete tracking.isSynced;
                          delete tracking.box_id;

                          const __tracking = await Tracking.query().findOne('code', tracking.code);
                          const _tracking: Tracking = await __tracking.$query().updateAndFetch(tracking).where('code', tracking.code);
                          await _tracking.$relatedQuery('awb').relate(_awb.id);
                          await _tracking.$relatedQuery('box').relate(_box.id);
                          await _tracking.$relatedQuery('businessPartner').relate(partner.id);
                          if (trackingTypeUID) {
                            const trackingType: TrackingType = await TrackingType.query().findOne('uid', trackingTypeUID);
                            if (trackingType) {
                              await _tracking.$relatedQuery('trackingType').relate(trackingType.id);
                            }
                          }
                        }
                      }),
                  );
                }),
            );
            if (boxes.length != boxQuantity) {
              throw new Error('Missing data');
            }
            reached = true;
          });
          reached = true;
        } catch (e) {
          // await Awb.query().patch({ sync_status: 'failed' }).where('code', awb.code);
          throw new BadRequestException('Error on ' + e);
        } finally {
          if (reached) {
            await Awb.query().patch({ sync_status: 'successful' }).where('code', awb.code);
          } else {
            await Awb.query().patch({ sync_status: 'failed' }).where('code', awb.code);
          }
        }
      }),
    );
  }

  private async fetchAwbsFromWarehouse(partnerUID: string, awbs: string[]) {
    const apiUrl: string = WAREHOUSE_API_URL || '';
    const apiToken: string = WAREHOUSE_API_TOKEN || '';
    const query = {
      populate: 'boxes',
      filters: {
        code: {
          $in: awbs,
        },
        status: 'Đang vận chuyển',
        boxes: {
          business_partners: {
            uid: {
              $eq: partnerUID,
            },
          },
        },
      },
    };
    console.log(apiUrl + '/api/awbs?' + qs.stringify(query));
    const { data } = await axios.get(apiUrl + '/api/awbs?' + qs.stringify(query), {
      headers: {
        Authorization: `Bearer ${apiToken}`,
      },
    });
    return data.data?.length ? data.data : [];
  }

  private async fetchTrackingsFromWarehouse(boxId: number, page: number) {
    const apiUrl: string = WAREHOUSE_API_URL || '';
    const apiToken: string = WAREHOUSE_API_TOKEN || '';
    const query = {
      populate: 'tracking_type',
      filters: {
        box: boxId,
      },
      pagination: {
        page,
        pageSize: 100,
      },
    };
    console.log(apiUrl + '/api/trackings?' + qs.stringify(query));
    const { data } = await axios.get(apiUrl + '/api/trackings?' + qs.stringify(query), {
      headers: {
        Authorization: `Bearer ${apiToken}`,
      },
    });
    return data;
  }

  private async insertTracking(tracking: any, awbId: number, boxId: number, partnerId: number) {
    const trackingTypeUID = tracking.tracking_type?.uid;
    delete tracking.id;
    delete tracking.tracking_type;
    delete tracking.isSynced;

    const _tracking: Tracking = await Tracking.query().insert(tracking);
    await _tracking.$relatedQuery('awb').relate(awbId);
    await _tracking.$relatedQuery('box').relate(boxId);
    await _tracking.$relatedQuery('businessPartner').relate(partnerId);
    if (trackingTypeUID) {
      const trackingType: TrackingType = await TrackingType.query().findOne('uid', trackingTypeUID);
      if (trackingType) {
        await _tracking.$relatedQuery('trackingType').relate(trackingType.id);
      }
    }
  }

  public async searchAwb(keyword) {
    const awbs = await Awb.query().select('id', 'code').whereLike('code', `%${keyword}%`);
    return awbs;
  }

  public async getDetail(req, id: number, params) {
    const queryBuilder = Awb.query().from('awbs as aw').findById(id);
    const { user } = req;
    const { trackingCode } = params;
    let { warehouse_id } = params;
    if (req.permission_business_logic) {
      switch (req.permission_business_logic) {
        case 1:
          break;
        case 2:
          warehouse_id = user.warehouseVN[0].id;
        default:
          break;
      }
    }

    const listTracking = await queryBuilder
      .withGraphFetched('tracking')
      .withGraphFetched('box')
      .leftJoinRelated('box')
      .modifyGraph('box', builder => {
        if (warehouse_id) {
          builder.leftJoinRelated('warehouseVN').where('warehouseVN.id', warehouse_id).orWhereNull('warehouseVN');
        }
        if (trackingCode) {
          builder
            .innerJoin('trackings_box_links', 'trackings_box_links.box_id', '=', 'boxes.id')
            .innerJoin('trackings', 'trackings.id', '=', 'trackings_box_links.tracking_id')
            .whereLike('trackings.code', `%${trackingCode}%`);
        }
        builder.withGraphFetched('warehouseVN').groupBy('boxes.id', 'boxes_awb_links.awb_id');
      });

    if (!listTracking) throw new HttpException(404, "Awb doesn't exist");

    let trackingTotalMoney = 0;
    let trackingCalculationWeight = 0;
    let trackingMiningWeight = 0;
    let customResults = {};
    let trackingQuantity = 0;
    let trackingExploitedQuantity = 0;
    listTracking.tracking.forEach(track => {
      trackingTotalMoney += Number(track.trackingTotalMoney);
      trackingCalculationWeight += Number(track.trackingCalculationWeight);
      trackingMiningWeight += Number(track.trackingMiningWeight);
    });

    await Promise.all(
      listTracking.box.map(async box => {
        const boxQuery = await Box.query().withGraphFetched('trackingBoxes as trackings').findById(box.id);
        trackingQuantity += boxQuery.trackings.length;
        const trackingsWithExploitStatus = boxQuery.trackings.filter(
          tr =>
            tr.exploitStatus === 'Hoàn thành' ||
            tr.exploitStatus === 'Đã khai thác' ||
            tr.exploitStatus === 'Đã đóng hàng' ||
            tr.exploitStatus === 'Đang giao hàng',
        );
        trackingExploitedQuantity += trackingsWithExploitStatus.length;
      }),
    );

    delete listTracking.tracking;
    delete listTracking.trackingQuantity;
    customResults = {
      ...listTracking,
      trackingTotalMoney,
      trackingCalculationWeight,
      trackingMiningWeight,
      trackingQuantity,
      trackingExploitedQuantity,
    };

    return customResults;
  }
}

export default AwbService;
