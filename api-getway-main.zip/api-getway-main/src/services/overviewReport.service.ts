import { EXPLOITATION_STAFF_ROLE_ID, SALE_ROLE_ID } from '@/constant/constant';
import { Awb } from '@/models/awb.model';
import { BoxesAwbLinks } from '@/models/awbBoxLink.model';
import { Customer } from '@/models/customer.model.';
import { CustomerTransactionLogs } from '@/models/customerTransactionLogs.model';
import { CustomerTransactionLogsCustomerLinks } from '@/models/customerTransactionLogsCustomerLinks.model';
import { DeliveryBill } from '@/models/deliveryBill.model';
import { Tracking } from '@/models/tracking.model';
import { TrackingsAwbLinks } from '@/models/trackingAwbLinks.model';
import { TrackingType } from '@/models/trackingType.model';
import { TrackingsExploitedByLinks } from '@/models/trackingsExploitedByLinks.model';
import { UserRoleLinks } from '@/models/userRoleLinks.model';
import { Users } from '@/models/users.model';
import { WarehouseConfig } from '@/models/warehouseConfig.model';
import * as ExcelJS from 'exceljs';
class OverviewReportService {
  static getInstant(): OverviewReportService {
    return new OverviewReportService();
  }

  public async getOverviewReport(user) {
    const totalBalanceQueryBuilder: any = Customer.query().sum('balance as totalBalance').where('balance', '<', '0').first();
    const totalPaymentQueryBuilder: any = CustomerTransactionLogs.query()
      .where('customer_transaction_type', 'THANH TOÁN')
      .sum('customerTransactionMoney as totalPayment')
      .first();

    const totalDepositQueryBuilder: any = CustomerTransactionLogs.query()
      .where('customer_transaction_type', 'NẠP TIỀN')
      .sum('customerTransactionMoney as totalDeposit')
      .first();
    const customerCountQueryBuilder: any = Customer.query().count('id as customerCount').first();
    if (user.role.type === 'nhan_vien_kinh_doanh') {
      const listCustomer = await Users.query()
        .findById(user.id)
        .withGraphFetched('saleOfCustomer')
        .modifyGraph('saleOfCustomer', builder => builder.select('customers.id'));
      const listCustomerId = listCustomer.saleOfCustomer.map(c => c.id);
      totalBalanceQueryBuilder.whereIn('id', listCustomerId);
      customerCountQueryBuilder.whereIn('id', listCustomerId);

      const transactionList = await CustomerTransactionLogsCustomerLinks.query().whereIn('customer_id', listCustomerId);
      const transactionListId = transactionList.map(c => c.customerTransactionLogId);
      totalPaymentQueryBuilder.whereIn('id', transactionListId);
      totalDepositQueryBuilder.whereIn('id', transactionListId);
    }

    return {
      totalBalance: (await totalBalanceQueryBuilder)?.totalBalance || 0,
      totalPayment: (await totalPaymentQueryBuilder)?.totalPayment || 0,
      totalDeposit: (await totalDepositQueryBuilder)?.totalDeposit || 0,
      customerCount: (await customerCountQueryBuilder)?.customerCount || 0,
    };
  }

  public async getOverviewRevenueByWarehouse(user, queries) {
    const { fromDate, toDate, warehouseId } = queries;
    const warehouseQueryBuilder = WarehouseConfig.query().select('id', 'name');
    if (warehouseId) {
      warehouseQueryBuilder.where('id', warehouseId);
    }
    const warehouses: any = await warehouseQueryBuilder;
    const promises = warehouses.map(async warehouse => {
      const trackings = Tracking.query()
        .select('trackings.id', 'tracking_mining_weight', 'tracking_calculation_weight', 'tracking_total_money')
        .innerJoinRelated('deliveryBill as bills')
        .innerJoin('trackings_warehouse_vn_links', 'trackings.id', '=', 'trackings_warehouse_vn_links.tracking_id')
        .where('trackings_warehouse_vn_links.warehouse_config_id', warehouse.id)
        .groupBy('trackings.id');

      const statisticByDeliveryBillQueryBuilder = DeliveryBill.query()
        .select()
        .from('delivery_bills')
        .leftJoinRelated('tracking as tr')
        .innerJoin('trackings_warehouse_vn_links', 'tr.id', '=', 'trackings_warehouse_vn_links.tracking_id')
        .where('trackings_warehouse_vn_links.warehouse_config_id', warehouse.id)
        .groupBy('delivery_bills.id');

      if (fromDate && toDate) {
        trackings.whereBetween('bills.created_at', [fromDate, toDate]);
        statisticByDeliveryBillQueryBuilder.whereBetween('delivery_bills.created_at', [fromDate, toDate]);
      }
      const { trackingCount, trackingMiningWeight, trackingCalculationWeight, trackingTotalMoney } = (await trackings).reduce(
        (accumulator, x) => {
          accumulator.trackingCount++;
          accumulator.trackingMiningWeight += Number(x.trackingMiningWeight);
          accumulator.trackingCalculationWeight += Number(x.trackingCalculationWeight);
          accumulator.trackingTotalMoney += Number(x.trackingTotalMoney);
          return accumulator;
        },
        { trackingCount: 0, trackingMiningWeight: 0, trackingCalculationWeight: 0, trackingTotalMoney: 0 },
      );

      const statisticByDeliveryBill = (await statisticByDeliveryBillQueryBuilder) as any;
      const avgSalePrice = Number(trackingCalculationWeight) !== 0 ? (Number(trackingTotalMoney) || 0) / Number(trackingCalculationWeight) : 0;
      warehouse.delivery_bill_count = Number(statisticByDeliveryBill.length) || 0;
      warehouse.tracking_mining_weight = Number(trackingMiningWeight) || 0;
      warehouse.tracking_calculation_weight = Number(trackingCalculationWeight) || 0;
      warehouse.tracking_total_money = Number(trackingTotalMoney) || 0;
      warehouse.tracking_count = Number(trackingCount) || 0;
      warehouse.avg_sale_price = avgSalePrice || 0;
    });

    await Promise.all(promises);
    return {
      warehouses,
    };
  }

  public async getOverviewRevenueByWarehouseDetail(user, queries, warehouseId) {
    const { fromDate, toDate } = queries;

    const trackingTypes: any = await TrackingType.query();
    let totalTrackingMiningWeight = 0;
    let totalTrackingCalculationWeight = 0;
    let totalTrackingTotalMoney = 0;
    const promises = trackingTypes.map(async type => {
      const trackings = Tracking.query()
        .select('trackings.id', 'tracking_mining_weight', 'tracking_calculation_weight', 'tracking_total_money', 'tracking_surcharge')
        .innerJoinRelated('deliveryBill as bills')
        .innerJoin('trackings_warehouse_vn_links', 'trackings.id', '=', 'trackings_warehouse_vn_links.tracking_id')
        .leftJoinRelated('trackingType')
        .where('trackings_warehouse_vn_links.warehouse_config_id', warehouseId)
        .where('trackingType.id', type.id)
        .groupBy('trackings.id');
      if (fromDate && toDate) {
        trackings.whereBetween('bills.created_at', [fromDate, toDate]);
      }
      const { trackingCount, trackingMiningWeight, trackingCalculationWeight, trackingTotalMoney, trackingSurcharge } = (await trackings).reduce(
        (accumulator, x) => {
          accumulator.trackingCount++;
          accumulator.trackingMiningWeight += Number(x.trackingMiningWeight);
          accumulator.trackingCalculationWeight += Number(x.trackingCalculationWeight);
          accumulator.trackingTotalMoney += Number(x.trackingTotalMoney);
          accumulator.trackingSurcharge += Number(x.trackingSurcharge);

          totalTrackingMiningWeight += Number(x.trackingMiningWeight);
          totalTrackingCalculationWeight += Number(x.trackingCalculationWeight);
          totalTrackingTotalMoney += Number(x.trackingTotalMoney);

          return accumulator;
        },
        { trackingCount: 0, trackingMiningWeight: 0, trackingCalculationWeight: 0, trackingTotalMoney: 0, trackingSurcharge: 0 },
      );

      const avgSalePrice = Number(trackingCalculationWeight) !== 0 ? (Number(trackingTotalMoney) || 0) / Number(trackingCalculationWeight) : 0;
      type.tracking_mining_weight = Number(trackingMiningWeight) || 0;
      type.tracking_calculation_weight = Number(trackingCalculationWeight) || 0;
      type.tracking_total_money = Number(trackingTotalMoney) || 0;
      type.tracking_count = Number(trackingCount) || 0;
      type.tracking_surcharge = Number(trackingSurcharge) || 0;
      type.avg_sale_price = avgSalePrice || 0;
    });

    await Promise.all(promises);

    trackingTypes.map(type => {
      type.proportionOfMiningWeight = type.tracking_mining_weight / totalTrackingMiningWeight;
      type.proportionOfCalculationWeight = type.tracking_calculation_weight / totalTrackingCalculationWeight;
      type.proportionOfTotalMoney = type.tracking_total_money / totalTrackingTotalMoney;
    });
    return {
      trackingTypes,
    };
  }

  public async getOverviewRevenueByDeliveryBillSale(user, queries) {
    const { page = 0, pageSize = 10, fromDate, toDate, fullname, warehouseId, orderBy } = queries;
    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }
    const saleStaffId = (await UserRoleLinks.query().select().where('role_id', SALE_ROLE_ID)).map((x: any) => x.userId);
    const saleStaffQueryBuilder = Users.query().from('up_users as u').select('u.id', 'u.username', 'u.fullname').whereIn('u.id', saleStaffId);
    if (fullname) {
      saleStaffQueryBuilder.whereILike('u.fullname', `%${fullname}%`);
    }
    if (orderBy) {
      const [field, sortOrder] = orderBy.split('-');
      if (['id', 'createdAt'].includes(field)) {
        saleStaffQueryBuilder.orderBy(`u.${field}`, sortOrder);
      } else {
        saleStaffQueryBuilder
          .innerJoin('customers_sale_links', 'customers_sale_links.user_id', '=', 'u.id')
          .innerJoin('trackings_customer_links', 'customers_sale_links.customer_id', '=', 'trackings_customer_links.customer_id')
          .innerJoin('trackings as tr', 'trackings_customer_links.tracking_id', '=', 'tr.id')
          .leftJoin('trackings_delivery_bill_links', 'trackings_delivery_bill_links.tracking_id', '=', 'tr.id')
          .leftJoin('delivery_bills', 'delivery_bills.id', '=', 'trackings_delivery_bill_links.delivery_bill_id')
          .groupBy('u.id')
          .orderByRaw(`SUM(tr.${field}) ` + sortOrder);
        if (fromDate && toDate) {
          saleStaffQueryBuilder.whereBetween('delivery_bills.created_at', [fromDate, toDate]);
        }
        if (warehouseId) {
          saleStaffQueryBuilder
            .innerJoin('trackings_warehouse_vn_links', 'tr.id', '=', 'trackings_warehouse_vn_links.tracking_id')
            .where('trackings_warehouse_vn_links.warehouse_config_id', warehouseId);
        }
      }
    } else {
      saleStaffQueryBuilder.orderBy('u.createdAt', 'desc');
    }

    const miningStaff: any = await saleStaffQueryBuilder.withGraphFetched('warehouseVN').page(pageIndex, pageSize);
    const { results, total } = miningStaff as any;

    const promises = results.map(async staff => {
      staff.warehouse_name = staff.warehouseVN.length !== 0 ? staff.warehouseVN[0].name : null;

      const trackings = Tracking.query()
        .select('tr.id', 'tracking_mining_weight', 'tracking_calculation_weight', 'tracking_total_money')
        .from('trackings as tr')
        .innerJoinRelated('deliveryBill')
        .innerJoin('trackings_customer_links', 'tr.id', '=', 'trackings_customer_links.tracking_id')
        .innerJoin('customers', 'trackings_customer_links.customer_id', '=', 'customers.id')
        .innerJoin('customers_sale_links', 'customers_sale_links.customer_id', '=', 'customers.id')
        .where('customers_sale_links.user_id', staff.id)
        .whereIn('exploit_status', ['Đã khai thác', 'Đã đóng hàng', 'Đang giao hàng', 'Hoàn thành'])
        .groupBy('tr.id');
      const statisticByDeliveryBillQueryBuilder = DeliveryBill.query()
        .select()
        .from('delivery_bills')
        .leftJoinRelated('tracking as tr')
        .innerJoin('trackings_customer_links', 'tr.id', '=', 'trackings_customer_links.tracking_id')
        .innerJoin('customers', 'trackings_customer_links.customer_id', '=', 'customers.id')
        .innerJoin('customers_sale_links', 'customers_sale_links.customer_id', '=', 'customers.id')
        .where('customers_sale_links.user_id', staff.id)
        .groupBy('delivery_bills.id');

      if (fromDate && toDate) {
        trackings.whereBetween('deliveryBill.created_at', [fromDate, toDate]);
        statisticByDeliveryBillQueryBuilder.whereBetween('delivery_bills.created_at', [fromDate, toDate]);
      }
      if (warehouseId) {
        trackings
          .innerJoin('trackings_warehouse_vn_links', 'tr.id', '=', 'trackings_warehouse_vn_links.tracking_id')
          .where('trackings_warehouse_vn_links.warehouse_config_id', warehouseId);
        statisticByDeliveryBillQueryBuilder
          .innerJoin('trackings_warehouse_vn_links', 'tr.id', '=', 'trackings_warehouse_vn_links.tracking_id')
          .where('trackings_warehouse_vn_links.warehouse_config_id', warehouseId);
      }

      const { trackingCount, trackingMiningWeight, trackingCalculationWeight, trackingTotalMoney } = (await trackings).reduce(
        (accumulator, x) => {
          accumulator.trackingCount++;
          accumulator.trackingMiningWeight += Number(x.trackingMiningWeight);
          accumulator.trackingCalculationWeight += Number(x.trackingCalculationWeight);
          accumulator.trackingTotalMoney += Number(x.trackingTotalMoney);
          return accumulator;
        },
        { trackingCount: 0, trackingMiningWeight: 0, trackingCalculationWeight: 0, trackingTotalMoney: 0 },
      );

      const statisticByDeliveryBill = (await statisticByDeliveryBillQueryBuilder) as any;
      const statisticByCustomer = (await Customer.query()
        .innerJoin('customers_sale_links', 'customers_sale_links.customer_id', '=', 'customers.id')
        .where('customers_sale_links.user_id', staff.id)
        .count('customers.id as customer_count')
        .first()) as any;
      staff.delivery_bill_count = Number(statisticByDeliveryBill.length) || 0;
      staff.customer_count = Number(statisticByCustomer.customerCount) || 0;
      staff.tracking_count = Number(trackingCount) || 0;
      staff.tracking_mining_weight = Number(trackingMiningWeight) || 0;
      staff.tracking_calculation_weight = Number(trackingCalculationWeight) || 0;
      staff.tracking_total_money = Number(trackingTotalMoney) || 0;
      delete staff['warehouseVN'];
    });

    await Promise.all(promises);

    return {
      paginations: {
        page: Number(pageIndex) + 1,
        pageSize: Number(pageSize),
        total: total,
        totalPage: Math.ceil(total / pageSize),
      },
      data: results,
    };
  }

  public async getOverviewRevenueByDeliveryBillCustomer(user, queries, isPaginated) {
    const { page = 0, pageSize = 10, fromDate, toDate, fullname, warehouseId, orderBy } = queries;
    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }
    const customerQueryBuilder = Customer.query().select().withGraphFetched('sale');
    if (fullname) {
      customerQueryBuilder.whereILike('name', `%${fullname}%`);
    }
    if (orderBy) {
      const [field, sortOrder] = orderBy.split('-');
      if (['id'].includes(field)) {
        customerQueryBuilder.orderBy(`customers.${field}`, sortOrder);
      } else {
        customerQueryBuilder
          .leftJoin('trackings_customer_links', 'customers.id', '=', 'trackings_customer_links.customer_id')
          .leftJoin('trackings as tr', 'tr.id', '=', 'trackings_customer_links.tracking_id')
          .leftJoin('trackings_delivery_bill_links', 'trackings_delivery_bill_links.tracking_id', '=', 'tr.id')
          .leftJoin('delivery_bills', 'delivery_bills.id', '=', 'trackings_delivery_bill_links.delivery_bill_id')
          .groupBy('customers.id')
          .orderByRaw(`SUM(tr.${field}) ` + sortOrder);
        if (fromDate && toDate) {
          customerQueryBuilder.whereBetween('delivery_bills.created_at', [fromDate, toDate]);
        }
        if (warehouseId) {
          customerQueryBuilder
            .innerJoin('trackings_warehouse_vn_links', 'tr.id', '=', 'trackings_warehouse_vn_links.tracking_id')
            .where('trackings_warehouse_vn_links.warehouse_config_id', warehouseId);
        }
      }
    } else {
      customerQueryBuilder.orderBy('customers.id', 'desc');
    }

    const customer: any = isPaginated ? await customerQueryBuilder.page(pageIndex, pageSize) : { results: await customerQueryBuilder, total: -1 };
    const promises = customer.results.map(async customer => {
      const trackings = Tracking.query()
        .select('tr.id', 'tracking_mining_weight', 'tracking_calculation_weight', 'tracking_total_money')
        .from('trackings as tr')
        .innerJoinRelated('deliveryBill')
        .innerJoin('trackings_customer_links', 'tr.id', '=', 'trackings_customer_links.tracking_id')
        .where('trackings_customer_links.customer_id', customer.id)
        .whereIn('exploit_status', ['Đã khai thác', 'Đã đóng hàng', 'Đang giao hàng', 'Hoàn thành'])
        .groupBy('tr.id');
      const statisticByDeliveryBillQueryBuilder = DeliveryBill.query()
        .select()
        .from('delivery_bills')
        .leftJoinRelated('tracking as tr')
        .innerJoin('trackings_customer_links', 'tr.id', '=', 'trackings_customer_links.tracking_id')
        .where('trackings_customer_links.customer_id', customer.id)
        .groupBy('delivery_bills.id');
      if (fromDate && toDate) {
        trackings.whereBetween('deliveryBill.created_at', [fromDate, toDate]);
        statisticByDeliveryBillQueryBuilder.whereBetween('delivery_bills.created_at', [fromDate, toDate]);
      }
      if (warehouseId) {
        trackings
          .innerJoin('trackings_warehouse_vn_links', 'tr.id', '=', 'trackings_warehouse_vn_links.tracking_id')
          .where('trackings_warehouse_vn_links.warehouse_config_id', warehouseId);
        statisticByDeliveryBillQueryBuilder
          .innerJoin('trackings_warehouse_vn_links', 'tr.id', '=', 'trackings_warehouse_vn_links.tracking_id')
          .where('trackings_warehouse_vn_links.warehouse_config_id', warehouseId);
      }
      const { trackingCount, trackingMiningWeight, trackingCalculationWeight, trackingTotalMoney } = (await trackings).reduce(
        (accumulator, x) => {
          accumulator.trackingCount++;
          accumulator.trackingMiningWeight += Number(x.trackingMiningWeight);
          accumulator.trackingCalculationWeight += Number(x.trackingCalculationWeight);
          accumulator.trackingTotalMoney += Number(x.trackingTotalMoney);
          return accumulator;
        },
        { trackingCount: 0, trackingMiningWeight: 0, trackingCalculationWeight: 0, trackingTotalMoney: 0 },
      );
      const statisticByDeliveryBill = (await statisticByDeliveryBillQueryBuilder) as any;
      customer.delivery_bill_count = Number(statisticByDeliveryBill.length) || 0;
      customer.tracking_count = Number(trackingCount) || 0;
      customer.tracking_mining_weight = Number(trackingMiningWeight) || 0;
      customer.tracking_calculation_weight = Number(trackingCalculationWeight) || 0;
      customer.tracking_total_money = Number(trackingTotalMoney) || 0;
      customer.sale_name = customer.sale[0]?.fullname || null;
      customer.fullname = customer.name;
      delete customer.sale;
    });

    await Promise.all(promises);
    return {
      paginations: {
        page: Number(pageIndex) + 1,
        pageSize: Number(pageSize),
        total: customer.total,
        totalPage: Math.ceil(customer.total / pageSize),
      },
      data: customer.results,
    };
  }

  public async getOverviewRevenueByAwb(user, queries) {
    const { page = 0, pageSize = 10, fromDate, toDate, warehouseId } = queries;
    let pageIndex = 0;

    if (page) {
      pageIndex = page - 1;
    }

    const awbQueryBuilder = Awb.query().select('awbs.id', 'awbs.status', 'awbs.code', 'awbs.exploitStatus').page(pageIndex, pageSize);
    if (warehouseId) {
      awbQueryBuilder
        .leftJoinRelated('box')
        .leftJoin('boxes_warehouse_vn_links', 'box.id', '=', 'boxes_warehouse_vn_links.box_id')
        .where('boxes_warehouse_vn_links.warehouse_config_id', warehouseId);
    }
    if (fromDate && toDate) {
      awbQueryBuilder.whereBetween('awbs.updated_at', [fromDate, toDate]);
    }
    const awbs = await awbQueryBuilder;
    const { results, total } = awbs as any;
    const promises = results.map(async (awb: any) => {
      const trackings = await TrackingsAwbLinks.query().select().where('awb_id', awb.id);
      const trackingIds = trackings.map((tr: any) => tr.trackingId);
      let statisticByTracking: any = Tracking.query()
        .select()
        .from('trackings as tr')
        .whereIn('tr.id', trackingIds)
        .count('tr.id as tracking_count')
        .sum('tracking_mining_weight as tracking_mining_weight')
        .sum('tracking_calculation_weight as tracking_calculation_weight')
        .select(
          Tracking.raw(`SUM(CASE
          WHEN "tracking_total_money" IS DISTINCT FROM NULL AND NOT "tracking_total_money"::TEXT = 'NaN'
          THEN CAST("tracking_total_money" AS BIGINT)
          ELSE 0
        END) AS "tracking_total_money"`),
        )
        .first();

      if (warehouseId) {
        statisticByTracking
          .innerJoin('trackings_warehouse_vn_links', 'tr.id', '=', 'trackings_warehouse_vn_links.tracking_id')
          .where('trackings_warehouse_vn_links.warehouse_config_id', warehouseId);
      }
      statisticByTracking = await statisticByTracking;
      const statisticByBoxes = (await BoxesAwbLinks.query()
        .select()
        .where('awb_id', awb.id)
        .count('boxes_awb_links.id as boxes_count')
        .first()) as any;

      awb.boxes_count = Number(statisticByBoxes.boxesCount) || 0;
      awb.tracking_count = Number(statisticByTracking.trackingCount) || 0;
      awb.tracking_mining_weight = Number(statisticByTracking.trackingMiningWeight) || 0;
      awb.tracking_calculation_weight = Number(statisticByTracking.trackingCalculationWeight) || 0;
      awb.tracking_total_money = Number(statisticByTracking.trackingTotalMoney) || 0;
    });

    await Promise.all(promises);
    return {
      paginations: {
        page: Number(pageIndex) + 1,
        pageSize: Number(pageSize),
        total: total,
        totalPage: Math.ceil(awbs.total / pageSize),
      },
      data: awbs.results,
    };
  }

  public async getTrackingStatistic(user, queries) {
    const { fromDate, toDate, warehouseId } = queries;
    const statisticByTrackingsQueryBuilder = Tracking.query()
      .select('tr1.id', 'tr1.created_at', 'tr1.import_date', 'tr1.exploited_date')
      .from('trackings as tr1')
      .whereNotNull('created_at')
      .whereNotNull('exploited_date')
      .whereNotNull('import_date');
    const trackingTotalMoneyQueryBuilder = Tracking.query()
      .select()
      .from('trackings as tr2')
      .count('tr2.id as tracking_count')
      .sum('tr2.tracking_calculation_weight as tracking_calculation_weight')
      .select(
        Tracking.raw(`SUM(CASE
        WHEN "tracking_total_money" IS DISTINCT FROM NULL AND NOT "tracking_total_money"::TEXT = 'NaN'
        THEN CAST("tracking_total_money" AS BIGINT)
        ELSE 0
      END) AS "tracking_total_money"`),
      )
      .whereNotNull('created_at')
      .whereNotNull('exploited_date')
      .whereNotNull('import_date')
      .first();
    const transactionTotalMoneyQueryBuilder = CustomerTransactionLogs.query()
      .select()
      .sum('customer_transaction_money as customer_transaction_money')
      .where('customer_transaction_type', 'THANH TOÁN')
      .where('status', 'hoàn thành')
      .first();
    if (fromDate && toDate) {
      statisticByTrackingsQueryBuilder.whereBetween('import_date', [fromDate, toDate]);
      trackingTotalMoneyQueryBuilder.whereBetween('import_date', [fromDate, toDate]);
      transactionTotalMoneyQueryBuilder.whereBetween('updated_at', [fromDate, toDate]);
    }
    if (warehouseId) {
      statisticByTrackingsQueryBuilder
        .innerJoin('trackings_warehouse_vn_links', 'tr1.id', '=', 'trackings_warehouse_vn_links.tracking_id')
        .where('trackings_warehouse_vn_links.warehouse_config_id', warehouseId);
      trackingTotalMoneyQueryBuilder
        .innerJoin('trackings_warehouse_vn_links', 'tr2.id', '=', 'trackings_warehouse_vn_links.tracking_id')
        .where('trackings_warehouse_vn_links.warehouse_config_id', warehouseId);
    }
    const trackings = (await statisticByTrackingsQueryBuilder) as any;
    const trackingTotalMoney = (await trackingTotalMoneyQueryBuilder) as any;
    const transactionTotalMoney = (await transactionTotalMoneyQueryBuilder) as any;
    let subtractions = 0;
    const tracking_by_date = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    const promises = trackings.map(async tracking => {
      if (tracking.importDate && tracking.exploitedDate) {
        const differenceInMiliseconds = Math.abs(tracking.importDate - tracking.exploitedDate);
        const differenceInDay = Math.round(differenceInMiliseconds / (1000 * 60 * 60 * 24));
        subtractions += differenceInDay;
        switch (true) {
          case differenceInDay >= 0 && differenceInDay <= 4:
            tracking_by_date[0] += 1;
            break;
          case differenceInDay >= 5 && differenceInDay <= 6:
            tracking_by_date[1] += 1;
            break;
          case differenceInDay >= 7 && differenceInDay <= 8:
            tracking_by_date[2] += 1;
            break;
          case differenceInDay >= 9 && differenceInDay <= 10:
            tracking_by_date[3] += 1;
            break;
          case differenceInDay >= 11 && differenceInDay <= 12:
            tracking_by_date[4] += 1;
            break;
          case differenceInDay >= 13 && differenceInDay <= 14:
            tracking_by_date[5] += 1;
            break;
          case differenceInDay >= 15 && differenceInDay <= 16:
            tracking_by_date[6] += 1;
            break;
          case differenceInDay >= 17 && differenceInDay <= 18:
            tracking_by_date[7] += 1;
            break;
          case differenceInDay >= 19 && differenceInDay <= 20:
            tracking_by_date[8] += 1;
            break;
          default:
            tracking_by_date[9] += 1;
        }
      }
    });

    await Promise.all(promises);
    return {
      total_money: transactionTotalMoney.customerTransactionMoney,
      tracking_count: trackingTotalMoney.trackingCount,
      avg_processing_time: Math.round(subtractions / trackingTotalMoney.trackingCount),
      tracking_date: tracking_by_date,
    };
  }

  public async getExploitationStatistic(user, queries, isPaginated: boolean) {
    const { page = 0, pageSize = 10, fromDate, toDate, employee_id } = queries;
    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }

    const miningStaffQueryBuilder = Users.query()
      .select('id', 'fullname')
      .whereIn('id', function () {
        this.select('user_id').from('trackings_exploited_by_links');
      });
    if (employee_id) {
      miningStaffQueryBuilder.where('id', employee_id);
    }
    const miningStaff: any = isPaginated
      ? await miningStaffQueryBuilder.page(pageIndex, pageSize)
      : { results: await miningStaffQueryBuilder, total: -1 };
    const { results, total } = miningStaff as any;
    const promises = results.map(async staff => {
      const trackingIds = (await TrackingsExploitedByLinks.query().select().where('user_id', staff.id)).map((tr: any) => tr.trackingId);
      const statisticByTrackingQueryBuilder = Tracking.query()
        .select()
        .whereIn('exploit_status', ['Đã khai thác', 'Đã đóng hàng', 'Đang giao hàng', 'Hoàn thành'])
        .whereIn('id', trackingIds)
        .where('is_deleted', false)
        .sum('tracking_mining_weight as tracking_mining_weight')
        .count('id as tracking_count')
        .first();
      if (fromDate && toDate) {
        statisticByTrackingQueryBuilder.whereBetween('exploitedDate', [fromDate, toDate]);
      }

      const statisticByTracking = (await statisticByTrackingQueryBuilder) as any;
      staff.delivery_bill_count = Number(statisticByTracking.trackingCount) || 0;
      staff.tracking_mining_weight = Number(statisticByTracking.trackingMiningWeight) || 0;
    });

    await Promise.all(promises);
    return {
      paginations: {
        page: Number(pageIndex) + 1,
        pageSize: Number(pageSize),
        total: total,
        totalPage: Math.ceil(total / pageSize),
      },
      data: results,
    };
  }

  public async getDetailRevenueByDeliveryBillSale(user, saleId, queries) {
    const { fromDate, toDate, fullname, warehouseId } = queries;

    const saleStaffId = (await UserRoleLinks.query().select().where('role_id', SALE_ROLE_ID)).map((x: any) => x.userId);
    const saleStaffQueryBuilder = Users.query().from('up_users as u').select('u.id', 'u.username', 'u.fullname').whereIn('u.id', saleStaffId);
    if (fullname) {
      saleStaffQueryBuilder.whereILike('u.fullname', `%${fullname}%`);
    }
    if (saleId) {
      saleStaffQueryBuilder.where('id', saleId);
    }

    const miningStaff: any = await saleStaffQueryBuilder.withGraphFetched('warehouseVN');
    const results = miningStaff as any;

    const promises = results.map(async staff => {
      staff.warehouse_name = staff.warehouseVN.length !== 0 ? staff.warehouseVN[0].name : null;

      const statisticByDeliveryBillQueryBuilder = DeliveryBill.query()
        .select()
        .from('delivery_bills')
        .leftJoinRelated('tracking as tr')
        .innerJoin('trackings_customer_links', 'tr.id', '=', 'trackings_customer_links.tracking_id')
        .innerJoin('customers', 'trackings_customer_links.customer_id', '=', 'customers.id')
        .innerJoin('customers_sale_links', 'customers_sale_links.customer_id', '=', 'customers.id')
        .where('customers_sale_links.user_id', staff.id)
        .withGraphFetched('tracking')
        .withGraphFetched('customer')
        .orderBy('created_at')
        .groupBy('delivery_bills.id');

      if (fromDate && toDate) {
        statisticByDeliveryBillQueryBuilder.whereBetween('delivery_bills.created_at', [fromDate, toDate]);
      }
      if (warehouseId) {
        statisticByDeliveryBillQueryBuilder
          .innerJoin('trackings_warehouse_vn_links', 'tr.id', '=', 'trackings_warehouse_vn_links.tracking_id')
          .where('trackings_warehouse_vn_links.warehouse_config_id', warehouseId);
      }
      let statisticByDeliveryBill = (await statisticByDeliveryBillQueryBuilder) as any;

      statisticByDeliveryBill = statisticByDeliveryBill.map(bill => {
        let totalTrackingMiningWeight = 0;
        let totalTrackingCalculationWeight = 0;
        let trackingTotalMoney = 0;
        let trackingTotalShippingFee = 0;

        bill.tracking.forEach(tr => {
          totalTrackingMiningWeight += Number(tr.trackingMiningWeight);
          totalTrackingCalculationWeight += Number(tr.trackingCalculationWeight);
          trackingTotalMoney += Number(tr.trackingTotalMoney);
          trackingTotalShippingFee += Number(tr.trackingShippingFee);
        });
        return {
          ...bill,
          totalTrackingMiningWeight,
          totalTrackingCalculationWeight,
          trackingTotalMoney,
          trackingTotalShippingFee,
        };
      });
      staff.delivery_bill_count = Number(statisticByDeliveryBill.length) || 0;

      delete staff['warehouseVN'];
      staff.statisticByDeliveryBill = statisticByDeliveryBill;
    });

    await Promise.all(promises);
    return results[0];
  }

  public async getRevenueByDeliveryReport(user, queries) {
    const { fromDate, toDate, warehouseId } = queries;

    const statisticByDeliveryBillQueryBuilder = DeliveryBill.query()
      .select()
      .from('delivery_bills')
      .innerJoinRelated('tracking as tr')
      .withGraphFetched('tracking')
      .modifyGraph('tracking', builder => builder.withGraphFetched('customer'))
      .withGraphFetched('customer')
      .modifyGraph('customer', builder => builder.withGraphFetched('sale'))
      .orderBy('created_at')
      .groupBy('delivery_bills.id');

    if (fromDate && toDate) {
      statisticByDeliveryBillQueryBuilder.whereBetween('delivery_bills.created_at', [fromDate, toDate]);
    }
    if (warehouseId) {
      statisticByDeliveryBillQueryBuilder
        .innerJoin('trackings_warehouse_vn_links', 'tr.id', '=', 'trackings_warehouse_vn_links.tracking_id')
        .where('trackings_warehouse_vn_links.warehouse_config_id', warehouseId);
    }
    let statisticByDeliveryBill = (await statisticByDeliveryBillQueryBuilder) as any;

    statisticByDeliveryBill = statisticByDeliveryBill.map(bill => {
      let totalTrackingMiningWeight = 0;
      let totalTrackingCalculationWeight = 0;
      let trackingTotalMoney = 0;
      let trackingTotalShippingFee = 0;

      bill.tracking.forEach(tr => {
        totalTrackingMiningWeight += Number(tr.trackingMiningWeight);
        totalTrackingCalculationWeight += Number(tr.trackingCalculationWeight);
        trackingTotalMoney += Number(tr.trackingTotalMoney);
        trackingTotalShippingFee += Number(tr.trackingShippingFee);
      });
      return {
        ...bill,
        totalTrackingMiningWeight,
        totalTrackingCalculationWeight,
        trackingTotalMoney,
        trackingTotalShippingFee,
      };
    });

    return statisticByDeliveryBill;
  }

  public async exportExcel(data, res) {
    try {
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Sheet 1');

      // Add header row
      const headerRow = worksheet.getRow(1);
      headerRow.values = ['ID', 'Họ tên', 'Số lượng PXK', 'Trọng lượng tracking đã khai thác'];
      // Add data rows
      data.data.forEach((item, index) => {
        const row = worksheet.getRow(index + 2);
        row.values = [item.id, item.fullname, item.delivery_bill_count, item.tracking_mining_weight];
      });

      // Adjust column widths based on the length of the values
      worksheet.columns.forEach((column, colNumber) => {
        let maxLength = 0;
        column.eachCell({ includeEmpty: true }, cell => {
          const len = cell.value ? String(cell.value).length : 0;
          if (len > maxLength) {
            maxLength = len;
          }
        });
        column.width = maxLength < 10 ? 10 : maxLength + 2; // Adjust as needed
      });

      // Set response headers
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=excel-export.xlsx');

      // Pipe the workbook to the response
      await workbook.xlsx.write(res);
      res.end();
    } catch (error) {
      console.error(error);
      res.status(500).send('Internal Server Error');
    }
  }

  public async exportExcelDeliveryBillReport(data, res) {
    try {
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet(`Báo cáo doanh thu theo PXK`);
      const headerRow = worksheet.getRow(1);
      headerRow.values = [
        'STT',
        'Mã PXK',
        'Tên khách hàng',
        'Mã khách hàng',
        'Nickname',
        'Nhân viên sale',
        'Ngày lập phiếu',
        'Tổng TL.KT',
        'Tổng TL.TT',
        'Số đơn',
        'Tổng tiền',
        'Trạng thái',
      ];

      let totalMoney = 0;
      let totalMiningWeight = 0;
      let totalCalculationWeight = 0;
      let totalTrackings = 0;
      let countBill = 0;
      // Add data rows
      data.forEach((bill, index) => {
        worksheet.addRow([
          countBill + 1,
          bill.code,
          bill.customer[0].name,
          bill.customer[0].idCustomer,
          bill.customer[0].nickName,
          bill.customer[0].sale[0].fullname,
          new Date(bill.createdAt).toLocaleString('en-US', { timeZone: 'Asia/Ho_Chi_Minh' }),
          Number(bill.totalTrackingMiningWeight),
          Number(bill.totalTrackingCalculationWeight),
          bill.tracking.length,
          Number(bill.trackingTotalMoney),
          bill.deliveryBillStatus,
        ]);

        countBill += 1;
        totalMiningWeight += Number(bill.totalTrackingMiningWeight);
        totalCalculationWeight += Number(bill.totalTrackingCalculationWeight);
        totalMoney += Number(bill.trackingTotalMoney);
        totalTrackings += bill.tracking.length;

        const accountColumns = [11]; // Cột F (cột 8) đến cột M (cột 13)
        accountColumns.forEach(col => {
          const cell = worksheet.getCell(worksheet.rowCount, col);
          cell.numFmt = '#,##0.00'; // Định dạng số tiền với dấu phẩy phân tách hàng nghìn
        });
      });
      worksheet.addRow([]);
      worksheet.addRow(['Tổng', `${countBill} PXK`, '', '', '', '', '', totalMiningWeight, totalCalculationWeight, totalTrackings, totalMoney]);
      const cell = worksheet.getCell(worksheet.rowCount, 11);
      cell.numFmt = '#,##0.00'; // Định dạng số tiền với dấu phẩy phân tách hàng nghìn
      worksheet.columns.forEach((column, colNumber) => {
        let maxLength = 0;
        column.eachCell({ includeEmpty: true }, cell => {
          const len = cell.value ? String(cell.value).length : 0;
          if (len > maxLength) {
            maxLength = len;
          }
          if (cell.type === ExcelJS.ValueType.Date) {
            // Định dạng ngày giờ theo định dạng tùy chỉnh
            cell.numFmt = 'dd/mm/yyyy hh:mm:ss';
          }
        });
        column.width = maxLength < 10 ? 10 : maxLength + 5; // Adjust as needed
      });
      // Set response headers
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=excel-export-1.xlsx');

      // Pipe the workbook to the response
      await workbook.xlsx.write(res);

      res.end();
    } catch (error) {
      console.error(error);
      res.status(500).send('Internal Server Error');
    }
  }
  public async exportExcelRevenueReportByCustomer(data, res) {
    try {
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet(`Báo cáo doanh thu theo PXK`);
      const headerRow = worksheet.getRow(1);
      headerRow.values = ['STT', 'Tên khách hàng', 'Mã khách hàng', 'NickName', 'Sale', 'Số lượng PXK', 'TLKT', 'TLTT', 'Tổng tiền'];

      let totalMoney = 0;
      let totalMiningWeight = 0;
      let totalCalculationWeight = 0;
      let countBill = 0;
      // Add data rows
      data.forEach((customer, index) => {
        worksheet.addRow([
          index + 1,
          customer.fullname,
          customer.idCustomer,
          customer.nickName,
          customer.sale_name ?? '',
          Number(customer.delivery_bill_count),
          Number(customer.tracking_mining_weight),
          Number(customer.tracking_calculation_weight),
          Number(customer.tracking_total_money),
        ]);

        countBill += customer.delivery_bill_count;
        totalMiningWeight += Number(customer.tracking_mining_weight);
        totalCalculationWeight += Number(customer.tracking_calculation_weight);
        totalMoney += Number(customer.tracking_total_money);

        const accountColumns = [8]; // Cột F (cột 8) đến cột M (cột 13)
        accountColumns.forEach(col => {
          const cell = worksheet.getCell(worksheet.rowCount, col);
          cell.numFmt = '#,##0.00'; // Định dạng số tiền với dấu phẩy phân tách hàng nghìn
        });
      });
      worksheet.addRow([]);
      worksheet.addRow(['Tổng', '', '', '', countBill, totalMiningWeight, totalCalculationWeight, totalMoney]);
      const cell = worksheet.getCell(worksheet.rowCount, 8);
      cell.numFmt = '#,##0.00'; // Định dạng số tiền với dấu phẩy phân tách hàng nghìn
      worksheet.columns.forEach((column, colNumber) => {
        let maxLength = 0;
        column.eachCell({ includeEmpty: true }, cell => {
          const len = cell.value ? String(cell.value).length : 0;
          if (len > maxLength) {
            maxLength = len;
          }
          if (cell.type === ExcelJS.ValueType.Date) {
            // Định dạng ngày giờ theo định dạng tùy chỉnh
            cell.numFmt = 'dd/mm/yyyy hh:mm:ss';
          }
        });
        column.width = maxLength < 10 ? 10 : maxLength + 5; // Adjust as needed
      });
      // Set response headers
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=excel-export-1.xlsx');

      // Pipe the workbook to the response
      await workbook.xlsx.write(res);

      res.end();
    } catch (error) {
      console.error(error);
      res.status(500).send('Internal Server Error');
    }
  }
}

export default OverviewReportService;
