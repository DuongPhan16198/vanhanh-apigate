import BadRequestException from '@/exceptions/BadRequestException';
import { NewsCategory } from '@/models/categories.model';
import { Config } from '@/models/config.model';

class NewsCategoryService {
  static getInstant(): NewsCategoryService {
    return new NewsCategoryService();
  }

  public async getAllNewsCategories() {
    return NewsCategory.query().select();
  }
}

export default NewsCategoryService;
