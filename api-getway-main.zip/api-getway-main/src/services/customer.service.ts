import { hash, compare } from 'bcrypt';
import { ChangePasswordDto } from '@/dtos/change-password.dto';
import { Customer } from '@/models/customer.model.';
import { CustomerTransactionLogs } from '@/models/customerTransactionLogs.model';
import { Tracking } from '@/models/tracking.model';
import { Users } from '@/models/users.model';
import { HttpException } from '@exceptions/HttpException';
import { generateRandomString, isEmpty, makeId } from '@utils/util';
import { UserCustomerLinks } from '@/models/userCustomerLinks.model';
import { UpUsersBusinessPartnerLinks } from '@/models/upUsersBusinessPartnerLinks.model';
import { UpUsersRoleLinks } from '@/models/upUsersRoleLinks.model';
import { UpUsersWarehouseVnLinks } from '@/models/upUsersWarehouseVnLinks.model';
import { TrackingType } from '@/models/trackingType.model';
import { CustomerSaleLinks } from '@/models/customerSaleLinks.model';
import { CustomerTags } from '@/models/customerTags.mode';
import { CustomerTagLink } from '@/models/customerTagLink.model';
import { RequestWithUser } from '@/interfaces/auth.interface';
import { CustomerBusinessPartnerLinks } from '@/models/customerBusinessPartnerLinks.model';
import BadRequestException from '@/exceptions/BadRequestException';
import { CustomerServiceStaffLinks } from '@/models/customerServiceStaffLink.model';
import { TrackingsDeliveryBillLinks } from '@/models/trackingsDeliveryBillLinks.model';
import * as ExcelJS from 'exceljs';

class CustomerService {
  static getInstant(): CustomerService {
    return new CustomerService();
  }

  public async findUserByCustomerByEmail(email: string): Promise<Customer> {
    const findCustomer: Customer = await Customer.query().select().where('email', email).first();
    if (!findCustomer) throw new HttpException(404, "User doesn't exist");

    return findCustomer;
  }

  // public async updateCustomer(email: string, customerData: any): Promise<Customer> {
  //   if (isEmpty(customerData)) throw new HttpException(400, 'userData is empty');
  //   const { name, phone, gender, birthday, taxId } = customerData;

  //   const findUser: Customer = await Customer.query().select().where('email', email).first();
  //   if (!findUser) throw new HttpException(409, "User doesn't exist or removed");

  //   const updateData: any = {};

  //   if (phone) {
  //     updateData.phone = phone;
  //   }

  //   if (name) {
  //     updateData.name = name;
  //   }

  //   if (gender) {
  //     updateData.gender = gender;
  //   }

  //   if (birthday) {
  //     updateData.birthday = birthday;
  //   }

  //   if (taxId) {
  //     updateData.taxId = taxId;
  //   }

  //   await Customer.query().update(updateData).where('email', email).into('customers');

  //   const updateUserData: Customer = await Customer.query().select().where('email', email).first();
  //   return updateUserData;
  // }

  public async findAllCustomer(req: RequestWithUser, params: any) {
    const {
      page = 0,
      pageSize = 10,
      email,
      fullname,
      phone,
      id,
      nickName,
      sale,
      undefinedSale,
      isDebt,
      isCard,
      keyword,
      isBlocked,
      orderBy,
    } = params;
    let pageIndex = 0;

    if (page) {
      pageIndex = page - 1;
    }

    const queryBuilder = Customer.query();

    queryBuilder.whereNotNull('user.phone').whereNotNull('user.fullname').whereNotNull('user.email');

    if (email) {
      queryBuilder.whereILike('user.email', `%${email}%`);
    }

    if (fullname) {
      queryBuilder.whereILike('name', `%${fullname}%`);
    }

    if (phone) {
      queryBuilder.whereILike('user.phone', `%${phone}%`);
    }

    if (id) {
      queryBuilder.where('user.id', `${id}`);
    }

    if (nickName) {
      queryBuilder.whereILike('nickName', `%${nickName}%`);
    }

    if (sale) {
      queryBuilder.where('sale.id', sale);
    }

    if (req.permission_business_logic) {
      const { user } = req;
      switch (req.permission_business_logic) {
        case 1:
          break;
        case 2:
          queryBuilder.where('sale.id', user.id);
          break;
        case 3:
          queryBuilder.where('customersServiceStaff.id', user.id);
          break;
        default:
          break;
      }
    }

    if (keyword) {
      queryBuilder.orWhereILike('user.email', `%${keyword}%`);
      queryBuilder.orWhereILike('user.username', `%${keyword}%`);
      queryBuilder.orWhereILike('user.phone', `%${keyword}%`);
      queryBuilder.orWhereILike('nickName', `%${keyword}%`);
    }

    if (undefinedSale && undefinedSale != 'false' && undefinedSale != false) {
      queryBuilder.whereNull('sale.id');
    }

    if (isDebt && isDebt != 'false' && isDebt != false) {
      queryBuilder.where('balance', '<', 0);
    }
    if (isBlocked && isBlocked == 'true') {
      queryBuilder.leftJoinRelated('user').where('user.blocked', true);
    } else queryBuilder.leftJoinRelated('user').where('user.blocked', false);

    if (isCard && isCard != 'false' && isCard != false) {
      queryBuilder.where('credit_amount', '>', 0);
    }
    if (orderBy) {
      const [field, sortOrder] = orderBy.split('-');
      if (['id', 'creditAmount', 'createdAt', 'balance'].includes(field)) {
        queryBuilder.orderBy(field, sortOrder);
      }
    } else {
      queryBuilder.orderBy('createdAt', 'desc');
    }

    const results: any = await queryBuilder
      .leftJoinRelated('sale')
      .leftJoinRelated('user')
      .leftJoinRelated('customersServiceStaff')
      .leftJoinRelated('generalConfigs')
      .withGraphFetched('generalConfigs as shippingCost')
      .withGraphFetched('user')
      .withGraphFetched('boxStag as tags')
      .withGraphFetched('sale')
      .withGraphFetched('customersServiceStaff')
      .groupBy('customers.id')
      .page(pageIndex, pageSize);

    results.results = results.results.map(rs => {
      return {
        ...rs,
        shippingCost: { ...rs.shippingCost, configValue: JSON.parse(rs.shippingCost.configValue) },
      };
    });
    return {
      pagination: {
        page: Number(pageIndex) + 1,
        pageSize: Number(pageSize),
        total: results.total,
        totalPage: Math.ceil(results.total / pageSize),
      },
      data: results.results.map(u => {
        delete u.user[0]['password'];
        delete u.user[0]['resetPasswordToken'];
        delete u.user[0]['confirmationToken'];
        delete u.user[0]['confirmPassword'];
        delete u.user[0]['tmpPassword'];
        if (isBlocked === 'true' || u.user[0].blocked === false) {
          return {
            ...u.user[0],
            customer: {
              ...u,
              user: undefined,
              sale: u.sale.length > 0 ? { id: u.sale[0].id, fullname: u.sale[0].fullname } : null,
              customerServiceStaff:
                u.customersServiceStaff.length > 0 ? { id: u.customersServiceStaff[0].id, fullname: u.customersServiceStaff[0].fullname } : null,
            },
          };
        }
      }),
    };
  }

  public async findAllCustomerTag() {
    return await CustomerTags.query().select().where('isActive', true);
  }

  public async findCustomerById(userId: string) {
    const customer: any = await Customer.query()
      .withGraphFetched('user')
      .withGraphFetched('customersServiceStaff')
      .withGraphFetched('sale')
      .withGraphFetched('customersServiceStaff')
      .leftJoinRelated('generalConfigs')
      .withGraphFetched('generalConfigs as shippingCost')
      .modifyGraph('user', builder =>
        builder
          .select('up_users.id', 'up_users.email', 'up_users.phone', 'up_users.type', 'up_users.fullname', 'up_users.blocked', 'up_users.avatar_url')
          .where('type', 'customer'),
      )
      .withGraphFetched('boxStag as tags')
      .withGraphFetched('trackings')
      .modifyGraph('trackings', builder =>
        builder
          .where('exploit_status', 'Đã khai thác')
          .whereNot('is_deleted', true)
          .leftJoin(TrackingsDeliveryBillLinks.tableName, 'trackings.id', 'trackings_delivery_bill_links.tracking_id')
          .whereNull('trackings_delivery_bill_links.delivery_bill_id')
          .withGraphFetched('deliveryBill')
          .modifyGraph('deliveryBill', billQuery => billQuery.whereNull('delivery_bills.id')),
      )
      .findById(userId);
    if (customer.user.length === 0) {
      throw new HttpException(404, "Customer doesn't exist");
    }

    let moneyTemporary = 0;
    customer.trackings.forEach((tr: any) => {
      moneyTemporary += Number(tr.trackingTotalMoney || 0);
    });

    const user = {
      id: customer.user[0].id,
      email: customer.user[0].email,
      phone: customer.user[0].phone,
      type: customer.user[0].type,
      fullname: customer.user[0].fullname,
      blocked: customer.user[0].blocked,
      avatar_url: customer.user[0].avatarUrl,
    };
    let sale = null;
    if (customer.sale && customer.sale.length !== 0) {
      sale = {
        id: customer.sale[0].id,
        email: customer.sale[0].email,
        phone: customer.sale[0].phone,
        type: customer.sale[0].type,
        fullname: customer.sale[0].fullname,
      };
    }
    let customerServiceStaff = null;
    if (customer.customersServiceStaff && customer.customersServiceStaff.length !== 0) {
      customerServiceStaff = {
        id: customer.customersServiceStaff[0].id,
        email: customer.customersServiceStaff[0].email,
        phone: customer.customersServiceStaff[0].phone,
        type: customer.customersServiceStaff[0].type,
        fullname: customer.customersServiceStaff[0].fullname,
      };
    }
    delete customer.user;
    delete customer.sale;
    delete customer.trackings;
    delete customer.customersServiceStaff;
    return {
      ...customer,
      moneyTemporary: Number(moneyTemporary),
      user: user,
      sale: sale,
      customerServiceStaff: customerServiceStaff,
      tags: customer.tags,
      shippingCost: {
        ...customer.shippingCost,
        configValue: JSON.parse(customer.shippingCost.configValue),
      },
    };
  }

  public async findTrackingsByCustomerId(id: string, params: any) {
    const userId = (await this.findCustomerById(id)).user.id;
    const findCustomer = await Users.query().where('type', 'customer').where('blocked', false).withGraphFetched('customer').findById(userId);
    if (!findCustomer) throw new HttpException(404, "Customer doesn't exist");

    const customerId = findCustomer.customer ? findCustomer.customer[0].id : '';
    const { page, pageSize = 10, type } = params;
    const queryBuilder = Tracking.query().from('trackings as tr');
    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }

    queryBuilder.joinRelated('customer').where('customer.id', customerId);
    const trackingList = await queryBuilder.select().page(pageIndex, pageSize);
    if (!trackingList) throw new HttpException(404, "Bill doesn't exist");

    return {
      paginations: {
        page: Number(pageIndex) + 1,
        pageSize: Number(pageSize),
        total: trackingList.total,
        totalPage: Math.ceil(trackingList.total / pageSize),
      },
      data: trackingList.results.map(tr => {
        delete findCustomer['customer'];
        delete findCustomer['password'];
        delete findCustomer['resetPasswordToken'];
        delete findCustomer['confirmationToken'];
        delete findCustomer['confirmPassword'];
        delete findCustomer['tmpPassword'];
        return {
          ...findCustomer,
          ...tr,
        };
      }),
    };
  }

  public async findOrdersByCustomerId(id: string, params: any) {
    const userId = (await this.findCustomerById(id)).user.id;
    const findCustomer = await Users.query().where('type', 'customer').where('blocked', false).withGraphFetched('customer').findById(userId);
    if (!findCustomer) throw new HttpException(404, "Customer doesn't exist");
    const customerId = findCustomer.customer ? findCustomer.customer[0].id : '';
    const { page, pageSize = 10, type } = params;
    const queryBuilder = Tracking.query().from('trackings as tr').whereNotNull('tr.order_id');
    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }

    queryBuilder.joinRelated('customer').where('customer.id', customerId);
    const trackingList = await queryBuilder.select().page(pageIndex, pageSize);
    if (!trackingList) throw new HttpException(404, "Bill doesn't exist");

    return {
      paginations: {
        page: Number(pageIndex) + 1,
        pageSize: Number(pageSize),
        total: trackingList.total,
        totalPage: Math.ceil(trackingList.total / pageSize),
      },
      data: trackingList.results.map(tr => {
        delete findCustomer['customer'];
        delete findCustomer['password'];
        delete findCustomer['resetPasswordToken'];
        delete findCustomer['confirmationToken'];
        delete findCustomer['confirmPassword'];
        delete findCustomer['tmpPassword'];
        return {
          ...findCustomer,
          ...tr,
        };
      }),
    };
  }

  public async findTransactionsByCustomerId(id: string, params: any) {
    const userId = (await this.findCustomerById(id)).user.id;
    const findCustomer = await Users.query().where('type', 'customer').where('blocked', false).withGraphFetched('customer').findById(userId);
    if (!findCustomer) throw new HttpException(404, "Customer doesn't exist");
    const customerId = findCustomer.customer ? findCustomer.customer[0].id : '';
    const { page, pageSize = 10, type } = params;
    const queryBuilder = CustomerTransactionLogs.query().from(`${CustomerTransactionLogs.getTableName()} as customerLogs`);

    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }

    if (type) {
      queryBuilder.where('customer_transaction_type', type);
    }

    queryBuilder.joinRelated('customer').where('customer.id', customerId);
    const listTransactionLogs = await queryBuilder.select().page(pageIndex, pageSize);
    if (!listTransactionLogs) throw new HttpException(404, "Bill doesn't exist");

    return {
      paginations: {
        page: Number(pageIndex) + 1,
        pageSize: Number(pageSize),
        total: listTransactionLogs.total,
        totalPage: Math.ceil(listTransactionLogs.total / pageSize),
      },
      data: listTransactionLogs.results.map(tr => {
        delete findCustomer['customer'];
        delete findCustomer['password'];
        delete findCustomer['resetPasswordToken'];
        delete findCustomer['confirmationToken'];
        delete findCustomer['confirmPassword'];
        delete findCustomer['tmpPassword'];
        return {
          ...findCustomer,
          ...tr,
        };
      }),
    };
  }

  public async searchAllCustomer(req, kw: string) {
    const keyword = kw ? kw : '';

    const queryBuilder = Customer.query().select(
      'customers.id',
      'name',
      'customers.email',
      'id_customer',
      'nick_name',
      'customers.phone',
      'general_configs.configValue',
    );
    // const saleId = ((await Users.query().where('fullname', keyword)) || []).map(item => item.id);
    if (req.permission_business_logic) {
      const { user } = req;
      switch (req.permission_business_logic) {
        case 1:
          break;
        case 2:
          queryBuilder.where('sale.id', user.id);
          break;
        case 3:
          queryBuilder.where('customerServiceStaff.id', user.id);
          break;
        default:
          break;
      }
    }

    let users: any = await queryBuilder
      .leftJoinRelated('sale')
      .leftJoinRelated('generalConfigs')
      .withGraphFetched('generalConfigs as shippingCost')
      .where(builder =>
        builder
          .whereILike('customers.name', `%${keyword}%`)
          .orWhereILike('customers.email', `%${keyword}%`)
          .orWhereILike('customers.id_customer', `%${keyword}%`)
          .orWhereILike('customers.nick_name', `%${keyword}%`)
          .orWhereILike('customers.phone', `%${keyword}%`),
      )
      .withGraphFetched('user')
      .modifyGraph('user', builder => builder.select('blocked', 'username', 'email', 'fullname', 'phone'));

    users = users.map(rs => {
      return {
        ...rs,
        configValue: JSON.parse(rs.configValue),
      };
    });

    return users.filter(item => item.user[0] && !item.user[0].blocked);
  }

  public deleteCustomer = async (id: string) => {
    const findCustomer: any = await UserCustomerLinks.query().where('customer_id', id);
    const customer: any = await Customer.query().where('id', id).withGraphFetched('trackings').first();
    if (!findCustomer || !customer) throw new HttpException(404, "Customer doesn't exist");
    const trackings = customer.trackings;

    if (trackings) {
      trackings.forEach(tr => {
        if (
          tr.status !== 'Hủy' &&
          tr.status !== 'Huỷ' &&
          tr.exploitStatus !== 'Hoàn thành' &&
          tr.exploitStatus !== 'Đã hủy bỏ' &&
          tr.isDeleted !== true
        ) {
          throw new HttpException(400, 'Cannot delete, customer still have trackings to complete');
        }
      });
    }

    if (customer.balance && Number(customer.balance) < 0) {
      throw new HttpException(402, 'Cannot delete customer is not yet fully paid');
    }
    const randomString = generateRandomString(8);
    await Users.query()
      .update({ email: customer.email + 'DELETED' + randomString, blocked: true })
      .where('id', findCustomer[0].userId)
      .into('up_users');

    await Customer.query()
      .update({ email: customer.email + 'DELETED' + randomString })
      .where('id', id);
  };

  public async changePasswordCustomer(id: string, changePassword: ChangePasswordDto) {
    const userId = (await this.findCustomerById(id)).user.id;
    const findCustomer = await Users.query()
      .where('type', 'customer')
      .withGraphFetched('role')
      .where('blocked', false)
      .withGraphFetched('customer')
      .findById(userId);
    if (!findCustomer) throw new HttpException(404, "Customer doesn't exist");

    const isPasswordMatching: boolean = await compare(changePassword.oldPassword, findCustomer.password);
    if (!isPasswordMatching) throw new HttpException(409, 'Old password is incorrect!');

    const hashedPassword = await hash(changePassword.newPassword, 10);

    await Users.query()
      .update({
        password: hashedPassword,
      })
      .where('id', userId)
      .into('up_users');
  }

  public async updateCustomerInfo(customerId: string, customerData: any) {
    const userId = (await this.findCustomerById(customerId)).user.id;
    const findCustomer = await Users.query()
      .where('type', 'customer')
      .where('blocked', false)
      .join('up_users_customer_links', 'up_users.id', 'up_users_customer_links.user_id')
      .join('customers', 'up_users_customer_links.customer_id', 'customers.id')
      .select('up_users.*')
      .where('up_users.id', userId)
      .withGraphFetched('customer')
      .modifyGraph('customer', builder => builder.withGraphFetched('sale').withGraphFetched('customersServiceStaff'));

    const customerInfo = findCustomer[0].customer ? findCustomer[0].customer[0] : null;
    if (!findCustomer || !customerInfo?.id) throw new HttpException(404, "Customer doesn't exist");
    if (isEmpty(customerData)) throw new HttpException(400, 'Customer Data is empty');
    const {
      name,
      phone,
      gender,
      birthday,
      address,
      nickName,
      email,
      note,
      saleId,
      chargeMoney,
      shippingCost,
      tagIds,
      creditAmount,
      password,
      customerServiceStaffId,
      avatar_url,
      isSubcribeToEmailNotification,
      isSubcribeToFcmNotification,
    } = customerData;

    const updateCustomerData: any = {};
    const updateUserData: any = {};
    const updateCustomerSaleLink: any = { user_id: saleId };
    const update = new Date();
    const formatUpdate = update.toISOString().slice(0, 19) + '.000';
    updateCustomerData.updatedAt = formatUpdate.replace('T', ' ');
    updateUserData.updatedAt = formatUpdate.replace('T', ' ');

    if (phone && phone !== '') {
      updateCustomerData.phone = phone;
      updateUserData.phone = phone;
    }

    if (name && name !== '') {
      updateCustomerData.name = name;
      updateUserData.fullname = name;
    }

    if (avatar_url) {
      updateUserData.avatar_url = avatar_url;
    }

    if (email && email !== '') {
      updateCustomerData.email = email;
      updateUserData.email = email;
    }

    if (password && password !== '') {
      const hashedPassword = await hash(password, 10);
      updateUserData.password = hashedPassword;
    }

    if (nickName && nickName !== '') {
      updateCustomerData.nickName = nickName;
    }

    if (gender && gender !== '') {
      updateCustomerData.gender = gender;
    }

    if (address && address !== '') {
      updateCustomerData.address = address;
    }

    if (chargeMoney && chargeMoney !== null) {
      updateCustomerData.chargeMoney = chargeMoney;
    }

    if (creditAmount) {
      updateCustomerData.creditAmount = creditAmount;
    }

    if (birthday && birthday !== '') {
      const parsedOriginalTime = new Date(birthday);
      const formattedTime = parsedOriginalTime.toISOString().slice(0, 19) + '.000';
      updateCustomerData.birthday = formattedTime.replace('T', ' ');
    }

    if (note && note !== '') {
      updateCustomerData.note = note;
    }

    if (shippingCost) {
      updateCustomerData.shippingCost = shippingCost;
    }

    if (['true', true, 'false', false].includes(isSubcribeToFcmNotification)) {
      updateCustomerData.isSubcribeToFcmNotification = Boolean(isSubcribeToFcmNotification);
    }

    if (['true', true, 'false', false].includes(isSubcribeToEmailNotification)) {
      updateCustomerData.isSubcribeToEmailNotification = Boolean(isSubcribeToEmailNotification);
    }

    if (saleId) {
      if (customerInfo?.sale.length > 0) {
        await CustomerSaleLinks.query()
          .patch({
            userId: saleId,
          })
          .where('customer_id', customerInfo?.id);
      } else {
        await CustomerSaleLinks.query()
          .insert({
            customerId: customerInfo?.id,
            userId: saleId,
          })
          .into(CustomerSaleLinks.tableName);
      }
    }

    if (customerServiceStaffId) {
      if (customerInfo?.customersServiceStaff.length > 0)
        await CustomerServiceStaffLinks.query()
          .patch({
            userId: customerServiceStaffId,
          })
          .where('customer_id', customerInfo?.id);
      else {
        await CustomerServiceStaffLinks.query()
          .insert({
            customerId: customerInfo?.id,
            userId: customerServiceStaffId,
          })
          .into(CustomerServiceStaffLinks.tableName);
      }
    }

    if (!isEmpty(updateCustomerData)) {
      await Customer.query().update(updateCustomerData).findById(customerInfo?.id).into('customers');
    }

    if (!isEmpty(updateUserData)) {
      await Users.query().update(updateUserData).findById(userId).into('up_users');
    }

    if (tagIds) {
      await CustomerTagLink.query().delete().where('customer_id', customerInfo?.id);
      tagIds.forEach(async (item: any) => {
        await CustomerTagLink.query().insert({ customer_id: customerInfo?.id, customer_tag_id: item }).into(CustomerTagLink.tableName);
      });
    }

    return await this.findCustomerById(customerId);
  }

  public async addCustomer(customerData: any, user: any) {
    if (isEmpty(customerData || !customerData.email)) throw new HttpException(400, 'Customer Data is empty');
    const findUser: Users = await Users.query().select().whereILike('email', '=', customerData.email).first();
    if (findUser) throw new HttpException(409, `This email ${customerData.email} already exists`);

    const hashedPassword = await hash(customerData.password, 10);

    let customerId;

    if (customerData.customerId) {
      if (await Customer.query().whereILike('idCustomer', customerData.customerId).first())
        throw new BadRequestException('This customer code is already exist');
      if (!/^[a-zA-Z]+$/.test(customerData.customerId)) throw new BadRequestException('This customer code is contain invalid character');
      customerId = customerData.customerId;
    } else {
      customerId = makeId(5);
      while (true) {
        if (await Customer.query().whereILike('idCustomer', customerId).first()) {
          customerId = makeId(5);
        } else {
          break;
        }
      }
    }

    const addUser = {
      email: customerData.email.toLowerCase(),
      fullname: customerData.fullname || null,
      password: hashedPassword,
      phone: customerData.phone || null,
      type: 'customer',
      blocked: false,
      confirmed: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    const addCustomer = {
      name: customerData.fullname || null,
      email: customerData.email.toLowerCase(),
      phone: customerData.phone || null,
      address: customerData.address || null,
      gender: customerData.gender || null,
      birthday: customerData.birthday || null,
      createdAt: new Date(),
      updatedAt: new Date(),
      shippingCost: customerData.shippingCost || null,
      creditAmount: customerData.creditAmount ? customerData.creditAmount : 0,
      note: customerData.note || null,
      idCustomer: customerId?.toUpperCase() || null,
      nickName: customerData.nickName?.toUpperCase() || null,
    };

    const createUserData = await Users.query().insert(addUser).into('up_users');
    const customer = await Customer.query().insert(addCustomer).into('customers');

    await UserCustomerLinks.query()
      .insert({
        customer_id: customer.id,
        user_id: createUserData.id,
      })
      .into(UserCustomerLinks.tableName);

    if (customerData.tagIds?.length > 0) {
      customerData.tagIds.forEach(async (item: any) => {
        await CustomerTagLink.query().insert({ customer_id: customer.id, customer_tag_id: item }).into(CustomerTagLink.tableName);
      });
    }

    // tạo liên kết giữa hai bảng customers và up_users

    // tạo liên kết của customer với sale phụ trách
    if (customerData.saleId)
      await CustomerSaleLinks.query()
        .insert({
          customerId: customer.id,
          userId: customerData.saleId,
        })
        .into(CustomerSaleLinks.tableName);

    if (customerData.customerServiceStaffId)
      await CustomerServiceStaffLinks.query()
        .insert({
          customerId: customer.id,
          userId: customerData.customerServiceStaffId,
        })
        .into(CustomerServiceStaffLinks.tableName);

    await CustomerBusinessPartnerLinks.query()
      .insert({
        customer_id: customer.id,
        business_partner_id: user?.businessPartner?.id || 1,
      })
      .into(CustomerBusinessPartnerLinks.tableName);
    await UpUsersBusinessPartnerLinks.query()
      .insert({
        user_id: createUserData.id,
        business_partner_id: user?.businessPartner?.id || 1,
      })
      .into(UpUsersBusinessPartnerLinks.tableName);

    // - Thêm liên kết up_users_role_links là customer với role_id = 3
    const queryBuilderUURLLinks = UpUsersRoleLinks.query().from('up_users_role_links');
    await queryBuilderUURLLinks.insert({ user_id: createUserData.id, role_id: 3 }).into('up_users_role_links');

    // - Thêm liên kết up_users_warehouse_vn_links
    if (customerData.warehouseId) {
      const queryBuilderUUWVNLinks = UpUsersWarehouseVnLinks.query().from('up_users_warehouse_vn_links');
      await queryBuilderUUWVNLinks
        .insert({ user_id: createUserData.id, warehouse_config_id: customerData.warehouseId })
        .into('up_users_warehouse_vn_links');
    }

    const createdCustomer: any = Users.query().select().withGraphFetched('customer').where('up_users.id', createUserData.id).first();
    return createdCustomer;
  }

  public async getAllTrackingType() {
    const res = await TrackingType.query().select();
    return res;
  }

  public async exportExcel(data, res) {
    try {
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Sheet 1');

      // Add header row
      const headerRow = worksheet.getRow(1);
      headerRow.values = ['STT', 'Tên Khách hàng', 'Nickname', 'Sale phụ trách', 'CSKH', 'Bảng giá', 'Công nợ', 'Số điện thoại', 'Email', 'Địa chỉ'];
      // Add data rows
      data.data.forEach((item, index) => {
        const row = worksheet.getRow(index + 2);
        const count = index + 1;
        row.values = [
          count,
          item.fullname,
          item.customer?.nickName,
          item.customer?.sale?.fullname,
          item.customer?.customerServiceStaff?.fullname,
          item.customer?.shippingCost?.configValue.info.description,
          item.customer?.balance,
          item.customer?.phone,
          item.customer?.email,
          item.customer?.address,
        ];
      });

      // Adjust column widths based on the length of the values
      worksheet.columns.forEach((column, colNumber) => {
        let maxLength = 0;
        column.eachCell({ includeEmpty: true }, cell => {
          const len = cell.value ? String(cell.value).length : 0;
          if (len > maxLength) {
            maxLength = len;
          }
        });
        column.width = maxLength < 10 ? 10 : maxLength + 2; // Adjust as needed
      });

      // Set response headers
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=excel-export.xlsx');

      // Pipe the workbook to the response
      await workbook.xlsx.write(res);
      res.end();
    } catch (error) {
      console.error(error);
      res.status(500).send('Internal Server Error');
    }
  }
}

export default CustomerService;
