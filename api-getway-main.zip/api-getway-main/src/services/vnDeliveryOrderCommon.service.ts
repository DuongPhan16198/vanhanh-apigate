import { VnDeliveryBoxStatus } from '@/models/vnDeliveryBox.model';
import { VnDeliveryOrders, VnDeliveryOrderStatus } from '@/models/vnDeliveryOrder.model';
import VnDeliveryBoxesCommonService from './vnDeliveryBoxCommon.service';
import BadRequestException from '@/exceptions/BadRequestException';

class VnDeliveryOrdersCommonService {
  private readonly deliveryBoxCommonService = new VnDeliveryBoxesCommonService();
  static getInstant(): VnDeliveryOrdersCommonService {
    return new VnDeliveryOrdersCommonService();
  }
  public async updateDeliveringStatusOfVnDeliveryOrder(vnDeliveryOrdersId, newStatus, body?) {
    if (newStatus === VnDeliveryOrderStatus.COMPLETED) {
      if (body?.shipperId) await this.deliveryBoxCommonService.assignShipperByDeliveryOrderId(vnDeliveryOrdersId, body?.shipperId);
    }
    await VnDeliveryOrders.query()
      .patch({
        status: newStatus,
      })
      .findById(vnDeliveryOrdersId);

    let boxNewStatus;
    let extraField = null;
    switch (newStatus) {
      case VnDeliveryBoxStatus.NEWLYCREATED:
        boxNewStatus = VnDeliveryBoxStatus.NEWLYCREATED;
        extraField = {
          receivedDate: null,
          deliveredDate: null,
        };
        break;
      case VnDeliveryBoxStatus.COMPLETED:
        boxNewStatus = VnDeliveryBoxStatus.COMPLETED;
        break;
      case VnDeliveryBoxStatus.FAILED:
        boxNewStatus = VnDeliveryBoxStatus.FAILED;
        break;
      default:
        boxNewStatus = VnDeliveryBoxStatus.FAILED;
        break;
    }
    await this.deliveryBoxCommonService.switchStatusByDeliveryOrderId(vnDeliveryOrdersId, boxNewStatus);
    return await VnDeliveryOrders.query().findById(vnDeliveryOrdersId);
  }
}

export default VnDeliveryOrdersCommonService;
