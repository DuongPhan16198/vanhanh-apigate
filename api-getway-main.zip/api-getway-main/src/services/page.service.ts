import { pageMetadataSampleInterface } from '@/constant/page_metadata_interface.constant';
import BadRequestException from '@/exceptions/BadRequestException';
import { HttpException } from '@/exceptions/HttpException';
import { Pages } from '@/models/page.model';
import { toSlug } from '@/utils/util';
import axios from 'axios';

class PageService {
  static getInstant(): PageService {
    return new PageService();
  }

  public async getPageMetadataInterface() {
    return pageMetadataSampleInterface;
  }

  public async getPages(param) {
    const queryBuilder = Pages.query().where('is_delete', false);
    const { name, slug, is_system } = param;

    let pages: any;

    if (name) {
      pages = queryBuilder.where('page_interface_file_name', name);
    }

    if (slug) {
      pages = queryBuilder.where('slug', slug);
    }

    if (is_system) {
      pages = queryBuilder.where('is_system', Boolean(is_system));
    }

    pages = await queryBuilder.orderBy('id');
    if (!(pages.length > 0)) {
      throw new HttpException(404, `Not found any pages`);
    }

    const results = pages.map(rs => {
      return {
        ...rs,
        pageMetadata: JSON.parse(rs.pageMetadata),
      };
    });
    return results;
  }

  public async getDetailPage(id) {
    const page: any = await Pages.query().findById(id).where('is_delete', false);
    if (!page) {
      throw new HttpException(404, `Page doesn't exist`);
    }
    return {
      ...page,
      pageMetadata: JSON.parse(page.pageMetadata),
    };
  }

  public async createPage(body) {
    let { page_interface_file_name: pageInterfaceFileName, page_metadata, is_system: isSystem, title, slug, description, imageUrl } = body;
    if (!pageInterfaceFileName || !page_metadata || !title) {
      throw new BadRequestException('Page metadata and name is required');
    }
    const invalidKeys = await this.fetchAndCheckKeys(pageInterfaceFileName, page_metadata);

    if (invalidKeys && invalidKeys.length > 0) {
      page_metadata = page_metadata.filter(item => {
        const keys = Object.keys(item);
        return !keys.some(key => invalidKeys.includes(key));
      });
    } else {
    }

    const page = await Pages.query()
      .insert({
        pageInterfaceFileName,
        pageMetadata: JSON.stringify(page_metadata),
        isDelete: false,
        title,
        slug,
        isSystem,
        description,
        imageUrl,
      })
      .into(Pages.tableName);
    if (!slug) {
      await Pages.query()
        .findById(page.id)
        .patch({ slug: `${toSlug(title)}-${page.id}` });
    }
    const newPage: any = await Pages.query().findById(page.id);
    return { invalidKeys, newPage };
  }

  public async updatePage(page_id, body) {
    let { page_interface_file_name, page_metadata, is_system: isSystem, title, slug, description, imageUrl } = body;
    if (!page_interface_file_name || !page_metadata) {
      throw new BadRequestException('Page key and value is required');
    }
    const isExist = await Pages.query().where('id', page_id).andWhere('is_delete', false).first();
    if (!isExist) {
      throw new BadRequestException(`Non existent page !`);
    }
    const invalidKeys = await this.fetchAndCheckKeys(page_interface_file_name, page_metadata);

    if (invalidKeys && invalidKeys.length > 0)
      page_metadata = page_metadata.filter(item => {
        const keys = Object.keys(item);
        return !keys.some(key => invalidKeys.includes(key));
      });
    const updatingData: any = {};
    if (title) {
      updatingData.title = title;
    }
    if (slug) {
      updatingData.slug = slug;
    }
    if (isSystem) {
      updatingData.isSystem = isSystem;
    }
    if (description) {
      updatingData.description = description;
    }
    await Pages.query()
      .patch({
        pageInterfaceFileName: page_interface_file_name,
        pageMetadata: JSON.stringify(page_metadata),
        title,
        slug,
        isSystem,
        description,
        imageUrl,
      })
      .where('id', page_id);

    const updatedPage: any = await Pages.query().findById(page_id);
    if (!slug || !updatedPage?.slug) {
      await Pages.query()
        .findById(page_id)
        .patch({ slug: toSlug(title) + page_id });
    }
    return { invalidKeys, updatedPage };
  }

  public async deletePage(id) {
    const res = await Pages.query()
      .patch({
        isDelete: true,
      })
      .where('id', id)
      .where('isSystem', false);
    if (!res) {
      throw new BadRequestException(`id not exist or it is system page!`);
    }
    return res;
  }

  private getAllKeyValues(obj, result = []) {
    if (typeof obj === 'object') {
      for (const key in obj) {
        if (key === 'key') {
          result.push(obj[key]);
        } else {
          this.getAllKeyValues(obj[key], result);
        }
      }
    }
    return result;
  }

  private async fetchAndCheckKeys(page_interface_file_name: string, metadata: any) {
    try {
      const response = await axios.get(`${process.env.CUSTOMER_DOMAIN}/pageConfigs/${page_interface_file_name}`);
      const jsonData = await response.data;
      const metadataKeys = metadata.map(item => Object.keys(item)[0]);
      const jsonFileInterfaceKeys = this.getAllKeyValues(jsonData);
      const invalidKeys = metadataKeys.filter(key => !jsonFileInterfaceKeys.includes(key));

      return invalidKeys;
    } catch (error) {
      throw new BadRequestException('Cannot fetch page interface file');
    }
  }
}

export default PageService;
