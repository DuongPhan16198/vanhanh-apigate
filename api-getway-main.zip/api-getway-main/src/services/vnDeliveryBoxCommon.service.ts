import { VnDeliveryBoxes, VnDeliveryBoxStatus } from '@/models/vnDeliveryBox.model';
import BadRequestException from '@/exceptions/BadRequestException';
import CreateVnDeliveryBoxDto from '@/dtos/createVnDeliveryBox.dto';
import { VnDeliveryOrderStatus } from '@/models/vnDeliveryOrder.model';

class VnDeliveryBoxesCommonService {
  static getInstant(): VnDeliveryBoxesCommonService {
    return new VnDeliveryBoxesCommonService();
  }

  public async create(createVnDeliveryBoxDto: CreateVnDeliveryBoxDto) {
    const { code, deliveryOrderId } = createVnDeliveryBoxDto;
    if (!deliveryOrderId) {
      throw new BadRequestException('delivery_order_id is required');
    }

    const insertData: any = {};

    if (code) {
      insertData.code = code;
    }
    if (deliveryOrderId) {
      insertData.vn_delivery_order_id = deliveryOrderId;
    }

    insertData.status = VnDeliveryBoxStatus.NEWLYCREATED;
    const vnDeliveryBoxes = await VnDeliveryBoxes.query().insert(insertData).into('vn_delivery_boxes');

    const newVnDeliveryBoxes: any = await VnDeliveryBoxes.query().findById(vnDeliveryBoxes.id);
    return newVnDeliveryBoxes;
  }

  public async deleteByDeliveryOrderId(VnDeliveryOrderId) {
    await VnDeliveryBoxes.query().delete().where('vnDeliveryOrderId', VnDeliveryOrderId);
  }

  public async switchStatusByDeliveryOrderId(VnDeliveryOrderId, newStatus, extraField?) {
    await VnDeliveryBoxes.query()
      .patch({ ...extraField, status: newStatus })
      .where('vnDeliveryOrderId', VnDeliveryOrderId);
  }

  public async assignShipperByDeliveryOrderId(VnDeliveryOrderId, deliveredById) {
    await VnDeliveryBoxes.query().patch({ deliveredById }).where('vnDeliveryOrderId', VnDeliveryOrderId);
  }

  public async receiveBoxes(userId, body, assignByAdmin?: boolean) {
    const { ids } = body;
    let vnDeliveryBox: any = VnDeliveryBoxes.query()
      .withGraphFetched('vnDeliveryOrder')
      .withGraphFetched('deliveryBill')
      .whereIn('id', ids)
      .where('status', VnDeliveryBoxStatus.NEWLYCREATED);
    if (!assignByAdmin) {
      vnDeliveryBox.where('deliveredById', userId);
    }
    vnDeliveryBox = await vnDeliveryBox;
    if (!vnDeliveryBox?.length) {
      throw new BadRequestException('Boxes not found or cannot receive/switch to delivering');
    }
    if (
      vnDeliveryBox?.some(
        vnBox => vnBox.deliveryBill.deliveryBillStatus !== 'Đã đóng hàng' && vnBox.deliveryBill.deliveryBillStatus !== 'Đang giao hàng',
      )
    ) {
      throw new BadRequestException('Can only receive box of packed bill or on delivering bill ');
    }
    const updateObject = {
      deliveredById: userId,
      status: VnDeliveryBoxStatus.ONDELIVERING,
      receivedDate: new Date(),
    };
    if (assignByAdmin) {
      delete updateObject.deliveredById;
    }
    let updated: any = VnDeliveryBoxes.query()
      .patch(updateObject)
      .whereIn(
        'id',
        vnDeliveryBox.map(x => x.id),
      );
    updated = await updated;

    return { vnDeliveryBox, ids };
  }

  public async assignShipperToBoxes(shipperId, body) {
    const { ids } = body;
    let vnDeliveryBox: any = VnDeliveryBoxes.query()
      .withGraphFetched('vnDeliveryOrder')
      .withGraphFetched('deliveryBill')
      .whereIn('id', ids)
      .where('status', VnDeliveryBoxStatus.NEWLYCREATED);
    vnDeliveryBox = await vnDeliveryBox;

    const updateObject = {
      deliveredById: shipperId,
    };
    let updated: any = VnDeliveryBoxes.query()
      .patch(updateObject)
      .whereIn(
        'id',
        vnDeliveryBox.map(x => x.id),
      );
    updated = await updated;

    return { vnDeliveryBox, ids };
  }
}

export default VnDeliveryBoxesCommonService;
