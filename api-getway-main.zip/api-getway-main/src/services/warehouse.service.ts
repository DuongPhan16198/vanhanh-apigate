import { WarehouseConfig } from '@/models/warehouseConfig.model';

class WarehouseService {
  static getInstant(): WarehouseService {
    return new WarehouseService();
  }

  public async getAllWarehouseVn() {
    const res = await WarehouseConfig.query().select().where('is_deleted', false);
    return res.map(item => {
      delete item['password'];
      delete item['isDeleted'];
      return item;
    });
  }
}

export default WarehouseService;
