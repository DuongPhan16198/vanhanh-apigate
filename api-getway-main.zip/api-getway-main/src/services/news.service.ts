import { News, NewsStatus } from '@/models/news.model';
import { HttpException } from '@exceptions/HttpException';
import BadRequestException from '@/exceptions/BadRequestException';
import { NewsCategoryLinks } from '@/models/news_category_links.model';
import { NewsCategory } from '@/models/categories.model';
import { generateRandomString, toSlug } from '@/utils/util';

class NewsService {
  static getInstant(): NewsService {
    return new NewsService();
  }

  public async findNews(param) {
    const { slug, cat_id, cat_slug, title, page = 1, pageSize = 10, isActive, isDetail } = param;
    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }
    let queryBuilder;

    queryBuilder = News.query()
      .from('news')
      .withGraphFetched('categories')
      .leftJoinRelated('categories')
      .groupBy('news.id')
      .orderBy('createdAt', 'desc');

    if (title) {
      queryBuilder.whereILike('news.title', `%${title}%`);
    }
    if (slug) {
      queryBuilder.whereILike('news.slug', `${slug}`);
    }
    if (cat_id) {
      queryBuilder.whereIn('categories.id', cat_id.split(','));
    }
    if (cat_slug) {
      queryBuilder.whereIn('categories.slug', cat_slug.split(','));
    }
    if (isActive) {
      queryBuilder.where('news.status', isActive);
    }

    const listNews = await queryBuilder.page(pageIndex, pageSize);
    if (!listNews) throw new HttpException(404, "News doesn't exist");
    const { results, total } = listNews;

    return {
      meta: {
        page: Number(pageIndex) + 1,
        pageSize,
        total,
        totalPage: Math.ceil(total / pageSize),
      },
      data: results.map(news => {
        return {
          ...news,
          content: isDetail === 'true' ? news.content : news.content.substring(0, 100),
        };
      }),
    };
  }

  public async newsDetail(id) {
    const news = await News.query().withGraphFetched('categories').where('id', id).first();
    if (news?.status === NewsStatus.DELETED) {
      throw new HttpException(404, "News doesn't exist");
    }
    return news;
  }

  public async findNewsById(id) {
    const news = await News.query().withGraphFetched('categories').where('id', id).first();
    return news;
  }

  public async create(body) {
    const { categories, title, thumbnail, content, slug, description } = body;
    if (!title) {
      throw new BadRequestException('title is required');
    }
    if (categories && !(categories instanceof Array)) {
      throw new BadRequestException('categories must be an array');
    }
    const insertData: any = {
      title,
    };

    if (thumbnail) {
      insertData.thumbnail = thumbnail;
    }

    if (content) {
      insertData.content = content;
    }

    if (description) {
      insertData.description = description;
    }
    insertData.createdAt = new Date();
    insertData.updatedAt = new Date();
    insertData.status = NewsStatus.ACTIVE;
    insertData.slug = slug || `${toSlug(title)}-${generateRandomString(4)}`;
    const news = await News.query().insert(insertData).into('news');

    await News.query()
      .patch({ slug: slug || `${toSlug(title)}-${news.id}` })
      .where('id', news.id);

    if (categories) {
      for (const cate of categories) {
        const category = await NewsCategory.query().findById(cate);
        if (category) {
          await NewsCategoryLinks.query().insert({
            category_id: category.id,
            news_id: news.id,
          });
        }
      }

      const newNews: any = await News.query().findById(news.id);
      return newNews;
    }
  }

  public async update(newsId, body) {
    const { categories, title, thumbnail, content, status, slug, description } = body;
    const news = await this.findNewsById(newsId);
    if (!title && !news.title) {
      throw new BadRequestException('Title is required');
    }
    // if (categories && !(categories instanceof Array)) {
    //   throw new BadRequestException('categories must be an array');
    // }
    let newsData: any = {};

    if (title) {
      newsData.title = title;
    }

    if (thumbnail) {
      newsData.thumbnail = thumbnail;
    }

    if (content) {
      newsData.content = content;
    }
    if (description) {
      newsData.description = description;
    }

    if (status === 0 || status === 1) {
      newsData.status = status;
    }
    newsData.updatedAt = new Date();
    newsData.slug = slug || `${toSlug(title || news.title)}-${newsId}`;
    await News.query().patch(newsData).where('id', newsId);

    if (categories) {
      await NewsCategoryLinks.query().delete().where('news_id', newsId);
      for (const cate of categories) {
        const category = await NewsCategory.query().findById(cate);
        if (category) {
          await NewsCategoryLinks.query().insert({
            category_id: category.id,
            news_id: newsId,
          });
        }
      }
    }

    const updateNews: any = await News.query().withGraphFetched('categories').where('id', newsId).first();

    return updateNews;
  }

  public async delete(newsId) {
    const news = await News.query().findById(newsId);
    if (news.status === NewsStatus.DELETED) {
      throw new HttpException(404, 'News has been deleted');
    }
    await News.query()
      .patch({
        status: NewsStatus.DELETED,
      })
      .findById(newsId);
    return await News.query().findById(newsId);
  }
}

export default NewsService;
