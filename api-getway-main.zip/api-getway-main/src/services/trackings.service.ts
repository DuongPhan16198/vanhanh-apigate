import BadRequestException from '@/exceptions/BadRequestException';
import { Tracking } from '@/models/tracking.model';
import { TrackingsAwbLinks } from '@/models/trackingAwbLinks.model';
import { TrackingsBoxLinks } from '@/models/trackingBoxLinks.model';
import { TrackingCustomerLinks } from '@/models/trackingCustomerLinks.model';
import { TrackingBusinessPartnerLink } from '@/models/trackingBusinessPartnerLink.model';
import { TrackingsWarehouseLinksLink } from '@/models/trackingsWarehouseLinksLink.model';
import { TrackingsWarehouseVnLinksLink } from '@/models/trackingsWarehouseVnLinksLink.model';
import { TrackingsExploitedByLinks } from '@/models/trackingsExploitedByLinks.model';
import { TrackingsTrackingTypeLinks } from '@/models/trackingsTrackingTypeLinks.model';
import { TrackingsDeliveryBillLinks } from '@/models/trackingsDeliveryBillLinks.model';
import { Users } from '@/models/users.model';
import { generateNextOrderId, generateRandomString, getChangedFields } from '@/utils/util';
import { HttpException } from '@exceptions/HttpException';
import { isEmpty } from 'lodash';
import moment from 'moment';
import axios from 'axios';
import { TRACKING_CHANGEBOX_STATUS, TRACKING_STATUS, TRACKING_STATUS_ORDER, TRACKING_UPDATABLE_STATUS } from '@/constant/constant';
import { WAREHOUSE_API_URL, WAREHOUSE_API_TOKEN } from '@config';
import { TrackingSaleLinks } from '@/models/trackingSaleLinks.model';
import qs from 'qs';
import { TrackingType } from '@/models/trackingType.model';
import UserService from './users.service';
import { TrackingLogs } from '@/models/trackingLogs.model';
import { CustomerSaleLinks } from '@/models/customerSaleLinks.model';
import { Box } from '@/models/box.model';
import { Awb } from '@/models/awb.model';
import GeneralConfigService from './config.service';
import CustomerService from './customer.service';
import { RequestWithUser } from '@/interfaces/auth.interface';
import { DeliveryBill } from '@/models/deliveryBill.model';
import { getListTrackings, getTimelineOfATrackingFromWh, sendCreateTicketRequest, sendCreateTrackingToWh } from '@/utils/requestsToWarehouseApi';
import FcmPushNotificationService from './fcmPushNotification.service';
import { TrackingStatusLogs } from '@/models/trackingStatusLog.model';
import { getStatusTrackingReal } from '@/utils/getStatusTracking';
import getReqPerrmissionBusinessLogic from '@/utils/getReqPerrmissionBusinessLogic';

class TrackingService {
  private userService = new UserService();
  private readonly fcmPushNotificationService = new FcmPushNotificationService();
  static readonly INSERT_FIELDS = [
    'code',
    'description',
    'importDate',
    'repackDate',
    'packedDate',
    'exportDate',
    'arrivalDate',
    'isRepack',
    'isSplit',
    'parentTracking',
    'imageUrl',
    'note',
    'shippingFee',
    'trackingMiningWeight',
    'trackingCalculationWeight',
    'trackingBarrelCoefficient',
    'trackingShippingCost',
    'trackingShippingFee',
    'trackingSurcharge',
    'trackingDeliveryFee',
    'trackingOtherFee',
    'trackingTotalMoney',
    'productName',
    'trackingAmount',
    'orderId',
    'optionalImage',
    'hasError',
    'price',
    'status',
    'exploitStatus',
  ];

  static getInstant(): TrackingService {
    return new TrackingService();
  }

  public async additionalReqPermissionLogic(req, queryBuilder, customer, user, isGettingOrder) {
    switch (req.permission_business_logic) {
      case 1:
        break;
      case 2:
        if (customer)
          queryBuilder
            .innerJoin('customers_sale_links', 'customers_sale_links.customer_id', '=', 'customers.id')
            .where('customers_sale_links.user_id', user.id);
        else
          queryBuilder
            .innerJoin('trackings_customer_links', 'tr.id', '=', 'trackings_customer_links.tracking_id')
            .innerJoin('customers', 'trackings_customer_links.customer_id', '=', 'customers.id')
            .innerJoin('customers_sale_links', 'customers_sale_links.customer_id', '=', 'customers.id')
            .where('customers_sale_links.user_id', user.id);
        break;
      case 3:
        queryBuilder
          .innerJoin('trackings_warehouse_vn_links', 'tr.id', '=', 'trackings_warehouse_vn_links.tracking_id')
          .where('trackings_warehouse_vn_links.warehouse_config_id', user.warehouseVN[0].id);
        break;
      case 4:
        if (customer)
          queryBuilder
            .innerJoin('customers_service_staff_links', 'customers_service_staff_links.customer_id', '=', 'customers.id')
            .where('customers_service_staff_links.user_id', user.id);
        else
          queryBuilder
            .innerJoin('trackings_customer_links', 'tr.id', '=', 'trackings_customer_links.tracking_id')
            .innerJoin('customers', 'trackings_customer_links.customer_id', '=', 'customers.id')
            .innerJoin('customers_service_staff_links', 'customers_service_staff_links.customer_id', '=', 'customers.id')
            .where('customers_service_staff_links.user_id', user.id);
        break;
      case 5:
        if (isGettingOrder)
          queryBuilder
            .innerJoin('trackings_customer_links', 'tr.id', '=', 'trackings_customer_links.tracking_id')
            .where('trackings_customer_links.customer_id', user.customer.id);
        break;
      default:
        break;
    }
  }

  public async findAll(user, param) {
    const queryBuilder = Tracking.query().from('trackings as tr');
    const { page = 0, pageSize = 10, exploitStatus, fromDate, toDate, filterDateBy, code, keyWords, isDeleted = false } = param;

    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }

    let codes = [];

    if (code) {
      codes = code.split(',').map(c => c.trim()) || [code.trim()];
      codes.forEach(c => {
        queryBuilder.orWhereLike('tr.code', `%${c}%`);
      });
    }
    queryBuilder.leftJoinRelated('trackingType');

    if (exploitStatus !== undefined) {
      switch (exploitStatus) {
        case '0':
          queryBuilder.where('tr.status', 'Đang vận chuyển về VN');
          queryBuilder.where('tr.exploitStatus', 'Đang vận chuyển về vn');
          break;
        case '1':
          queryBuilder.where('tr.exploitStatus', 'Đã vận chuyển về vn');
          break;
        case '2':
          queryBuilder.where('tr.exploitStatus', 'Đã khai thác');
          break;
        case '3':
          queryBuilder.where('tr.exploitStatus', 'Đã hủy bỏ');
          break;
        case '4':
          queryBuilder.whereNull('trackingType.id');
          break;
        default:
          break;
      }
    }

    if (keyWords) {
      queryBuilder.whereLike('tr.code', `%${keyWords}%`);
      queryBuilder.orWhereLike('order_id', `%${keyWords}%`);
    }

    if (fromDate && toDate && filterDateBy) {
      queryBuilder.whereBetween(filterDateBy, [fromDate, toDate]);
    }

    let selectDelete = false;

    if (isDeleted) {
      selectDelete = true;
    }
    queryBuilder.leftJoinRelated('customer').where('customer.email', user.email);

    const listTracking = await queryBuilder
      .select('tr.*')
      .withGraphFetched('tr ackingType')
      .withGraphFetched('awb')
      .withGraphFetched('box')
      .withGraphFetched('businessPartner')
      .withGraphFetched('warehouse')
      .withGraphFetched('warehouseVn')
      .withGraphFetched('exploitedBy')
      .withGraphFetched('deliveryBill')
      .withGraphFetched('customer')
      .where('tr.is_deleted', selectDelete)
      .page(pageIndex, pageSize);
    if (!listTracking) throw new HttpException(404, "Tracking doesn't exist");
    const { results, total } = listTracking;

    return {
      meta: {
        page: Number(pageIndex) + 1,
        pageSize,
        total,
        totalPage: Math.ceil(total / pageSize),
      },
      data: results.map(tr => ({
        ...tr,
        box: tr.box[0] || null,
        awb: tr.awb[0] || null,
        businessPartner: tr.businessPartner[0] || null,
        warehouse: tr.warehouse[0] || null,
        warehouseVn: tr.warehouseVn[0] || null,
        exploitedBy: tr.exploitedBy[0] || null,
        deliveryBill: tr.deliveryBill[0] || null,
        trackingType: tr.trackingType[0] || null,
        customer: tr.customer[0] || null,
      })) as any,
    };
  }

  public async findAllByPartner(user, param) {
    const { page = 0, pageSize = 10, exploitStatus, fromDate, toDate, filterDateBy, keyWords, isDeleted = false } = param;
    let pageIndex = 0;

    if (page) {
      pageIndex = page - 1;
    }

    const queryBuilder = Tracking.query();

    let isOnlyGetTrackingOfCustomer = true;

    if (exploitStatus !== undefined) {
      switch (exploitStatus) {
        case '0':
          queryBuilder.where('trackings.status', 'Đang vận chuyển về VN');
          queryBuilder.where('trackings.exploitStatus', 'Đang vận chuyển về vn');
          break;
        case '1':
          queryBuilder.where('trackings.exploitStatus', 'Đã vận chuyển về vn');
          break;
        case '2':
          queryBuilder.where('trackings.exploitStatus', 'Đã khai thác');
          break;
        case '3':
          queryBuilder.where('trackings.exploitStatus', 'Đã hủy bỏ');
          break;
        case '4':
          queryBuilder.whereNull('trackingType.id');
          break;
        case '5':
          isOnlyGetTrackingOfCustomer = false;
          break;
        default:
          break;
      }
    }

    queryBuilder.leftJoinRelated('customer');
    if (isOnlyGetTrackingOfCustomer) {
      const listCustomer = await Users.query()
        .findById(user.id)
        .withGraphFetched('saleOfCustomer')
        .modifyGraph('saleOfCustomer', builder => builder.select('customers.id'));
      const listCustomerId = listCustomer.saleOfCustomer.map(c => c.id);
      queryBuilder.orWhereIn('customer.id', listCustomerId);
    }

    if (keyWords) {
      queryBuilder.whereLike('trackings.code', `%${keyWords}%`);
      queryBuilder.orWhereLike('order_id', `%${keyWords}%`);
    } else if (user.role.type === 'nhan_vien_khai_thac') {
      queryBuilder.orWhereNull('customer.id');
    }

    if (fromDate && toDate && filterDateBy) {
      queryBuilder.whereBetween(filterDateBy, [fromDate, toDate]);
    }

    let selectDelete = false;

    if (isDeleted) {
      selectDelete = true;
    }

    const listTracking = await queryBuilder
      .withGraphFetched('customer')
      .withGraphFetched('box')
      .withGraphFetched('awb')
      .withGraphFetched('businessPartner')
      .withGraphFetched('warehouse')
      .withGraphFetched('warehouseVn')
      .withGraphFetched('exploitedBy')
      .withGraphFetched('deliveryBill')
      .where('trackings.is_deleted', selectDelete)
      .orderBy('updatedAt', 'desc')
      .page(pageIndex, pageSize);

    let { results, total } = listTracking;

    results = results.map(tr => ({
      ...tr,
      box: tr.box[0] || null,
      awb: tr.awb[0] || null,
      businessPartner: tr.businessPartner[0] || null,
      warehouse: tr.warehouse[0] || null,
      warehouseVn: tr.warehouseVn[0] || null,
      exploitedBy: tr.exploitedBy[0] || null,
      deliveryBill: tr.deliveryBill[0] || null,
      customer: tr.customer[0] || null,
    })) as any;

    return {
      meta: {
        page: Number(pageIndex) + 1,
        pageSize: Number(pageSize),
        total,
        totalPage: Math.ceil(total / pageSize),
      },
      data: results,
    };
  }

  private validateCreateTrackingData = (listTracking: Tracking[]) => {
    listTracking.forEach((data: Tracking) => {
      if (!data.code || /^[a-zA-Z0-9-_]+$/.test(data.code)) return false;
    });
    return true;
  };

  private getStatusTrackingReal = (tr: any) => {
    let status;
    if (tr.exploitStatus === 'Đã hủy bỏ' || tr.isDeleted) {
      status = 'Đã hủy bỏ';
    } else if (tr.status === 'Chờ nhà cung cấp' || tr.status === 'Đã tiếp nhận' || tr.status === 'Chưa nhập kho') {
      status = 'Chờ nhập kho US';
    } else if (tr.status === 'Đã nhập kho') {
      status = 'Đã nhập kho US';
    } else if (
      (tr.status === 'Đang đóng thùng' ||
        tr.status === 'Đã đóng thùng' ||
        tr.status === 'Đang xử lý awb' ||
        tr.status === 'Đang vận chuyển về VN' ||
        tr.status === 'Hoàn thành') &&
      tr.exploitStatus === 'Đang vận chuyển về vn'
    ) {
      status = 'Đang vận chuyển về VN';
    } else if (tr.exploitStatus === 'Đã vận chuyển về vn') {
      status = 'Đã nhập kho VN';
    } else if (tr.exploitStatus === 'Đã khai thác') {
      status = 'Đã khai thác';
    } else if (tr.exploitStatus === 'Đã đóng hàng') {
      status = 'Đã đóng hàng';
    } else if (tr.exploitStatus === 'Đang giao hàng') {
      status = 'Đang giao hàng';
    } else if (tr.exploitStatus === 'Hoàn thành') {
      status = 'Hoàn thành';
    } else if (tr.exploitStatus === 'Đã hủy bỏ' || tr.isDeleted) {
      status = 'Đã hủy bỏ';
    } else {
      status = 'Lỗi';
    }
    return status;
  };

  private getExistTrackings = async (listTracking: Tracking[]) => {
    const existCustomerTrackingCd = [];
    const existNonCustomerTrackingCd = [];
    // Tracking có customer
    for (let i = 0; i < listTracking.length; i++) {
      const tracking = listTracking[i];
      const existCustomerTracking = await Tracking.query()
        .select('code', 'customer.id as customer', 'trackings.id')
        .innerJoinRelated('customer')
        .where('code', tracking.code.trim())
        .orWhereLike('code', `%${tracking.code?.slice(-8)}`)
        .where('is_deleted', false)
        .first();

      if (existCustomerTracking) {
        existCustomerTrackingCd.push({
          id: existCustomerTracking.id,
          code: existCustomerTracking.code.trim(),
          customerId: existCustomerTracking.customer,
          newCustomerId: tracking.customer,
        });
        listTracking.splice(i, 1);
        i--;
      }
    }

    for (let i = 0; i < listTracking.length; i++) {
      const tracking = listTracking[i];
      const existNonCustomerTracking = await Tracking.query()
        .select('id', 'code')
        .where('code', tracking.code.trim())
        .where('is_deleted', false)
        .first();

      if (existNonCustomerTracking) {
        existNonCustomerTrackingCd.push({
          id: existNonCustomerTracking.id,
          code: existNonCustomerTracking.code.trim(),
          customerId: tracking.customer,
        });
        listTracking.splice(i, 1);
        i--;
      }
    }
    return [existCustomerTrackingCd, existNonCustomerTrackingCd, listTracking];
  };

  private updateFreeTrackings = async (freeTrackingCds: any[], user) => {
    let { prefix, date, count } = await generateNextOrderId();
    for (const tracking of freeTrackingCds) {
      const tr = await Tracking.query().findById(tracking.id);
      const queryBuilderLinks = TrackingCustomerLinks.query().from('trackings_customer_links');
      const queryBuilderTracking = Tracking.query().from('trackings');
      await queryBuilderLinks.insert({ customer_id: tracking.customerId, tracking_id: tracking.id }).into('trackings_customer_links');
      await queryBuilderTracking.patch({ orderId: prefix + date + `0000${count}`.slice(-5), updatedAt: new Date() }).where('id', tracking.id);
      if (user.warehouseVN.length > 0 && !tr.warehouseVn) {
        await TrackingsWarehouseVnLinksLink.query()
          .patch({ tracking_id: tracking.id, warehouse_config_id: user.warehouseVn.id })
          .where('id', tracking.id);
      }
      count += 1;
    }
  };

  private updateFreeTrackingsWithBox = async (freeTrackingCds: any[], box_id: any) => {
    let { prefix, date, count } = await generateNextOrderId();

    const box = await Box.query().findById(box_id).withGraphFetched('awb').withGraphFetched('warehouseVN');
    const awb_id = box.awb[0].id;
    let boxStatusNumber = 0;
    switch (box.exploitStatus) {
      case 'Đang vận chuyển về vn':
        boxStatusNumber = 1;
        break;
      case 'Đã vận chuyển về vn':
        boxStatusNumber = 2;
        break;
      case 'Đang khai thác':
        boxStatusNumber = 3;
        break;
      case 'Đã khai thác':
        boxStatusNumber = 4;
        break;
      default:
        break;
    }

    let trackingStatus = 'Đang vận chuyển về VN';
    let trackingExploitStatus = 'Đang vận chuyển về vn';
    switch (boxStatusNumber) {
      case 2:
      case 3:
      case 4:
        trackingExploitStatus = 'Đã vận chuyển về vn';
        trackingStatus = 'Hoàn thành';
        break;
    }
    for (const tracking of freeTrackingCds) {
      const trackingFetched = await Tracking.query()
        .findById(tracking.id)
        .withGraphFetched('awb')
        .withGraphFetched('box')
        .withGraphFetched('warehouseVn');
      const queryBuilderTrackingAwb = TrackingsAwbLinks.query().from('trackings_awb_links');
      const queryBuilderTracking = Tracking.query().from('trackings');
      const queryBuilderLinks = TrackingCustomerLinks.query().from('trackings_customer_links');
      const queryBuilderTrackingBox = TrackingsBoxLinks.query().from('trackings_box_links');
      await queryBuilderLinks.insert({ customer_id: tracking.customerId, tracking_id: tracking.id }).into('trackings_customer_links');
      await queryBuilderTracking
        .patch({
          status: trackingStatus,
          exploitStatus: trackingExploitStatus,
          orderId: prefix + date + `0000${count}`.slice(-5),
          updatedAt: new Date(),
          vnImportDate: trackingExploitStatus === 'Đã vận chuyển về vn' ? new Date() : null,
        })
        .where('id', tracking.id);
      if (!trackingFetched?.box[0]) await queryBuilderTrackingBox.insert({ tracking_id: tracking.id, box_id: box_id }).into('trackings_box_links');
      else await queryBuilderTrackingBox.patch({ box_id }).where('tracking_id', tracking.id);
      if (!trackingFetched?.awb[0]) await queryBuilderTrackingAwb.insert({ awb_id, tracking_id: tracking.id }).into('trackings_awb_links');
      else await queryBuilderTrackingAwb.patch({ awb_id }).where('tracking_id', tracking.id);
      if ((box as any).warehouseVN[0]) {
        if (!trackingFetched.warehouseVn[0]?.warehouse_config_id)
          await TrackingsWarehouseVnLinksLink.query()
            .insert({
              warehouse_config_id: (box as any).warehouseVN[0].id,
              tracking_id: tracking.id,
            })
            .into('trackings_warehouse_vn_links');
        else {
          await TrackingsWarehouseVnLinksLink.query()
            .patch({
              warehouse_config_id: (box as any).warehouseVN[0].id,
            })
            .where('tracking_id', tracking.id);
        }
      }
      count += 1;
    }
  };

  private insertNewTrackings = async (listTracking: any[], user) => {
    let { prefix, date, count } = await generateNextOrderId();

    for (const tracking of listTracking) {
      let tried = 0;
      const queryBuilderCustomerLinks = TrackingCustomerLinks.query().from('trackings_customer_links');
      const queryBuilderBusinessPartnerLinks = TrackingBusinessPartnerLink.query().from('trackings_business_partner_links');
      const queryBuilderTracking = Tracking.query();
      do {
        try {
          const order_id = prefix + date + `0000${count}`.slice(-5);
          const insertedTracking = await queryBuilderTracking
            .insert({
              code: tracking.code.trim(),
              orderId: order_id,
              isDeleted: false,
              status: 'Đã tiếp nhận',
              exploitStatus: 'Đang vận chuyển về vn',
              price: tracking.price,
              businessPartner: tracking.businessPartner,
              description: tracking.description,
              trackingAmount: tracking?.trackingAmount || 1,
              createdAt: new Date(),
              updatedAt: new Date(),
            })
            .into('trackings');
          await queryBuilderCustomerLinks
            .insert({ customer_id: tracking.customer, tracking_id: insertedTracking.id })
            .into('trackings_customer_links');

          const sale: CustomerSaleLinks = await CustomerSaleLinks.query().select().where('customer_id', tracking.customer).first();
          if (sale && sale.userId)
            await TrackingSaleLinks.query().insert({
              tracking_id: insertedTracking.id,
              user_id: sale.userId,
            });
          await queryBuilderBusinessPartnerLinks
            .insert({ business_partner_id: 1, tracking_id: insertedTracking.id })
            .into('trackings_business_partner_links');
          if (user.warehouseVN.length > 0) {
            await TrackingsWarehouseVnLinksLink.query()
              .insert({ tracking_id: insertedTracking.id, warehouse_config_id: user.warehouseVN[0].id })
              .into('trackings_warehouse_vn_links');
          }
          tried = 4;
        } catch (error) {
          tried += 1;
        } finally {
          count += 1;
        }
      } while (tried < 4);
    }
    await sendCreateTrackingToWh(listTracking.map(tracking => tracking.code.trim()));
  };

  private insertNewTrackingsWithBox = async (listTracking: any[], box_id: number) => {
    let { prefix, date, count } = await generateNextOrderId();
    const box = await Box.query().findById(box_id).withGraphFetched('awb').withGraphFetched('warehouseVN');
    const awb_id = box.awb[0].id;
    let boxStatusNumber = 0;
    switch (box.exploitStatus) {
      case 'Đang vận chuyển về vn':
        boxStatusNumber = 1;
        break;
      case 'Đã vận chuyển về vn':
        boxStatusNumber = 2;
        break;
      case 'Đang khai thác':
        boxStatusNumber = 3;
        break;
      case 'Đã khai thác':
        boxStatusNumber = 4;
        break;
      default:
        break;
    }

    let trackingStatus = 'Đang vận chuyển về VN';
    let trackingExploitStatus = 'Đang vận chuyển về vn';
    switch (boxStatusNumber) {
      case 2:
      case 3:
      case 4:
        trackingExploitStatus = 'Đã vận chuyển về vn';
        trackingStatus = 'Hoàn thành';
        break;
    }
    for (const tracking of listTracking) {
      let tried = 0;
      const queryBuilderCustomerLinks = TrackingCustomerLinks.query().from('trackings_customer_links');
      const queryBuilderTrackingBox = TrackingsBoxLinks.query().from('trackings_box_links');
      const queryBuilderTrackingAwb = TrackingsAwbLinks.query().from('trackings_awb_links');
      const queryBuilderBusinessPartnerLinks = TrackingBusinessPartnerLink.query().from('trackings_business_partner_links');
      const queryBuilderTracking = Tracking.query();
      do {
        try {
          const order_id = prefix + date + `0000${count}`.slice(-5);
          const insertedTracking = await queryBuilderTracking
            .insert({
              code: tracking.code.trim(),
              orderId: order_id,
              isDeleted: false,
              status: trackingStatus,
              exploitStatus: trackingExploitStatus,
              price: tracking.price,
              businessPartner: tracking.businessPartner,
              description: tracking.description,
              trackingAmount: tracking?.trackingAmount || 1,
              vnImportDate: trackingExploitStatus === 'Đã vận chuyển về vn' ? new Date() : null,
              createdAt: new Date(),
              updatedAt: new Date(),
            })
            .into('trackings');
          if (tracking.customer) {
            await queryBuilderCustomerLinks
              .insert({ customer_id: tracking.customer, tracking_id: insertedTracking.id })
              .into('trackings_customer_links');
            const sale: CustomerSaleLinks = await CustomerSaleLinks.query().select().where('customer_id', tracking.customer).first();
            if (sale && sale.userId)
              await TrackingSaleLinks.query().insert({
                tracking_id: insertedTracking.id,
                user_id: sale.userId,
              });
          }
          await queryBuilderTrackingBox.insert({ box_id: box_id, tracking_id: insertedTracking.id }).into('trackings_box_links');
          await queryBuilderTrackingAwb.insert({ awb_id, tracking_id: insertedTracking.id }).into('trackings_awb_links');
          await queryBuilderBusinessPartnerLinks
            .insert({ business_partner_id: 1, tracking_id: insertedTracking.id })
            .into('trackings_business_partner_links');
          if ((box as any).warehouseVN[0]) {
            await TrackingsWarehouseVnLinksLink.query()
              .insert({
                warehouse_config_id: (box as any).warehouseVN[0].id,
                tracking_id: insertedTracking.id,
              })
              .into('trackings_warehouse_vn_links');
          }
          await TrackingsWarehouseLinksLink.query().insert({
            tracking_id: insertedTracking.id,
            warehouse_id: tracking.warehouse_id || 1,
          });

          tried = 4;
        } catch (error) {
          tried += 1;
        } finally {
          count += 1;
        }
      } while (tried < 4);
    }
  };

  private existTrackingsWithBox = async (listTracking: any[], box_id: number) => {
    const box = await Box.query().findById(box_id).withGraphFetched('awb').withGraphFetched('warehouseVN');
    const awb_id = box.awb[0].id;
    let boxStatusNumber = 0;
    switch (box.exploitStatus) {
      case 'Đang vận chuyển về vn':
        boxStatusNumber = 1;
        break;
      case 'Đã vận chuyển về vn':
        boxStatusNumber = 2;
        break;
      case 'Đang khai thác':
        boxStatusNumber = 3;
        break;
      case 'Đã khai thác':
        boxStatusNumber = 4;
        break;
      default:
        break;
    }

    let trackingStatus = 'Đang vận chuyển về VN';
    let trackingExploitStatus = 'Đang vận chuyển về vn';
    switch (boxStatusNumber) {
      case 2:
      case 3:
      case 4:
        trackingExploitStatus = 'Đã vận chuyển về vn';
        trackingStatus = 'Hoàn thành';
        break;
    }
    for (const tracking of listTracking) {
      const trackingFetched = await Tracking.query()
        .findById(tracking.id)
        .withGraphFetched('awb')
        .withGraphFetched('box')
        .withGraphFetched('warehouseVn')
        .withGraphFetched('customer');
      if (TRACKING_CHANGEBOX_STATUS.includes(this.getStatusTrackingReal(trackingFetched))) {
        const queryBuilderTrackingCustomer = TrackingCustomerLinks.query().from('trackings_customer_links');
        const queryBuilderTrackingBox = TrackingsBoxLinks.query().from('trackings_box_links');
        const queryBuilderTrackingAwb = TrackingsAwbLinks.query().from('trackings_awb_links');
        if (!trackingFetched?.customer[0])
          await queryBuilderTrackingCustomer
            .insert({ customer_id: tracking.newCustomerId, tracking_id: tracking.id })
            .into('trackings_customer_links');
        else await queryBuilderTrackingCustomer.patch({ customer_id: tracking.newCustomerId }).where('tracking_id', tracking.id);
        if (!trackingFetched?.box[0]) await queryBuilderTrackingBox.insert({ tracking_id: tracking.id, box_id: box_id }).into('trackings_box_links');
        else await queryBuilderTrackingBox.patch({ box_id }).where('tracking_id', tracking.id);
        if (!trackingFetched?.awb[0]) await queryBuilderTrackingAwb.insert({ awb_id, tracking_id: tracking.id }).into('trackings_awb_links');
        else await queryBuilderTrackingAwb.patch({ awb_id }).where('tracking_id', tracking.id);
        if ((box as any).warehouseVN[0]) {
          if (!trackingFetched.warehouseVn[0]?.warehouse_config_id)
            await TrackingsWarehouseVnLinksLink.query()
              .insert({
                warehouse_config_id: (box as any).warehouseVN[0].id,
                tracking_id: tracking.id,
              })
              .into('trackings_warehouse_vn_links');
          else {
            await TrackingsWarehouseVnLinksLink.query()
              .patch({
                warehouse_config_id: (box as any).warehouseVN[0].id,
              })
              .where('tracking_id', tracking.id);
          }
        }
        await Tracking.query()
          .patch({
            exploitStatus: trackingExploitStatus,
            status: trackingStatus,
            vnImportDate: trackingExploitStatus === 'Đã vận chuyển về vn' ? new Date() : null,
          })
          .where('id', tracking.id);
      }
    }
  };

  public async createMany(listTracking, user) {
    if (!this.validateCreateTrackingData(listTracking)) {
      throw new BadRequestException('tracking code is empty');
    }
    const [existTracking, freeTrackingCds, notExistTracking] = await this.getExistTrackings(listTracking);
    if (freeTrackingCds.length > 0) {
      await this.updateFreeTrackings(freeTrackingCds, user);
    }
    if (notExistTracking.length > 0) {
      await this.insertNewTrackings(notExistTracking, user);
    }

    return {
      existTracking: existTracking.map(tr => tr.code),
      insertedTracking: notExistTracking.map(tr => tr.code),
      updatedTracking: freeTrackingCds.map(tr => tr.code),
    };
  }

  public async createManyWithBox(listTracking, box_id) {
    let existTrackingData = [];
    let insertedTrackingData = [];
    let updatedTrackingData = [];
    if (!this.validateCreateTrackingData(listTracking)) {
      throw new BadRequestException('tracking code is empty or contain special character');
    }
    const [existTracking, freeTrackingCds, notExistTracking] = await this.getExistTrackings(listTracking);
    if (freeTrackingCds.length > 0) {
      await this.updateFreeTrackingsWithBox(freeTrackingCds, box_id);
      updatedTrackingData = freeTrackingCds.map(tr => tr.code);
    }
    if (notExistTracking.length > 0) {
      await this.insertNewTrackingsWithBox(notExistTracking, box_id);
      insertedTrackingData = notExistTracking.map(tr => tr.code);
    }
    if (existTracking) {
      const r = await this.existTrackingsWithBox(existTracking, box_id);
      existTrackingData = [];
      updatedTrackingData = [...updatedTrackingData, ...existTracking];
    }

    return {
      existTracking: existTrackingData,
      insertedTracking: insertedTrackingData,
      updatedTracking: updatedTrackingData,
    };
  }

  public delete = async (trackingId, user) => {
    const tracking = await Tracking.query().select().where('trackings.id', trackingId).first();
    if (
      tracking.exploitStatus === 'Hoàn thành' ||
      tracking.exploitStatus === 'Đã đóng hàng' ||
      tracking.exploitStatus === 'Đang giao hàng' ||
      tracking.exploitStatus === 'Đã hủy bỏ'
    ) {
      throw new BadRequestException("tracking can't delete!");
    }
    if (tracking) {
      await Tracking.query()
        .patch({ code: tracking.code + 'DELETED' + generateRandomString(8), isDeleted: true, exploitStatus: 'Đã hủy bỏ' })
        .where('id', trackingId)
        .into('trackings');
      await TrackingsDeliveryBillLinks.query().delete().where('tracking_id', trackingId);
      // create backlog
      await TrackingLogs.query()
        .insert({
          trackingCode: tracking.code,
          actionType: 'entry.delete',
          actionTime: new Date(),
          trackingId,
          createdById: user?.id,
        })
        .into('tracking_logs');
    } else {
      throw new HttpException(404, "Tracking doesn't exist");
    }
  };

  public codeSuggestion = async (user, trackingCode, param) => {
    const queryBuilder = Tracking.query().from('trackings as tr');
    const { exploitStatus, fromDate, toDate, filterDateBy } = param;

    queryBuilder.leftJoinRelated('trackingType');

    if (exploitStatus !== undefined) {
      switch (exploitStatus) {
        case '0':
          queryBuilder.where('tr.status', 'Đang vận chuyển về VN');
          queryBuilder.where('tr.exploitStatus', 'Đang vận chuyển về vn');
          break;
        case '1':
          queryBuilder.where('tr.exploitStatus', 'Đã vận chuyển về vn');
          break;
        case '2':
          queryBuilder.where('tr.exploitStatus', 'Đã khai thác');
          break;
        case '3':
          queryBuilder.where('tr.exploitStatus', 'Đã hủy bỏ');
          break;
        case '4':
          queryBuilder.whereNull('trackingType.id');
          break;
        default:
          break;
      }
    }

    if (fromDate && toDate && filterDateBy) {
      queryBuilder.whereBetween(filterDateBy, [fromDate, toDate]);
    }

    const selectDelete = false;
    const codes = await queryBuilder
      .select('code')
      .joinRelated('customer')
      .where('customer.email', user.email)
      .andWhere('is_deleted', selectDelete)
      .andWhereLike('code', `%${trackingCode}`);
    return codes.length > 0 ? codes.map(c => c.code) : [];
  };

  public getCostModifiableDeliveryBillOfATracking = async trackingId => {
    if (!(await TrackingsDeliveryBillLinks.query().where('tracking_id', trackingId).first())) {
      return true;
    }
    const bill = await DeliveryBill.query()
      .from('delivery_bills as dvb')
      .leftJoinRelated('tracking as tr')
      .where('tr.id', trackingId)
      .whereIn('delivery_bill_status', ['Phiếu mới tạo', 'Sale duyệt'])
      .groupBy('dvb.id')
      .first();
    if (!bill) {
      throw new HttpException(400, 'This bill is already approved, cannot change shippingCost');
    }
    return true;
  };

  public updateTracking = async (trackingId, param, canModifyStatus: boolean, user?) => {
    if (isEmpty(param)) throw new HttpException(400, 'trackingData is empty');

    const tracking = await this.getDetailToCompare(trackingId);
    if (!tracking) {
      throw new HttpException(404, 'tracking is not found');
    }
    if (!TRACKING_UPDATABLE_STATUS.includes(this.getStatusTrackingReal(tracking))) {
      throw new HttpException(400, 'Order is not in updateable status!');
    }

    const validField = [
      'description',
      'importDate',
      'repackDate',
      'packedDate',
      'exportDate',
      'arrivalDate',
      'completedAt',
      'exploitedDate',
      'invoicedDate',
      'checkingDate',
      'isRepack',
      'isSplit',
      'parentTracking',
      'isDeleted',
      'imageUrl',
      'note',
      'exploitStatus',
      'shippingFee',
      'trackingMiningWeight',
      'trackingCalculationWeight',
      'trackingBarrelCoefficient',
      'trackingShippingCost',
      'trackingShippingFee',
      'trackingSurcharge',
      'trackingDeliveryFee',
      'trackingOtherFee',
      'trackingTotalMoney',
      'trackingDiscountAmount',
      'weight',
      'trackingAmount',
      'orderId',
      'optionalImage',
      'productName',
      'price',
      'uid',
    ];
    const data = {} as any;
    for (const field of validField) {
      if (param[field] != undefined || param[field] != null) {
        data[field] = param[field];
      }
    }
    if (param.status && canModifyStatus) {
      data.status = param.status;
      await TrackingStatusLogs.query()
        .insert({
          name: `[Kho US]-Đơn hàng đã thay đổi trạng thái mới: ${param.status}`,
          updatedTime: new Date(),
          trackingId: trackingId,
        })
        .into('tracking_status_logs');
    }
    data['updatedAt'] = new Date();
    const serviceBox = GeneralConfigService.getInstant();
    const boxCoefficient =
      Number(param.customizedBoxCoefficient) ||
      Number(tracking.trackingBarrelCoefficient) ||
      (await serviceBox.getBoxCoefficientConfig())?.trackingBarrelCoefficient;
    if (param.customer && param.customer !== tracking.customer[0]?.id) {
      const trackingCustomer = await TrackingCustomerLinks.query().where('tracking_id', trackingId).first();
      if (trackingCustomer) {
        await TrackingCustomerLinks.query()
          .update({
            customer_id: param.customer,
          })
          .where('tracking_id', trackingId);
        if (!tracking.orderId) {
          const { code } = await generateNextOrderId();
          await Tracking.query().patch({ orderId: code }).where('id', trackingId);
        }
        if (param.customer !== tracking.customer[0]?.id) {
          await TrackingsDeliveryBillLinks.query().delete().where('tracking_id', tracking.id);
          data.vnPackedDate = null;
          const sale: CustomerSaleLinks = await CustomerSaleLinks.query().select().where('customer_id', param.customer).first();
          if (sale && sale.userId) {
            const isExistLink = await TrackingSaleLinks.query().where('tracking_id', trackingId).first();
            if (isExistLink)
              await TrackingSaleLinks.query()
                .patch({
                  user_id: sale.userId,
                })
                .where('tracking_id', trackingId);
            else
              await TrackingSaleLinks.query().insert({
                tracking_id: trackingId,
                user_id: sale.userId,
              });
          }
        }
      } else {
        if (!tracking.orderId) {
          const { code } = await generateNextOrderId();
          await Tracking.query().patch({ orderId: code }).where('id', trackingId);
        }
        await TrackingCustomerLinks.query()
          .insert({
            customer_id: param.customer,
            tracking_id: trackingId,
          })
          .into('trackings_customer_links');
      }
    }

    if (param.customer || tracking.customer[0]) {
      const serviceCustomer = CustomerService.getInstant();
      const customerDetail = await serviceCustomer.findCustomerById(param.customer || tracking.customer[0].id);
      // update shipping_cost
      const warehouseVn = await TrackingsWarehouseVnLinksLink.query().where('tracking_id', tracking.id);
      let shippingCost = tracking.trackingShippingCost || 0;
      if (param.shippingCost && (await this.getCostModifiableDeliveryBillOfATracking(tracking.id))) {
        shippingCost = param.shippingCost;
      } else if (param.trackingType) {
        if (param.warehouseVN) {
          shippingCost = customerDetail.shippingCost.configValue.config.filter(
            item => item.tracking_type === param.trackingType && item.warehouse_config_id === param.warehouseVN,
          )[0].cost;
        } else if (warehouseVn && warehouseVn.length) {
          shippingCost = customerDetail.shippingCost.configValue.config.filter(
            item => item.tracking_type === param.trackingType && item.warehouse_config_id === warehouseVn[0].warehouseConfigId,
          )[0].cost;
        }
      }
      const trackingTotalMoney =
        Number(Number(Number(Number(param.trackingMiningWeight ?? tracking.trackingMiningWeight) || 0) * Number(boxCoefficient)).toFixed(2)) *
          (shippingCost || 0) +
        (Number(param.trackingSurcharge ?? tracking.trackingSurcharge) || 0) +
        (Number(param.trackingDeliveryFee ?? tracking.trackingDeliveryFee) || 0) +
        (Number(param.trackingOtherFee ?? tracking.trackingOtherFee) || 0) -
        (Number(param.trackingDiscountAmount ?? tracking.trackingDiscountAmount) || 0);
      if (trackingTotalMoney < 0) {
        throw new BadRequestException('Discount amount must smaller than t  rackingTotalMoney!');
      }
      await Tracking.query()
        .patch({
          ...data,
          trackingShippingCost: shippingCost || 0,
          trackingBarrelCoefficient: Number(boxCoefficient),
          trackingCalculationWeight: (Number(param.trackingMiningWeight ?? tracking.trackingMiningWeight) || 0) * Number(boxCoefficient),
          trackingShippingFee:
            Number(Number(Number(Number(param.trackingMiningWeight ?? tracking.trackingMiningWeight) || 0) * Number(boxCoefficient)).toFixed(2)) *
            (shippingCost || 0),
          trackingDiscountAmount: Number(param.trackingDiscountAmount ?? tracking.trackingDiscountAmount) || 0,
          trackingTotalMoney: trackingTotalMoney,
          trackingDeliveryFee: Number(param.trackingDeliveryFee ?? tracking.trackingDeliveryFee) || 0,
          updatedAt: new Date(),
        })
        .where('id', trackingId);
    } else {
      await Tracking.query()
        .patch({
          ...data,
          trackingBarrelCoefficient: Number(boxCoefficient),
          trackingCalculationWeight: (Number(param.trackingMiningWeight ?? tracking.trackingMiningWeight) || 0) * Number(boxCoefficient),
          updatedAt: new Date(),
        })
        .where('id', trackingId);
    }

    // trackingType
    if (param.trackingType) {
      const tracking = await TrackingsTrackingTypeLinks.query().where('tracking_id', trackingId).first();
      if (tracking) {
        await TrackingsTrackingTypeLinks.query()
          .update({
            tracking_type_id: param.trackingType,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingsTrackingTypeLinks.query()
          .insert({
            tracking_type_id: param.trackingType,
            tracking_id: trackingId,
          })
          .into('trackings_tracking_type_links');
      }
    }
    // businessPartner
    if (param.businessPartner) {
      const tracking = await TrackingBusinessPartnerLink.query().where('tracking_id', trackingId).first();
      if (tracking) {
        await TrackingBusinessPartnerLink.query()
          .update({
            business_partner_id: param.businessPartner,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingBusinessPartnerLink.query()
          .insert({
            business_partner_id: param.businessPartner,
            tracking_id: trackingId,
          })
          .into('trackings_business_partner_links');
      }
    }
    // warehouse
    if (param.warehouse) {
      const tracking = await TrackingsWarehouseLinksLink.query().where('tracking_id', trackingId).first();
      if (tracking) {
        await TrackingsWarehouseLinksLink.query()
          .update({
            warehouse_id: param.warehouse,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingsWarehouseLinksLink.query()
          .insert({
            warehouse_id: param.warehouse,
            tracking_id: trackingId,
          })
          .into('trackings_warehouse_links');
      }
    }
    // warehouseVn
    if (param.warehouseVn) {
      const tracking = await TrackingsWarehouseVnLinksLink.query().where('tracking_id', trackingId).first();
      if (tracking) {
        await TrackingsWarehouseVnLinksLink.query()
          .update({
            warehouse_config_id: param.warehouseVn,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingsWarehouseVnLinksLink.query()
          .insert({
            warehouse_config_id: param.warehouseVn,
            tracking_id: trackingId,
          })
          .into('trackings_warehouse_vn_links');
      }
    }
    // exploitedBy
    if (param.exploitedBy) {
      const tracking = await TrackingsExploitedByLinks.query().where('tracking_id', trackingId).first();
      if (tracking) {
        await TrackingsExploitedByLinks.query()
          .update({
            user_id: param.exploitedBy,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingsExploitedByLinks.query()
          .insert({
            user_id: param.exploitedBy,
            tracking_id: trackingId,
          })
          .into('trackings_exploited_by_links');
      }
    }
    // deliveryBill
    if (param.deliveryBill) {
      const tracking = await TrackingsDeliveryBillLinks.query().where('tracking_id', trackingId).first();
      if (tracking) {
        await TrackingsDeliveryBillLinks.query()
          .update({
            delivery_bill_id: param.deliveryBill,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingsDeliveryBillLinks.query()
          .insert({
            delivery_bill_id: param.deliveryBill,
            tracking_id: trackingId,
          })
          .into('trackings_delivery_bill_links');
      }
    }
    const updatedTracking = await this.getDetailToCompare(trackingId);

    if (updatedTracking.customer[0]) {
      updatedTracking.sale = updatedTracking.customer[0]?.sale ? updatedTracking.customer[0]?.sale[0] : null;
      delete updatedTracking.customer[0]?.sale;
      if (data.status && updatedTracking.customer[0].user && updatedTracking.customer[0].user[0]) {
        if (updatedTracking?.customer[0]?.isSubcribeToFcmNotification)
          await this.sendTrackingStatusPushNotification(updatedTracking.customer[0].user[0].id, updatedTracking.code, data.status, '[Kho US]');
      }
    }
    // create backlog

    setTimeout(async () => {
      try {
        await TrackingLogs.query()
          .insert({
            trackingCode: tracking.code,
            actionType: 'entry.update',
            actionTime: new Date(),
            changedField: JSON.stringify(getChangedFields(tracking, updatedTracking)),
            updatedAt: new Date(),
            trackingId: trackingId,
            createdById: user?.id,
          })
          .into('tracking_logs');
      } catch (e) {
        console.log(e);
      }
    }, 0);

    return {
      ...updatedTracking,
      box: updatedTracking.box[0] || null,
      awb: updatedTracking.awb[0] || null,
      businessPartner: updatedTracking.businessPartner[0] || null,
      warehouse: updatedTracking.warehouse[0] || null,
      warehouseVn: updatedTracking.warehouseVn[0] || null,
      exploitedBy: updatedTracking.exploitedBy[0] || null,
      deliveryBill: updatedTracking.deliveryBill[0] || null,
      customer: updatedTracking.customer[0] || null,
      trackingType: updatedTracking.trackingType[0] || null,
    };
  };

  public exploitTracking = async (user, trackingId, param) => {
    if (isEmpty(param)) throw new HttpException(400, 'trackingData is empty');
    if (user.type === 'customer') throw new HttpException(403, 'Permission denied');

    const tracking = await this.getDetailToCompare(trackingId);
    if (!tracking) {
      throw new HttpException(404, 'tracking is not found');
    }

    if (!param.trackingAmount || !param.trackingMiningWeight || !param.trackingType || !param.warehouseVn) {
      throw new HttpException(404, 'param is missing!');
    }
    const validField = [
      'description',
      'importDate',
      'repackDate',
      'packedDate',
      'exportDate',
      'arrivalDate',
      'completedAt',
      'exploitedDate',
      'invoicedDate',
      'checkingDate',
      'isRepack',
      'isSplit',
      'parentTracking',
      'isDeleted',
      'imageUrl',
      'note',
      'exploitStatus',
      'shippingFee',
      'trackingMiningWeight',
      'trackingCalculationWeight',
      'trackingBarrelCoefficient',
      'trackingShippingCost',
      'trackingShippingFee',
      'trackingSurcharge',
      'trackingDeliveryFee',
      'trackingOtherFee',
      'trackingDiscountAmount',
      'trackingTotalMoney',
      'weight',
      'trackingAmount',
      'orderId',
      'optionalImage',
      'productName',
      'price',
      'uid',
    ];

    const data = {} as any;
    for (const field of validField) {
      if (param[field] != undefined || param[field] != null) {
        data[field] = param[field];
      }
    }

    data['updatedAt'] = new Date();
    const serviceBox = GeneralConfigService.getInstant();
    const boxCoefficient = await serviceBox.getBoxCoefficientConfig();
    const trackingBarrelCoefficient = Number(param.customizedBoxCoefficient) || boxCoefficient.trackingBarrelCoefficient;
    const serviceCustomer = CustomerService.getInstant();
    // update shipping_cost

    let shippingCost = 0;
    let customerUserId = null;
    const warehouseVn = await TrackingsWarehouseVnLinksLink.query().where('tracking_id', tracking.id);
    if (param.customer || tracking.customer[0]) {
      const customerDetail = await serviceCustomer.findCustomerById(param.customer || tracking.customer[0].id);
      // update shipping_cost
      customerUserId = customerDetail.user.id;
      if (param.warehouseVn) {
        shippingCost = customerDetail.shippingCost.configValue.config.filter(
          item => item.tracking_type === param.trackingType && item.warehouse_config_id === param.warehouseVn,
        )[0].cost;
      } else if (warehouseVn) {
        shippingCost = customerDetail.shippingCost.configValue.config.filter(
          item => item.tracking_type === param.trackingType && item.warehouse_config_id === warehouseVn[0].warehouseConfigId,
        )[0].cost;
      }
    }

    if (param.customer) {
      const trackingCustomer = await TrackingCustomerLinks.query().where('tracking_id', trackingId).first();
      if (trackingCustomer) {
        await TrackingCustomerLinks.query()
          .update({
            customer_id: param.customer,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingCustomerLinks.query()
          .insert({
            customer_id: param.customer,
            tracking_id: trackingId,
          })
          .into('trackings_customer_links');
      }
      if (!tracking.orderId) {
        const { code } = await generateNextOrderId();
        await Tracking.query().patch({ orderId: code }).where('id', trackingId);
      }
    }
    const trackingCalculationWeight = Number(
      Number((Number(param.trackingMiningWeight ?? tracking.trackingMiningWeight) || 0) * Number(trackingBarrelCoefficient)).toFixed(2),
    );
    const trackingTotalMoney =
      trackingCalculationWeight * (shippingCost || 0) +
      (Number(tracking.trackingSurcharge) || 0) +
      (Number(tracking.trackingDeliveryFee) || 0) +
      (Number(tracking.trackingOtherFee) || 0) -
      (Number(param.trackingDiscountAmount) || Number(tracking.trackingDiscountAmount) || 0);
    if (trackingTotalMoney < 0) {
      throw new BadRequestException('Discount amount must smaller than trackingTotalMoney!');
    }
    await Tracking.query()
      .patch({
        ...data,
        trackingShippingCost: shippingCost || 0,
        trackingBarrelCoefficient: Number(trackingBarrelCoefficient),
        trackingCalculationWeight: trackingCalculationWeight,
        trackingShippingFee: trackingCalculationWeight * (shippingCost || 0),
        trackingDiscountAmount: Number(param.trackingDiscountAmount ?? tracking.trackingDiscountAmount) || 0,
        trackingTotalMoney: trackingTotalMoney,
        trackingDeliveryFee: Number(tracking.trackingDeliveryFee) || 0,
        exploitStatus: 'Đã khai thác',
        status: 'Hoàn thành',
        exploitedDate: new Date(),
        updatedAt: new Date(),
      })
      .where('id', trackingId);

    let statusBox = null;
    let quantityTrackingExploit = 0;

    // trackingType
    if (param.trackingType) {
      const tracking = await TrackingsTrackingTypeLinks.query().where('tracking_id', trackingId).first();
      if (tracking) {
        await TrackingsTrackingTypeLinks.query()
          .update({
            tracking_type_id: param.trackingType,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingsTrackingTypeLinks.query()
          .insert({
            tracking_type_id: param.trackingType,
            tracking_id: trackingId,
          })
          .into('trackings_tracking_type_links');
      }
    }
    // businessPartner
    if (param.businessPartner || (tracking.businessPartner && tracking.businessPartner.length === 0)) {
      const tracking = await TrackingBusinessPartnerLink.query().where('tracking_id', trackingId).first();
      if (tracking) {
        await TrackingBusinessPartnerLink.query()
          .update({
            business_partner_id: param.businessPartner || 1,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingBusinessPartnerLink.query()
          .insert({
            business_partner_id: param.businessPartner || 1,
            tracking_id: trackingId,
          })
          .into('trackings_business_partner_links');
      }
    }
    // warehouse
    if (param.warehouse) {
      const tracking = await TrackingsWarehouseLinksLink.query().where('tracking_id', trackingId).first();
      if (tracking) {
        await TrackingsWarehouseLinksLink.query()
          .update({
            warehouse_id: param.warehouse,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingsWarehouseLinksLink.query()
          .insert({
            warehouse_id: param.warehouse,
            tracking_id: trackingId,
          })
          .into('trackings_warehouse_links');
      }
    }
    // warehouseVn
    if (param.warehouseVn) {
      const tracking = await TrackingsWarehouseVnLinksLink.query().where('tracking_id', trackingId).first();
      if (tracking) {
        await TrackingsWarehouseVnLinksLink.query()
          .update({
            warehouse_config_id: param.warehouseVn,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingsWarehouseVnLinksLink.query()
          .insert({
            warehouse_config_id: param.warehouseVn,
            tracking_id: trackingId,
          })
          .into('trackings_warehouse_vn_links');
      }
    }
    // exploitedBy
    if (user?.id) {
      const tracking = await TrackingsExploitedByLinks.query().where('tracking_id', trackingId).first();
      if (tracking) {
        await TrackingsExploitedByLinks.query()
          .update({
            user_id: user?.id,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingsExploitedByLinks.query()
          .insert({
            user_id: user?.id,
            tracking_id: trackingId,
          })
          .into('trackings_exploited_by_links');
      }
    }
    // deliveryBill
    if (param.deliveryBill) {
      const tracking = await TrackingsDeliveryBillLinks.query().where('tracking_id', trackingId).first();
      if (tracking) {
        await TrackingsDeliveryBillLinks.query()
          .update({
            delivery_bill_id: param.deliveryBill,
          })
          .where('tracking_id', trackingId);
      } else {
        await TrackingsDeliveryBillLinks.query()
          .insert({
            delivery_bill_id: param.deliveryBill,
            tracking_id: trackingId,
          })
          .into('trackings_delivery_bill_links');
      }
    }
    const updatedTracking = await this.getDetailToCompare(trackingId);
    if (updatedTracking.customer[0]) {
      updatedTracking.sale = updatedTracking.customer[0]?.sale ? updatedTracking.customer[0]?.sale[0] : null;
      delete updatedTracking.customer[0]?.sale;
    }

    setTimeout(async () => {
      try {
        // create backlog
        await TrackingStatusLogs.query()
          .insert({
            name: 'Đơn hàng đã được khai thác bởi đối tác Việt Nam',
            updatedTime: new Date(),
            trackingId,
          })
          .into('tracking_status_logs');
        if (tracking.box.length !== 0) {
          const boxes = await Box.query().findById(tracking.box[0].id).withGraphFetched('trackingBoxes');
          let checkBox = 0;
          boxes.trackingBoxes.forEach(item => {
            if (item.exploitStatus === 'Đã vận chuyển về vn' || item.exploitStatus === 'Đang vận chuyển về vn') {
              checkBox++;
            }
          });
          if (checkBox === 0) {
            statusBox = 'Đã khai thác';
            await Box.query()
              .patch({ exploitStatus: 'Đã khai thác', status: 'Hoàn thành', exploitEndDate: new Date() })
              .where('id', tracking.box[0].id);
          } else {
            statusBox = 'Đang khai thác';
            await Box.query()
              .patch({ exploitStatus: 'Đang khai thác', status: 'Hoàn thành', exploitStartDate: new Date() })
              .where('id', tracking.box[0].id)
              .andWhereNot('exploitStatus', 'Đang khai thác');
          }
        }
        if (tracking.awb.length !== 0) {
          const awb = (await Awb.query().findById(tracking.awb[0].id).withGraphFetched('box').withGraphFetched('tracking')) as any;
          let minStatus = 7;
          awb.box.forEach(async box => {
            let boxStatusAsNumber = 7;
            switch (box.exploitStatus) {
              case 'Đang vận chuyển về vn':
                boxStatusAsNumber = 3;
                break;
              case 'Đã vận chuyển về vn':
                boxStatusAsNumber = 4;
                break;
              case 'Đang khai thác':
                boxStatusAsNumber = 5;
                break;
              case 'Đã khai thác':
                boxStatusAsNumber = 6;
                break;
              default:
                boxStatusAsNumber = 7;
                break;
            }
            if (boxStatusAsNumber < minStatus) {
              minStatus = boxStatusAsNumber;
            }
          });
          let awbStatus: string;
          switch (minStatus) {
            case 3:
              awbStatus = 'Đang vận chuyển về vn';
              break;
            case 4:
              awbStatus = 'Đã vận chuyển về vn';
              break;
            case 5:
              awbStatus = 'Đang khai thác';
              break;
            case 6:
              awbStatus = 'Đã khai thác';
              break;
            default:
              awbStatus = 'Đang vận chuyển về vn';
              break;
          }
          await Awb.query().patch({ exploitStatus: awbStatus, status: 'Hoàn thành' }).where('id', tracking.awb[0].id);
          awb.tracking.forEach(item => {
            if (
              item.exploitStatus === 'Đã khai thác' ||
              item.exploitStatus === 'Hoàn thành' ||
              item.exploitStatus === 'Đang giao hàng' ||
              item.exploitStatus === 'Đã đóng hàng'
            ) {
              quantityTrackingExploit++;
            }
          });
        }
        await TrackingLogs.query()
          .insert({
            trackingCode: tracking.code,
            actionType: 'entry.update',
            actionTime: new Date(),
            changedField: JSON.stringify(getChangedFields(tracking, updatedTracking)),
            updatedAt: new Date(),
            trackingId: trackingId,
            createdById: user?.id,
          })
          .into('tracking_logs');

        const trackingUpdated = await Tracking.query().findById(trackingId).withGraphFetched('customer');
        if (customerUserId && trackingUpdated?.customer[0]?.isSubcribeToFcmNotification)
          await this.sendTrackingStatusPushNotification(customerUserId, trackingUpdated.code, 'Đã khai thác', '[VN]');
      } catch (e) {
        console.log(e);
      }
    }, 0);
    return {
      ...updatedTracking,
      box: updatedTracking.box[0] || null,
      awb: updatedTracking.awb[0] || null,
      businessPartner: updatedTracking.businessPartner[0] || null,
      warehouse: updatedTracking.warehouse[0] || null,
      warehouseVn: updatedTracking.warehouseVn[0] || null,
      exploitedBy: updatedTracking.exploitedBy[0] || null,
      deliveryBill: updatedTracking.deliveryBill[0] || null,
      customer: updatedTracking.customer[0] || null,
      trackingType: updatedTracking.trackingType[0] || null,
      statusBox: statusBox,
      quantityTrackingExploit: quantityTrackingExploit,
    };
  };

  public findPublic = async (trackingCode: string, isGettingStatusLog: string) => {
    const code = trackingCode.split(',') || [];

    if (code.length === 0) {
      throw new HttpException(404, 'Tracking not found');
    }

    const queryBuilder = Tracking.query();

    queryBuilder
      .select(
        'id',
        'code',
        'status',
        'exploitStatus',
        'imageUrl',
        'optionalImage',
        'trackingCalculationWeight',
        'trackingTotalMoney',
        'createdAt',
        'note',
        'description',
        'orderId',
        'importDate',
        'packedDate',
        'arrivalDate',
        'vnImportDate',
        'exploitedDate',
      )
      .withGraphFetched('awb')
      .withGraphFetched('warehouse')
      .withGraphFetched('statusLogs')
      .withGraphFetched('trackingType')
      .whereIn('code', code);

    code.forEach(item => {
      queryBuilder.orWhere('code', 'like', `%${item.slice(-8)}`);
    });

    const trackings: any = await queryBuilder;

    if (!trackings) {
      throw new HttpException(404, 'Tracking not found');
    }
    return await Promise.all(
      trackings.map(async resTracking => {
        if (isGettingStatusLog === 'true') {
          resTracking.statusLogs = await TrackingStatusLogs.query().where('trackingId', resTracking.id);
          const timelineFromWh = resTracking.whTrackingId ? await getTimelineOfATrackingFromWh(resTracking.whTrackingId) : [];
          resTracking.statusLogs = timelineFromWh ? timelineFromWh.concat(resTracking.statusLogs) : resTracking.statusLogs;
        }
        return {
          ...resTracking,
          status: this.getStatusTrackingReal(resTracking),
        };
      }),
    );
  };

  public findOne = async (user, id) => {
    let customerId = [];
    const queryBuilder = Tracking.query();

    if (user.role.type.toLowerCase() === 'customer') {
      customerId = user.customer?.id ? [user.customer.id] : [];
    } else {
      const listCustomer = await Users.query()
        .findById(user.id)
        .withGraphFetched('saleOfCustomer')
        .modifyGraph('saleOfCustomer', builder => builder.select('customers.id'));
      customerId = listCustomer.saleOfCustomer.map(c => c.id);
    }

    if (customerId.length === 0) {
      throw new BadRequestException('Customer is not found');
    }

    const tracking = await queryBuilder
      .leftJoinRelated('customer')
      .whereIn('customer.id', customerId)
      .withGraphFetched('trackingType')
      .withGraphFetched('awb')
      .withGraphFetched('box')
      .withGraphFetched('businessPartner')
      .withGraphFetched('warehouse')
      .withGraphFetched('warehouseVn')
      .withGraphFetched('exploitedBy')
      .withGraphFetched('deliveryBill')
      .withGraphFetched('customer')
      .findById(id)
      .first();

    if (!tracking) {
      throw new HttpException(404, 'Tracking is not found');
    }

    return {
      ...tracking,
      box: tracking.box[0] || null,
      awb: tracking.awb[0] || null,
      businessPartner: tracking.businessPartner[0] || null,
      warehouse: tracking.warehouse[0] || null,
      warehouseVn: tracking.warehouseVn[0] || null,
      exploitedBy: tracking.exploitedBy[0] || null,
      deliveryBill: tracking.deliveryBill[0] || null,
      customer: tracking.customer[0] || null,
      trackingType: tracking.trackingType[0] || null,
    };
  };

  private getDetailToCompare = async trackingId => {
    return Tracking.query()
      .findById(trackingId)
      .withGraphFetched('awb')
      .withGraphFetched('box')
      .withGraphFetched('trackingType')
      .withGraphFetched('customer')
      .modifyGraph('customer', builder => builder.withGraphFetched('sale').withGraphFetched('user'))
      .withGraphFetched('businessPartner')
      .withGraphFetched('warehouse')
      .withGraphFetched('warehouseVn')
      .withGraphFetched('exploitedBy')
      .withGraphFetched('deliveryBill')
      .withGraphFetched('sale');
  };

  public searchTracking = async codes => {
    try {
      const { data } = await getListTrackings(1, { trackingCodes: codes });
      return data.rows.map(tr => {
        tr.wh_tracking_id = tr.id;
        tr.warehouse = tr.Warehouse ? tr.Warehouse.id : null;
        tr.imageUrl =
          tr.Images.map(i => {
            if (i.isMain === true) {
              return i.optimizeUrl;
            }
          })[0] || null;
        tr.optionalImage =
          tr.Images.map(i => {
            if (i.isMain === false) {
              return i.optimizeUrl;
            }
          })?.join(',') || null;

        delete tr.note;
        delete tr.order_id;
        delete tr.id;
        delete tr.isSynced;
        delete tr.business_partner;
        delete tr.businessPartner;

        delete tr.Author;
        delete tr.Tickets;
        delete tr.Images;
        delete tr.Partner;
        delete tr.Awb;
        delete tr.Box;
        delete tr.Warehouse;
        delete tr.TrackingType;
        return {
          ...tr,
        };
      });
    } catch (e) {}
  };

  public searchTrackingAlongId = async code => {
    const queryBuilder = Tracking.query();
    const tracking = await queryBuilder
      .leftJoinRelated('customer')
      .where('code', code)
      .orWhereLike('code', `%${code.slice(-8)}`)
      .where('is_deleted', false)
      .withGraphFetched('trackingType')
      .withGraphFetched('awb')
      .withGraphFetched('box')
      .withGraphFetched('businessPartner')
      .withGraphFetched('warehouse')
      .withGraphFetched('warehouseVn')
      .withGraphFetched('exploitedBy')
      .withGraphFetched('deliveryBill')
      .withGraphFetched('customer')
      .first();

    return {
      ...tracking,
      box: tracking.box[0] || null,
      awb: tracking.awb[0] || null,
      businessPartner: tracking.businessPartner[0] || null,
      warehouse: tracking.warehouse[0] || null,
      warehouseVn: tracking.warehouseVn[0] || null,
      exploitedBy: tracking.exploitedBy[0] || null,
      deliveryBill: tracking.deliveryBill[0] || null,
      customer: tracking.customer[0] || null,
      trackingType: tracking.trackingType[0] || null,
    };
  };

  public findFromDatabaseAndWarehouse = async code => {
    let results = [];
    const codes = code.split(',') || [code];

    const queryBuilder = Tracking.query();

    queryBuilder
      .withGraphFetched('awb')
      .withGraphFetched('box')
      .withGraphFetched('trackingType')
      .withGraphFetched('customer')
      .withGraphFetched('businessPartner')
      .withGraphFetched('warehouse')
      .withGraphFetched('warehouseVn')
      .withGraphFetched('exploitedBy')
      .withGraphFetched('deliveryBill')
      .leftJoinRelated('businessPartner')
      .whereIn('code', codes)
      .where('is_deleted', false);

    codes.forEach(item => {
      queryBuilder.orWhere('code', 'like', `%${item.slice(-8)}`);
    });

    const existedTracking: any = await queryBuilder;

    existedTracking.forEach(tr => {
      if (codes.includes(tr.code)) {
        codes.splice(codes.indexOf(tr.code), 1);
      }
    });
    const unique = {};
    const result = [];
    for (const item of existedTracking) {
      if (!unique[item.code]) {
        result.push(item);
        unique[item.code] = true;
      }
    }

    result.forEach(tr => {
      results.push({
        ...tr,
        box: tr.box[0] || null,
        awb: tr.awb[0] || null,
        businessPartner: tr.businessPartner[0] || null,
        warehouse: tr.warehouse[0] || null,
        warehouseVn: tr.warehouseVn[0] || null,
        exploitedBy: tr.exploitedBy[0] || null,
        deliveryBill: tr.deliveryBill[0] || null,
        customer: tr.customer[0] || null,
        trackingType: tr.trackingType[0] || null,
        exploitStatus: this.getStatusTrackingReal(tr),
      });
    });
    results = results.concat(await this.findAndUpdateFromWarehouse(codes));
    return results;
  };

  public findAndUpdateFromWarehouse = async codes => {
    const results = [];
    if (codes.length) {
      const data = await this.searchTracking(codes);

      if (data) {
        for (const tr of data) {
          const tracking = await Tracking.query().where('code', tr.code).first();
          const trackingData = { ...tr };
          delete trackingData.code;
          if (tracking) {
            const updatedTracking = await this.updateTracking(tracking.id, trackingData, true);
            results.push(updatedTracking);
          } else {
            const warehouse = tr.warehouse;
            delete tr.warehouse;
            const newTracking = await Tracking.query()
              .insert({
                ...tr,
                exploitStatus: 'Đang vận chuyển về vn',
                isDeleted: false,
              })
              .into('trackings');
            await TrackingBusinessPartnerLink.query().insert({
              tracking_id: newTracking.id,
              business_partner_id: 1,
            });
            if (warehouse) {
              await TrackingsWarehouseLinksLink.query()
                .insert({
                  warehouse_id: warehouse,
                  tracking_id: newTracking.id,
                })
                .into('trackings_warehouse_links');
            }
            const updatedTracking = await Tracking.query()
              .findById(newTracking.id)
              .withGraphFetched('awb')
              .withGraphFetched('box')
              .withGraphFetched('trackingType')
              .withGraphFetched('customer')
              .withGraphFetched('businessPartner')
              .withGraphFetched('warehouse')
              .withGraphFetched('warehouseVn')
              .withGraphFetched('exploitedBy')
              .withGraphFetched('deliveryBill')
              .leftJoinRelated('businessPartner');
            results.push({
              ...updatedTracking,
              box: updatedTracking.box[0] || null,
              awb: updatedTracking.awb[0] || null,
              businessPartner: updatedTracking.businessPartner[0] || null,
              warehouse: updatedTracking.warehouse[0] || null,
              warehouseVn: updatedTracking.warehouseVn[0] || null,
              exploitedBy: updatedTracking.exploitedBy[0] || null,
              deliveryBill: updatedTracking.deliveryBill[0] || null,
              customer: updatedTracking.customer[0] || null,
              trackingType: updatedTracking.trackingType[0] || null,
              exploitStatus: this.getStatusTrackingReal(updatedTracking),
            });
          }
        }
      }
    }
    return results;
  };

  public getListTracking = async (req: RequestWithUser, user, param) => {
    const { page = 0, pageSize = 10 } = param;
    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }
    const queryBuilder = Tracking.query().from('trackings as tr');
    this.filterTracking(req, user, param, queryBuilder, false);
    const listTracking = await queryBuilder
      .withGraphFetched('trackingType')
      .withGraphFetched('awb')
      .withGraphFetched('box')
      .withGraphFetched('businessPartner')
      .withGraphFetched('warehouse')
      .withGraphFetched('warehouseVn')
      .withGraphFetched('exploitedBy')
      .withGraphFetched('deliveryBill')
      .withGraphFetched('customer')
      .modifyGraph('customer', builder =>
        builder
          .withGraphFetched('boxStag as tags')
          .select('customers.id', 'customers.name', 'customers.nick_name', 'customers.shipping_cost', 'customers.email', 'customers.id_customer'),
      )
      .withGraphFetched('sale')
      .withGraphFetched('vnPackedBy')
      .groupBy('tr.id')
      .orderBy('createdAt', 'desc')
      .page(pageIndex, pageSize);

    let { results, total } = listTracking;
    if (!results) throw new HttpException(404, "Tracking list doesn't exist");
    results = results.map(tr => {
      return {
        ...tr,
        box: tr.box[0] || null,
        awb: tr.awb[0] || null,
        businessPartner: tr.businessPartner[0] || null,
        warehouse: tr.warehouse[0] || null,
        warehouseVn: tr.warehouseVn[0] || null,
        exploitedBy: tr.exploitedBy[0] || null,
        deliveryBill: tr.deliveryBill[0] || null,
        customer: tr.customer[0] || null,
        trackingType: tr.trackingType[0] || null,
        sale: tr.sale[0] || null,
        status: this.getStatusTrackingReal(tr),
      };
    }) as any;

    return {
      pagination: {
        page: Number(pageIndex) + 1,
        pageSize: Number(pageSize),
        total,
        totalPage: Math.ceil(total / pageSize),
      },
      data: results,
    };
  };

  private filterTracking(req, user, param, queryBuilder, statusOnly) {
    let { exploitStatus, fromDate, toDate, filterDateBy, code, customer, sale, warehouse_id, isGettingOrder } = param;
    let { undefinedCustomer } = param;
    let orderByField = filterDateBy;
    if (statusOnly) {
      exploitStatus = orderByField = null;
    }
    if (code) {
      queryBuilder.whereLike('tr.code', `%${code}%`);
    }

    if (filterDateBy && fromDate && toDate) {
      queryBuilder.where(filterDateBy, '>=', new Date(fromDate)).where(filterDateBy, '<=', new Date(toDate));
    }
    if (isGettingOrder) {
      queryBuilder.whereNotNull('tr.order_id');
    }

    if (orderByField) {
      queryBuilder.orderBy(orderByField, 'desc');
    }

    if (warehouse_id && (!req.permission_business_logic || req.permission_business_logic == 1)) {
      queryBuilder
        .innerJoin('trackings_warehouse_vn_links', 'tr.id', '=', 'trackings_warehouse_vn_links.tracking_id')
        .where('trackings_warehouse_vn_links.warehouse_config_id', warehouse_id);
    }

    if (exploitStatus !== undefined && exploitStatus !== null && customer) {
      queryBuilder
        .innerJoin('trackings_customer_links', 'tr.id', '=', 'trackings_customer_links.tracking_id')
        .innerJoin('customers', 'trackings_customer_links.customer_id', '=', 'customers.id')
        .where('trackings_customer_links.customer_id', customer);
      switch (exploitStatus) {
        case '0':
          queryBuilder.where('trackings_customer_links.customer_id', customer);
          break;
        case '1':
          queryBuilder
            .whereIn('tr.status', ['Chờ nhập kho US', 'Đã tiếp nhận', 'Chưa nhập kho'])
            .andWhere('tr.exploit_status', 'Đang vận chuyển về vn')
            .where('trackings_customer_links.customer_id', customer);
          break;
        case '2':
          queryBuilder
            .where('tr.status', 'Đã nhập kho')
            .andWhere('tr.exploit_status', 'Đang vận chuyển về vn')
            .where('trackings_customer_links.customer_id', customer);
          break;
        case '3':
          queryBuilder
            .whereIn('tr.status', ['Đang đóng thùng', 'Đã đóng thùng', 'Đang xử lý awb', 'Đang vận chuyển về VN', 'Hoàn thành'])
            .andWhere('tr.exploit_status', 'Đang vận chuyển về vn')
            .andWhere('trackings_customer_links.customer_id', customer);
          break;
        case '4':
          queryBuilder.where('tr.exploit_status', 'Đã vận chuyển về vn').where('trackings_customer_links.customer_id', customer);
          break;
        case '5':
          queryBuilder.where('tr.exploit_status', 'Đã khai thác').where('trackings_customer_links.customer_id', customer);
          break;
        case '6':
          queryBuilder.where('tr.exploit_status', 'Đã đóng hàng').where('trackings_customer_links.customer_id', customer);
          break;
        case '7':
          queryBuilder.where('tr.exploit_status', 'Đang giao hàng').where('trackings_customer_links.customer_id', customer);
          break;
        case '8':
          queryBuilder.where('tr.exploit_status', 'Hoàn thành').where('trackings_customer_links.customer_id', customer);
          break;
        case '9':
          queryBuilder.where('tr.is_deleted', true).where('trackings_customer_links.customer_id', customer);
          break;
        default:
          break;
      }
    } else if (exploitStatus !== undefined && exploitStatus !== null && !customer) {
      switch (exploitStatus) {
        case '0':
          break;
        case '1':
          queryBuilder.whereIn('tr.status', ['Chờ nhập kho US', 'Đã tiếp nhận', 'Chưa nhập kho']);
          break;
        case '2':
          queryBuilder.where('tr.status', 'Đã nhập kho');
          break;
        case '3':
          queryBuilder
            .whereIn('tr.status', ['Đang đóng thùng', 'Đã đóng thùng', 'Đang xử lý awb', 'Đang vận chuyển về VN', 'Hoàn thành'])
            .andWhere('tr.exploit_status', 'Đang vận chuyển về vn');
          break;
        case '4':
          queryBuilder.where('tr.exploit_status', 'Đã vận chuyển về vn');
          break;
        case '5':
          queryBuilder.where('tr.exploit_status', 'Đã khai thác');
          break;
        case '6':
          queryBuilder.where('tr.exploit_status', 'Đã đóng hàng');
          break;
        case '7':
          queryBuilder.where('tr.exploit_status', 'Đang giao hàng');
          break;
        case '8':
          queryBuilder.where('tr.exploit_status', 'Hoàn thành');
          break;
        case '9':
          queryBuilder.where('tr.is_deleted', true);
          break;
        default:
          break;
      }
    } else if (customer) {
      queryBuilder
        .innerJoin('trackings_customer_links', 'tr.id', '=', 'trackings_customer_links.tracking_id')
        .innerJoin('customers', 'trackings_customer_links.customer_id', '=', 'customers.id')
        .where('trackings_customer_links.customer_id', customer);
    }

    if (exploitStatus !== '9' && !statusOnly) {
      queryBuilder.whereNot('tr.is_deleted', true);
    }

    if (req.permission_business_logic) {
      if (req.permission_business_logic === 5 && !isGettingOrder) {
        undefinedCustomer = true;
      }
      this.additionalReqPermissionLogic(req, queryBuilder, customer, user, isGettingOrder);
    }

    if (sale) {
      queryBuilder.leftJoinRelated('sale').where('sale.id', sale);
    }

    if (user && user.businessPartner) {
      queryBuilder.leftJoinRelated('businessPartner').where('businessPartner.id', user.businessPartner.id);
    }

    if (undefinedCustomer && undefinedCustomer != 'false' && undefinedCustomer != false) {
      queryBuilder.leftJoinRelated('customer').whereNull('customer.id');
    }
  }

  public getDetailTracking = async (req, id, isGettingStatusLog, isGettingBacklogs) => {
    const queryBuilder = Tracking.query()
      .withGraphFetched('customer')
      .modifyGraph('customer', builder => builder.withGraphFetched('boxStag as tags'))
      .withGraphFetched('box')
      .withGraphFetched('awb')
      .withGraphFetched('businessPartner')
      .withGraphFetched('warehouse')
      .withGraphFetched('warehouseVn')
      .withGraphFetched('exploitedBy')
      .withGraphFetched('deliveryBill')
      .withGraphFetched('trackingType')
      .withGraphFetched('vnPackedBy')
      .findById(id);
    const { user } = req;
    let timelineFromWh = null;
    if (req.permission_business_logic) {
      switch (req.permission_business_logic) {
        case 1:
          break;
        case 2:
          if (req.customer)
            queryBuilder
              .innerJoin('customers_sale_links', 'customers_sale_links.customer_id', '=', 'customers.id')
              .where('customers_sale_links.user_id', user.id);
          else
            queryBuilder
              .innerJoin('trackings_customer_links', 'trackings.id', '=', 'trackings_customer_links.tracking_id')
              .innerJoin('customers', 'trackings_customer_links.customer_id', '=', 'customers.id')
              .innerJoin('customers_sale_links', 'customers_sale_links.customer_id', '=', 'customers.id')
              .where('customers_sale_links.user_id', user.id);
          break;
        case 3:
          queryBuilder
            .innerJoin('trackings_warehouse_vn_links', 'trackings.id', '=', 'trackings_warehouse_vn_links.tracking_id')
            .where('trackings_warehouse_vn_links.warehouse_config_id', user.warehouseVN[0].id);
          break;
        case 4:
          if (req.customer)
            queryBuilder
              .innerJoin('customers_service_staff_links', 'customers_service_staff_links.customer_id', '=', 'customers.id')
              .where('customers_service_staff_links.user_id', user.id);
          else
            queryBuilder
              .innerJoin('trackings_customer_links', 'trackings.id', '=', 'trackings_customer_links.tracking_id')
              .innerJoin('customers', 'trackings_customer_links.customer_id', '=', 'customers.id')
              .innerJoin('customers_service_staff_links', 'customers_service_staff_links.customer_id', '=', 'customers.id')
              .where('customers_service_staff_links.user_id', user.id);
          break;
        default:
          break;
      }
    }
    let tracking;
    if (isGettingStatusLog === 'true') {
      queryBuilder.withGraphFetched('statusLogs');
      tracking = await queryBuilder;
      timelineFromWh = tracking.whTrackingId ? await getTimelineOfATrackingFromWh(tracking.whTrackingId) : [];
      tracking.statusLogs = timelineFromWh ? timelineFromWh.concat(tracking.statusLogs) : tracking.statusLogs;
    } else {
      tracking = await queryBuilder.withGraphFetched('statusLogs');
    }
    let backlogs = null;
    if (isGettingBacklogs)
      backlogs = await TrackingLogs.query()
        .select('id', 'actionTime', 'actionType', 'trackingCode', 'changedField', 'trackingId', 'createdAt', 'createdById')
        .where('tracking_id', id)
        .whereNotIn('actionType', ['entry.createOrder', 'entry.createTracking'])
        .withGraphFetched('createdBy')
        .orderBy('action_time', 'asc');
    if (!tracking) {
      throw new HttpException(404, 'Tracking is not found');
    }
    return {
      data: {
        ...tracking,
        status: this.getStatusTrackingReal(tracking),
        box: tracking.box[0] || null,
        awb: tracking.awb[0] || null,
        businessPartner: tracking.businessPartner[0] || null,
        warehouse: tracking.warehouse[0] || null,
        warehouseVn: tracking.warehouseVn[0] || null,
        exploitedBy: tracking.exploitedBy[0] || null,
        deliveryBill: tracking.deliveryBill[0] || null,
        customer: tracking.customer[0] || null,
        trackingType: tracking.trackingType[0] || null,
        backlogs,
      },
    };
  };

  public getStatusTracking = async (req, param) => {
    let queryBuilder: any = Tracking.query()
      .select('exploitStatus', 'status', 'isDeleted')
      .from('trackings as tr')
      .count('tr.id as total')
      .groupBy('exploitStatus', 'status', 'isDeleted');
    await getReqPerrmissionBusinessLogic(req, 'api:: GET /api/trackings');
    this.filterTracking(req, req.user, param, queryBuilder, true);
    queryBuilder = await queryBuilder;
    const summary: any = {};

    // Khởi tạo summary với số lượng 0 cho tất cả các trạng thái
    Object.keys(TRACKING_STATUS_ORDER).forEach(status => {
      summary[status] = 0;
    });

    queryBuilder.forEach(item => {
      const name = getStatusTrackingReal(item);
      summary[name] += parseInt(item.total);
    });

    const summaryArray = Object.entries(summary)
      .map(([name, total]) => ({ name, total: total.toString() }))
      .map(item => ({ ...item, id: TRACKING_STATUS_ORDER[item.name] }))
      .sort((a, b) => a.id - b.id);

    return summaryArray;
  };

  public createManyTracking = async (trackingList, user) => {
    const self = this;
    return await Promise.all(
      trackingList.map(async trackingData => {
        return self.createTracking(trackingData, user);
      }),
    );
  };

  public createTracking = async (trackingData, user) => {
    if (isEmpty(trackingData)) throw new HttpException(400, 'trackingData is required');
    if (isEmpty(trackingData.code)) throw new HttpException(400, 'tracking code is required');

    const existTracking = await Tracking.query()
      .whereLike('code', `%${trackingData.code?.slice(-8)}`)
      .first();

    if (existTracking) {
      throw new BadRequestException(`Tracking ${existTracking.code} is existed`);
    }

    const data = {} as any;
    for (const field of TrackingService.INSERT_FIELDS) {
      if (trackingData[field] != undefined || trackingData[field] != null) {
        data[field] = trackingData[field];
      }
    }
    data['createdAt'] = moment().toDate();
    if (!data['status']) {
      data['status'] = 'Đã tiếp nhận';
    }
    if (!data['exploitStatus']) {
      data['exploitStatus'] = 'Đang vận chuyển về vn';
    }
    const tracking = await Tracking.query().insert(data).into(Tracking.tableName);
    if (trackingData.awb) {
      await TrackingsAwbLinks.query().insert({
        tracking_id: tracking.id,
        awb_id: trackingData.awb,
      });
    }
    if (trackingData.box) {
      await TrackingsBoxLinks.query().insert({
        tracking_id: tracking.id,
        box_id: trackingData.box,
      });
    }
    if (trackingData.business_partner) {
      await TrackingBusinessPartnerLink.query().insert({
        tracking_id: tracking.id,
        business_partner_id: trackingData.business_partner,
      });
    }
    if (trackingData.trackingType) {
      await TrackingsTrackingTypeLinks.query().insert({
        tracking_id: tracking.id,
        tracking_type_id: trackingData.trackingType,
      });
    }
    if (trackingData.warehouse) {
      await TrackingsWarehouseLinksLink.query().insert({
        tracking_id: tracking.id,
        warehouse_id: trackingData.warehouse,
      });
    }
    if (trackingData.warehouseVn) {
      await TrackingsWarehouseVnLinksLink.query().insert({
        tracking_id: tracking.id,
        warehouse_config_id: trackingData.warehouseVn,
      });
    }
    if (trackingData.customer) {
      const user: Users = await Users.query()
        .where('type', 'customer')
        .where('blocked', false)
        .withGraphFetched('customer')
        .findById(trackingData.customer);

      if (user && user.customer) {
        const customerId = user.customer?.id;
        await TrackingCustomerLinks.query().insert({
          tracking_id: tracking.id,
          customer_id: customerId,
        });
        const sale: CustomerSaleLinks = await CustomerSaleLinks.query().select().where('customer_id', customerId).first();
        if (sale && sale.userId)
          await TrackingSaleLinks.query().insert({
            tracking_id: tracking.id,
            user_id: sale.userId,
          });
      }
    }
    const newTracking = await Tracking.query()
      .findById(tracking.id)
      .withGraphFetched('awb')
      .withGraphFetched('box')
      .withGraphFetched('trackingType')
      .withGraphFetched('customer')
      .withGraphFetched('businessPartner')
      .withGraphFetched('warehouse')
      .withGraphFetched('warehouseVn')
      .withGraphFetched('exploitedBy')
      .withGraphFetched('deliveryBill')
      .withGraphFetched('sale');
    if (newTracking.customer[0]) {
      newTracking.sale = newTracking.customer[0]?.sale ? newTracking.customer[0]?.sale[0] : null;
      delete newTracking.customer[0]?.sale;
    }
    // create backlog
    await TrackingLogs.query()
      .insert({
        trackingCode: tracking.code,
        actionType: 'entry.createTracking',
        actionTime: new Date(),
        extraData: JSON.stringify({
          ...newTracking,
          box: newTracking.box[0] || null,
          awb: newTracking.awb[0] || null,
          businessPartner: newTracking.businessPartner[0] || null,
          warehouse: newTracking.warehouse[0] || null,
          warehouseVn: newTracking.warehouseVn[0] || null,
          exploitedBy: newTracking.exploitedBy[0] || null,
          deliveryBill: newTracking.deliveryBill[0] || null,
          customer: newTracking.customer[0] || null,
          trackingType: newTracking.trackingType[0] || null,
        }),
        createdAt: new Date(),
        updatedAt: new Date(),
        trackingId: tracking.id,
        createdById: user?.id,
      })
      .into('tracking_logs');

    return {
      ...newTracking,
      box: newTracking.box[0] || null,
      awb: newTracking.awb[0] || null,
      businessPartner: newTracking.businessPartner[0] || null,
      warehouse: newTracking.warehouse[0] || null,
      warehouseVn: newTracking.warehouseVn[0] || null,
      exploitedBy: newTracking.exploitedBy[0] || null,
      deliveryBill: newTracking.deliveryBill[0] || null,
      customer: newTracking.customer[0] || null,
      trackingType: newTracking.trackingType[0] || null,
    };
  };

  public addOrderId = async (trackingId, user) => {
    const tracking = await Tracking.query().findById(trackingId);
    if (!tracking) {
      throw new BadRequestException('Tracking is not found');
    }

    const { code } = await generateNextOrderId();
    await Tracking.query()
      .patch({
        orderId: code,
      })
      .where('id', trackingId);

    const updatedTracking = await Tracking.query()
      .findById(trackingId)
      .withGraphFetched('awb')
      .withGraphFetched('box')
      .withGraphFetched('trackingType')
      .withGraphFetched('customer')
      .withGraphFetched('businessPartner')
      .withGraphFetched('warehouse')
      .withGraphFetched('warehouseVn')
      .withGraphFetched('exploitedBy')
      .withGraphFetched('deliveryBill')
      .withGraphFetched('sale');

    if (updatedTracking.customer[0]) {
      updatedTracking.sale = updatedTracking.customer[0]?.sale ? updatedTracking.customer[0]?.sale[0] : null;
      delete updatedTracking.customer[0]?.sale;
    }
    // create backlog
    await TrackingLogs.query()
      .insert({
        trackingCode: tracking.code,
        actionType: 'entry.createOrder',
        actionTime: new Date(),
        extraData: JSON.stringify({
          ...updatedTracking,
          box: updatedTracking.box[0] || null,
          awb: updatedTracking.awb[0] || null,
          businessPartner: updatedTracking.businessPartner[0] || null,
          warehouse: updatedTracking.warehouse[0] || null,
          warehouseVn: updatedTracking.warehouseVn[0] || null,
          exploitedBy: updatedTracking.exploitedBy[0] || null,
          deliveryBill: updatedTracking.deliveryBill[0] || null,
          customer: updatedTracking.customer[0] || null,
          trackingType: updatedTracking.trackingType[0] || null,
        }),
        createdAt: new Date(),
        updatedAt: new Date(),
        trackingId: trackingId,
        createdById: user?.id,
      })
      .into('tracking_logs');

    return {
      ...updatedTracking,
      box: updatedTracking.box[0] || null,
      awb: updatedTracking.awb[0] || null,
      businessPartner: updatedTracking.businessPartner[0] || null,
      warehouse: updatedTracking.warehouse[0] || null,
      warehouseVn: updatedTracking.warehouseVn[0] || null,
      exploitedBy: updatedTracking.exploitedBy[0] || null,
      deliveryBill: updatedTracking.deliveryBill[0] || null,
      customer: updatedTracking.customer[0] || null,
      trackingType: updatedTracking.trackingType[0] || null,
    };
  };

  public sendCheckRequest = async (trackingId, message) => {
    const toCheckTracking = await Tracking.query().findById(trackingId);
    if (!toCheckTracking || !toCheckTracking.whTrackingId) {
      throw new HttpException(404, 'Not found tracking or cannot find wh_tracking_id of it!');
    }
    const { data: responseBody } = await sendCreateTicketRequest(toCheckTracking.whTrackingId, message);
    if (responseBody && responseBody.id) {
      await Tracking.query()
        .patch({ ticketResponse: `Đã gửi-[${new Date()}]-Đang chờ xử lí` })
        .where('id', trackingId);
    }
    return responseBody;
  };

  public findWarehouseTracking = async (partnerUID, params) => {
    // FE doesn't call
    const { keywords, page = 1, pageSize = 10 } = params;
    if (isEmpty(keywords)) throw new HttpException(400, 'keywords is empty');
    const code = keywords.split(',') || [keywords];

    const queryCode = code.map(c => ({
      code: {
        $endsWith: c.trim(),
      },
    }));

    const apiUrl: string = WAREHOUSE_API_URL || '';
    const apiToken: string = WAREHOUSE_API_TOKEN || '';

    const query = {
      populate: ['tracking_type', 'warehouse', 'box', 'warehouse', 'awb', 'business_partner'],
      filters: {
        $or: queryCode,
        business_partner: {
          uid: {
            $eq: partnerUID,
          },
        },
      },
      pagination: {
        pageSize,
        page,
      },
    };
    const { data } = await axios.get(apiUrl + '/api/trackings?' + qs.stringify(query), {
      headers: {
        Authorization: `Bearer ${apiToken}`,
      },
    });
    return {
      data: data.data,
      pagination: data.meta.pagination,
    };
  };

  public async getTrackingByCustomer(id: number, params: any) {
    const { page = 0, pageSize = 10 } = params;

    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }
    const listTracking = await Tracking.query()
      .select('trackings.*')
      .join('trackings_customer_links', 'trackings.id', '=', 'trackings_customer_links.tracking_id')
      .where('trackings_customer_links.customer_id', id)
      .withGraphFetched('customer')
      .withGraphFetched('awb')
      .withGraphFetched('box')
      .withGraphFetched('businessPartner')
      .withGraphFetched('warehouse')
      .withGraphFetched('warehouseVn')
      .withGraphFetched('exploitedBy')
      .withGraphFetched('deliveryBill')
      .page(pageIndex, pageSize);
    const { results, total } = listTracking;

    return {
      pagination: {
        page: Number(pageIndex) + 1,
        pageSize,
        total,
        totalPage: Math.ceil(total / pageSize),
      },
      data: results.map(tr => ({
        ...tr,
        box: tr.box[0] || null,
        awb: tr.awb[0] || null,
        businessPartner: tr.businessPartner[0] || null,
        warehouse: tr.warehouse[0] || null,
        warehouseVn: tr.warehouseVn[0] || null,
        exploitedBy: tr.exploitedBy[0] || null,
        deliveryBill: tr.deliveryBill[0] || null,
        customer: tr.customer[0] || null,
      })) as any,
    };
  }

  public getTrackingType = async () => {
    const res = await TrackingType.query().select();
    return {
      data: res.map(item => item),
    };
  };

  public syncTracking = async businessPartnerId => {
    try {
      const codes = (await Tracking.query().select('id', 'code').whereNot('status', 'Hoàn thành')).map(tr => tr.code);
      const processedTrackings = [];
      if (codes.length > 0) {
        const chunkSize = 100;
        for (let i = 0; i < codes.length; i += chunkSize) {
          const chunk = codes.slice(i, i + chunkSize);
          const { data: trackingDataFromWarehouse } = await getListTrackings(1, { trackingCodes: chunk });
          await Promise.all(
            trackingDataFromWarehouse.rows.map(async tr => {
              delete tr.note;
              delete tr.order_id;
              delete tr.isSynced;
              delete tr.business_partner;
              delete tr.businessPartner;
              if (!processedTrackings.includes(tr.code)) {
                await Tracking.query()
                  .patch({ status: tr.status, whTrackingId: tr.id })
                  .where('code', tr.code.trim())
                  .orWhereLike('code', `%${tr.code?.slice(-8)}`);
                processedTrackings.push(tr.code);
              }
            }),
          );
        }
      }
    } catch (e) {
      throw new BadRequestException(e.message);
    }
  };

  public async hookUpdateTrackingTicketResponse(warehouseTrackingId: string, ticketResponseMessage: string) {
    const tracking = await Tracking.query()
      .patch({ ticketResponse: `Đã phản hồi-[${new Date()}]-${ticketResponseMessage}` })
      .where('wh_tracking_id', warehouseTrackingId)
      .first();
    if (!tracking) {
      throw new BadRequestException('Cannot find corresponding tracking');
    }
    return tracking;
  }

  public async hookUpdateWhTrackingStatus(warehouseTrackingId: string, status: string) {
    const tracking = await Tracking.query().patch({ status }).where('wh_tracking_id', warehouseTrackingId).first();
    if (!tracking) {
      throw new BadRequestException('Cannot find corresponding tracking');
    }
    return tracking;
  }

  private async sendTrackingStatusPushNotification(userId: number, trackingCode: string, newStatus: string, prefix: string) {
    await this.fcmPushNotificationService.sendNotificationToGroupOfUser(
      [userId],
      `[DP Cargo]-Thông báo`,
      `${prefix} Tracking ${trackingCode} đã được cập nhật với trạng thái mới : ${newStatus}`,
    );
  }
}

export default TrackingService;
