import { hash, compare } from 'bcrypt';
import { sign, verify } from 'jsonwebtoken';
import { REFRESH_TOKEN_PRIVATE_KEY, SECRET_KEY } from '@config';
import { HttpException } from '@exceptions/HttpException';
import { DataStoredInToken, LoginData, TokenData } from '@interfaces/auth.interface';
import { User } from '@interfaces/users.interface';
import { Users } from '@models/users.model';
import { isEmpty } from '@utils/util';
import { CreateUserDto } from '@/dtos/users.dto';
import BadRequestException from '@/exceptions/BadRequestException';
import { ChangePasswordDto } from '@/dtos/change-password.dto';
import { UpUsers } from '@/models/upUsers.model';
import { UpUsersBusinessPartnerLinks } from '@/models/upUsersBusinessPartnerLinks.model';
import { UpUsersRoleLinks } from '@/models/upUsersRoleLinks.model';
import { UpUsersWarehouseVnLinks } from '@/models/upUsersWarehouseVnLinks.model';
import { UserRoleLinks } from '@/models/userRoleLinks.model';
import { Customer } from '@/models/customer.model.';
import { UserCustomerLinks } from '@/models/userCustomerLinks.model';
import { v4 as uuidv4 } from 'uuid';
import SetNewPasswordDto from '@/dtos/set-new-password.dto';
import { Mailer } from '@/helper/mailer';
class AuthService {
  public async signup(userData: CreateUserDto): Promise<User> {
    if (isEmpty(userData)) throw new HttpException(400, 'userData is empty');

    const findUser: Users = await Users.query().select().from('up_users').whereILike('email', '=', userData.email).first();
    if (findUser) throw new HttpException(409, `This email ${userData.email} already exists`);

    const hashedPassword = await hash(userData.password, 10);
    const createUserData: User = await Users.query()
      .insert({ ...userData, email: userData.email.toLowerCase(), password: hashedPassword })
      .into('up_users');
    return createUserData;
  }

  public async signUpCustomer(userData: CreateUserDto): Promise<User> {
    if (isEmpty(userData)) throw new HttpException(400, 'userData is empty');

    const findUser: Users = await Users.query().select().from('up_users').whereILike('email', '=', userData.email).first();
    if (findUser) throw new HttpException(409, `This email ${userData.email} already exists`);

    const hashedPassword = await hash(userData.password, 10);
    const createUserData: User = await Users.query()
      .insert({ ...userData, email: userData.email.toLowerCase(), password: hashedPassword, type: 'customer', blocked: false })
      .into('up_users');
    //TODO pricing config
    const customer = await Customer.query().insert({ email: userData.email, shippingCost: 1 }).into('customers');
    await UserCustomerLinks.query()
      .insert({
        customer_id: customer.id,
        user_id: createUserData.id,
      })
      .into(UserCustomerLinks.tableName);
    await UserRoleLinks.query().insert({
      user_id: createUserData.id,
      role_id: 3,
    });

    const createdCustomer: any = Users.query().select().withGraphFetched('customer').where('up_users.id', createUserData.id).first();
    return createdCustomer;
  }

  public async login(userData: CreateUserDto): Promise<{ cookie: string; loginData }> {
    if (isEmpty(userData)) throw new HttpException(400, 'userData is empty');
    const email = (userData.username || userData.email).toLowerCase();

    const findUser: any = await Users.query()
      .leftJoinRelated('businessPartner')
      .withGraphFetched('customer')
      .withGraphFetched('warehouseVN')
      .withGraphFetched('role')
      .modifyGraph('role', builder => builder.withGraphFetched('actions'))
      .where('up_users.email', '=', email)
      .andWhere('up_users.blocked', false)
      .first();
    if (!findUser) throw new HttpException(409, `This email ${userData.email} was not found`);
    const isPasswordMatching: boolean = await compare(userData.password, findUser.password);
    if (!isPasswordMatching) throw new HttpException(409, 'Password is not matching');
    const tokenData = this.createToken(findUser);
    const cookie = this.createCookie(tokenData);

    // other user field
    const loginData = {
      token: tokenData.token,
      refreshToken: tokenData.refreshToken,
      expiresIn: tokenData.expiresIn,
      id: findUser.id,
      customerName: findUser.customer[0]?.name,
      fullname: findUser.fullname,
      email: findUser.email,
      businessPartnerId: findUser.businessPartnerId,
      warehouseVN: findUser.warehouseVN[0],
      type: findUser.type,
      role: findUser.role[0]
        ? {
            ...findUser.role[0],
            actions: findUser.role[0].actions?.map(ac => ac.action),
          }
        : null,
    };

    return { cookie, loginData };
  }

  public async changeRole(userId, roleId) {
    await UserRoleLinks.query().delete().where('user_id', userId);
    await UserRoleLinks.query()
      .insert({
        user_id: userId,
        role_id: roleId,
      })
      .into(UserRoleLinks.tableName);

    const findUser: any = await Users.query()
      .leftJoinRelated('businessPartner')
      .withGraphFetched('customer')
      .withGraphFetched('warehouseVN')
      .withGraphFetched('role')
      .modifyGraph('role', builder => builder.withGraphFetched('actions'))
      .where('up_users.id', userId)
      .first();

    // other user field
    const updatedUser = {
      id: findUser.id,
      customerName: findUser.customer[0]?.name,
      username: findUser.username,
      email: findUser.email,
      businessPartnerId: findUser.businessPartnerId,
      warehouseVN: findUser.warehouseVN[0],
      type: findUser.type,
      role: findUser.role[0]
        ? {
            ...findUser.role[0],
            actions: findUser.role[0].actions?.map(ac => ac.action),
          }
        : null,
    };

    return updatedUser;
  }

  public async resetPassword(userData: User, changePassword: ChangePasswordDto): Promise<{ cookie: string; loginData }> {
    if (isEmpty(userData)) throw new HttpException(400, 'userData is empty');

    const email = userData.email.toLowerCase();

    const findUser: User = await Users.query().select().from('users').where('email', '=', email).first();
    if (!findUser) throw new HttpException(409, `This email ${email} was not found or removed.`);

    const isPasswordMatching: boolean = await compare(changePassword.oldPassword, findUser.password);
    if (!isPasswordMatching) throw new HttpException(409, 'Old password is incorrect!');

    const hashedPassword = await hash(changePassword.newPassword, 10);
    await Users.query()
      .update({
        password: hashedPassword,
      })
      .where('staff_code', '=', userData.id)
      .into('users');

    const updatedUser: User = await Users.query().select().from('users').where('email', '=', email).first();
    if (!findUser) throw new HttpException(409, `This email ${email} was not found or removed.`);

    const tokenData = this.createToken(updatedUser);
    const cookie = this.createCookie(tokenData);

    // other user field
    const loginData = {
      token: tokenData.token,
      refreshToken: tokenData.refreshToken,
      expiresIn: tokenData.expiresIn,
      id: findUser.id,
      customerName: findUser.customerName,
      username: findUser.username,
      email: findUser.email,
      permission: [updatedUser.role],
      menu: [],
    };

    return { cookie, loginData };
  }

  public async resetPasswordRequest(email: string) {
    const findUser = await Users.query().where('email', email.toLowerCase()).withGraphFetched('role').first();
    if (!findUser) {
      throw new HttpException(404, 'Cannot found corresponding email');
    }
    let isCustomer = false;
    if (findUser.role[0].type === 'khach_hang') {
      isCustomer = true;
    }
    const newResetPasswordToken = uuidv4();
    await Users.query().patch({ resetPasswordToken: newResetPasswordToken }).where('email', email);
    await Mailer.resetPassword(email, findUser.fullname || findUser.username || findUser.email, newResetPasswordToken, isCustomer);
  }

  public async verifyResetPasswordToken(resetPasswordToken: string): Promise<void> {
    const findUser: any = await Users.query().where('reset_password_token', resetPasswordToken).first();
    if (!findUser) {
      throw new HttpException(404, 'Cannot found corresponding ResetPasswordToken');
    }
    return;
  }

  public async setNewPassword(setNewPasswordDto: SetNewPasswordDto): Promise<void> {
    const { resetPasswordToken, newPassword } = setNewPasswordDto;
    const findUser: any = await Users.query().where('reset_password_token', resetPasswordToken).first();
    if (!findUser) {
      throw new HttpException(404, 'Cannot found corresponding ResetPasswordToken');
    }
    const hashedPassword = await hash(newPassword, 10);
    await Users.query().patch({ resetPasswordToken: uuidv4(), password: hashedPassword }).where('reset_password_token', resetPasswordToken);
    return;
  }
  public async changePassword(userId, changePassword: ChangePasswordDto): Promise<{ cookie: string; loginData }> {
    if (isEmpty(userId)) throw new HttpException(400, 'userId is empty');

    const findUser: User = await Users.query().findById(userId);
    if (!findUser) throw new HttpException(409, `User was not found or removed.`);

    const isPasswordMatching: boolean = await compare(changePassword.oldPassword, findUser.password);
    if (!isPasswordMatching) throw new HttpException(409, 'Old password is incorrect!');

    const hashedPassword = await hash(changePassword.newPassword, 10);

    await Users.query()
      .update({
        password: hashedPassword,
      })
      .where('id', userId)
      .into('up_users');

    const updatedUser: any = await Users.query()
      .select('up_users.*', 'customer.id as customerId', 'customer.name as customerName', 'businessPartner.id as businessPartnerId')
      .from('up_users')
      .joinRelated('businessPartner')
      .joinRelated('customer')
      .where('up_users.id', userId)
      .first();
    if (!updatedUser) throw new HttpException(409, `This user was not found or removed.`);

    const tokenData = this.createToken(updatedUser);
    const cookie = this.createCookie(tokenData);

    const loginData = {
      token: tokenData.token,
      refreshToken: tokenData.refreshToken,
      expiresIn: tokenData.expiresIn,
      id: findUser.id,
      customerName: findUser.customerName,
      username: findUser.username,
      email: findUser.email,
      menu: [],
      businessPartnerId: findUser.businessPartnerId,
    };

    return { cookie, loginData };
  }

  public async logout(userData: User, accessToken: string): Promise<User> {
    if (isEmpty(userData)) throw new HttpException(400, 'userData is empty');

    const findUser: User = await Users.query()
      .select()
      .from('up_users')
      .where('email', '=', userData.email)
      .andWhere('password', '=', userData.password)
      .first();

    if (!findUser) throw new HttpException(409, "User doesn't exist");

    return findUser;
  }

  public createToken(user: User): TokenData {
    const dataStoredInToken: DataStoredInToken = {
      id: user.id,
      email: user.email,
      warehouseVN: !user.warehouseVN || user.warehouseVN?.length === 0 ? null : { id: user.warehouseVN[0].id, label: user.warehouseVN[0].name },
    };
    if (user.customerId) {
      dataStoredInToken.customerId = user.customerId;
    }
    const secretKey: string = SECRET_KEY;
    const refreshTokenSecretKey = REFRESH_TOKEN_PRIVATE_KEY;

    const expiresIn: number = 60 * 60;

    return {
      expiresIn,
      token: sign(dataStoredInToken, secretKey, { expiresIn }),
      refreshToken: sign(dataStoredInToken, refreshTokenSecretKey, { expiresIn: 2400 * expiresIn }),
    };
  }

  public async createAccountPartner(user: any) {
    const ALLOWS_KEY = ['businessPartnerId', 'confirmPassword', 'confirmed', 'email', 'password', 'phone', 'role', 'type', 'username', 'warehouseVn'];
    // const addUser = {
    //   business_partner: model.value.bPartner.id,
    //   confirmPassword: "12345678",
    //   confirmed: true,
    //   email: model.value.email,
    //   password: model.value.password,
    //   phone: model.value.phone,
    //   role: model.value.roleRule.id,
    //   type: "partner",
    //   username: model.value.name,
    //   warehouse_vn: model.value.bWHVN
    // }

    const userData = { ...user } as any;

    Object.keys(userData).map(key => {
      if (!ALLOWS_KEY.includes(key)) {
        delete userData[key];
      }
    });

    // const hashedPassword = await hash(userData.password, 10);
    // const createUserData: UpUsers = await UpUsers.query()
    //   .insert({ ...userData, password: hashedPassword })
    //   .into('up_users');

    const userId = 1; // TODO
    // - Thêm liên kết up_users_business_partner_links
    const queryBuilderUUBPLLinks = UpUsersBusinessPartnerLinks.query().from('up_users_business_partner_links');
    await queryBuilderUUBPLLinks.insert({ user_id: userId, business_partner_id: userData.businessPartnerId }).into('up_users_business_partner_links');
    // - Thêm liên kết up_users_role_links
    const queryBuilderUURLLinks = UpUsersRoleLinks.query().from('up_users_role_links');
    await queryBuilderUURLLinks.insert({ user_id: userId, role_id: userData.role }).into('up_users_role_links');
    // - Thêm liên kết up_users_warehouse_vn_links
    const queryBuilderUUWVNLinks = UpUsersWarehouseVnLinks.query().from('up_users_warehouse_vn_links');
    await queryBuilderUUWVNLinks.insert({ user_id: userId, warehouse_config_id: userData.warehouseVn }).into('up_users_warehouse_vn_links');

    return true;
    // return createUserData;
  }

  public createCookie(tokenData: TokenData): string {
    return `Authorization=${tokenData.token}; HttpOnly; Max-Age=${tokenData.expiresIn};`;
  }

  public async verifyRefreshToken(refreshToken: string) {
    const privateKey = REFRESH_TOKEN_PRIVATE_KEY;

    if (!privateKey) {
      throw new BadRequestException('Invalid refresh token');
    }

    try {
      const { id } = verify(refreshToken, REFRESH_TOKEN_PRIVATE_KEY) as DataStoredInToken;
      return id;
    } catch {
      throw new BadRequestException('Invalid refresh token');
    }
  }
}

export default AuthService;
