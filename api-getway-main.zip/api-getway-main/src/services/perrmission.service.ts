import BadRequestException from '@/exceptions/BadRequestException';
import { Permission } from '@/models/permission.model';
class PermissionService {
  static getInstant(): PermissionService {
    return new PermissionService();
  }

  public async list() {
    return await Permission.query().orderBy('id', 'ASC');
  }

  public async create(body) {
    const { action } = body;
    if (!action) {
      throw new BadRequestException('Action is required');
    }
    const isExist = await Permission.query().where('action', action).first();
    if (isExist) {
      throw new BadRequestException(`Action ${action} is exist`);
    }

    const acRes = await Permission.query()
      .insert({
        action,
      })
      .into(Permission.tableName);
    const newAction: any = await Permission.query().findById(acRes.id);
    return newAction;
  }
}

export default PermissionService;
