import { BusinessPartner } from '@/models/businessPartner.model';

class BusinessPartnerService {
  static getInstant(): BusinessPartnerService {
    return new BusinessPartnerService();
  }

  public async getAllPartner() {
    const res = await BusinessPartner.query().select();
    return res;
  }
}

export default BusinessPartnerService;
