import { VnDeliveryOrders, VnDeliveryOrderStatus } from '@/models/vnDeliveryOrder.model';
import { HttpException } from '@exceptions/HttpException';
import BadRequestException from '@/exceptions/BadRequestException';
import CreateVnDeliveryOrderDto from '@/dtos/createVnDeliveryOrder.dto';
import { RequestWithUser } from '@/interfaces/auth.interface';
import Objection from 'objection';
import DeliveryBillsService from './deliveryBills.service';
import VnDeliveryBoxesCommonService from './vnDeliveryBoxCommon.service';
import { generateRandomString } from '@/utils/util';

class VnDeliveryOrdersService {
  private readonly deliveryBoxCommonService = new VnDeliveryBoxesCommonService();
  private readonly deliveryBillService = new DeliveryBillsService();

  static getInstant(): VnDeliveryOrdersService {
    return new VnDeliveryOrdersService();
  }

  private async vDOAdditionalFilterByPermissionBusinessLogic(
    req: RequestWithUser,
    queryBuilder: Objection.QueryBuilder<VnDeliveryOrders, VnDeliveryOrders[]>,
    user,
  ) {
    if (req.permission_business_logic) {
      switch (req.permission_business_logic) {
        case 1:
          break;
        case 2:
          queryBuilder.whereExists(function () {
            this.select('*')
              .from('delivery_bills')
              .whereRaw('vn_delivery_orders.delivery_bill_id = delivery_bills.id')
              .innerJoin('delivery_bills_customer_links', 'delivery_bills_customer_links.delivery_bill_id', '=', 'delivery_bills.id')
              .innerJoin('customers', 'customers.id', '=', 'delivery_bills_customer_links.customer_id')
              .innerJoin('customers_sale_links', 'customers_sale_links.customer_id', '=', 'customers.id')
              .where('customers_sale_links.user_id', user.id);
          });
          break;
        case 3:
          queryBuilder.whereExists(function () {
            this.select('*')
              .from('delivery_bills')
              .whereRaw('vn_delivery_orders.delivery_bill_id = delivery_bills.id')
              .innerJoin('trackings_delivery_bill_links', 'trackings_delivery_bill_links.delivery_bill_id', '=', 'delivery_bills.id')
              .innerJoin('trackings', 'trackings.id', '=', 'trackings_delivery_bill_links.tracking_id')
              .innerJoin('trackings_warehouse_vn_links', 'trackings.id', '=', 'trackings_warehouse_vn_links.tracking_id')
              .where('trackings_warehouse_vn_links.warehouse_config_id', user.warehouseVN[0].id);
          });
          break;
        case 4:
          queryBuilder.whereExists(function () {
            this.select('*')
              .from('delivery_bills')
              .whereRaw('vn_delivery_orders.delivery_bill_id = delivery_bills.id')
              .innerJoin('delivery_bills_customer_links', 'delivery_bills_customer_links.delivery_bill_id', '=', 'delivery_bills.id')
              .innerJoin('customers', 'customers.id', '=', 'delivery_bills_customer_links.customer_id')
              .innerJoin('customers_service_staff_links', 'customers_service_staff_links.customer_id', '=', 'customers.id')
              .where('customers_service_staff_links.user_id', user.id);
          });
          break;
        case 5:
          queryBuilder.whereExists(function () {
            this.select('*')
              .from('delivery_bills')
              .whereRaw('vn_delivery_orders.delivery_bill_id = delivery_bills.id')
              .innerJoin('delivery_bills_customer_links', 'delivery_bills_customer_links.delivery_bill_id', '=', 'delivery_bills.id')
              .where('delivery_bills_customer_links.customer_id', user.customer.id);
          });
          break;
        default:
          break;
      }
    }
  }

  public async getVnDeliveryOrders(req, param) {
    const { deliveryBillId, deliveryUnitId, code, status, page = 1, pageSize = 10, isDeleted } = param;
    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }
    let queryBuilder;

    queryBuilder = VnDeliveryOrders.query()
      .withGraphFetched('vnDeliveryUnit')
      .withGraphFetched('vnDeliveryBoxes')
      .withGraphFetched('vnDeliveryBill')
      .modifyGraph('vnDeliveryBill', builder => builder.withGraphFetched('tracking'))
      .orderBy('vn_delivery_orders.id', 'desc');
    if (req.permission_business_logic) {
      this.vDOAdditionalFilterByPermissionBusinessLogic(req, queryBuilder, req.user);
    }

    if (code) {
      queryBuilder.whereILike('code', `%${code}%`);
    }
    if (deliveryBillId) {
      queryBuilder.where('delivery_bill_id', deliveryBillId);
    }
    if (deliveryUnitId) {
      queryBuilder.where('vn_delivery_unit_id', deliveryUnitId);
    }

    if (status) {
      queryBuilder.where('status', Number(status));
    }
    const listVnDeliveryOrders = await queryBuilder.page(pageIndex, pageSize);
    if (!listVnDeliveryOrders) throw new HttpException(404, "VnDeliveryOrders doesn't exist");
    const { results, total } = listVnDeliveryOrders;
    return {
      meta: {
        page: Number(pageIndex) + 1,
        pageSize,
        total,
        totalPage: Math.ceil(total / pageSize),
      },
      data: results,
    };
  }

  public async getVnDeliveryOrdersDetail(id) {
    const vnDeliveryOrders = await VnDeliveryOrders.query()
      .withGraphFetched('vnDeliveryUnit')
      .withGraphFetched('vnDeliveryBoxes')
      .modifyGraph('vnDeliveryBoxes', builder => builder.withGraphFetched('deliveredBy'))
      .withGraphFetched('vnDeliveryBill')
      .findById(id);
    if (vnDeliveryOrders.status === VnDeliveryOrderStatus.DELETED) {
      throw new HttpException(404, "VnDeliveryOrders doesn't exist");
    }
    return vnDeliveryOrders;
  }

  public async getVnDeliveryOrdersStatus() {
    return [
      {
        id: 0,
        name: 'Mã mới tạo',
      },
      {
        id: 1,
        name: 'Đang giao hàng',
      },
      { id: 2, name: 'Giao thành công' },
      { id: 3, name: 'Giao thất bại' },
      { id: 4, name: 'Đã hủy bỏ' },
    ];
  }

  public async create(req, createVnDeliveryOrderDto: CreateVnDeliveryOrderDto) {
    const { deliveryBillId, quantity, deliveryUnitId } = createVnDeliveryOrderDto;
    let { code } = createVnDeliveryOrderDto;
    if (!deliveryUnitId) {
      throw new BadRequestException('delivery_unit_id is required');
    }
    await this.deliveryBillService.findDeliveryBillById(req, req.user, deliveryBillId);
    const insertData: any = {};

    if (code) {
      code = code.toUpperCase();
      while ((await VnDeliveryOrders.query().whereILike('code', code)).length !== 0) {
        code = generateRandomString(12).toUpperCase();
      }
      if (!/^[A-Z0-9]{10,15}$/.test(code)) {
        throw new BadRequestException('Bad order code');
      }
      insertData.code = code;
    }
    if (quantity < 1) {
      throw new BadRequestException('Quantity must >= 1');
    }
    if (quantity) {
      insertData.quantity = quantity;
    }
    if (deliveryUnitId) {
      insertData.vn_delivery_unit_id = deliveryUnitId;
    }
    if (deliveryBillId) {
      insertData.delivery_bill_id = deliveryBillId;
    }

    insertData.status = VnDeliveryOrderStatus.NEWLYCREATED;
    const vnDeliveryOrders = await VnDeliveryOrders.query().insert(insertData).into('vn_delivery_orders');

    const newVnDeliveryOrders: any = await VnDeliveryOrders.query().findById(vnDeliveryOrders.id);
    if (quantity === 1) {
      await this.deliveryBoxCommonService.create({ deliveryOrderId: newVnDeliveryOrders.id, code: `${code}` });
    }
    if (quantity > 1) {
      for (let i = 0; i < quantity; i++) {
        await this.deliveryBoxCommonService.create({ deliveryOrderId: newVnDeliveryOrders.id, code: `${code}_${i + 1}` });
      }
    }
    return newVnDeliveryOrders;
  }

  public async update(vnDeliveryOrdersId, createVnDeliveryOrderDto: CreateVnDeliveryOrderDto) {
    const { deliveryBillId, quantity, deliveryUnitId } = createVnDeliveryOrderDto;
    if (!vnDeliveryOrdersId) {
      throw new BadRequestException('vnDeliveryOrderId is required');
    }
    const toUpdateDeliveryOrder: any = await this.getVnDeliveryOrdersDetail(vnDeliveryOrdersId);
    if (toUpdateDeliveryOrder.status !== VnDeliveryOrderStatus.NEWLYCREATED) {
      throw new BadRequestException('Can only update newlyCreated vnDeliveryOrder');
    }
    let vnDeliveryOrdersData: any = {};
    if (quantity < 1) {
      throw new BadRequestException('Quantity must >= 1');
    }
    if (quantity) {
      vnDeliveryOrdersData.quantity = quantity;
      await this.deliveryBoxCommonService.deleteByDeliveryOrderId(toUpdateDeliveryOrder.id);
      if (quantity === 1) {
        await this.deliveryBoxCommonService.create({ deliveryOrderId: toUpdateDeliveryOrder.id, code: `${toUpdateDeliveryOrder.code}` });
      } else {
        for (let i = 0; i < quantity; i++) {
          await this.deliveryBoxCommonService.create({ deliveryOrderId: toUpdateDeliveryOrder.id, code: `${toUpdateDeliveryOrder.code}_${i + 1}` });
        }
      }
    }
    if (deliveryUnitId) {
      vnDeliveryOrdersData.vn_delivery_unit_id = deliveryUnitId;
    }
    if (deliveryBillId) {
      vnDeliveryOrdersData.delivery_bill_id = deliveryBillId;
    }

    await VnDeliveryOrders.query().patch(vnDeliveryOrdersData).where('id', vnDeliveryOrdersId);

    const updateVnDeliveryOrders: any = await VnDeliveryOrders.query().where('id', vnDeliveryOrdersId).first();

    return updateVnDeliveryOrders;
  }

  public async delete(VnDeliveryOrdersId) {
    const vnDeliveryOrders = await VnDeliveryOrders.query().findById(VnDeliveryOrdersId);
    if (vnDeliveryOrders.status === VnDeliveryOrderStatus.DELETED) {
      throw new HttpException(404, 'VnDeliveryOrders has been deleted');
    }
    if (vnDeliveryOrders.status === VnDeliveryOrderStatus.ONDELIVERING || vnDeliveryOrders.status === VnDeliveryOrderStatus.COMPLETED) {
      throw new HttpException(404, 'VnDeliveryOrders cannot be deleted : On delivering or completed');
    }
    await VnDeliveryOrders.query()
      .patch({
        status: VnDeliveryOrderStatus.DELETED,
        deliveryBillId: null,
      })
      .findById(VnDeliveryOrdersId);
    await this.deliveryBoxCommonService.deleteByDeliveryOrderId(VnDeliveryOrdersId);
    return await VnDeliveryOrders.query().findById(VnDeliveryOrdersId);
  }

  public async switchToDelivering(vnDeliveryOrdersId: number) {
    const vnDeliveryOrder: any = await this.getVnDeliveryOrdersDetail(vnDeliveryOrdersId);
    await VnDeliveryOrders.query()
      .patch({
        status: VnDeliveryOrderStatus.ONDELIVERING,
      })
      .findById(vnDeliveryOrdersId);
    if (vnDeliveryOrder.vnDeliveryBill.deliveryBillStatus === 'Đã đóng hàng') {
      await this.deliveryBillService.packBill(vnDeliveryOrder.vnDeliveryBill.id);
    }
  }

  public async switchToCompleted(vnDeliveryOrdersId: number) {
    const vnDeliveryOrder: any = await this.getVnDeliveryOrdersDetail(vnDeliveryOrdersId);
    await VnDeliveryOrders.query()
      .patch({
        status: VnDeliveryOrderStatus.COMPLETED,
      })
      .findById(vnDeliveryOrdersId);
    if (
      (
        await VnDeliveryOrders.query()
          .joinRelated('vnDeliveryBill')
          .where('deliveryBillId', vnDeliveryOrder.deliveryBillId)
          .whereIn('status', [VnDeliveryOrderStatus.NEWLYCREATED, VnDeliveryOrderStatus.ONDELIVERING, VnDeliveryOrderStatus.FAILED])
      ).length === 0
    )
      await this.deliveryBillService.finishBill(vnDeliveryOrder.vnDeliveryBill.id);
  }

  public async switchToFailed(req, vnDeliveryOrdersId: number) {
    const vnDeliveryOrder: any = await this.getVnDeliveryOrdersDetail(vnDeliveryOrdersId);
    await VnDeliveryOrders.query()
      .patch({
        status: VnDeliveryOrderStatus.FAILED,
      })
      .findById(vnDeliveryOrdersId);
    if (
      (
        await VnDeliveryOrders.query()
          .joinRelated('vnDeliveryBill')
          .where('deliveryBillId', vnDeliveryOrder.deliveryBillId)
          .whereIn('status', [VnDeliveryOrderStatus.NEWLYCREATED, VnDeliveryOrderStatus.ONDELIVERING, VnDeliveryOrderStatus.COMPLETED])
      ).length === 0
    )
      await this.deliveryBillService.failedBill(req, vnDeliveryOrder.vnDeliveryBill.id);
  }

  public async assignShipperToADeliveryOrder(vnDeliveryOrdersId, body?) {
    const { deliveredById } = body;
    if (!deliveredById) throw new BadRequestException('Shipper Id is required!');
    const vnDeliveryOrder: any = await VnDeliveryOrders.query().findById(vnDeliveryOrdersId).withGraphFetched('vnDeliveryBoxes');
    if (!vnDeliveryOrder) {
      throw new BadRequestException('This order is not found!');
    }
    await this.deliveryBoxCommonService.assignShipperToBoxes(deliveredById, { ids: vnDeliveryOrder.vnDeliveryBoxes.map(box => box.id) });
  }
}

export default VnDeliveryOrdersService;
