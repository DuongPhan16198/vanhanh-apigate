import { VnDeliveryUnits, VnDeliveryUnitStatus } from '@/models/vnDeliveryUnit.model';
import { HttpException } from '@exceptions/HttpException';
import BadRequestException from '@/exceptions/BadRequestException';
import CreateVnDeliveryUnitDto from '@/dtos/createVnDeliveryUnit.dto';

class VnDeliveryUnitsService {
  static getInstant(): VnDeliveryUnitsService {
    return new VnDeliveryUnitsService();
  }

  public async getVnDeliveryUnits(param) {
    const { name, code, page = 1, pageSize = 10, status } = param;
    let pageIndex = 0;
    if (page) {
      pageIndex = page - 1;
    }
    let queryBuilder;

    queryBuilder = VnDeliveryUnits.query();

    if (name) {
      queryBuilder.whereILike('name', `%${name}%`);
    }
    if (code) {
      queryBuilder.whereILike('code', `%${code}%`);
    }
    if (status) {
      queryBuilder.where('status', status);
    }

    const listVnDeliveryUnits = await queryBuilder.page(pageIndex, pageSize);
    if (!listVnDeliveryUnits) throw new HttpException(404, "VnDeliveryUnits doesn't exist");
    const { results, total } = listVnDeliveryUnits;
    return {
      meta: {
        page: Number(pageIndex) + 1,
        pageSize,
        total,
        totalPage: Math.ceil(total / pageSize),
      },
      data: results,
    };
  }

  public async vnDeliveryUnitsDetail(id) {
    const vnDeliveryUnits = await VnDeliveryUnits.query().findById(id);
    if (vnDeliveryUnits.status === VnDeliveryUnitStatus.DELETED) {
      throw new HttpException(404, "VnDeliveryUnits doesn't exist");
    }
    return vnDeliveryUnits;
  }

  public async create(createVnDeliveryUnitDto: CreateVnDeliveryUnitDto) {
    const { name, code, logo_url } = createVnDeliveryUnitDto;
    if (!name) {
      throw new BadRequestException('name is required');
    }

    const insertData: any = {
      name,
    };

    if (code) {
      insertData.code = code;
      if (await VnDeliveryUnits.query().where('code', code).andWhere('status', VnDeliveryUnitStatus.ACTIVE).first()) {
        throw new BadRequestException('This delivery Unit code is already exist');
      }
    }

    if (logo_url) {
      insertData.logo_url = logo_url;
    }

    insertData.status = VnDeliveryUnitStatus.ACTIVE;
    const vnDeliveryUnits = await VnDeliveryUnits.query().insert(insertData).into('vn_delivery_units');

    const newVnDeliveryUnits: any = await VnDeliveryUnits.query().findById(vnDeliveryUnits.id);
    return newVnDeliveryUnits;
  }

  public async update(vnDeliveryUnitsId, createVnDeliveryUnitDto: CreateVnDeliveryUnitDto) {
    const { name, code, logo_url } = createVnDeliveryUnitDto;

    if (!name) {
      throw new BadRequestException('name is required');
    }
    let vnDeliveryUnitsData: any = {};

    if (name) {
      vnDeliveryUnitsData.name = name;
    }

    if (code) {
      vnDeliveryUnitsData.code = code;
      if (
        await VnDeliveryUnits.query().where('code', code).andWhere('status', VnDeliveryUnitStatus.ACTIVE).whereNot('id', vnDeliveryUnitsId).first()
      ) {
        throw new BadRequestException('This delivery Unit code is already exist');
      }
    }

    if (logo_url) {
      vnDeliveryUnitsData.logo_url = logo_url;
    }

    await VnDeliveryUnits.query().patch(vnDeliveryUnitsData).where('id', vnDeliveryUnitsId);

    const updateVnDeliveryUnits: any = await VnDeliveryUnits.query().where('id', vnDeliveryUnitsId).first();

    return updateVnDeliveryUnits;
  }

  public async delete(VnDeliveryUnitsId) {
    const vnDeliveryUnits = await VnDeliveryUnits.query().findById(VnDeliveryUnitsId);
    if (vnDeliveryUnits.status === VnDeliveryUnitStatus.DELETED) {
      throw new HttpException(404, 'VnDeliveryUnits has been deleted');
    }
    await VnDeliveryUnits.query()
      .patch({
        status: VnDeliveryUnitStatus.DELETED,
      })
      .findById(VnDeliveryUnitsId);
    return await VnDeliveryUnits.query().findById(VnDeliveryUnitsId);
  }
}

export default VnDeliveryUnitsService;
