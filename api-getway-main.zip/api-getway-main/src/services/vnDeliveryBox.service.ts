import { VnDeliveryBoxes, VnDeliveryBoxStatus } from '@/models/vnDeliveryBox.model';
import { HttpException } from '@exceptions/HttpException';
import BadRequestException from '@/exceptions/BadRequestException';
import CreateVnDeliveryBoxDto from '@/dtos/createVnDeliveryBox.dto';
import { DeliveryBill } from '@/models/deliveryBill.model';
import DeliveryBillsService from './deliveryBills.service';
import { RequestWithUser } from '@/interfaces/auth.interface';
import Objection from 'objection';
import { VnDeliveryOrderStatus } from '@/models/vnDeliveryOrder.model';
import VnDeliveryOrdersService from './vnDeliveryOrder.service';
import VnDeliveryBoxesCommonService from './vnDeliveryBoxCommon.service';
import getReqPerrmissionBusinessLogic from '@/utils/getReqPerrmissionBusinessLogic';

class VnDeliveryBoxesService {
  static getInstant(): VnDeliveryBoxesService {
    return new VnDeliveryBoxesService();
  }
  private readonly vnDeliveryOrderService = new VnDeliveryOrdersService();
  private readonly vnDeliveryBoxesCommonService = new VnDeliveryBoxesCommonService();

  private async vnDeliveryBoxesAdditionalFilterByPermissionBusinessLogic(
    req: RequestWithUser,
    queryBuilder: Objection.QueryBuilder<VnDeliveryBoxes, VnDeliveryBoxes[]>,
    user,
  ) {
    await getReqPerrmissionBusinessLogic(req, 'api:: GET /api/vn_delivery_boxes');
    if (req.permission_business_logic) {
      switch (req.permission_business_logic) {
        case 1:
          break;
        case 2:
          queryBuilder.andWhere(builder => {
            builder.where('deliveredById', user.id);
          });
          break;
        default:
          break;
      }
    }
  }

  public async getVnDeliveryBoxes(req, param) {
    const { deliveryOrderId, code, status } = param;
    let queryBuilder;

    queryBuilder = VnDeliveryBoxes.query().orderBy('vnDeliveryBoxes.id', 'desc');
    if (code) {
      queryBuilder
        .joinRelated('deliveryBill')
        .andWhere(builder => {
          builder.whereILike('deliveryBill.code', `%${code}%`).orWhere('vnDeliveryBoxes.id.code', code);
        })
        .groupBy('vnDeliveryBoxes.id');
    }
    if (deliveryOrderId) {
      queryBuilder.where('vn_delivery_order_id', deliveryOrderId);
    }
    if (Number(status)) {
      queryBuilder.where('status', Number(status));
    }

    if (req.permission_business_logic) {
      this.vnDeliveryBoxesAdditionalFilterByPermissionBusinessLogic(req, queryBuilder, req.user);
    }

    const listVnDeliveryBoxes = await queryBuilder;
    if (!listVnDeliveryBoxes) throw new HttpException(404, "VnDeliveryBoxes doesn't exist");
    return listVnDeliveryBoxes;
  }

  public async getVnDeliveryBoxesStatus() {
    return [
      {
        id: 0,
        name: 'Mã mới tạo',
      },
      {
        id: 1,
        name: 'Đang giao hàng',
      },
      { id: 2, name: 'Giao thành công' },
      { id: 3, name: 'Giao thất bại' },
      { id: 4, name: 'Đã hủy bỏ' },
    ];
  }

  public async getVnDeliveryBoxesDetail(req, id) {
    const queryBuilder = VnDeliveryBoxes.query().withGraphFetched('vnDeliveryOrder').withGraphFetched('deliveryBill').where('id', id);
    if (req.permission_business_logic) {
      this.vnDeliveryBoxesAdditionalFilterByPermissionBusinessLogic(req, queryBuilder, req.user);
    }
    const vnDeliveryBoxes = await queryBuilder.first();
    if (!vnDeliveryBoxes || vnDeliveryBoxes?.status === VnDeliveryBoxStatus.DELETED) {
      throw new HttpException(404, "VnDeliveryBoxes doesn't exist");
    }
    return vnDeliveryBoxes;
  }

  public async create(createVnDeliveryBoxDto: CreateVnDeliveryBoxDto) {
    return this.vnDeliveryBoxesCommonService.create(createVnDeliveryBoxDto);
  }

  public async receiveBoxes(req, user, body) {
    await getReqPerrmissionBusinessLogic(req, 'api:: GET /api/vn_delivery_boxes');
    const { vnDeliveryBox, ids } = await this.vnDeliveryBoxesCommonService.receiveBoxes(user.id, body, req?.permission_business_logic === 1);
    if (vnDeliveryBox?.some(vnBox => vnBox.vnDeliveryOrder.status === VnDeliveryOrderStatus.NEWLYCREATED)) {
      const uniqueDeliveryOrders: any = [...new Map(vnDeliveryBox.map(box => [box.vnDeliveryOrder.id, box.vnDeliveryOrder])).values()];
      await Promise.all(
        uniqueDeliveryOrders.map(async vnOrder => {
          if (vnOrder.status === VnDeliveryOrderStatus.NEWLYCREATED) await this.vnDeliveryOrderService.switchToDelivering(vnOrder.id);
        }),
      );
    }
    return {
      successReceive: vnDeliveryBox.map(x => x.id),
      failedReceive: ids.filter(item => !vnDeliveryBox.map(x => x.id).includes(item)),
    };
  }

  public async deliverySuccessfulBox(req, body, user) {
    const { ids } = body;

    let vnDeliveryBox: any = VnDeliveryBoxes.query()
      .withGraphFetched('vnDeliveryOrder')
      .withGraphFetched('deliveryBill')
      .whereIn('id', ids)
      .where('status', VnDeliveryBoxStatus.ONDELIVERING);
    if (req) {
      this.vnDeliveryBoxesAdditionalFilterByPermissionBusinessLogic(req, vnDeliveryBox, user);
    }
    vnDeliveryBox = await vnDeliveryBox;
    if (vnDeliveryBox.length === 0) {
      throw new BadRequestException('Box not found!');
    }
    await VnDeliveryBoxes.query()
      .patch({
        deliveredDate: new Date(),
        status: VnDeliveryBoxStatus.COMPLETED,
      })
      .whereIn(
        'id',
        vnDeliveryBox.map(x => x.id),
      );
    const uniqueDeliveryOrders: any = [...new Map(vnDeliveryBox.map(box => [box.vnDeliveryOrder.id, box.vnDeliveryOrder])).values()];
    await Promise.all(
      uniqueDeliveryOrders.map(async vnOrder => {
        if (
          vnOrder.status === VnDeliveryOrderStatus.ONDELIVERING &&
          (
            await VnDeliveryBoxes.query()
              .where('vnDeliveryOrderId', vnOrder.id)
              .whereIn('vnDeliveryBoxes.status', [VnDeliveryBoxStatus.ONDELIVERING, VnDeliveryBoxStatus.NEWLYCREATED])
          ).length === 0
        )
          await this.vnDeliveryOrderService.switchToCompleted(vnOrder.id);
      }),
    );
    return {
      successfulSwitch: vnDeliveryBox.map(x => x.id),
      failedSwitch: ids.filter(item => !vnDeliveryBox.map(x => x.id).includes(item)),
    };
  }

  public async deliveryFailedBox(req, ids, user) {
    console.log(ids);
    let vnDeliveryBox: any = VnDeliveryBoxes.query()
      .withGraphFetched('vnDeliveryOrder')
      .withGraphFetched('deliveryBill')
      .whereIn('id', ids)
      .whereIn('status', [VnDeliveryBoxStatus.ONDELIVERING, VnDeliveryBoxStatus.NEWLYCREATED]);
    if (req) {
      this.vnDeliveryBoxesAdditionalFilterByPermissionBusinessLogic(req, vnDeliveryBox, user);
    }
    vnDeliveryBox = await vnDeliveryBox;
    if (vnDeliveryBox.length === 0) {
      throw new BadRequestException('Box not found!');
    }
    await VnDeliveryBoxes.query()
      .patch({
        status: VnDeliveryBoxStatus.FAILED,
      })
      .whereIn(
        'id',
        vnDeliveryBox.map(x => x.id),
      );
    const uniqueDeliveryOrders: any = [...new Map(vnDeliveryBox.map(box => [box.vnDeliveryOrder.id, box.vnDeliveryOrder])).values()];
    await Promise.all(
      uniqueDeliveryOrders.map(async vnOrder => {
        if (
          vnOrder.status === VnDeliveryOrderStatus.ONDELIVERING &&
          (
            await VnDeliveryBoxes.query()
              .where('vnDeliveryOrderId', vnOrder.id)
              .whereIn('vnDeliveryBoxes.status', [VnDeliveryBoxStatus.ONDELIVERING, VnDeliveryBoxStatus.NEWLYCREATED, VnDeliveryBoxStatus.COMPLETED])
          ).length === 0
        )
          await this.vnDeliveryOrderService.switchToFailed(req, vnOrder.id);
      }),
    );
    return {
      successfulSwitch: vnDeliveryBox.map(x => x.id),
      failedSwitch: ids.filter(item => !vnDeliveryBox.map(x => x.id).includes(item)),
    };
  }

  public async update(req, vnDeliveryBoxesId, body) {
    const { note } = body;
    if (!vnDeliveryBoxesId) {
      throw new BadRequestException('vnDeliveryBoxId is required');
    }
    await this.getVnDeliveryBoxesDetail(req, vnDeliveryBoxesId);
    let vnDeliveryBoxesData: any = {};

    if (note) {
      vnDeliveryBoxesData.note = note;
    }

    await VnDeliveryBoxes.query().patch(vnDeliveryBoxesData).where('id', vnDeliveryBoxesId);

    const updateVnDeliveryBoxes: any = await VnDeliveryBoxes.query().where('id', vnDeliveryBoxesId).first();

    return updateVnDeliveryBoxes;
  }

  public async deleteById(vnDeliveryBoxesId) {
    await VnDeliveryBoxes.query().deleteById(vnDeliveryBoxesId);
  }

  public async deleteByDeliveryOrderId(vnDeliveryOrderId) {
    await this.vnDeliveryBoxesCommonService.deleteByDeliveryOrderId(vnDeliveryOrderId);
  }
}

export default VnDeliveryBoxesService;
