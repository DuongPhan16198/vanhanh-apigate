import BadRequestException from '@/exceptions/BadRequestException';
import { Mailer } from '@/helper/mailer';

class ContactService {
  static getInstant(): ContactService {
    return new ContactService();
  }

  public async submitContact(body) {
    const { email, phoneNumber } = body;
    if (!email || !phoneNumber) {
      throw new BadRequestException('Email and phone_number is required');
    }
    await Mailer.notifyNewContactToAdmin(email, phoneNumber);
  }
}

export default ContactService;
