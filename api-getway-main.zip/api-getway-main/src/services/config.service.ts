import { AllGeneralConfigInterfaces } from '@/constant/general_config.constants';
import BadRequestException from '@/exceptions/BadRequestException';
import { Config } from '@/models/config.model';
import { GeneralConfigs } from '@/models/generalConfig.model';
const KEY_OF_CONFIG_OPEN_FOR_CUSTOMER = ['BANK_ACCOUNT_CONFIG', 'CONTACT_INFORMATION_CONFIG'];
const KEY_OF_CONFIG_OPEN_FOR_PUBLIC = ['CONTACT_INFORMATION_CONFIG'];
class GeneralConfigService {
  static getInstant(): GeneralConfigService {
    return new GeneralConfigService();
  }

  public async getAllConfigsInterface() {
    return AllGeneralConfigInterfaces;
  }

  public async getGeneralConfigs(req, param) {
    const queryBuilder = GeneralConfigs.query();
    let key = param?.key?.split(',') || [];
    if (req?.permission_business_logic) {
      switch (req.permission_business_logic) {
        case 1:
          break;
        case 2:
          if (key.length === 0) key = KEY_OF_CONFIG_OPEN_FOR_CUSTOMER;
          key =
            key.filter(item => KEY_OF_CONFIG_OPEN_FOR_CUSTOMER.includes(item))?.length > 0
              ? key.filter(item => KEY_OF_CONFIG_OPEN_FOR_CUSTOMER.includes(item))
              : [];
          break;
        default:
          break;
      }
    }
    let listRole: any;
    if (key) {
      listRole = await queryBuilder.whereIn('config_key', key).andWhere('isDelete', false).orderBy('id');
    } else {
      listRole = await queryBuilder.where('isDelete', false).orderBy('id');
    }

    const results = listRole.map(rs => {
      return {
        ...rs,
        configValue: JSON.parse(rs.configValue),
      };
    });
    return results;
  }

  public async getPublicGeneralConfigs(param) {
    const queryBuilder = GeneralConfigs.query();
    let key = param?.key?.split(',') || [];

    if (key.length === 0) key = KEY_OF_CONFIG_OPEN_FOR_PUBLIC;
    key =
      key.filter(item => KEY_OF_CONFIG_OPEN_FOR_PUBLIC.includes(item))?.length > 0
        ? key.filter(item => KEY_OF_CONFIG_OPEN_FOR_PUBLIC.includes(item))
        : [];
    let listRole: any;
    if (key) {
      listRole = await queryBuilder.whereIn('config_key', key).andWhere('isDelete', false).orderBy('id');
    } else {
      listRole = await queryBuilder.where('isDelete', false).orderBy('id');
    }

    const results = listRole.map(rs => {
      return {
        ...rs,
        configValue: JSON.parse(rs.configValue),
      };
    });
    return results;
  }

  public async getDetailConfig(id) {
    const config = await GeneralConfigs.query().findById(id);

    return {
      ...config,
      configValue: JSON.parse(config.configValue),
    };
  }

  public async createConfig(body) {
    const { key, value } = body;
    if (!key || !value) {
      throw new BadRequestException('Config key and value is required');
    }

    const generalConfig = await GeneralConfigs.query()
      .insert({
        config_key: key,
        config_value: JSON.stringify(value),
        isDelete: false,
      })
      .into(GeneralConfigs.tableName);
    const newConfig: any = await GeneralConfigs.query().findById(generalConfig.id);
    return newConfig;
  }

  public async getBoxCoefficientConfig() {
    const res = await Config.query().select();
    return res[0];
  }

  public async updateBoxCoefficient(id: number, body: any) {
    await Config.query()
      .update({
        trackingBarrelCoefficient: body.trackingBarrelCoefficient,
      })
      .where('id', id)
      .into('configs');
    return await Config.query().findById(id);
  }

  public async updateConfig(config_id, body) {
    const { key, value } = body;
    if (!key || !value) {
      throw new BadRequestException('Config key and value is required');
    }
    const isExist = await GeneralConfigs.query().where('id', config_id).first();
    if (!isExist) {
      throw new BadRequestException(`Non existent config !`);
    }

    await GeneralConfigs.query()
      .patch({
        config_key: key,
        config_value: JSON.stringify(value),
      })
      .where('id', config_id);
    const updatedConfig: any = await GeneralConfigs.query().findById(config_id);
    return updatedConfig;
  }

  public async deleteConfig(id) {
    const res = await GeneralConfigs.query()
      .patch({
        isDelete: true,
      })
      .where('id', id);
    if (!res) {
      throw new BadRequestException(`id not exist!`);
    }
    return res;
  }
}

export default GeneralConfigService;
