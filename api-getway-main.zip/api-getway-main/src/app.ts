// import initBullWorkers from '@/workers/index';
import { CREDENTIALS, LOG_FORMAT, NODE_ENV, ORIGIN, PORT, TZ } from '@config';
import knex from '@databases';
import { Routes } from '@interfaces/routes.interface';
import errorMiddleware from '@middlewares/error.middleware';
import { logger, stream } from '@utils/logger';
import { json, urlencoded } from 'body-parser';
import compression from 'compression';
import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import hpp from 'hpp';
import morgan from 'morgan';
import { Model } from 'objection';
import swaggerJSDoc from 'swagger-jsdoc';
import { boss } from './config/pgBoss.conf';
import { UsersShape } from './models/users.model';
import methodOverride from 'method-override';
import { randomUUID } from 'crypto';
import { renameTrackingCode } from './cronJobs/renameTrackingCode.cron';

declare module 'express-serve-static-core' {
  interface Request {
    user?: UsersShape;
  }
}
class App {
  public app: express.Application;
  public env: string;
  public port: string | number;
  private bossWorkers: string[];
  public static networkUUID = randomUUID();

  constructor(routes: Routes[]) {
    this.app = express();
    this.env = NODE_ENV || 'development';
    this.port = PORT || 3000;
    process.env.TZ = TZ ?? 'UTC';

    this.connectToDatabase();
    this.initializeMiddlewares();
    this.initializeRoutes(routes);
    this.initializeErrorHandling();
    renameTrackingCode.start();
    setTimeout(() => {
      this.initBossWorkers();
    }, 1000);
  }

  public listen() {
    return this.app.listen(this.port, () => {
      logger.info(`=================================`);
      logger.info(`======= ENV: ${this.env} =======`);
      logger.info(`🚀 App listening on the port ${this.port}`);
      logger.info(`=================================`);
    });
  }

  public getNetworkUUId() {
    return App.networkUUID;
  }

  public getServer() {
    return this.app;
  }

  private connectToDatabase() {
    Model.knex(knex);
  }

  private async initBossWorkers() {
    // this.bossWorkers = (await initBullWorkers(App.networkUUID)) as string[];
    // console.log('Boss workers', this.bossWorkers);
  }

  private initializeMiddlewares() {
    this.app.use(morgan(LOG_FORMAT, { stream }));
    this.app.use(cors({ origin: ORIGIN, credentials: CREDENTIALS }));
    this.app.use(hpp());
    this.app.use(helmet());
    this.app.use(compression());
    this.app.use(json());
    this.app.use(urlencoded({ extended: true }));
    this.app.use(methodOverride());
  }

  private initializeRoutes(routes: Routes[]) {
    routes.forEach(route => {
      this.app.use('/', route.router);
    });
  }

  private initializeErrorHandling() {
    process
      .on('unhandledRejection', (reason, p) => {
        // Use your own logger here
        console.error(reason, 'Unhandled Rejection at Promise', p);
        throw new Error(reason as string);
      })
      .on('uncaughtException', async err => {
        // Use your own logger here
        console.error(err, 'Uncaught Exception thrown');

        await this.killAllWorkers();

        // Optional: Ensure process will stop after this
        process.exit(1);
      });

    this.app.use(errorMiddleware);
  }

  public async killAllWorkers() {
    let count = 0;

    if (!this.bossWorkers) {
      return;
    }

    for await (const _ of this.bossWorkers.map(item => boss.offWork({ id: item }))) {
      count++;
      logger.info(`Kill ${count} workers`);
    }
    await boss.offWork("*");
  }
}

export default App;
