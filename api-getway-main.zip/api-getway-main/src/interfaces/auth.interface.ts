import { Users, UsersShape } from '@/models/users.model';
import { User } from '@interfaces/users.interface';
import { Request } from 'express';

export interface DataStoredInToken {
  id: number;
  email: string;
  warehouseVN: {
    id: number;
    label: string;
  };
  role?: string;
  customerId?: number;
  actions?: string[];
}

export interface TokenData {
  token: string;
  expiresIn: number;
  refreshToken: string;
}

export interface LoginData {
  token: string;
  refreshToken: string;
  expiresIn: number;
  id: number;
  name: string;
  username: string;
  email: string;
  department: string;
  avatar: string;
  status: number;
  telephone: string;
  creatorId: string;
  createTime: number;
  merchantCode: string;
  deleted: number;
  permission: string[];
  menu: any;
}

export interface RequestWithUser extends Request {
  user: any;
  accessToken: string;
  permission_business_logic: number;
}
