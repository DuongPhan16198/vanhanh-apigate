export interface Store {
  storeId: string;
  storeName: string;
  platF: string;
}
