import { Customer } from '@/models/customer.model.';
import { WarehouseConfig } from '@/models/warehouseConfig.model';
import { BusinessPartner } from './businessPartner.interface';

export interface User {
  id: number;
  email: string;
  password: string;
  username: string;
  customerName: string;
  department: string;
  role: any;
  manager: string;
  // stores: Store[];
  isRemove: boolean;
  customerId?: number;
  businessPartnerId?: number;
  customer?: Customer;
  warehouseVN?: WarehouseConfig;
  type: string;
  businessPartner: BusinessPartner;
  balance: number;
  creditAmount: number;
}
