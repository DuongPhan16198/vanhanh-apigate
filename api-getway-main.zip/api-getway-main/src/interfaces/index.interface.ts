export interface SponsoredProductAdsInterface {
  id: string;
  storeName: string;
  market: string;
  date: Date;
  portfolioName: string;
  currency: string;
  campaignName: string;
  adGroupName: string;
  advertisedSku: string;
  advertisedAsin: string;
  impressions: number;
  clicks: number;
  spend: number;
  '7DayTotalSales': number;
  '7DayTotalOrders': number;
  '7DayTotalUnits': number;
  '7DayAdvertisedSkuUnits': number;
  '7DayOtherSkuUnits': number;
  '7DayAdvertisedSkuSales': number;
  '7DayOtherSkuSales': number;
}

export interface SellerSdaApModelInterface {
  id: string;
  storeName: string;
  market: string;
  date: Date;
  currency: string;
  campaignName: string;
  portfolioName: string;
  constType: string;
  adGroupName: string;
  bidOptimization: string;
  advertisedSku: string;
  advertisedAsin: string;
  impressions: number;
  viewableImpressions: number;
  'click-thruRate': number;
  '14DayDetailPageView': number;
  spend: number;
  '14DayTotalOrder': number;
  '14DayTotalSales': number;
  '14DayNew-to-brandOders': number;
  '14DayNew-to-brandSales': number;
  '14DayNew-to-brandUnits': number;
  '14DayNew-to-brandOrdersClick': number;
  '14DayNew-to-brandSalesClick': number;
  '14DayNew-to-branUnitsClick': number;
  '14DayTotalOrdersClick': number;
  '14DayTotalUnitsClick': number;
  '14DayTotalSalesClick': number;
}

export interface SponsoredProductAdsXlsxData {
  Date: number;
  'Portfolio name': string;
  Currency: string;
  'Campaign Name': string;
  'Ad Group Name': string;
  'Advertised SKU': string;
  'Advertised ASIN': string;
  Impressions: number;
  Clicks: number;
  'Click-Thru Rate (CTR)': number;
  Spend: number;
  '7 Day Total Sales ': number;
  '7 Day Total Orders (#)': number;
  '7 Day Total Units (#)': number;
  '7 Day Advertised SKU Units (#)': number;
  '7 Day Other SKU Units (#)': number;
  '7 Day Advertised SKU Sales ': number;
  '7 Day Other SKU Sales ': number;

  storeName: string;
  market: string;
}

export interface PlatformWithStoreResponse {
  platformId: number;
  platformName?: string;
  stores: any;
}
