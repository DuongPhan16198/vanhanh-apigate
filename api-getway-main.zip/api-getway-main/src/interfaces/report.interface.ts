export interface StoresReportStat {
  storeName: string;
  importedStatus: StoreImportStatus[];
  reports: ReportStat[];
}

export interface StoreImportStatus {
  date: string;
  status: string;
}

export interface ReportStat {
  reportName: string;
  importedRecord: ImportedRecordCount[];
}

export interface ImportedRecordCount {
  date: string;
  count: number;
}

export interface ImportedRecordCountPerDay {
  storeName: string;
  reportName: string;
  date: string;
  count: number;
}

export interface Report {
  reportId: string;
  reportName: string;
  reportTable: string;
}

export interface ImportedReportPerDay {
  storeName: string;
  reports: string[];
  date: string;
}

export interface ListReportOfStore {
  storeName: string;
  reports: string[];
}
