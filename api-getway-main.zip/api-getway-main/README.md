
# Project Title

A brief description of what this project does and who it's for


## Environment Variables

To run this project, you will need to add the following environment variables to your .env file

`PG_CONNECTION_STRING`

`SECRET_KEY`


## Run Locally

Clone the project

```bash
  git clone https://link-to-project
```

Go to the project directory

```bash
  cd dpc-api-gateway
```

Install dependencies

```bash
  npm install
```

```bash
  [Optional Docker] Start Posgresql in Docker. SHOULD use ENV file.
  npm run db:start
```

Config ENV local
```
cp .env.development.example .env.development.local
```

Start the server

```bash
  npm run dev
```


## Deployment

To deploy this project run

```bash
  npm run deploy
```


## Running Tests

To run tests, run the following command

```bash
  npm run test
```


## Tech Stack

**Server:** Node.js, Express.js, Typescript, Progresql, Knex.js (ORM)


