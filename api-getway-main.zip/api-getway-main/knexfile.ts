import { NODE_ENV, PG_CONNECTION_STRING } from './src/config';

const dbConfig = {
  client: 'pg',
  connection: PG_CONNECTION_STRING,
  migrations: {
    directory: 'src/databases/migrations',
    tableName: 'migrations',
  },
  seeds: {
    directory: 'src/databases/seeds',
  },
  searchPath: ['dev', 'public'],
  pool: {
    min: 2,
    max: 5,
  },
  debug: NODE_ENV !== 'production',
};

export default dbConfig;
