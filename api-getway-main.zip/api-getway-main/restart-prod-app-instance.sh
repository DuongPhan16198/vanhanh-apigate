#! /bash/sh

cd /home/ubuntu/tcs-report-be
npm run pm2:prod
pm2 list